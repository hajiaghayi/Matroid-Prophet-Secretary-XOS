#!/usr/bin/env python3
"""Reject unproved or unchecked declarations in this project's Lean sources."""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
paths = sorted((root / "MatroidProphet").glob("*.lean"))
paths += [root / "MatroidProphet.lean", root / "Check.lean"]
forbidden = re.compile(r"\b(sorry|admit|axiom|unsafe|native_decide|sorryAx)\b")
errors = []
for path in paths:
    text = path.read_text(encoding="utf-8")
    for match in forbidden.finditer(text):
        line = text.count("\n", 0, match.start()) + 1
        errors.append(f"{path.relative_to(root)}:{line}: {match.group()}")
if errors:
    print("\n".join(errors), file=sys.stderr)
    sys.exit(1)
print(f"Checked {len(paths)} Lean files: no unfinished proofs or custom axioms.")
