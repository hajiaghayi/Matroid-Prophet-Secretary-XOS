#!/usr/bin/env python3
"""Build-audit companion: reject nonstandard logical dependencies."""
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
run = subprocess.run(
    ["lake", "env", "lean", "Check.lean"], cwd=root,
    text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
)
print(run.stdout, end="")
if run.returncode:
    sys.exit(run.returncode)
expected = re.findall(r"^#print axioms (\S+)", (root / "Check.lean").read_text(), re.M)
found = re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", run.stdout, re.S)
allowed = {"propext", "Classical.choice", "Quot.sound"}
if {name for name, _ in found} != set(expected):
    sys.exit("Missing or unexpected dependency-audit entry.")
for name, deps in found:
    actual = {x.strip() for x in deps.split(",") if x.strip()}
    if not actual <= allowed:
        sys.exit(f"Nonstandard dependencies in {name}: {sorted(actual - allowed)}")
print(f"Audited {len(found)} declarations: only Lean's standard logical dependencies.")
