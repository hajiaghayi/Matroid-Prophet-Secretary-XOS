import MatroidProphet.Weighted

namespace MatroidProphet
namespace RankModel
variable {α ι : Type*} [DecidableEq α] [Fintype ι]

 theorem profile_bounds (R : RankModel α) (I : Finset α) (labels : List α) (e : α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) :
    0 ≤ R.profile I labels e v ∧ R.profile I labels e v ≤ 1 := by
  exact Cube.probability_bounds _ ⟨by linarith [hv.2],by linarith [hv.1]⟩

 theorem potential_cons (R : RankModel α) (I : Finset α) (labels : List α) (e : α) (v : ℝ) :
    R.potential I (e::labels) v = R.potential I labels v+v*R.profile I labels e v := by
  rw [profile_diff]
  dsimp [potential,average]
  ring

 theorem potential_nonneg (R : RankModel α) (I : Finset α) (labels : List α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) : 0 ≤ R.potential I labels v := by
  induction labels with
  | nil => simp [potential,average]
  | cons e rest ih =>
    rw [potential_cons]
    exact add_nonneg ih (mul_nonneg hv.1 (profile_bounds R I rest e hv).1)

 theorem potential_le (R : RankModel α) (I : Finset α) (labels : List α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) : R.potential I labels v ≤ labels.length*v := by
  induction labels with
  | nil => simp [potential,average]
  | cons e rest ih =>
    rw [potential_cons]
    have hs := mul_le_mul_of_nonneg_left (profile_bounds R I rest e hv).2 hv.1
    simp only [List.length_cons,Nat.cast_add,Nat.cast_one]
    nlinarith

 theorem benchmark_nonneg (R : RankModel α) (L : FiniteLaw ι) (I : Finset α) (labels : List α) :
    0 ≤ R.rankBenchmark L I labels := by
  apply Finset.sum_nonneg
  intro i hi
  exact mul_nonneg (L.increment_nonneg i) (potential_nonneg R I labels (L.level_range i))

 theorem algorithmBand_nonneg (R : RankModel α) (I : Finset α) (labels : List α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) : 0 ≤ R.algorithmBand I labels v :=
  (mul_nonneg coefficient_pos.le (R.potential_nonneg I labels hv)).trans (R.algorithmBand_guarantee I labels hv)

 theorem algorithmBand_le (R : RankModel α) (I : Finset α) (labels : List α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) : R.algorithmBand I labels v ≤ labels.length*v := by
  induction labels generalizing I with
  | nil => simp [algorithmBand]
  | cons e rest ih =>
    have hq := cutoff_bounds R I rest e
    have h1 := mul_le_mul_of_nonneg_left (ih I) (show 0 ≤ 1-R.cutoff I rest e by linarith [hq.2])
    have h2 := mul_le_mul_of_nonneg_left (ih (insert e I)) hq.1
    have h3 : min v (R.cutoff I rest e) ≤ v := min_le_left _ _
    dsimp [algorithmBand]
    simp only [List.length_cons,Nat.cast_add,Nat.cast_one]
    nlinarith

end RankModel

/-- Advertised decimal factor, with every mathematical hypothesis discharged. -/
theorem finite_law_decimal {α ι : Type*} [DecidableEq α] [Finite α] [Fintype ι]
    (M : Matroid α) (L : RankModel.FiniteLaw ι) (labels : List α) :
    (6767410571/10000000000 : ℝ) * (matroidRankModel M).rankBenchmark L ∅ labels ≤
      (matroidRankModel M).algorithmValue L ∅ labels :=
  matroid_finite_law_decimal M L labels (RankModel.benchmark_nonneg _ _ _ _)

end MatroidProphet
