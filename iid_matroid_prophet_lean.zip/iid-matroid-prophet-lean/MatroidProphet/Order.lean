import MatroidProphet.Bounds

namespace MatroidProphet
namespace RankModel
variable {α : Type*} [DecidableEq α]

 theorem average_perm {labels other : List α} (h : labels.Perm other)
    (f : Finset α → ℝ) (I : Finset α) (v : ℝ) :
    average labels f I v = average other f I v := by
  induction h generalizing I with
  | nil => rfl
  | cons e h ih => simp only [average,ih]
  | swap a b rest => simp only [average,Finset.insert_comm]; ring
  | trans h1 h2 ih1 ih2 => exact (ih1 I).trans (ih2 I)

 theorem profile_perm (R : RankModel α) (I : Finset α) (e : α)
    {labels other : List α} (h : labels.Perm other) :
    R.profile I labels e = R.profile I other e := by
  funext v
  simp only [profile_average]
  exact average_perm h _ _ _

 theorem profile_shape_of_nonloop (R : RankModel α) (I : Finset α) (labels : List α) (e : α)
    (hstart : R.increment I e = 1) : ExponentialShape (R.profile I labels e) := by
  have hinc := eventCube_increasing labels (fun A => R.increment A e = 1) (R.increment_antitone e) I
  have hp1 : (R.profileCube I labels e).probability 1 = 1 := by
    unfold profileCube
    rw [eventCube_one]
    simp [hstart]
  exact Cube.survival_shape _ hinc hp1

private theorem calibrated_unique {S : ℝ → ℝ} {q r : ℝ}
    (hs : ExponentialShape S) (hq : q ∈ Set.Ioo (0:ℝ) 1) (hr : r ∈ Set.Ioo (0:ℝ) 1)
    (hcq : S q = Real.exp (-eta)) (hcr : S r = Real.exp (-eta)) : q = r := by
  apply le_antisymm
  · by_contra h
    have hh : r ≤ q := (lt_of_not_ge h).le
    have hm := hs hr hq hh
    dsimp only at hm
    rw [hcq,hcr,Real.log_exp,neg_neg] at hm
    have hi := (div_le_div_iff₀ hr.1 hq.1).mp hm
    nlinarith [eta_pos]
  · by_contra h
    have hh : q ≤ r := (lt_of_not_ge h).le
    have hm := hs hq hr hh
    dsimp only at hm
    rw [hcq,hcr,Real.log_exp,neg_neg] at hm
    have hi := (div_le_div_iff₀ hq.1 hr.1).mp hm
    nlinarith [eta_pos]

/-- The decision cutoff uses the unseen set, with no advice about its future order. -/
theorem cutoff_perm (R : RankModel α) (I : Finset α) (e : α)
    {labels other : List α} (h : labels.Perm other) : R.cutoff I labels e = R.cutoff I other e := by
  have he : labels.toFinset = other.toFinset := by
    ext x
    simp only [List.mem_toFinset]
    exact h.mem_iff
  classical
  by_cases h0 : R.increment I e = 0
  · simp [cutoff,h0]
  by_cases h1 : R.increment (I ∪ labels.toFinset) e = 1
  · have h2 : R.increment (I ∪ other.toFinset) e = 1 := by simpa only [he] using h1
    simp [cutoff,h0,h1,h2]
  · have h2 : ¬R.increment (I ∪ other.toFinset) e = 1 := by simpa only [he] using h1
    simp only [cutoff,dif_neg h0,dif_neg h1,dif_neg h2]
    have hs : R.increment I e = 1 := (R.unit I e).resolve_left h0
    have hz1 : R.increment (I ∪ labels.toFinset) e = 0 := (R.unit _ e).resolve_right h1
    have hz2 : R.increment (I ∪ other.toFinset) e = 0 := (R.unit _ e).resolve_right h2
    have hc1 := Classical.choose_spec (R.profile_cutoff I labels e hs hz1)
    have hc2 := Classical.choose_spec (R.profile_cutoff I other e hs hz2)
    apply calibrated_unique (profile_shape_of_nonloop R I labels e hs) hc1.1 hc2.1 hc1.2
    rw [profile_perm R I e h]
    exact hc2.2

end RankModel
end MatroidProphet
