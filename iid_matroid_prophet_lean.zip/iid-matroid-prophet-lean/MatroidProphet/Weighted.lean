import MatroidProphet.MatroidRank
import MatroidProphet.Numerics

namespace MatroidProphet
namespace RankModel
variable {α ι : Type*} [DecidableEq α] [Fintype ι]

/-- A finite decreasing quantile is a nonnegative sum of upper-band indicators.
Ordering the cutoffs is unnecessary: the sum is decreasing automatically. -/
structure FiniteLaw (ι : Type*) where
  level : ι → ℝ
  increment : ι → ℝ
  level_range : ∀ i, level i ∈ Set.Icc (0:ℝ) 1
  increment_nonneg : ∀ i, 0 ≤ increment i

noncomputable def FiniteLaw.upperReward (L : FiniteLaw ι) (q : ℝ) : ℝ :=
  ∑ i, L.increment i * min (L.level i) q

/-- Exact expected-weight recurrence of the quantile-threshold algorithm. -/
noncomputable def algorithmValue (R : RankModel α) (L : FiniteLaw ι)
    (I : Finset α) (labels : List α) : ℝ := match labels with
  | [] => 0
  | e::rest => L.upperReward (R.cutoff I rest e)+
      (1-R.cutoff I rest e)*algorithmValue R L I rest+
      R.cutoff I rest e*algorithmValue R L (insert e I) rest

/-- Expected-rank layer-cake benchmark for the common finite law. -/
noncomputable def rankBenchmark (R : RankModel α) (L : FiniteLaw ι)
    (I : Finset α) (labels : List α) : ℝ :=
  ∑ i, L.increment i * R.potential I labels (L.level i)

 theorem algorithmValue_eq_band_sum (R : RankModel α) (L : FiniteLaw ι)
    (I : Finset α) (labels : List α) :
    R.algorithmValue L I labels = ∑ i, L.increment i*R.algorithmBand I labels (L.level i) := by
  induction labels generalizing I with
  | nil => simp [algorithmValue,algorithmBand]
  | cons e rest ih =>
    simp only [algorithmValue,algorithmBand,FiniteLaw.upperReward,ih]
    rw [Finset.mul_sum, Finset.mul_sum]
    rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro i hi
    ring

/-- Full finite-law inequality for the algorithm's expected-value recurrence. -/
theorem finite_law_guarantee (R : RankModel α) (L : FiniteLaw ι)
    (I : Finset α) (labels : List α) :
    coefficient * R.rankBenchmark L I labels ≤ R.algorithmValue L I labels := by
  rw [algorithmValue_eq_band_sum]
  unfold rankBenchmark
  apply combine_bands
  · intro i hi
    exact L.increment_nonneg i
  · intro i hi
    exact R.algorithmBand_guarantee I labels (L.level_range i)

end RankModel

/-- Main finite-law statement specialized to actual finite mathlib matroids. -/
theorem matroid_finite_law_guarantee {α ι : Type*} [DecidableEq α] [Finite α] [Fintype ι]
    (M : Matroid α) (L : RankModel.FiniteLaw ι) (labels : List α) :
    coefficient * (matroidRankModel M).rankBenchmark L ∅ labels ≤
      (matroidRankModel M).algorithmValue L ∅ labels :=
  RankModel.finite_law_guarantee _ _ _ _

/-- The same guarantee with the advertised, downward-rounded decimal. -/
theorem matroid_finite_law_decimal {α ι : Type*} [DecidableEq α] [Finite α] [Fintype ι]
    (M : Matroid α) (L : RankModel.FiniteLaw ι) (labels : List α)
    (hbench : 0 ≤ (matroidRankModel M).rankBenchmark L ∅ labels) :
    (6767410571/10000000000 : ℝ) * (matroidRankModel M).rankBenchmark L ∅ labels ≤
      (matroidRankModel M).algorithmValue L ∅ labels := by
  have hc : (6767410571/10000000000 : ℝ) ≤ coefficient := by
    linarith [coefficient_bracket.1]
  exact (mul_le_mul_of_nonneg_right hc hbench).trans (matroid_finite_law_guarantee M L labels)

end MatroidProphet
