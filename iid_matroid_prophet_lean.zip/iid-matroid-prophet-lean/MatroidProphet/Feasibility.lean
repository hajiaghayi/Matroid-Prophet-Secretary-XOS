import MatroidProphet.Bounds

namespace MatroidProphet
namespace RankModel

attribute [local instance] Classical.propDecidable
variable {α : Type*} [DecidableEq α]

/-- The actual selected set on a fixed collection of quantiles. The explicit
unit-increment guard also rejects loops on the null quantile endpoint zero. -/
noncomputable def run (R : RankModel α) (I : Finset α) (labels : List α) (u : α → ℝ) : Finset α :=
  match labels with
  | [] => I
  | e::rest => if R.increment I e = 1 ∧ u e ≤ R.cutoff I rest e then
      run R (insert e I) rest u else run R I rest u

 theorem run_rank_eq_card (R : RankModel α) (I : Finset α) (labels : List α) (u : α → ℝ)
    (hI : R.rank I = I.card) : R.rank (R.run I labels u) = (R.run I labels u).card := by
  induction labels generalizing I with
  | nil => exact hI
  | cons e rest ih =>
    dsimp [run]
    split_ifs with h
    · apply ih
      have he : e ∉ I := by
        intro he
        have hh := h.1
        simp [increment,Finset.insert_eq_of_mem he] at hh
      have hr := h.1
      dsimp [increment] at hr
      rw [Finset.card_insert_of_notMem he,Nat.cast_add,Nat.cast_one]
      linarith
    · exact ih I hI

end RankModel

/-- The recursively defined policy always returns an independent set of the
actual mathlib matroid. This statement is pointwise in the input quantiles. -/
theorem matroid_run_independent {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (labels : List α) (u : α → ℝ) :
    M.Indep (↑((matroidRankModel M).run ∅ labels u) : Set α) := by
  let I := (matroidRankModel M).run ∅ labels u
  have hr : realRank M I = (I.card : ℝ) :=
    RankModel.run_rank_eq_card (matroidRankModel M) ∅ labels u (by
      simpa using (matroidRankModel M).empty)
  apply (Matroid.indep_iff_eRk_eq_encard_of_finite I.finite_toSet).mpr
  have hn : (M.eRk (↑I : Set α)).toNat = I.card := by
    unfold realRank at hr
    exact_mod_cast hr
  have hf : M.eRk (↑I : Set α) ≠ ⊤ := by
    exact Matroid.eRk_ne_top_iff.mpr (Matroid.RankFinite.isRkFinite _)
  rw [← ENat.coe_toNat hf, hn]
  simp

end MatroidProphet
