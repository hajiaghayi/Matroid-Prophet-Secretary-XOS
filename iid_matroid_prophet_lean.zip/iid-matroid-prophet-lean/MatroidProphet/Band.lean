import Mathlib

/-!
# The one-step band inequality

This file uses explicit exponential crossing bounds. It does not assert that a
matroid supplies those bounds. The latter analytic obligation is separated out.
-/

namespace MatroidProphet

/-- Conditional drop of the Bernoulli-rank potential. -/
def drop (q v s : ℝ) : ℝ := q + (v - q) * s

/-- The largest wide-band surcharge. -/
theorem exponential_cap {a x : ℝ} (ha : 0 < a) :
    (x - 1) * Real.exp (-a * x) ≤ Real.exp (-1-a) / a := by
  apply (le_div_iff₀ ha).2
  have ht : a * (x - 1) ≤ Real.exp (a * (x - 1) - 1) := by
    have h := Real.add_one_le_exp (a * (x - 1) - 1)
    linarith
  calc
    (x - 1) * Real.exp (-a * x) * a =
        (a * (x - 1)) * Real.exp (-a * x) := by ring
    _ ≤ Real.exp (a * (x - 1) - 1) * Real.exp (-a * x) :=
      mul_le_mul_of_nonneg_right ht (Real.exp_nonneg _)
    _ = Real.exp (-1-a) := by rw [← Real.exp_add]; congr 1; ring

/-- Narrow bands use the lower exponential bound. -/
theorem narrow_band {a q v s : ℝ} (ha : 0 ≤ a) (hq : 0 < q)
    (hv : 0 ≤ v) (hvq : v ≤ q)
    (hs : Real.exp (-a * (v/q)) ≤ s) :
    drop q v s ≤ (1+a) * v := by
  have ht : 1-s ≤ a*(v/q) := by
    have h := Real.add_one_le_exp (-a*(v/q))
    linarith
  have hm := mul_le_mul_of_nonneg_left ht (sub_nonneg.mpr hvq)
  have hvq' : 0 ≤ v/q := div_nonneg hv hq.le
  have hm' : (q-v)*(a*(v/q)) ≤ a*v := by
    calc
      (q-v)*(a*(v/q)) ≤ q*(a*(v/q)) := by
        apply mul_le_mul_of_nonneg_right (by linarith) (mul_nonneg ha hvq')
      _ = a*v := by field_simp
  unfold drop
  nlinarith

/-- Wide bands use the upper exponential bound. -/
theorem wide_band {a q v s : ℝ} (ha : 0 < a) (hq : 0 < q)
    (hqv : q ≤ v) (hs : s ≤ Real.exp (-a * (v/q))) :
    drop q v s ≤ (1 + Real.exp (-1-a)/a) * q := by
  have hb := exponential_cap (x := v/q) ha
  have hm := mul_le_mul_of_nonneg_left hs (sub_nonneg.mpr hqv)
  have he : (v-q) * Real.exp (-a*(v/q)) ≤
      q * (Real.exp (-1-a)/a) := by
    have h := mul_le_mul_of_nonneg_left hb hq.le
    have hh : q * ((v/q-1)*Real.exp (-a*(v/q))) =
        (v-q)*Real.exp (-a*(v/q)) := by field_simp
    rw [hh] at h
    exact h
  unfold drop
  nlinarith

/-- One cutoff pays for every band, under the stated crossing bounds. -/
theorem band_certificate {a c q v s : ℝ}
    (ha : 0 < a) (hc : 0 ≤ c) (hq : 0 < q) (hv : 0 ≤ v)
    (hsmall : c*(1+a) ≤ 1)
    (hlarge : c*(1+Real.exp (-1-a)/a) ≤ 1)
    (hlo : v ≤ q → Real.exp (-a*(v/q)) ≤ s)
    (hhi : q ≤ v → s ≤ Real.exp (-a*(v/q))) :
    c * drop q v s ≤ min v q := by
  by_cases h : v ≤ q
  · rw [min_eq_left h]
    have hd := narrow_band ha.le hq hv h (hlo h)
    calc
      c * drop q v s ≤ c * ((1+a)*v) := mul_le_mul_of_nonneg_left hd hc
      _ = (c*(1+a))*v := by ring
      _ ≤ v := by nlinarith [mul_le_mul_of_nonneg_right hsmall hv]
  · have h' : q ≤ v := le_of_not_ge h
    rw [min_eq_right h']
    have hd := wide_band ha hq h' (hhi h')
    calc
      c * drop q v s ≤ c * ((1+Real.exp (-1-a)/a)*q) :=
        mul_le_mul_of_nonneg_left hd hc
      _ = (c*(1+Real.exp (-1-a)/a))*q := by ring
      _ ≤ q := by nlinarith [mul_le_mul_of_nonneg_right hlarge hq.le]

/-- The rank identities give precisely the drop used above. -/
theorem drop_from_rank_identities {r rd rc q v s : ℝ}
    (hdel : r = rd + v*s) (hcon : rd-rc = 1-s) :
    r - ((1-q)*rd+q*rc) = drop q v s := by
  have hc : rc = rd - 1 + s := by linarith
  rw [hdel, hc]
  unfold drop
  ring

end MatroidProphet
