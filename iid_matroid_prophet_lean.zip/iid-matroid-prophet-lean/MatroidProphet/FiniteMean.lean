import MatroidProphet.Tail

open MeasureTheory

namespace MatroidProphet
namespace RankModel
variable {α : Type*} [DecidableEq α]

/-- The common nonnegative mean, in survival-tail representation. -/
noncomputable def tailMean (tail : ℝ → ℝ) : ENNReal :=
  ∫⁻ t in Set.Ici (0:ℝ), ENNReal.ofReal (tail t)

 theorem tailAlgorithm_le (R : RankModel α) (I : Finset α) (labels : List α)
    (tail : ℝ → ℝ) (ht : ∀ t, tail t ∈ Set.Icc (0:ℝ) 1) :
    R.tailAlgorithm I labels tail ≤ ENNReal.ofReal (labels.length:ℝ) * tailMean tail := by
  unfold tailAlgorithm tailMean
  rw [← lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply lintegral_mono
  intro t
  dsimp only
  rw [← ENNReal.ofReal_mul (Nat.cast_nonneg _)]
  exact ENNReal.ofReal_le_ofReal (R.algorithmBand_le I labels (ht t))

 theorem tailRank_le (R : RankModel α) (I : Finset α) (labels : List α)
    (tail : ℝ → ℝ) (ht : ∀ t, tail t ∈ Set.Icc (0:ℝ) 1) :
    R.tailRank I labels tail ≤ ENNReal.ofReal (labels.length:ℝ) * tailMean tail := by
  unfold tailRank tailMean
  rw [← lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply lintegral_mono
  intro t
  dsimp only
  rw [← ENNReal.ofReal_mul (Nat.cast_nonneg _)]
  exact ENNReal.ofReal_le_ofReal (R.potential_le I labels (ht t))

/-- A real-valued competitive inequality whenever the common mean is finite. -/
theorem tail_real_guarantee (R : RankModel α) (I : Finset α) (labels : List α)
    (tail : ℝ → ℝ) (ht : ∀ t, tail t ∈ Set.Icc (0:ℝ) 1)
    (hmean : tailMean tail ≠ ⊤) :
    coefficient * (R.tailRank I labels tail).toReal ≤ (R.tailAlgorithm I labels tail).toReal := by
  have hfin : R.tailAlgorithm I labels tail ≠ ⊤ :=
    ne_top_of_le_ne_top (ENNReal.mul_ne_top ENNReal.ofReal_ne_top hmean) (R.tailAlgorithm_le I labels tail ht)
  have hh := ENNReal.toReal_mono hfin (R.tail_guarantee I labels tail ht)
  simpa only [ENNReal.toReal_mul,ENNReal.toReal_ofReal coefficient_pos.le] using hh

end RankModel

 theorem matroid_tail_real_guarantee {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (labels : List α) (tail : ℝ → ℝ)
    (ht : ∀ t, tail t ∈ Set.Icc (0:ℝ) 1) (hmean : RankModel.tailMean tail ≠ ⊤) :
    coefficient * ((matroidRankModel M).tailRank ∅ labels tail).toReal ≤
      ((matroidRankModel M).tailAlgorithm ∅ labels tail).toReal :=
  RankModel.tail_real_guarantee _ _ _ _ ht hmean

end MatroidProphet
