import MatroidProphet.Entropy

namespace MatroidProphet

/-- A Boolean function on a cube, represented by its two restrictions. -/
inductive Cube : ℕ → Type
  | leaf (value : Bool) : Cube 0
  | node {n : ℕ} (lo hi : Cube n) : Cube (n+1)

namespace Cube

/-- Product Bernoulli probability of the event. -/
noncomputable def probability : {n : ℕ} → Cube n → ℝ → ℝ
  | _, leaf b, _ => if b then 1 else 0
  | _, node lo hi, p => (1-p)*lo.probability p+p*hi.probability p

noncomputable def slope : {n : ℕ} → Cube n → ℝ → ℝ
  | _, leaf _, _ => 0
  | _, node lo hi, p => hi.probability p-lo.probability p+
      (1-p)*lo.slope p+p*hi.slope p

/-- Pointwise implication of Boolean events. -/
def Implies : {n : ℕ} → Cube n → Cube n → Prop
  | _, leaf a, leaf b => a = true → b = true
  | _, node a b, node c d => a.Implies c ∧ b.Implies d

/-- Increasing in each absence bit. -/
def Increasing : {n : ℕ} → Cube n → Prop
  | _, leaf _ => True
  | _, node lo hi => lo.Increasing ∧ hi.Increasing ∧ lo.Implies hi

theorem probability_bounds {n : ℕ} (f : Cube n) {p : ℝ}
    (hp : p ∈ Set.Icc (0:ℝ) 1) : 0 ≤ f.probability p ∧ f.probability p ≤ 1 := by
  induction f with
  | leaf b => cases b <;> simp [probability]
  | node lo hi ihlo ihhi =>
    dsimp [probability]
    have h1 := mul_nonneg (sub_nonneg.mpr hp.2) ihlo.1
    have h2 := mul_nonneg hp.1 ihhi.1
    have h3 := mul_le_mul_of_nonneg_left ihlo.2 (sub_nonneg.mpr hp.2)
    have h4 := mul_le_mul_of_nonneg_left ihhi.2 hp.1
    constructor <;> nlinarith

theorem probability_le {n : ℕ} {f g : Cube n} (h : f.Implies g)
    {p : ℝ} (hp : p ∈ Set.Icc (0:ℝ) 1) : f.probability p ≤ g.probability p := by
  induction f with
  | leaf a =>
    cases g with
    | leaf b => cases a <;> cases b <;> simp_all [Implies,probability]
  | node a b iha ihb =>
    cases g with
    | node c d =>
      have h1 := iha h.1
      have h2 := ihb h.2
      exact add_le_add (mul_le_mul_of_nonneg_left h1 (sub_nonneg.mpr hp.2))
        (mul_le_mul_of_nonneg_left h2 hp.1)

theorem hasDerivAt_probability {n : ℕ} (f : Cube n) (p : ℝ) :
    HasDerivAt f.probability (f.slope p) p := by
  induction f with
  | leaf b =>
    cases b
    · simpa [probability,slope] using hasDerivAt_const p (0:ℝ)
    · simpa [probability,slope] using hasDerivAt_const p (1:ℝ)
  | node lo hi ihlo ihhi =>
    have h1 := ((hasDerivAt_const p (1:ℝ)).sub (hasDerivAt_id p)).mul ihlo
    have h2 := (hasDerivAt_id p).mul ihhi
    convert h1.add h2 using 1 <;> dsimp [probability,slope] <;> ring

/-- Weak biased edge-isoperimetry for an increasing Boolean function. -/
theorem entropy_bound {n : ℕ} (f : Cube n) (hf : f.Increasing)
    {p : ℝ} (hp : 0 < p) (hp1 : p < 1) :
    ent (f.probability p) ≤ ent p * f.slope p := by
  induction f with
  | leaf b => cases b <;> simp [probability,slope,ent]
  | node lo hi ihlo ihhi =>
    have hl := ihlo hf.1
    have hh := ihhi hf.2.1
    have hb := probability_bounds lo ⟨hp.le,hp1.le⟩
    have hm := probability_le hf.2.2 ⟨hp.le,hp1.le⟩
    have he := entropy_mix hp hp1 hb.1 hm
    have h1 := mul_le_mul_of_nonneg_left hl (show 0 ≤ 1-p by linarith)
    have h2 := mul_le_mul_of_nonneg_left hh hp.le
    dsimp [probability,slope]
    nlinarith

theorem slope_nonneg {n : ℕ} (f : Cube n) (hf : f.Increasing)
    {p : ℝ} (hp : p ∈ Set.Icc (0:ℝ) 1) : 0 ≤ f.slope p := by
  induction f with
  | leaf b => simp [slope]
  | node lo hi ihlo ihhi =>
    have h1 := ihlo hf.1
    have h2 := ihhi hf.2.1
    have h3 := probability_le hf.2.2 hp
    dsimp [slope]
    have h4 := mul_nonneg (show 0 ≤ 1-p by linarith [hp.2]) h1
    have h5 := mul_nonneg hp.1 h2
    nlinarith

end Cube
end MatroidProphet
