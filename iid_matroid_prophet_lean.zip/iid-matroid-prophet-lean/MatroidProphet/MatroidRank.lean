import MatroidProphet.Selection
import Mathlib.Combinatorics.Matroid.Rank.ENat

namespace MatroidProphet

attribute [local instance] Classical.propDecidable
variable {α : Type*} [DecidableEq α] [Finite α]

/-- Real-valued finite rank of an actual mathlib matroid. -/
noncomputable def realRank (M : Matroid α) (A : Finset α) : ℝ := (M.eRk (↑A : Set α)).toNat

private theorem rank_ne_top (M : Matroid α) (X : Set α) : M.eRk X ≠ ⊤ := by
  apply Matroid.eRk_ne_top_iff.mpr
  exact Matroid.RankFinite.isRkFinite X

 theorem realRank_insert (M : Matroid α) (A : Finset α) (e : α) :
    realRank M (insert e A) = realRank M A+
      if e ∈ M.E ∧ e ∉ M.closure (↑A : Set α) then 1 else 0 := by
  classical
  by_cases hg : e ∈ M.E
  · by_cases hc : e ∈ M.closure (↑A : Set α)
    · have he : M.eRk (insert e (↑A : Set α)) = M.eRk (↑A : Set α) := by
        rw [← M.eRk_closure_eq (insert e (↑A : Set α)),
          Matroid.closure_insert_eq_of_mem_closure hc, M.eRk_closure_eq]
      simp only [realRank, Finset.coe_insert, he, hc, not_true_eq_false, and_false, if_false, add_zero]
    · have he := Matroid.eRk_insert_eq_add_one (M := M) (X := (↑A : Set α)) ⟨hg,hc⟩
      simp only [realRank, Finset.coe_insert, he, ENat.toNat_add (rank_ne_top M _)
        (show (1:ℕ∞) ≠ ⊤ by simp), ENat.toNat_one, Nat.cast_add, Nat.cast_one]
      simp [hg,hc]
  · have he := M.eRk_insert_of_notMem_ground (↑A : Set α) hg
    simp [realRank,Finset.coe_insert,he,hg]

/-- Every finite mathlib matroid supplies the rank axioms used by the algorithm. -/
noncomputable def matroidRankModel (M : Matroid α) : RankModel α where
  rank := realRank M
  empty := by simp [realRank,M.eRk_empty]
  unit := by
    intro A e
    rw [realRank_insert]
    split_ifs <;> simp
  diminishing := by
    intro A B hAB e
    rw [realRank_insert,realRank_insert]
    by_cases hB : e ∈ M.E ∧ e ∉ M.closure (↑B : Set α)
    · have hA : e ∈ M.E ∧ e ∉ M.closure (↑A : Set α) := by
        refine ⟨hB.1,fun h => hB.2 (M.closure_mono ?_ h)⟩
        exact_mod_cast hAB
      simp [hB,hA]
    · simp only [hB,if_false,add_zero,sub_self]
      split_ifs <;> linarith

/-- All finite matroids and all fixed label orders satisfy the band guarantee. -/
theorem matroid_band_guarantee (M : Matroid α) (labels : List α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) :
    coefficient * (matroidRankModel M).potential ∅ labels v ≤
      (matroidRankModel M).algorithmBand ∅ labels v :=
  RankModel.algorithmBand_guarantee _ _ _ hv

end MatroidProphet
