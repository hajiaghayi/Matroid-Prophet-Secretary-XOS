import MatroidProphet.Band
import MatroidProphet.Constants

namespace MatroidProphet

/-- The analytic shape property. Survival.lean derives it from the Boolean-cube
entropy bound, and MatroidRank.lean discharges it for actual finite matroids. -/
def ExponentialShape (S : ℝ → ℝ) : Prop :=
  MonotoneOn (fun v => -Real.log (S v) / v) (Set.Ioo 0 1)

/-- A continuous nonloop/noncoloop profile has a calibrated cutoff. -/
theorem calibrated_cutoff {S : ℝ → ℝ} (hc : ContinuousOn S (Set.Icc 0 1))
    (h0 : S 0 = 1) (h1 : S 1 = 0) :
    ∃ q ∈ Set.Ioo (0:ℝ) 1, S q = Real.exp (-eta) := by
  have hb0 : 0 < Real.exp (-eta) := Real.exp_pos _
  have hb1 : Real.exp (-eta) < 1 := Real.exp_lt_one_iff.mpr (by linarith [eta_pos])
  obtain ⟨q, hq, he⟩ := intermediate_value_Icc' (show (0:ℝ) ≤ 1 by norm_num)
    hc (show Real.exp (-eta) ∈ Set.Icc (S 1) (S 0) by
      constructor
      · rw [h1]; exact hb0.le
      · rw [h0]; exact hb1.le)
  refine ⟨q, ⟨?_, ?_⟩, he⟩
  · by_contra h
    have hz : q = 0 := le_antisymm (le_of_not_gt h) hq.1
    subst q
    rw [h0] at he
    linarith
  · by_contra h
    have hz : q = 1 := le_antisymm hq.2 (le_of_not_gt h)
    subst q
    rw [h1] at he
    linarith

/-- The shape inequality gives the lower exponential crossing. -/
theorem crossing_lower {S : ℝ → ℝ} {q v : ℝ} (hshape : ExponentialShape S)
    (hq : q ∈ Set.Ioo (0:ℝ) 1) (hv : v ∈ Set.Ioo (0:ℝ) 1)
    (hp : 0 < S v) (hcal : S q = Real.exp (-eta)) (hvq : v ≤ q) :
    Real.exp (-eta*(v/q)) ≤ S v := by
  have hm := hshape hv hq hvq
  dsimp only at hm
  rw [hcal, Real.log_exp] at hm
  have hcross := (div_le_div_iff₀ hv.1 hq.1).mp hm
  apply (Real.le_log_iff_exp_le hp).mp
  have he : -eta*(v/q) = (-eta*v)/q := by ring
  rw [he]
  apply (div_le_iff₀ hq.1).mpr
  nlinarith

/-- The shape inequality gives the upper exponential crossing. -/
theorem crossing_upper {S : ℝ → ℝ} {q v : ℝ} (hshape : ExponentialShape S)
    (hq : q ∈ Set.Ioo (0:ℝ) 1) (hv : v ∈ Set.Ioo (0:ℝ) 1)
    (hp : 0 < S v) (hcal : S q = Real.exp (-eta)) (hqv : q ≤ v) :
    S v ≤ Real.exp (-eta*(v/q)) := by
  have hm := hshape hq hv hqv
  dsimp only at hm
  rw [hcal, Real.log_exp] at hm
  have hcross := (div_le_div_iff₀ hq.1 hv.1).mp hm
  apply (Real.log_le_iff_le_exp hp).mp
  have he : -eta*(v/q) = (-eta*v)/q := by ring
  rw [he]
  apply (le_div_iff₀ hq.1).mpr
  nlinarith

/-- Conditional version of the manuscript's local theorem, including endpoints. -/
theorem profile_band {S : ℝ → ℝ} {q v : ℝ}
    (hshape : ExponentialShape S) (h0 : S 0 = 1) (h1 : S 1 = 0)
    (hpos : ∀ t ∈ Set.Ioo (0:ℝ) 1, 0 < S t)
    (hq : q ∈ Set.Ioo (0:ℝ) 1) (hv : v ∈ Set.Icc (0:ℝ) 1)
    (hcal : S q = Real.exp (-eta)) :
    coefficient * drop q v (S v) ≤ min v q := by
  apply band_certificate eta_pos coefficient_pos.le hq.1 hv.1
    coefficient_small.le coefficient_large.le
  · intro hvq
    by_cases hz : v = 0
    · simp [hz, h0]
    · have ht : v ∈ Set.Ioo (0:ℝ) 1 := ⟨lt_of_le_of_ne hv.1 (Ne.symm hz), lt_of_le_of_lt hvq hq.2⟩
      exact crossing_lower hshape hq ht (hpos _ ht) hcal hvq
  · intro hqv
    by_cases hz : v = 1
    · rw [hz, h1]
      exact (Real.exp_pos _).le
    · have ht : v ∈ Set.Ioo (0:ℝ) 1 := ⟨lt_of_lt_of_le hq.1 hqv, lt_of_le_of_ne hv.2 hz⟩
      exact crossing_upper hshape hq ht (hpos _ ht) hcal hqv

end MatroidProphet
