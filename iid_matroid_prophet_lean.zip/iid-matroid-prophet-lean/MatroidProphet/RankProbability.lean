import MatroidProphet.WeightedProbability

open MeasureTheory Set
namespace MatroidProphet

theorem uniform_choice {q A B : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    (∫ x, (if x ∈ Ioc 0 q then A else B) ∂uniformQuantile) = q*A+(1-q)*B := by
  have he : (fun x : ℝ => if x ∈ Ioc 0 q then (if x ≤ (0:ℝ) then 1 else 0)+A else B) =
      fun x : ℝ => if x ∈ Ioc 0 q then A else B := by
    funext x
    by_cases h : x ∈ Ioc 0 q
    · simp [h,not_le.mpr h.1]
    · simp [h]
  have h := uniform_step (q:=q) (v:=0) (A:=A) (B:=B) hq (by simp)
  simpa only [he,min_eq_left hq.1,zero_add] using h

theorem quantile_choice (μ : Measure ℝ) {t A B : ℝ} (ht : 0 ≤ t) :
    (∫ x, (if t < weightQuantile μ x then A else B) ∂uniformQuantile) =
      lawTail μ t*A+(1-lawTail μ t)*B := by
  have he : (fun x : ℝ => if t < weightQuantile μ x then A else B) =ᵐ[uniformQuantile]
      (fun x : ℝ => if x ∈ Ioc 0 (lawTail μ t) then A else B) := by
    filter_upwards [uniformQuantile_ae_Ioo,uniformQuantile_ae_ne (lawTail μ t)] with x hx hn
    have hh : (t < weightQuantile μ x) ↔ x ∈ Ioc 0 (lawTail μ t) := by
      rw [weightQuantile_gt_iff μ hx ht]
      exact ⟨fun h => ⟨hx.1,h.le⟩,fun h => lt_of_le_of_ne h.2 hn⟩
    simp only [hh]
  rw [integral_congr_ae he,uniform_choice (lawTail_range μ t)]

/-- All elements whose realized weights exceed the level. -/
noncomputable def upperSet {α : Type*} [DecidableEq α] (μ : Measure ℝ)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) : Finset α := match labels with
  | [] => ∅
  | e::rest => if t < weightQuantile μ z.1 then insert e (upperSet μ rest z.2 t)
      else upperSet μ rest z.2 t

namespace RankModel
variable {α : Type*} [DecidableEq α]

/-- Rank of the realized upper-level set, including a contracted starting set. -/
noncomputable def rankAt (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) : ℝ := match labels with
  | [] => R.rank I
  | e::rest => if t < weightQuantile μ z.1 then R.rankAt μ (insert e I) rest z.2 t
      else R.rankAt μ I rest z.2 t

 theorem rankAt_eq (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) :
    R.rankAt μ I labels z t = R.rank (I ∪ upperSet μ labels z t) := by
  induction labels generalizing I with
  | nil => simp [rankAt,upperSet]
  | cons e rest ih =>
    dsimp [rankAt,upperSet]
    split_ifs
    · rw [ih]
      congr 1
      ext a
      simp [or_assoc,or_comm,or_left_comm]
    · exact ih I z.2

 theorem rankAt_measurable (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (t : ℝ) : Measurable (fun z => R.rankAt μ I labels z t) := by
  induction labels generalizing I with
  | nil => exact measurable_const
  | cons e rest ih =>
    exact Measurable.ite (measurableSet_lt measurable_const
      ((weightQuantile_measurable μ).comp measurable_fst))
      ((ih (insert e I)).comp measurable_snd) ((ih I).comp measurable_snd)

 theorem rankAt_joint (R : RankModel α) (μ : Measure ℝ) (I : Finset α) (labels : List α) :
    Measurable (fun z : QuantileSpace labels.length × ℝ => R.rankAt μ I labels z.1 z.2) := by
  induction labels generalizing I with
  | nil => exact measurable_const
  | cons e rest ih =>
    change Measurable (fun z : (ℝ × QuantileSpace rest.length) × ℝ =>
      if z.2 < weightQuantile μ z.1.1 then R.rankAt μ (insert e I) rest z.1.2 z.2
      else R.rankAt μ I rest z.1.2 z.2)
    apply Measurable.ite (measurableSet_lt measurable_snd
      ((weightQuantile_measurable μ).comp (measurable_fst.comp measurable_fst)))
    · exact (ih (insert e I)).comp ((measurable_snd.comp measurable_fst).prodMk measurable_snd)
    · exact (ih I).comp ((measurable_snd.comp measurable_fst).prodMk measurable_snd)

 theorem rankAt_bounds (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) :
    R.rank I ≤ R.rankAt μ I labels z t ∧ R.rankAt μ I labels z t ≤ R.rank I+labels.length := by
  induction labels generalizing I with
  | nil => simp [rankAt]
  | cons e rest ih =>
    have h1 := ih I z.2
    have h2 := ih (insert e I) z.2
    have hu := R.unit I e
    dsimp [rankAt]
    simp only [List.length_cons,Nat.cast_add,Nat.cast_one]
    split_ifs <;> rcases hu with hu | hu <;> constructor <;> linarith

 theorem rankAt_integrable (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (t : ℝ) :
    Integrable (fun z => R.rankAt μ I labels z t) (quantileMeasure labels.length) := by
  apply (integrable_const (|R.rank I|+labels.length)).mono'
    (R.rankAt_measurable μ I labels t).aestronglyMeasurable
  filter_upwards [] with z
  rw [Real.norm_eq_abs,abs_le]
  have h := R.rankAt_bounds μ I labels z t
  have h1 := le_abs_self (R.rank I)
  have h2 := neg_abs_le (R.rank I)
  have hl : (0:ℝ) ≤ labels.length := by positivity
  constructor <;> linarith

/-- Bernoulli rank averaging is exactly expected realized rank. -/
theorem integral_rankAt (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) {t : ℝ} (ht : 0 ≤ t) :
    (∫ z, R.rankAt μ I labels z t ∂quantileMeasure labels.length) =
      average labels R.rank I (lawTail μ t) := by
  induction labels generalizing I with
  | nil => simp [rankAt,average]
  | cons e rest ih =>
    have hi := R.rankAt_integrable μ I (e::rest) t
    change Integrable (fun z => R.rankAt μ I (e::rest) z t)
      (uniformQuantile.prod (quantileMeasure rest.length)) at hi
    change (∫ z, R.rankAt μ I (e::rest) z t
      ∂uniformQuantile.prod (quantileMeasure rest.length)) = _
    rw [integral_prod _ hi]
    have he : (fun x => ∫ y, R.rankAt μ I (e::rest) (x,y) t ∂quantileMeasure rest.length) =
      fun x => if t < weightQuantile μ x then average rest R.rank (insert e I) (lawTail μ t)
        else average rest R.rank I (lawTail μ t) := by
      funext x
      by_cases hx : t < weightQuantile μ x
      · simpa only [rankAt,hx,if_true] using ih (insert e I)
      · simpa only [rankAt,hx,if_false] using ih I
    rw [he,quantile_choice μ ht]
    dsimp [average]
    ring

/-- Expected rank layer cake for a sample of actual weights. -/
theorem expected_rank_cake (R : RankModel α) (μ : Measure ℝ) (labels : List α) :
    (∫⁻ t in Ioi (0:ℝ), ∫⁻ z, ENNReal.ofReal (R.rankAt μ ∅ labels z t)
      ∂quantileMeasure labels.length) = R.tailRank ∅ labels (lawTail μ) := by
  unfold tailRank
  rw [← restrict_Ioi_eq_restrict_Ici]
  apply setLIntegral_congr_fun measurableSet_Ioi
  intro t ht
  dsimp only
  rw [← ofReal_integral_eq_lintegral_ofReal (R.rankAt_integrable μ ∅ labels t)]
  · rw [R.integral_rankAt μ ∅ labels ht.le]
    simp [potential,R.empty]
  · exact Filter.Eventually.of_forall (fun z => by
      have hh := (R.rankAt_bounds μ ∅ labels z t).1
      simpa only [R.empty] using hh)

end RankModel
end MatroidProphet
