import Mathlib

namespace MatroidProphet

noncomputable section

/-- The homogeneous entropy integrand, continuous also at zero. -/
def ent (x : ℝ) : ℝ := -x * Real.log x

private def mixGap (p t : ℝ) : ℝ :=
  ent (p+(1-p)*t) - (1-p)*ent t

private theorem mixGap_deriv {p t : ℝ} (hp : 0 < p) (hp1 : p < 1) (ht : 0 < t) :
    HasDerivAt (mixGap p) ((1-p)*(Real.log t-Real.log (p+(1-p)*t))) t := by
  have hpm : 0 < 1-p := by linarith
  have hr : 0 < p+(1-p)*t := by positivity
  have hlin : HasDerivAt (fun x : ℝ => p+(1-p)*x) (1-p) t := by convert (hasDerivAt_id t).const_mul (1-p) |>.const_add p using 1 <;> simp
  have h1 := (Real.hasDerivAt_mul_log hr.ne').comp t hlin
  have h2 := (Real.hasDerivAt_mul_log ht.ne').const_mul (1-p)
  have h := h1.neg.sub h2.neg
  convert h using 1
  · ext x
    dsimp [mixGap,ent]
    ring
  · ring

private theorem mixGap_convex {p : ℝ} (hp : 0 < p) (hp1 : p < 1) :
    ConvexOn ℝ (Set.Icc (0:ℝ) 1) (mixGap p) := by
  apply MonotoneOn.convexOn_of_deriv (convex_Icc 0 1)
  · have h : Continuous (mixGap p) := by
      unfold mixGap ent
      have h1 : Continuous (fun t : ℝ => (p+(1-p)*t)*Real.log (p+(1-p)*t)) := by
        exact Real.continuous_mul_log.comp (by fun_prop)
      have h2 : Continuous (fun t : ℝ => t*Real.log t) := Real.continuous_mul_log
      have h3 : Continuous (fun t : ℝ => (1-p)*(t*Real.log t)) := continuous_const.mul h2
      convert h1.neg.add h3 using 1
      ext t
      dsimp
      ring
    exact h.continuousOn
  · intro t ht
    rw [interior_Icc] at ht
    exact (mixGap_deriv hp hp1 ht.1).differentiableAt.differentiableWithinAt
  · intro u hu v hv huv
    rw [interior_Icc] at hu hv
    rw [(mixGap_deriv hp hp1 hu.1).deriv, (mixGap_deriv hp hp1 hv.1).deriv]
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    have hpm : 0 < 1-p := by linarith
    have hup : 0 < u := hu.1
    have hvp : 0 < v := hv.1
    have hru : 0 < p+(1-p)*u := by positivity
    have hrv : 0 < p+(1-p)*v := by positivity
    rw [← Real.log_div hu.1.ne' hru.ne', ← Real.log_div hv.1.ne' hrv.ne']
    apply Real.log_le_log (div_pos hu.1 hru)
    apply (div_le_div_iff₀ hru hrv).mpr
    nlinarith

/-- The two-point entropy bound used in induction over a Boolean cube. -/
private theorem normalized_mix_bound {p t : ℝ} (hp : 0 < p) (hp1 : p < 1)
    (ht : t ∈ Set.Icc (0:ℝ) 1) :
    mixGap p t ≤ (1-t)*ent p := by
  have hcv := mixGap_convex hp hp1
  obtain ⟨_, hconv⟩ := hcv
  have h := hconv (x := (0:ℝ)) (y := (1:ℝ))
    (by simp : (0:ℝ) ∈ Set.Icc 0 1) (by simp : (1:ℝ) ∈ Set.Icc 0 1)
    (a := 1-t) (b := t) (by linarith [ht.2]) ht.1 (by ring)
  simpa [mixGap, ent] using h

/-- A homogeneous form of the Boolean two-point entropy inequality. -/
theorem entropy_mix {p a b : ℝ} (hp : 0 < p) (hp1 : p < 1)
    (ha : 0 ≤ a) (hab : a ≤ b) :
    ent ((1-p)*a+p*b) ≤ (1-p)*ent a+p*ent b+ent p*(b-a) := by
  by_cases hb : b = 0
  · have : a = 0 := le_antisymm (by simpa [hb] using hab) ha
    simp [this,hb,ent]
  have hbpos : 0 < b := lt_of_le_of_ne (ha.trans hab) (Ne.symm hb)
  by_cases ha0 : a = 0
  · simp only [ha0, mul_zero, zero_add, sub_zero, ent, Real.log_zero]
    rw [Real.log_mul hp.ne' hb]
    ring_nf
    rfl
  have hapos : 0 < a := lt_of_le_of_ne ha (Ne.symm ha0)
  let t := a/b
  have ht : t ∈ Set.Icc (0:ℝ) 1 := ⟨div_nonneg ha hbpos.le, (div_le_one hbpos).mpr hab⟩
  have htpos : 0 < t := div_pos hapos hbpos
  have hpm : 0 < 1-p := by linarith
  have hr : 0 < p+(1-p)*t := by positivity
  have h := normalized_mix_bound hp hp1 ht
  have haeq : a = b*t := by dsimp [t]; field_simp
  have hmeq : (1-p)*a+p*b = b*(p+(1-p)*t) := by rw [haeq]; ring
  rw [hmeq, haeq]
  unfold ent
  rw [Real.log_mul hb hr.ne', Real.log_mul hb htpos.ne']
  dsimp [mixGap,ent] at h
  have hm := mul_le_mul_of_nonneg_left h hbpos.le
  nlinarith

end

end MatroidProphet
