import MatroidProphet.ProphetProbability

open MeasureTheory Set
namespace MatroidProphet
namespace RankModel
variable {α : Type*} [DecidableEq α]

/-- Newly accepted labels; only the current quantile is inspected. -/
noncomputable def selectedNew (R : RankModel α) (I : Finset α) (labels : List α)
    (z : QuantileSpace labels.length) : Finset α := match labels with
  | [] => ∅
  | e::rest => if z.1 ∈ Ioc 0 (R.cutoff I rest e) then
      insert e (R.selectedNew (insert e I) rest z.2)
    else R.selectedNew I rest z.2

 theorem selectedNew_subset (R : RankModel α) (I : Finset α) (labels : List α)
    (z : QuantileSpace labels.length) : R.selectedNew I labels z ⊆ labels.toFinset := by
  induction labels generalizing I with
  | nil => exact Finset.Subset.refl _
  | cons e rest ih =>
    dsimp [selectedNew]
    split_ifs
    · simpa using Finset.insert_subset_insert e (ih (insert e I) z.2)
    · exact (ih I z.2).trans (by simp)

 theorem cutoff_accept_increment (R : RankModel α) (I : Finset α) (rest : List α) (e : α)
    {x : ℝ} (hx : x ∈ Ioc 0 (R.cutoff I rest e)) : R.increment I e = 1 := by
  rcases R.unit I e with h | h
  · have hz : R.cutoff I rest e = 0 := by simp [cutoff,increment,h]
    rw [hz] at hx
    exact False.elim (not_lt_of_ge hx.2 hx.1)
  · exact h

 theorem selectedNew_rank (R : RankModel α) (I : Finset α) (labels : List α)
    (hI : R.rank I = I.card) (z : QuantileSpace labels.length) :
    R.rank (I ∪ R.selectedNew I labels z) = ((I ∪ R.selectedNew I labels z).card : ℝ) := by
  induction labels generalizing I with
  | nil => simpa [selectedNew] using hI
  | cons e rest ih =>
    by_cases hx : z.1 ∈ Ioc 0 (R.cutoff I rest e)
    · have hr := R.cutoff_accept_increment I rest e hx
      have he : e ∉ I := by
        intro h
        simp [increment,Finset.insert_eq_of_mem h] at hr
      have hi : R.rank (insert e I) = ((insert e I).card:ℝ) := by
        rw [Finset.card_insert_of_notMem he,Nat.cast_add,Nat.cast_one]
        dsimp [increment] at hr
        linarith
      have hh := ih (insert e I) hi z.2
      simpa only [selectedNew,hx,if_true,Finset.insert_union,Finset.union_insert] using hh
    · simpa only [selectedNew,hx,if_false] using ih I hI z.2

/-- The numerical reward in the expectation theorem is exactly the sum of the
weights on the labels returned by the policy. -/
theorem policyValue_eq_selected_sum (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (hn : labels.Nodup) (z : QuantileSpace labels.length) :
    R.policyValue I labels (weightQuantile μ) z =
      ∑ a ∈ R.selectedNew I labels z, streamWeights μ labels z a := by
  induction labels generalizing I with
  | nil => simp [policyValue,selectedNew]
  | cons e rest ih =>
    have hn' := List.nodup_cons.mp hn
    have he (J : Finset α) : e ∉ R.selectedNew J rest z.2 := by
      intro hm
      exact hn'.1 (List.mem_toFinset.mp (R.selectedNew_subset J rest z.2 hm))
    have hsum (J : Finset α) :
        (∑ a ∈ R.selectedNew J rest z.2, streamWeights μ (e::rest) z a) =
        ∑ a ∈ R.selectedNew J rest z.2, streamWeights μ rest z.2 a := by
      apply Finset.sum_congr rfl
      intro a ha
      have hne : a ≠ e := by intro hh; subst a; exact he J ha
      simp [streamWeights,Function.update_apply,hne]
    by_cases hx : z.1 ∈ Ioc 0 (R.cutoff I rest e)
    · simp only [policyValue,selectedNew,hx,if_true]
      rw [Finset.sum_insert (he (insert e I)),hsum,← ih (insert e I) hn'.2 z.2]
      simp [streamWeights]
    · simp only [policyValue,selectedNew,hx,if_false]
      rw [hsum]
      exact ih I hn'.2 z.2

end RankModel

 theorem matroid_selectedNew_independent {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (labels : List α) (z : QuantileSpace labels.length) :
    M.Indep (↑((matroidRankModel M).selectedNew ∅ labels z) : Set α) := by
  let S := (matroidRankModel M).selectedNew ∅ labels z
  have hr : realRank M S = (S.card:ℝ) := by
    simpa only [Finset.empty_union] using
      RankModel.selectedNew_rank (matroidRankModel M) ∅ labels (by simp [(matroidRankModel M).empty]) z
  apply (Matroid.indep_iff_eRk_eq_encard_of_finite S.finite_toSet).mpr
  have hn : (M.eRk (↑S : Set α)).toNat = S.card := by
    unfold realRank at hr
    exact_mod_cast hr
  have hf : M.eRk (↑S : Set α) ≠ ⊤ :=
    Matroid.eRk_ne_top_iff.mpr (Matroid.RankFinite.isRkFinite _)
  rw [← ENat.coe_toNat hf,hn]
  simp

end MatroidProphet
