import MatroidProphet.Constants

set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

namespace MatroidProphet

private theorem eta_product : eta * Real.exp ((1+eta)/2) = 1 := by
  have he : Real.exp ((1+eta)/2)^2 = Real.exp (1+eta) := by
    rw [pow_two, ← Real.exp_add]
    congr 1
    ring
  have hs : (eta * Real.exp ((1+eta)/2))^2 = 1 := by
    rw [mul_pow, eta_equation, he, ← Real.exp_add]
    norm_num
  have hp : 0 < eta * Real.exp ((1+eta)/2) := mul_pos eta_pos (Real.exp_pos _)
  nlinarith

private theorem lower_product :
    (47767006226321 / 100000000000000 : ℝ) *
      Real.exp ((1+47767006226321 / 100000000000000)/2) < 1 := by
  have he := Real.exp_bound' (x := (1+47767006226321 / 100000000000000)/2)
    (by norm_num) (by norm_num) (n := 22) (by norm_num)
  norm_num [Finset.sum_range_succ, Nat.factorial] at he
  nlinarith

private theorem upper_product :
    1 < (47767006226322 / 100000000000000 : ℝ) *
      Real.exp ((1+47767006226322 / 100000000000000)/2) := by
  have he := Real.sum_le_exp_of_nonneg
    (x := (1+47767006226322 / 100000000000000)/2) (by norm_num) 22
  norm_num [Finset.sum_range_succ, Nat.factorial] at he
  nlinarith

/-- Certified rational bracket; no floating-point computation is trusted. -/
theorem eta_bracket :
    (47767006226321 / 100000000000000 : ℝ) < eta ∧
    eta < 47767006226322 / 100000000000000 := by
  constructor
  · by_contra hh
    have h : eta ≤ (47767006226321 / 100000000000000 : ℝ) := le_of_not_gt hh
    have he := Real.exp_monotone (show (1+eta)/2 ≤
        (1+(47767006226321 / 100000000000000 : ℝ))/2 by linarith)
    have hp := Real.exp_pos ((1+(47767006226321 / 100000000000000 : ℝ))/2)
    have hm := mul_le_mul h he (Real.exp_pos _).le (by norm_num :
        (0:ℝ) ≤ 47767006226321 / 100000000000000)
    rw [eta_product] at hm
    linarith [lower_product]
  · by_contra hh
    have h : (47767006226322 / 100000000000000 : ℝ) ≤ eta := le_of_not_gt hh
    have he := Real.exp_monotone (show
        (1+(47767006226322 / 100000000000000 : ℝ))/2 ≤ (1+eta)/2 by linarith)
    have hm := mul_le_mul h he (Real.exp_pos _).le eta_pos.le
    rw [eta_product] at hm
    linarith [upper_product]

/-- The decimal in the paper is enclosed by proved rational inequalities. -/
theorem coefficient_bracket :
    (67674105711283 / 100000000000000 : ℝ) < coefficient ∧
    coefficient < 67674105711285 / 100000000000000 := by
  have he := eta_bracket
  have hp : 0 < 1+eta := by linarith [eta_pos]
  unfold coefficient
  constructor
  · apply (lt_div_iff₀ hp).2
    nlinarith
  · apply (div_lt_iff₀ hp).2
    nlinarith

end MatroidProphet
