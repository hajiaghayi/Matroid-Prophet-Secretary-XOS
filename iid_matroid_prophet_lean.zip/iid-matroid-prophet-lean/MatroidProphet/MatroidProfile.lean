import MatroidProphet.Survival
import Mathlib.Combinatorics.Matroid.Closure

namespace MatroidProphet

attribute [local instance] Classical.propDecidable

namespace Cube

/-- Encoding a subset event as a Boolean cube in a specified label order. -/
noncomputable def fromPredicate {α : Type*} [DecidableEq α]
    (labels : List α) (P : Finset α → Prop) (A : Finset α) : Cube labels.length := by
  classical
  exact match labels with
    | [] => .leaf (decide (P A))
    | x::xs => .node (fromPredicate xs P A) (fromPredicate xs P (insert x A))

theorem fromPredicate_implies {α : Type*} [DecidableEq α] (labels : List α)
    (P : Finset α → Prop) (hP : ∀ A B, A ⊆ B → P A → P B)
    {A B : Finset α} (hAB : A ⊆ B) :
    (fromPredicate labels P A).Implies (fromPredicate labels P B) := by
  induction labels generalizing A B with
  | nil => simpa [fromPredicate,Implies] using hP A B hAB
  | cons x xs ih =>
    exact ⟨ih hAB, ih (Finset.insert_subset_insert x hAB)⟩

theorem fromPredicate_increasing {α : Type*} [DecidableEq α] (labels : List α)
    (P : Finset α → Prop) (hP : ∀ A B, A ⊆ B → P A → P B) (A : Finset α) :
    (fromPredicate labels P A).Increasing := by
  induction labels generalizing A with
  | nil => trivial
  | cons x xs ih =>
    exact ⟨ih A, ih (insert x A), fromPredicate_implies xs P hP (Finset.subset_insert _ _)⟩

theorem fromPredicate_zero {α : Type*} [DecidableEq α] (labels : List α)
    (P : Finset α → Prop) (A : Finset α) :
    (fromPredicate labels P A).probability 0 = if P A then 1 else 0 := by
  classical
  induction labels generalizing A with
  | nil => simp [fromPredicate,probability]
  | cons x xs ih => simpa [fromPredicate,probability] using ih A

theorem fromPredicate_one {α : Type*} [DecidableEq α] (labels : List α)
    (P : Finset α → Prop) (A : Finset α) :
    (fromPredicate labels P A).probability 1 = if P (A ∪ labels.toFinset) then 1 else 0 := by
  classical
  induction labels generalizing A with
  | nil => simp [fromPredicate,probability]
  | cons x xs ih =>
    simp only [fromPredicate, probability, sub_self, zero_mul, one_mul, zero_add]
    rw [ih]
    have he : insert x A ∪ xs.toFinset = A ∪ (x :: xs).toFinset := by
      ext a
      simp only [Finset.mem_union, Finset.mem_insert, List.toFinset_cons]
      tauto
    rw [he]

end Cube

variable {α : Type*} [DecidableEq α]

/-- The absence-set event for the genuine mathlib matroid closure operation. -/
def Unspanned (M : Matroid α) (others : Finset α) (e : α) (absent : Finset α) : Prop :=
  e ∉ M.closure (↑(others \ absent) : Set α)

theorem unspanned_mono (M : Matroid α) (others : Finset α) (e : α)
    {A B : Finset α} (hAB : A ⊆ B) : Unspanned M others e A → Unspanned M others e B := by
  intro h hmem
  apply h
  apply M.closure_mono _ hmem
  intro x hx
  simp only [Finset.mem_coe, Finset.mem_sdiff] at hx ⊢
  exact ⟨hx.1, fun ha => hx.2 (hAB ha)⟩

/-- The Bernoulli nonspanning profile constructed from the matroid, rather
than supplied as an unproved shape assumption. Each listed label has its
own independent Bernoulli bit. -/
noncomputable def nonspanningCube (M : Matroid α) (labels : List α) (e : α) :
    Cube labels.length := Cube.fromPredicate labels (Unspanned M labels.toFinset e) ∅

noncomputable def nonspanning (M : Matroid α) (labels : List α) (e : α) : ℝ → ℝ :=
  (nonspanningCube M labels e).survival

theorem nonspanning_increasing (M : Matroid α) (labels : List α) (e : α) :
    (nonspanningCube M labels e).Increasing := by
  apply Cube.fromPredicate_increasing
  intro A B hAB
  exact unspanned_mono M labels.toFinset e hAB

theorem nonspanning_endpoints (M : Matroid α) (labels : List α) (e : α)
    (hloop : e ∉ M.closure ∅) (hspan : e ∈ M.closure (↑labels.toFinset : Set α)) :
    nonspanning M labels e 0 = 1 ∧ nonspanning M labels e 1 = 0 := by
  classical
  unfold nonspanning Cube.survival nonspanningCube
  constructor
  · rw [show (1-(0:ℝ)) = 1 by norm_num, Cube.fromPredicate_one]
    simp [Unspanned,hloop]
  · rw [show (1-(1:ℝ)) = 0 by norm_num, Cube.fromPredicate_zero]
    have ht : e ∈ M.closure {a | a ∈ labels} := by simpa using hspan
    simp [Unspanned, ht]

/-- Every nonloop, noncoloop tag admits the exact local competitive cutoff.
The only matroid assumptions are its closure and the two stated endpoints. -/
theorem matroid_local_cutoff (M : Matroid α) (labels : List α) (e : α)
    (hloop : e ∉ M.closure ∅) (hspan : e ∈ M.closure (↑labels.toFinset : Set α)) :
    ∃ q ∈ Set.Ioo (0:ℝ) 1, ∀ v ∈ Set.Icc (0:ℝ) 1,
      coefficient * drop q v (nonspanning M labels e v) ≤ min v q := by
  have he := nonspanning_endpoints M labels e hloop hspan
  have hf := nonspanning_increasing M labels e
  have hprob : (nonspanningCube M labels e).probability 1 = 1 := by
    simpa [nonspanning,Cube.survival] using he.1
  have hshape : ExponentialShape (nonspanning M labels e) := Cube.survival_shape _ hf hprob
  have hc : Continuous (nonspanning M labels e) := by
    apply continuous_iff_continuousAt.mpr
    intro v
    exact ((nonspanningCube M labels e).survival_hasDerivAt v).continuousAt
  obtain ⟨q,hq,hcal⟩ := calibrated_cutoff hc.continuousOn he.1 he.2
  refine ⟨q,hq,fun v hv => ?_⟩
  apply profile_band hshape he.1 he.2 _ hq hv hcal
  intro t ht
  exact Cube.probability_pos _ hprob (by linarith [ht.2]) (by linarith [ht.1])

end MatroidProphet
