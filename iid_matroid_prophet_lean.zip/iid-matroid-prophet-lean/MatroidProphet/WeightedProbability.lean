import MatroidProphet.Quantile
import MatroidProphet.Tail
import Mathlib.MeasureTheory.Integral.Layercake

open MeasureTheory Set
namespace MatroidProphet
namespace RankModel
variable {α : Type*} [DecidableEq α]

/-- Sum of the weights accepted by the online threshold policy. -/
noncomputable def policyValue (R : RankModel α) (I : Finset α) (labels : List α)
    (g : ℝ → ℝ) : QuantileSpace labels.length → ℝ := match labels with
  | [] => fun _ => 0
  | e::rest => fun z => if z.1 ∈ Ioc 0 (R.cutoff I rest e) then
      g z.1+R.policyValue (insert e I) rest g z.2
    else R.policyValue I rest g z.2

 theorem policyValue_measurable (R : RankModel α) (I : Finset α) (labels : List α)
    {g : ℝ → ℝ} (hg : Measurable g) : Measurable (R.policyValue I labels g) := by
  induction labels generalizing I with
  | nil => exact measurable_const
  | cons e rest ih =>
    exact Measurable.ite (measurableSet_Ioc.preimage measurable_fst)
      ((hg.comp measurable_fst).add ((ih (insert e I)).comp measurable_snd))
      ((ih I).comp measurable_snd)

 theorem policyValue_nonneg (R : RankModel α) (I : Finset α) (labels : List α)
    {g : ℝ → ℝ} (hg : ∀ x, 0 ≤ g x) (z : QuantileSpace labels.length) :
    0 ≤ R.policyValue I labels g z := by
  induction labels generalizing I with
  | nil => exact le_rfl
  | cons e rest ih =>
    dsimp [policyValue]
    split_ifs
    · exact add_nonneg (hg _) (ih _ _)
    · exact ih _ _

/-- Number of accepted weights exceeding a fixed level. -/
noncomputable def weightBand (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) : ℝ :=
  R.policyValue I labels (fun u => if t < weightQuantile μ u then 1 else 0) z

 theorem weightBand_joint (R : RankModel α) (μ : Measure ℝ) (I : Finset α) (labels : List α) :
    Measurable (fun z : QuantileSpace labels.length × ℝ => R.weightBand μ I labels z.1 z.2) := by
  induction labels generalizing I with
  | nil => exact measurable_const
  | cons e rest ih =>
    change Measurable (fun z : (ℝ × QuantileSpace rest.length) × ℝ =>
      if z.1.1 ∈ Ioc 0 (R.cutoff I rest e) then
        (if z.2 < weightQuantile μ z.1.1 then (1:ℝ) else 0)+
          R.weightBand μ (insert e I) rest z.1.2 z.2
      else R.weightBand μ I rest z.1.2 z.2)
    apply Measurable.ite (measurableSet_Ioc.preimage (measurable_fst.comp measurable_fst))
    · apply Measurable.add
      · exact Measurable.ite (measurableSet_lt measurable_snd
          ((weightQuantile_measurable μ).comp (measurable_fst.comp measurable_fst)))
          measurable_const measurable_const
      · exact (ih (insert e I)).comp
          ((measurable_snd.comp measurable_fst).prodMk measurable_snd)
    · exact (ih I).comp ((measurable_snd.comp measurable_fst).prodMk measurable_snd)

 theorem weightBand_nonneg (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) :
    0 ≤ R.weightBand μ I labels z t :=
  R.policyValue_nonneg I labels (fun _ => by split_ifs <;> norm_num) z

 theorem weightBand_le (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) (t : ℝ) :
    R.weightBand μ I labels z t ≤ labels.length := by
  induction labels generalizing I with
  | nil => simp [weightBand,policyValue]
  | cons e rest ih =>
    have h1 := ih I z.2
    have h2 := ih (insert e I) z.2
    change (if z.1 ∈ Ioc 0 (R.cutoff I rest e) then
      (if t < weightQuantile μ z.1 then 1 else 0)+R.weightBand μ (insert e I) rest z.2 t
      else R.weightBand μ I rest z.2 t) ≤ _
    simp only [List.length_cons,Nat.cast_add,Nat.cast_one]
    split_ifs <;> linarith

 theorem weightBand_integrable (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (t : ℝ) :
    Integrable (fun z => R.weightBand μ I labels z t) (quantileMeasure labels.length) := by
  apply (integrable_const (labels.length:ℝ)).mono'
    ((R.weightBand_joint μ I labels).comp (measurable_id.prodMk measurable_const)).aestronglyMeasurable
  filter_upwards [] with z
  change ‖R.weightBand μ I labels z t‖ ≤ _
  rw [Real.norm_eq_abs,abs_of_nonneg (R.weightBand_nonneg μ I labels z t)]
  exact R.weightBand_le μ I labels z t

/-- Expected selected count for an actual weight threshold is the band recurrence. -/
theorem integral_weightBand (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) {t : ℝ} (ht : 0 ≤ t) :
    (∫ z, R.weightBand μ I labels z t ∂quantileMeasure labels.length) =
      R.algorithmBand I labels (lawTail μ t) := by
  induction labels generalizing I with
  | nil => simp [weightBand,policyValue,algorithmBand]
  | cons e rest ih =>
    have hi := R.weightBand_integrable μ I (e::rest) t
    change Integrable (fun z => R.weightBand μ I (e::rest) z t)
      (uniformQuantile.prod (quantileMeasure rest.length)) at hi
    change (∫ z, R.weightBand μ I (e::rest) z t
      ∂uniformQuantile.prod (quantileMeasure rest.length)) = _
    rw [integral_prod _ hi]
    have he : (fun x => ∫ y, R.weightBand μ I (e::rest) (x,y) t ∂quantileMeasure rest.length) =
        fun x : ℝ => if x ∈ Ioc 0 (R.cutoff I rest e) then
          (if t < weightQuantile μ x then 1 else 0)+R.algorithmBand (insert e I) rest (lawTail μ t)
        else R.algorithmBand I rest (lawTail μ t) := by
      funext x
      by_cases hx : x ∈ Ioc 0 (R.cutoff I rest e)
      · change (∫ y, (if x ∈ Ioc 0 (R.cutoff I rest e) then
          (if t < weightQuantile μ x then 1 else 0)+R.weightBand μ (insert e I) rest y t
          else R.weightBand μ I rest y t) ∂quantileMeasure rest.length) = _
        simp only [hx,if_true]
        rw [integral_add (integrable_const (if t < weightQuantile μ x then (1:ℝ) else 0))
          (R.weightBand_integrable μ (insert e I) rest t)]
        rw [integral_const,measureReal_univ_eq_one,one_smul,ih]
      · simpa only [weightBand,policyValue,hx,if_false] using ih I
    rw [he]
    have hae : (fun x : ℝ => if x ∈ Ioc 0 (R.cutoff I rest e) then
        (if t < weightQuantile μ x then 1 else 0)+R.algorithmBand (insert e I) rest (lawTail μ t)
        else R.algorithmBand I rest (lawTail μ t)) =ᵐ[uniformQuantile]
      (fun x : ℝ => if x ∈ Ioc 0 (R.cutoff I rest e) then
        (if x ≤ lawTail μ t then 1 else 0)+R.algorithmBand (insert e I) rest (lawTail μ t)
        else R.algorithmBand I rest (lawTail μ t)) := by
      filter_upwards [uniformQuantile_ae_Ioo,uniformQuantile_ae_ne (lawTail μ t)] with x hx hn
      have heq : (t < weightQuantile μ x) ↔ x ≤ lawTail μ t := by
        rw [weightQuantile_gt_iff μ hx ht]
        exact lt_iff_le_and_ne.trans (by simp [hn])
      simp only [heq]
    rw [integral_congr_ae hae,uniform_step (R.cutoff_bounds I rest e) (lawTail_range μ t)]
    dsimp [algorithmBand]
    ring

theorem scalar_cake (w : ℝ) :
    (∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal (if t < w then (1:ℝ) else 0)) = ENNReal.ofReal w := by
  have he : (fun t : ℝ => ENNReal.ofReal (if t < w then (1:ℝ) else 0)) =
      (Iio w).indicator (fun _ => (1:ENNReal)) := by ext t; by_cases h:t<w <;> simp [h]
  rw [he,lintegral_indicator measurableSet_Iio]
  have hi : Iio w ∩ Ioi (0:ℝ) = Ioo 0 w := by ext t; simp [and_comm]
  simp [Measure.restrict_apply measurableSet_Iio,hi,Real.volume_Ioo]

/-- The layer-cake identity holds pointwise for the weights actually selected. -/
theorem policyValue_cake (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) :
    ENNReal.ofReal (R.policyValue I labels (weightQuantile μ) z) =
      ∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal (R.weightBand μ I labels z t) := by
  induction labels generalizing I with
  | nil => simp [policyValue,weightBand]
  | cons e rest ih =>
    by_cases hx : z.1 ∈ Ioc 0 (R.cutoff I rest e)
    · conv_lhs => rw [policyValue]; simp only [hx,if_true]
      have he : (fun t => ENNReal.ofReal (R.weightBand μ I (e::rest) z t)) =
        fun t => ENNReal.ofReal (if t < weightQuantile μ z.1 then (1:ℝ) else 0)+
          ENNReal.ofReal (R.weightBand μ (insert e I) rest z.2 t) := by
        funext t
        dsimp [weightBand,policyValue]
        simp only [hx,if_true]
        rw [ENNReal.ofReal_add (by split_ifs <;> norm_num)
          (R.policyValue_nonneg _ _ (fun _ => by split_ifs <;> norm_num) _)]
      rw [he,lintegral_add_left]
      · rw [ENNReal.ofReal_add (weightQuantile_nonneg μ _) (R.policyValue_nonneg _ _ (weightQuantile_nonneg μ) _),
          scalar_cake,ih]
      · exact (Measurable.ite (measurableSet_lt measurable_id measurable_const)
          measurable_const measurable_const).ennreal_ofReal
    · simpa only [weightBand,policyValue,hx,if_false] using ih I z.2

/-- Exact expected value of the policy for an arbitrary common quantile law. -/
theorem expected_policyValue (R : RankModel α) (μ : Measure ℝ) (I : Finset α) (labels : List α) :
    (∫⁻ z, ENNReal.ofReal (R.policyValue I labels (weightQuantile μ) z)
      ∂quantileMeasure labels.length) = R.tailAlgorithm I labels (lawTail μ) := by
  simp_rw [R.policyValue_cake μ I labels]
  rw [lintegral_lintegral_swap]
  · unfold tailAlgorithm
    rw [← restrict_Ioi_eq_restrict_Ici]
    apply setLIntegral_congr_fun measurableSet_Ioi
    intro t ht
    dsimp only
    rw [← ofReal_integral_eq_lintegral_ofReal (R.weightBand_integrable μ I labels t)
      (Filter.Eventually.of_forall (fun z => R.weightBand_nonneg μ I labels z t)),
      integral_weightBand R μ I labels ht.le]
  · exact (R.weightBand_joint μ I labels).ennreal_ofReal.aemeasurable

end RankModel
end MatroidProphet
