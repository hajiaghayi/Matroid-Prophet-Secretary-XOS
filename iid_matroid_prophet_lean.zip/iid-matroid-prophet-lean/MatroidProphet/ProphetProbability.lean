import MatroidProphet.RankProbability

open MeasureTheory Set
namespace MatroidProphet
variable {α : Type*} [DecidableEq α]

/-- Weight vector revealed by a stream of independent quantiles. -/
noncomputable def streamWeights (μ : Measure ℝ) (labels : List α)
    (z : QuantileSpace labels.length) : α → ℝ := match labels with
  | [] => fun _ => 0
  | e::rest => Function.update (streamWeights μ rest z.2) e (weightQuantile μ z.1)

 theorem streamWeights_nonneg (μ : Measure ℝ) (labels : List α)
    (z : QuantileSpace labels.length) (a : α) : 0 ≤ streamWeights μ labels z a := by
  induction labels with
  | nil => exact le_rfl
  | cons e rest ih =>
    by_cases h : a=e
    · subst a; simpa [streamWeights] using weightQuantile_nonneg μ z.1
    · simpa [streamWeights,Function.update_apply,h] using ih z.2

 theorem streamWeights_measurable (μ : Measure ℝ) (labels : List α) (a : α) :
    Measurable (fun z => streamWeights μ labels z a) := by
  induction labels with
  | nil => exact measurable_const
  | cons e rest ih =>
    by_cases h : a=e
    · subst a
      simpa [streamWeights] using (weightQuantile_measurable μ).comp measurable_fst
    · simpa [streamWeights,Function.update_apply,h] using ih.comp measurable_snd

 theorem upperSet_subset (μ : Measure ℝ) (labels : List α)
    (z : QuantileSpace labels.length) (t : ℝ) : upperSet μ labels z t ⊆ labels.toFinset := by
  induction labels with
  | nil => exact Finset.Subset.refl _
  | cons e rest ih =>
    dsimp [upperSet]
    split_ifs
    · simpa using Finset.insert_subset_insert e (ih z.2)
    · exact (ih z.2).trans (by simp)

 theorem upperSet_eq_filter (μ : Measure ℝ) (labels : List α) (hn : labels.Nodup)
    (z : QuantileSpace labels.length) (t : ℝ) :
    upperSet μ labels z t = labels.toFinset.filter (fun a => t < streamWeights μ labels z a) := by
  induction labels with
  | nil => simp [upperSet]
  | cons e rest ih =>
    have hn' := List.nodup_cons.mp hn
    rw [upperSet]
    rw [ih hn'.2 z.2]
    ext a
    by_cases h : a=e
    · subst a
      by_cases ht : t < weightQuantile μ z.1 <;> simp [streamWeights,hn'.1,ht]
    · by_cases ht : t < weightQuantile μ z.1 <;>
        simp [ht,streamWeights,Function.update_apply,h]

 theorem finset_weight_cake (S : Finset α) (w : α → ℝ) :
    (∑ e ∈ S, ENNReal.ofReal (w e)) =
      ∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal ((S.filter (fun e => t < w e)).card : ℝ) := by
  have hm (e : α) : Measurable (fun t : ℝ => ENNReal.ofReal (if t < w e then (1:ℝ) else 0)) :=
    (Measurable.ite (measurableSet_lt measurable_id measurable_const)
      measurable_const measurable_const).ennreal_ofReal
  calc
    _ = ∑ e ∈ S, ∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal (if t < w e then (1:ℝ) else 0) := by
      apply Finset.sum_congr rfl
      intro e he
      exact (RankModel.scalar_cake (w e)).symm
    _ = ∫⁻ t in Ioi (0:ℝ), ∑ e ∈ S, ENNReal.ofReal (if t < w e then (1:ℝ) else 0) :=
      (lintegral_finset_sum S (fun e _ => hm e)).symm
    _ = _ := by
      apply lintegral_congr
      intro t
      rw [← ENNReal.ofReal_sum_of_nonneg (fun e _ => by split_ifs <;> norm_num),Finset.sum_boole]

section Matroid
variable [Finite α]

 theorem realRank_mono (M : Matroid α) {S T : Finset α} (h : S ⊆ T) : realRank M S ≤ realRank M T := by
  have hn : M.eRk (↑T : Set α) ≠ ⊤ :=
    Matroid.eRk_ne_top_iff.mpr (Matroid.RankFinite.isRkFinite _)
  have he : M.eRk (↑S : Set α) ≤ M.eRk (↑T : Set α) := M.eRk_mono (by exact_mod_cast h)
  unfold realRank
  exact_mod_cast ENat.toNat_le_toNat he hn

 theorem indep_realRank (M : Matroid α) {S : Finset α} (h : M.Indep (↑S : Set α)) :
    realRank M S = (S.card : ℝ) := by
  simp [realRank,h.eRk_eq_encard]

/-- Maximum total weight of an independent subset of the arrived labels. The
supremum is over a finite family, so this is the usual offline optimum. -/
noncomputable def prophetValue (M : Matroid α) (labels : List α) (w : α → ℝ) : ENNReal :=
  ⨆ S : Finset α, ⨆ (_ : S ⊆ labels.toFinset), ⨆ (_ : M.Indep (↑S : Set α)),
    ∑ e ∈ S, ENNReal.ofReal (w e)

/-- Each feasible offline solution is bounded by the rank layer cake. -/
theorem prophetValue_le_cake (M : Matroid α) (μ : Measure ℝ) (labels : List α)
    (hn : labels.Nodup) (z : QuantileSpace labels.length) :
    prophetValue M labels (streamWeights μ labels z) ≤
      ∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal ((matroidRankModel M).rankAt μ ∅ labels z t) := by
  apply iSup_le
  intro S
  apply iSup_le
  intro hS
  apply iSup_le
  intro hI
  rw [finset_weight_cake]
  apply lintegral_mono
  intro t
  apply ENNReal.ofReal_le_ofReal
  rw [RankModel.rankAt_eq]
  simp only [Finset.empty_union]
  have hsub : S.filter (fun e => t < streamWeights μ labels z e) ⊆ upperSet μ labels z t := by
    rw [upperSet_eq_filter μ labels hn]
    exact Finset.filter_subset_filter _ hS
  have hi : M.Indep (↑(S.filter (fun e => t < streamWeights μ labels z e)) : Set α) :=
    hI.subset (by exact_mod_cast Finset.filter_subset (fun e => t < streamWeights μ labels z e) S)
  exact (indep_realRank M hi).symm.le.trans (realRank_mono M hsub)

/-- The rank functional upper-bounds the expectation of the actual prophet. -/
theorem expected_prophet_le (M : Matroid α) (μ : Measure ℝ) (labels : List α)
    (hn : labels.Nodup) :
    (∫⁻ z, prophetValue M labels (streamWeights μ labels z) ∂quantileMeasure labels.length) ≤
      (matroidRankModel M).tailRank ∅ labels (lawTail μ) := by
  calc
    _ ≤ ∫⁻ z, (∫⁻ t in Ioi (0:ℝ), ENNReal.ofReal ((matroidRankModel M).rankAt μ ∅ labels z t))
        ∂quantileMeasure labels.length := lintegral_mono (prophetValue_le_cake M μ labels hn)
    _ = ∫⁻ t in Ioi (0:ℝ), ∫⁻ z, ENNReal.ofReal ((matroidRankModel M).rankAt μ ∅ labels z t)
        ∂quantileMeasure labels.length := lintegral_lintegral_swap
      ((RankModel.rankAt_joint _ μ ∅ labels).ennreal_ofReal.aemeasurable)
    _ = _ := RankModel.expected_rank_cake _ μ labels

/-- Full competitive inequality between the expected actual online reward
and the expected maximum-weight independent set, on the product sample space. -/
theorem matroid_prophet_competitive (M : Matroid α) (μ : Measure ℝ) (labels : List α)
    (hn : labels.Nodup) :
    ENNReal.ofReal coefficient *
      (∫⁻ z, prophetValue M labels (streamWeights μ labels z) ∂quantileMeasure labels.length) ≤
      ∫⁻ z, ENNReal.ofReal ((matroidRankModel M).policyValue ∅ labels (weightQuantile μ) z)
        ∂quantileMeasure labels.length := by
  rw [RankModel.expected_policyValue]
  exact (mul_le_mul_left' (expected_prophet_le M μ labels hn) _).trans
    (matroid_tail_guarantee M labels (lawTail μ) (lawTail_range μ))

/-- Downward-rounded public constant. -/
theorem matroid_prophet_decimal (M : Matroid α) (μ : Measure ℝ) (labels : List α)
    (hn : labels.Nodup) :
    ENNReal.ofReal (6767410571/10000000000 : ℝ) *
      (∫⁻ z, prophetValue M labels (streamWeights μ labels z) ∂quantileMeasure labels.length) ≤
      ∫⁻ z, ENNReal.ofReal ((matroidRankModel M).policyValue ∅ labels (weightQuantile μ) z)
        ∂quantileMeasure labels.length := by
  have hc : (6767410571/10000000000 : ℝ) ≤ coefficient := by linarith [coefficient_bracket.1]
  exact (mul_le_mul_right' (ENNReal.ofReal_le_ofReal hc) _).trans
    (matroid_prophet_competitive M μ labels hn)

end Matroid
end MatroidProphet
