import Mathlib

namespace MatroidProphet

private theorem exists_balancing_parameter :
    ∃ a : ℝ, 0 < a ∧ a < 1 ∧ a^2 = Real.exp (-1-a) := by
  let f : ℝ → ℝ := fun a => a^2 - Real.exp (-1-a)
  have hf : Continuous f := by fun_prop
  have h0 : f 0 < 0 := by dsimp [f]; simpa using (Real.exp_pos (-1))
  have h1 : 0 < f 1 := by
    have h := (Real.exp_lt_one_iff).2 (show (-1-(1:ℝ)) < 0 by norm_num)
    dsimp [f]
    nlinarith
  obtain ⟨a, ha, he⟩ := intermediate_value_Icc (show (0:ℝ) ≤ 1 by norm_num)
    hf.continuousOn (show 0 ∈ Set.Icc (f 0) (f 1) from ⟨h0.le,h1.le⟩)
  refine ⟨a, ?_, ?_, ?_⟩
  · by_contra hh
    have : a = 0 := le_antisymm (le_of_not_gt hh) ha.1
    subst a
    linarith
  · by_contra hh
    have : a = 1 := le_antisymm ha.2 (le_of_not_gt hh)
    subst a
    linarith
  · dsimp [f] at he
    linarith

/-- The unique positive root of `a² = exp(-1-a)`. -/
noncomputable def eta : ℝ := Classical.choose exists_balancing_parameter

theorem eta_pos : 0 < eta := (Classical.choose_spec exists_balancing_parameter).1

theorem eta_lt_one : eta < 1 := (Classical.choose_spec exists_balancing_parameter).2.1

theorem eta_equation : eta^2 = Real.exp (-1-eta) :=
  (Classical.choose_spec exists_balancing_parameter).2.2

theorem balancing_parameter_unique {a b : ℝ} (ha : 0 < a) (hb : 0 < b)
    (hea : a^2 = Real.exp (-1-a)) (heb : b^2 = Real.exp (-1-b)) : a = b := by
  by_contra h
  rcases lt_or_gt_of_ne h with hlt | hgt
  · have he := Real.exp_strictMono (show -1-b < -1-a by linarith)
    nlinarith
  · have he := Real.exp_strictMono (show -1-a < -1-b by linarith)
    nlinarith

/-- The exact coefficient, rather than a floating-point approximation. -/
noncomputable def coefficient : ℝ := 1 / (1+eta)

theorem coefficient_pos : 0 < coefficient := by
  unfold coefficient
  have h := eta_pos
  positivity

theorem coefficient_lt_one : coefficient < 1 := by
  unfold coefficient
  apply (div_lt_one (by linarith [eta_pos])).2
  linarith [eta_pos]

theorem coefficient_small : coefficient * (1+eta) = 1 := by
  unfold coefficient
  have h : 1 + eta ≠ 0 := by linarith [eta_pos]
  field_simp

theorem coefficient_large : coefficient * (1+Real.exp (-1-eta)/eta) = 1 := by
  rw [← eta_equation]
  have h : eta^2/eta = eta := by field_simp
  rw [h]
  exact coefficient_small

end MatroidProphet
