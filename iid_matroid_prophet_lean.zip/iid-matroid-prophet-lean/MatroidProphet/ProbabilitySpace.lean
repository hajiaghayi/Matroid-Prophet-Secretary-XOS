import MatroidProphet.Feasibility
import Mathlib.MeasureTheory.Integral.Prod

open MeasureTheory Set

namespace MatroidProphet

/-- One fresh uniform quantile, with a zero-probability endpoint removed. -/
noncomputable def uniformQuantile : Measure ℝ := volume.restrict (Ioc 0 1)

instance : IsProbabilityMeasure uniformQuantile := by
  constructor
  simp [uniformQuantile, Real.volume_Ioc]

/-- A finite sequence of independent real quantiles. -/
def QuantileSpace : ℕ → Type
  | 0 => Unit
  | n+1 => ℝ × QuantileSpace n

instance quantileMeasurableSpace : (n : ℕ) → MeasurableSpace (QuantileSpace n)
  | 0 => inferInstanceAs (MeasurableSpace Unit)
  | n+1 => @Prod.instMeasurableSpace ℝ (QuantileSpace n) _ (quantileMeasurableSpace n)

noncomputable def quantileMeasure : (n : ℕ) → Measure (QuantileSpace n)
  | 0 => Measure.dirac ()
  | n+1 => uniformQuantile.prod (quantileMeasure n)

instance quantileProbability : (n : ℕ) → IsProbabilityMeasure (quantileMeasure n)
  | 0 => by dsimp [quantileMeasure]; infer_instance
  | n+1 => by
    haveI := quantileProbability n
    change IsProbabilityMeasure (uniformQuantile.prod (quantileMeasure n))
    exact Measure.prod.instIsProbabilityMeasure uniformQuantile (quantileMeasure n)

 theorem uniformQuantile_Ioc {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    uniformQuantile (Ioc 0 q) = ENNReal.ofReal q := by
  rw [uniformQuantile,Measure.restrict_apply measurableSet_Ioc]
  have he : Ioc (0:ℝ) q ∩ Ioc 0 1 = Ioc 0 q :=
    inter_eq_left.mpr (Ioc_subset_Ioc_right hq.2)
  rw [he,Real.volume_Ioc,sub_zero]

 theorem uniformQuantile_Ioc_real {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    uniformQuantile.real (Ioc 0 q) = q := by
  rw [Measure.real,uniformQuantile_Ioc hq,ENNReal.toReal_ofReal hq.1]

/-- Elementary one-step expectation, with arbitrary continuation values. -/
theorem uniform_step {q v A B : ℝ} (hq : q ∈ Icc (0:ℝ) 1) (hv : v ∈ Icc (0:ℝ) 1) :
    (∫ x, (if x ∈ Ioc 0 q then (if x ≤ v then 1 else 0)+A else B) ∂uniformQuantile) =
      min v q+q*A+(1-q)*B := by
  let f1 : ℝ → ℝ := (Ioc 0 (min v q)).indicator (fun _ => 1)
  let f2 : ℝ → ℝ := (Ioc 0 q).indicator (fun _ => A)
  let f3 : ℝ → ℝ := (Ioc 0 q)ᶜ.indicator (fun _ => B)
  have he : (fun x : ℝ => if x ∈ Ioc 0 q then (if x ≤ v then 1 else 0)+A else B) =
      fun x => f1 x+f2 x+f3 x := by
    funext x
    dsimp [f1,f2,f3,Set.indicator]
    split_ifs <;> simp_all only [mem_Ioc,mem_compl_iff,le_min_iff] <;> aesop
  have h1 : Integrable f1 uniformQuantile := (integrable_const 1).indicator measurableSet_Ioc
  have h2 : Integrable f2 uniformQuantile := (integrable_const A).indicator measurableSet_Ioc
  have h3 : Integrable f3 uniformQuantile := (integrable_const B).indicator measurableSet_Ioc.compl
  rw [he]
  change (∫ x, (f1+f2) x+f3 x ∂uniformQuantile) = _
  rw [integral_add (h1.add h2) h3]
  change (∫ x, f1 x+f2 x ∂uniformQuantile)+(∫ x,f3 x ∂uniformQuantile) = _
  rw [integral_add h1 h2]
  dsimp [f1,f2,f3]
  rw [integral_indicator_const,integral_indicator_const,integral_indicator_const]
  · rw [uniformQuantile_Ioc_real ⟨le_min hv.1 hq.1,(min_le_right _ _).trans hq.2⟩,
        uniformQuantile_Ioc_real hq]
    have hm : uniformQuantile.real (Ioc 0 q)ᶜ = 1-q := by
      rw [measureReal_compl measurableSet_Ioc,measureReal_univ_eq_one,uniformQuantile_Ioc_real hq]
    rw [hm]
    simp only [smul_eq_mul,mul_one]
  all_goals measurability

namespace RankModel
variable {α : Type*} [DecidableEq α]

/-- Actual band reward of the sequential policy on a stream of quantiles. -/
noncomputable def bandCount (R : RankModel α) (I : Finset α) (labels : List α)
    (v : ℝ) : QuantileSpace labels.length → ℝ := match labels with
  | [] => fun _ => 0
  | e::rest => fun z => if z.1 ∈ Ioc 0 (R.cutoff I rest e) then
      (if z.1 ≤ v then 1 else 0)+R.bandCount (insert e I) rest v z.2
    else R.bandCount I rest v z.2

 theorem bandCount_measurable (R : RankModel α) (I : Finset α) (labels : List α) (v : ℝ) :
    Measurable (R.bandCount I labels v) := by
  induction labels generalizing I with
  | nil => exact measurable_const
  | cons e rest ih =>
    apply Measurable.ite (measurableSet_Ioc.preimage measurable_fst)
    · apply Measurable.add
      · exact Measurable.ite (measurableSet_le measurable_fst measurable_const) measurable_const measurable_const
      · exact (ih (insert e I)).comp measurable_snd
    · exact (ih I).comp measurable_snd

 theorem bandCount_bounds (R : RankModel α) (I : Finset α) (labels : List α) (v : ℝ)
    (z : QuantileSpace labels.length) : 0 ≤ R.bandCount I labels v z ∧ R.bandCount I labels v z ≤ labels.length := by
  induction labels generalizing I with
  | nil => simp [bandCount]
  | cons e rest ih =>
    have h1 := ih I z.2
    have h2 := ih (insert e I) z.2
    dsimp [bandCount]
    split_ifs <;> simp only [List.length_cons,Nat.cast_add,Nat.cast_one] <;> constructor <;> linarith

 theorem bandCount_integrable (R : RankModel α) (I : Finset α) (labels : List α) (v : ℝ) :
    Integrable (R.bandCount I labels v) (quantileMeasure labels.length) := by
  apply (integrable_const (labels.length:ℝ)).mono' (R.bandCount_measurable I labels v).aestronglyMeasurable
  filter_upwards [] with z
  rw [Real.norm_eq_abs,abs_of_nonneg (R.bandCount_bounds I labels v z).1]
  exact (R.bandCount_bounds I labels v z).2

/-- The recursive band formula is the integral of the actual sequential reward
on a product probability space of fresh independent uniform quantiles. -/
theorem integral_bandCount (R : RankModel α) (I : Finset α) (labels : List α)
    {v : ℝ} (hv : v ∈ Icc (0:ℝ) 1) :
    (∫ z, R.bandCount I labels v z ∂quantileMeasure labels.length) =
      R.algorithmBand I labels v := by
  induction labels generalizing I with
  | nil => simp [bandCount,algorithmBand]
  | cons e rest ih =>
    have hi := R.bandCount_integrable I (e::rest) v
    change Integrable (R.bandCount I (e::rest) v)
      (uniformQuantile.prod (quantileMeasure rest.length)) at hi
    change (∫ z, R.bandCount I (e::rest) v z
      ∂uniformQuantile.prod (quantileMeasure rest.length)) = _
    rw [integral_prod _ hi]
    have he : (fun x => ∫ y, R.bandCount I (e::rest) v (x,y) ∂quantileMeasure rest.length) =
        fun x : ℝ => if x ∈ Ioc 0 (R.cutoff I rest e) then
          (if x ≤ v then 1 else 0)+R.algorithmBand (insert e I) rest v
        else R.algorithmBand I rest v := by
      funext x
      by_cases hx : x ∈ Ioc 0 (R.cutoff I rest e)
      · simp only [bandCount,hx,if_true]
        rw [integral_add (integrable_const (if x ≤ v then (1:ℝ) else 0)) (R.bandCount_integrable (insert e I) rest v)]
        rw [integral_const,measureReal_univ_eq_one,one_smul,ih]
      · simpa only [bandCount,hx,if_false] using ih I
    rw [he,uniform_step (R.cutoff_bounds I rest e) hv]
    dsimp [algorithmBand]
    ring

end RankModel
end MatroidProphet
