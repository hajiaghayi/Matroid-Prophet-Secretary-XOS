import MatroidProphet.Profile

namespace MatroidProphet

/-- Calculus part of the entropy argument. Survival.lean supplies this
differential inequality for increasing Boolean events. -/
theorem shape_of_entropy_bound {S S' : ℝ → ℝ}
    (hder : ∀ x ∈ Set.Ioo (0:ℝ) 1, HasDerivAt S (S' x) x)
    (hpos : ∀ x ∈ Set.Ioo (0:ℝ) 1, 0 < S x)
    (hent : ∀ x ∈ Set.Ioo (0:ℝ) 1,
      -(S x)*Real.log (S x) ≤ x * (-(S' x))) :
    ExponentialShape S := by
  let f : ℝ → ℝ := fun x => -Real.log (S x)/x
  have hd : ∀ x ∈ Set.Ioo (0:ℝ) 1,
      HasDerivAt f ((Real.log (S x)-x*(S' x)/(S x))/x^2) x := by
    intro x hx
    have h := ((hder x hx).log (ne_of_gt (hpos x hx))).neg.div
      (hasDerivAt_id x) (ne_of_gt hx.1)
    convert h using 1 <;> dsimp [f]
    field_simp
    <;> ring
  have hn : ∀ x ∈ Set.Ioo (0:ℝ) 1,
      0 ≤ (Real.log (S x)-x*(S' x)/(S x))/x^2 := by
    intro x hx
    apply div_nonneg _ (sq_nonneg _)
    have he := hent x hx
    have hp := hpos x hx
    have heq : Real.log (S x)-x*(S' x)/(S x) =
        ((S x)*Real.log (S x)-x*(S' x))/(S x) := by field_simp
    rw [heq]
    exact div_nonneg (by nlinarith) hp.le
  unfold ExponentialShape
  apply monotoneOn_of_hasDerivWithinAt_nonneg (f' := fun x =>
    (Real.log (S x)-x*(S' x)/(S x))/x^2) (convex_Ioo 0 1)
  · exact continuousOn_of_forall_continuousAt (fun x hx => (hd x hx).continuousAt)
  · intro x hx
    rw [interior_Ioo] at hx ⊢
    exact (hd x hx).hasDerivWithinAt
  · simpa only [interior_Ioo] using hn

end MatroidProphet
