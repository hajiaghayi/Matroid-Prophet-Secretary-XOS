import MatroidProphet.OnlineTheorem

open MeasureTheory Set
namespace MatroidProphet

 theorem prophetValue_finite {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (labels : List α) (w : α → ℝ) : prophetValue M labels w ≠ ⊤ := by
  have h : prophetValue M labels w ≤ ∑ a ∈ labels.toFinset, ENNReal.ofReal (w a) := by
    apply iSup_le
    intro S
    apply iSup_le
    intro hS
    apply iSup_le
    intro hI
    exact Finset.sum_le_sum_of_subset hS
  exact ne_top_of_le_ne_top (ENNReal.sum_ne_top.mpr (fun _ _ => ENNReal.ofReal_ne_top)) h

 theorem observedValue_nonneg_ae {α : Type*} [DecidableEq α] (R : RankModel α)
    (μ : Measure ℝ) [IsProbabilityMeasure μ] (hμ : μ (Ici (0:ℝ))ᶜ = 0)
    (I : Finset α) (labels : List α) :
    ∀ᵐ z ∂onlineMeasure μ labels.length, 0 ≤ R.observedValue I labels z := by
  rw [← observationLift_map μ hμ labels.length]
  rw [ae_map_iff (observationLift_measurable μ labels.length).aemeasurable
    (measurableSet_le measurable_const (R.observedValue_measurable I labels))]
  exact Filter.Eventually.of_forall (fun z => by
    rw [RankModel.observedValue_lift]
    exact R.policyValue_nonneg I labels (weightQuantile_nonneg μ) z)

 theorem expected_online_finite {α : Type*} [DecidableEq α] (R : RankModel α)
    (μ : Measure ℝ) [IsProbabilityMeasure μ] (hμ : μ (Ici (0:ℝ))ᶜ = 0)
    (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤) (I : Finset α) (labels : List α) :
    (∫⁻ z, ENNReal.ofReal (R.observedValue I labels z) ∂onlineMeasure μ labels.length) ≠ ⊤ := by
  rw [expected_observedValue R μ hμ I labels]
  exact ne_top_of_le_ne_top (ENNReal.mul_ne_top ENNReal.ofReal_ne_top
    (by rwa [lawTail_mean μ hμ]))
    (R.tailAlgorithm_le I labels (lawTail μ) (lawTail_range μ))

 theorem observedValue_integrable {α : Type*} [DecidableEq α] (R : RankModel α)
    (μ : Measure ℝ) [IsProbabilityMeasure μ] (hμ : μ (Ici (0:ℝ))ᶜ = 0)
    (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤) (I : Finset α) (labels : List α) :
    Integrable (R.observedValue I labels) (onlineMeasure μ labels.length) := by
  refine ⟨(R.observedValue_measurable I labels).aestronglyMeasurable,?_⟩
  apply (hasFiniteIntegral_iff_ofReal (observedValue_nonneg_ae R μ hμ I labels)).mpr
  exact lt_top_iff_ne_top.mpr (expected_online_finite R μ hμ hmean I labels)

 theorem expected_prophet_finite {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤)
    (labels : List α) (hn : labels.Nodup) :
    (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length) ≠ ⊤ := by
  rw [expected_prophet_iid M μ hμ labels]
  exact ne_top_of_le_ne_top (ENNReal.mul_ne_top ENNReal.ofReal_ne_top
    (by rwa [lawTail_mean μ hμ]))
    ((expected_prophet_le M μ labels hn).trans
      (RankModel.tailRank_le _ ∅ labels (lawTail μ) (lawTail_range μ)))

 theorem prophet_integrable {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤)
    (labels : List α) (hn : labels.Nodup) :
    Integrable (fun w => (prophetValue M labels (streamVector labels w)).toReal)
      (iidMeasure μ labels.length) := by
  refine ⟨(prophet_stream_measurable M labels).ennreal_toReal.aestronglyMeasurable,?_⟩
  apply (hasFiniteIntegral_iff_ofReal (Filter.Eventually.of_forall (fun _ => ENNReal.toReal_nonneg))).mpr
  simp_rw [ENNReal.ofReal_toReal (prophetValue_finite M labels _)]
  exact lt_top_iff_ne_top.mpr (expected_prophet_finite M μ hμ hmean labels hn)

/-- Conventional expectation formulation of the full theorem. The prophet is
the maximum over independent subsets and the online value is the sum accepted
by the observation-based policy. Both functions are integrable. -/
theorem main_theorem {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤)
    (labels : List α) (hn : labels.Nodup) :
    coefficient * (∫ w, (prophetValue M labels (streamVector labels w)).toReal
      ∂iidMeasure μ labels.length) ≤
      ∫ z, (matroidRankModel M).observedValue ∅ labels z ∂onlineMeasure μ labels.length := by
  rw [integral_eq_lintegral_of_nonneg_ae
    (Filter.Eventually.of_forall (fun _ => ENNReal.toReal_nonneg))
    (prophet_stream_measurable M labels).ennreal_toReal.aestronglyMeasurable]
  rw [integral_eq_lintegral_of_nonneg_ae
    (observedValue_nonneg_ae _ μ hμ ∅ labels)
    ((matroidRankModel M).observedValue_measurable ∅ labels).aestronglyMeasurable]
  simp_rw [ENNReal.ofReal_toReal (prophetValue_finite M labels _)]
  exact online_iid_matroid_prophet_real M μ hμ hmean labels hn

/-- The same conventional expectation statement with the certified decimal. -/
theorem main_theorem_decimal {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤)
    (labels : List α) (hn : labels.Nodup) :
    (6767410571/10000000000:ℝ) * (∫ w, (prophetValue M labels (streamVector labels w)).toReal
      ∂iidMeasure μ labels.length) ≤
      ∫ z, (matroidRankModel M).observedValue ∅ labels z ∂onlineMeasure μ labels.length := by
  have hc : (6767410571/10000000000:ℝ) ≤ coefficient := by linarith [coefficient_bracket.1]
  have hp : 0 ≤ ∫ w, (prophetValue M labels (streamVector labels w)).toReal
      ∂iidMeasure μ labels.length := integral_nonneg (fun _ => ENNReal.toReal_nonneg)
  exact (mul_le_mul_of_nonneg_right hc hp).trans (main_theorem M μ hμ hmean labels hn)

end MatroidProphet
