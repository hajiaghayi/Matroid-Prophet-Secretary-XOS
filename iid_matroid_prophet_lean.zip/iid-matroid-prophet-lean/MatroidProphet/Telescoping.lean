import Mathlib

namespace MatroidProphet

/-- Summing conditional rank comparisons covers the initial potential. -/
theorem telescope {n : ℕ} {c : ℝ} {potential reward : ℕ → ℝ}
    (hstep : ∀ i < n, c * (potential i - potential (i+1)) ≤ reward i)
    (hterminal : potential n = 0) :
    c * potential 0 ≤ ∑ i ∈ Finset.range n, reward i := by
  have h := Finset.sum_le_sum (s := Finset.range n) (fun i hi => hstep i (Finset.mem_range.mp hi))
  have hs : (∑ i ∈ Finset.range n, c * (potential i-potential (i+1))) =
      c * (potential 0-potential n) := by
    rw [← Finset.mul_sum]
    have ht := Finset.sum_range_sub potential n
    have he : (∑ i ∈ Finset.range n, (potential i-potential (i+1))) =
        -(∑ i ∈ Finset.range n, (potential (i+1)-potential i)) := by
      rw [← Finset.sum_neg_distrib]
      apply Finset.sum_congr rfl
      intro i hi
      ring
    rw [he, ht]
    ring
  rw [hs, hterminal, sub_zero] at h
  exact h

/-- Finite layer-cake: nonnegative weighted band guarantees imply a weight guarantee. -/
theorem combine_bands {ι : Type*} (s : Finset ι) {c : ℝ}
    {increments accepted benchmark : ι → ℝ}
    (hnonneg : ∀ i ∈ s, 0 ≤ increments i)
    (hband : ∀ i ∈ s, c * benchmark i ≤ accepted i) :
    c * (∑ i ∈ s, increments i * benchmark i) ≤
      ∑ i ∈ s, increments i * accepted i := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  have h := mul_le_mul_of_nonneg_left (hband i hi) (hnonneg i hi)
  nlinarith

end MatroidProphet
