import MatroidProphet.RuntimePolicy
import Mathlib.Probability.Kernel.Disintegration.StandardBorel

open MeasureTheory Set ProbabilityTheory
namespace MatroidProphet

/-- The law of a finite stream of independent observations. -/
noncomputable def iidMeasure (μ : Measure ℝ) : (n : ℕ) → Measure (QuantileSpace n)
  | 0 => Measure.dirac ()
  | n+1 => μ.prod (iidMeasure μ n)

instance iidProbability (μ : Measure ℝ) [IsProbabilityMeasure μ] :
    (n : ℕ) → IsProbabilityMeasure (iidMeasure μ n)
  | 0 => by dsimp [iidMeasure]; infer_instance
  | n+1 => by
    haveI := iidProbability μ n
    change IsProbabilityMeasure (μ.prod (iidMeasure μ n))
    exact Measure.prod.instIsProbabilityMeasure μ (iidMeasure μ n)

/-- Apply the same measurable transformation to every coordinate. -/
def streamMap (f : ℝ → ℝ) : (n : ℕ) → QuantileSpace n → QuantileSpace n
  | 0 => id
  | n+1 => Prod.map f (streamMap f n)

 theorem streamMap_measurable {f : ℝ → ℝ} (hf : Measurable f) :
    (n : ℕ) → Measurable (streamMap f n)
  | 0 => measurable_id
  | n+1 => hf.prodMap (streamMap_measurable hf n)

/-- Inverse transformation realizes the full product law, hence independence
as well as the individual weight distributions. -/
theorem streamQuantile_map (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (n : ℕ) :
    Measure.map (streamMap (weightQuantile μ) n) (quantileMeasure n) = iidMeasure μ n := by
  induction n with
  | zero => exact Measure.map_id
  | succ n ih =>
    change Measure.map (Prod.map (weightQuantile μ) (streamMap (weightQuantile μ) n))
      (uniformQuantile.prod (quantileMeasure n)) = μ.prod (iidMeasure μ n)
    rw [← Measure.map_prod_map _ _ (weightQuantile_measurable μ)
      (streamMap_measurable (weightQuantile_measurable μ) n),weightQuantile_map μ hμ,ih]

/-- Joint distribution of the observed weight and its randomized quantile. -/
noncomputable def observationLaw (μ : Measure ℝ) : Measure (ℝ × ℝ) :=
  Measure.map (fun u => (weightQuantile μ u,u)) uniformQuantile

instance observationProbability (μ : Measure ℝ) : IsProbabilityMeasure (observationLaw μ) :=
  Measure.isProbabilityMeasure_map ((weightQuantile_measurable μ).prodMk measurable_id).aemeasurable

/-- Local randomization kernel: it is sampled after seeing the current weight.
Its arguments contain no other weights or future arrivals. -/
noncomputable def quantileKernel (μ : Measure ℝ) : Kernel ℝ ℝ := (observationLaw μ).condKernel

instance quantileKernel_markov (μ : Measure ℝ) : IsMarkovKernel (quantileKernel μ) := by
  dsimp [quantileKernel]
  infer_instance

/-- The auxiliary quantile can be generated from the observed weight alone.
Disintegration handles all atoms, including zero, without a density assumption. -/
theorem observation_disintegration (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) : μ.compProd (quantileKernel μ) = observationLaw μ := by
  have hf : (observationLaw μ).fst = μ := by
    exact (Measure.fst_map_prodMk (Y:=fun u : ℝ => u) measurable_id).trans (weightQuantile_map μ hμ)
  calc
    _ = (observationLaw μ).fst.compProd (quantileKernel μ) := by rw [hf]
    _ = _ := Measure.disintegrate (observationLaw μ) (observationLaw μ).condKernel

/-- Forgetting weights leaves a fresh uniform quantile. -/
theorem observation_quantile_marginal (μ : Measure ℝ) :
    (observationLaw μ).snd = uniformQuantile := by
  rw [observationLaw,Measure.snd_map_prodMk (weightQuantile_measurable μ),Measure.map_id']

variable {α : Type*} [DecidableEq α]

/-- The coordinate vector of an ordinary stream of weights. -/
noncomputable def streamVector (labels : List α) (z : QuantileSpace labels.length) : α → ℝ :=
  match labels with
  | [] => fun _ => 0
  | e::rest => Function.update (streamVector rest z.2) e z.1

 theorem streamVector_measurable (labels : List α) (a : α) :
    Measurable (fun z => streamVector labels z a) := by
  induction labels with
  | nil => exact measurable_const
  | cons e rest ih =>
    by_cases h : a=e
    · subst a; simpa [streamVector] using (measurable_fst : Measurable (fun z : ℝ × QuantileSpace rest.length => z.1))
    · simpa [streamVector,Function.update_apply,h] using ih.comp measurable_snd

 theorem streamVector_quantile (μ : Measure ℝ) (labels : List α) (z : QuantileSpace labels.length) :
    streamVector labels (streamMap (weightQuantile μ) labels.length z) = streamWeights μ labels z := by
  induction labels with
  | nil => rfl
  | cons e rest ih =>
    change Function.update (streamVector rest (streamMap (weightQuantile μ) rest.length z.2)) e
      (weightQuantile μ z.1) = Function.update (streamWeights μ rest z.2) e (weightQuantile μ z.1)
    rw [ih]

section
variable [Finite α]

 theorem prophet_stream_measurable (M : Matroid α) (labels : List α) :
    Measurable (fun z => prophetValue M labels (streamVector labels z)) := by
  letI := Fintype.ofFinite α
  apply Measurable.iSup
  intro S
  apply Measurable.iSup
  intro hS
  apply Measurable.iSup
  intro hI
  exact S.measurable_sum (fun a _ => (streamVector_measurable labels a).ennreal_ofReal)

/-- The prophet expectation is taken under the specified common law itself. -/
theorem expected_prophet_iid (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (labels : List α) :
    (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length) =
      ∫⁻ z, prophetValue M labels (streamWeights μ labels z) ∂quantileMeasure labels.length := by
  rw [← streamQuantile_map μ hμ labels.length,
    lintegral_map (prophet_stream_measurable M labels)
      (streamMap_measurable (weightQuantile_measurable μ) labels.length)]
  simp only [streamVector_quantile]

/-- Main probability-space theorem. Weights are independent with the arbitrary
specified nonnegative common law. The reward is the sum on the policy's output. -/
theorem iid_matroid_prophet (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (labels : List α) (hn : labels.Nodup) :
    ENNReal.ofReal coefficient *
      (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length) ≤
      ∫⁻ z, ENNReal.ofReal (∑ a ∈ (matroidRankModel M).selectedNew ∅ labels z,
        streamWeights μ labels z a) ∂quantileMeasure labels.length := by
  rw [expected_prophet_iid M μ hμ labels]
  have h := matroid_prophet_competitive M μ labels hn
  simpa only [RankModel.policyValue_eq_selected_sum _ μ _ labels hn] using h

/-- The advertised decimal version of the probability-space theorem. -/
theorem iid_matroid_prophet_decimal (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (labels : List α) (hn : labels.Nodup) :
    ENNReal.ofReal (6767410571/10000000000:ℝ) *
      (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length) ≤
      ∫⁻ z, ENNReal.ofReal (∑ a ∈ (matroidRankModel M).selectedNew ∅ labels z,
        streamWeights μ labels z a) ∂quantileMeasure labels.length := by
  have hc : (6767410571/10000000000:ℝ) ≤ coefficient := by linarith [coefficient_bracket.1]
  exact (mul_le_mul_right' (ENNReal.ofReal_le_ofReal hc) _).trans
    (iid_matroid_prophet M μ hμ labels hn)

end
end MatroidProphet
