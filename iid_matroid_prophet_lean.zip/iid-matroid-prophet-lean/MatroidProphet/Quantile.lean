import MatroidProphet.ProbabilitySpace
import Mathlib.Probability.CDF

open MeasureTheory Set Filter ProbabilityTheory
open scoped Topology

namespace MatroidProphet

/-- The decreasing inverse CDF, with harmless endpoint values set to zero. -/
noncomputable def weightQuantile (μ : Measure ℝ) (u : ℝ) : ℝ :=
  if u ∈ Ioo (0:ℝ) 1 then sInf {x : ℝ | 0 ≤ x ∧ 1-u ≤ cdf μ x} else 0

private theorem quantile_set_nonempty (μ : Measure ℝ) {u : ℝ} (hu : u ∈ Ioo (0:ℝ) 1) :
    {x : ℝ | 0 ≤ x ∧ 1-u ≤ cdf μ x}.Nonempty := by
  have hf : ∀ᶠ x in atTop, 1-u < cdf μ x :=
    (tendsto_cdf_atTop μ).eventually (eventually_gt_nhds (by linarith [hu.1] : 1-u < 1))
  obtain ⟨x,hx,hf⟩ := ((eventually_ge_atTop (0:ℝ)).and hf).exists
  exact ⟨x,hx,hf.le⟩

theorem weightQuantile_nonneg (μ : Measure ℝ) (u : ℝ) : 0 ≤ weightQuantile μ u := by
  unfold weightQuantile
  split_ifs with hu
  · exact le_csInf (quantile_set_nonempty μ hu) (fun x hx => hx.1)
  · exact le_rfl

/-- Inversion holds at atoms as well as at continuity points. -/
theorem weightQuantile_le_iff (μ : Measure ℝ) {u t : ℝ}
    (hu : u ∈ Ioo (0:ℝ) 1) (ht : 0 ≤ t) :
    weightQuantile μ u ≤ t ↔ 1-u ≤ cdf μ t := by
  let S : Set ℝ := {x | 0 ≤ x ∧ 1-u ≤ cdf μ x}
  have hne : S.Nonempty := quantile_set_nonempty μ hu
  have hb : BddBelow S := ⟨0,fun x hx => hx.1⟩
  have hq : weightQuantile μ u = sInf S := by simp [weightQuantile,hu,S]
  have hs : 1-u ≤ cdf μ (sInf S) := by
    have hh : ∀ x > sInf S, 1-u ≤ cdf μ x := by
      intro x hx
      obtain ⟨a,ha,hax⟩ := exists_lt_of_csInf_lt hne hx
      exact ha.2.trans ((monotone_cdf μ) hax.le)
    have hc := (cdf μ).right_continuous (sInf S)
    have hl : Tendsto (fun n : ℕ => sInf S+1/((n:ℝ)+1)) atTop (𝓝 (sInf S)) := by
      simpa using tendsto_const_nhds.add tendsto_one_div_add_atTop_nhds_zero_nat
    have hw : Tendsto (fun n : ℕ => sInf S+1/((n:ℝ)+1)) atTop (𝓝[Ici (sInf S)] (sInf S)) :=
      tendsto_nhdsWithin_iff.mpr ⟨hl,Eventually.of_forall (fun n => by
        simp only [mem_Ici]; exact le_add_of_nonneg_right (by positivity))⟩
    exact le_of_tendsto_of_tendsto' tendsto_const_nhds (hc.tendsto.comp hw)
      (fun n => hh _ (lt_add_of_pos_right _ (by positivity)))
  rw [hq]
  constructor
  · intro h
    exact hs.trans ((monotone_cdf μ) h)
  · intro h
    exact csInf_le hb ⟨ht,h⟩

theorem weightQuantile_measurable (μ : Measure ℝ) : Measurable (weightQuantile μ) := by
  apply measurable_of_Iic
  intro t
  by_cases ht : 0 ≤ t
  · have he : (weightQuantile μ ⁻¹' Iic t) =
        (Ioo (0:ℝ) 1 ∩ Ici (1-cdf μ t)) ∪ (Ioo (0:ℝ) 1)ᶜ := by
      ext u
      by_cases hu : u ∈ Ioo (0:ℝ) 1
      · simp only [mem_preimage,mem_Iic,mem_union,mem_inter_iff,mem_Ici,mem_compl_iff,hu,
          true_and,not_true_eq_false,or_false]
        rw [weightQuantile_le_iff μ hu ht]
        constructor <;> intro h <;> linarith
      · simp [weightQuantile,hu,ht]
    rw [he]
    measurability
  · have he : weightQuantile μ ⁻¹' Iic t = ∅ := by
      ext u
      simp only [mem_preimage,mem_Iic,mem_empty_iff_false,iff_false]
      exact not_le.mpr ((lt_of_not_ge ht).trans_le (weightQuantile_nonneg μ u))
    rw [he]
    exact MeasurableSet.empty

theorem uniformQuantile_ae_ne (a : ℝ) : ∀ᵐ u ∂uniformQuantile, u ≠ a := by
  apply ae_iff.mpr
  have he : {u : ℝ | ¬u ≠ a} = {a} := by ext u; simp
  rw [he,uniformQuantile,Measure.restrict_apply (measurableSet_singleton a)]
  exact measure_mono_null inter_subset_left (measure_singleton a)

/-- The removed endpoints have probability zero. -/
theorem uniformQuantile_ae_Ioo : ∀ᵐ u ∂uniformQuantile, u ∈ Ioo (0:ℝ) 1 := by
  have hn := uniformQuantile_ae_ne 1
  filter_upwards [ae_restrict_mem measurableSet_Ioc,hn] with u hu hn
  exact ⟨hu.1,lt_of_le_of_ne hu.2 hn⟩

noncomputable def lawTail (μ : Measure ℝ) (t : ℝ) : ℝ := 1-cdf μ t

theorem lawTail_range (μ : Measure ℝ) (t : ℝ) : lawTail μ t ∈ Icc (0:ℝ) 1 := by
  constructor <;> dsimp [lawTail] <;> linarith [cdf_nonneg μ t,cdf_le_one μ t]

theorem lawTail_measurable (μ : Measure ℝ) : Measurable (lawTail μ) :=
  measurable_const.sub (monotone_cdf μ).measurable

theorem weightQuantile_gt_iff (μ : Measure ℝ) {u t : ℝ}
    (hu : u ∈ Ioo (0:ℝ) 1) (ht : 0 ≤ t) :
    t < weightQuantile μ u ↔ u < lawTail μ t := by
  rw [← not_le,weightQuantile_le_iff μ hu ht]
  dsimp [lawTail]
  constructor <;> intro h <;> linarith

theorem lawTail_measure (μ : Measure ℝ) [IsProbabilityMeasure μ] (t : ℝ) :
    ENNReal.ofReal (lawTail μ t) = μ (Ioi t) := by
  rw [← compl_Iic,measure_compl measurableSet_Iic (measure_ne_top _ _),measure_univ,
    ← ofReal_cdf]
  rw [lawTail,ENNReal.ofReal_sub 1 (cdf_nonneg μ t),ENNReal.ofReal_one]

/-- Exact upper-tail law of the inverse CDF; no atomlessness assumption. -/
theorem weightQuantile_tail (μ : Measure ℝ) {t : ℝ} (ht : 0 ≤ t) :
    uniformQuantile {u | t < weightQuantile μ u} = ENNReal.ofReal (lawTail μ t) := by
  have he : {u | t < weightQuantile μ u} =ᵐ[uniformQuantile] Ioo 0 (lawTail μ t) := by
    filter_upwards [uniformQuantile_ae_Ioo] with u hu
    change (t < weightQuantile μ u) = (u ∈ Ioo 0 (lawTail μ t))
    apply propext
    simpa only [mem_Ioo,hu.1,true_and] using weightQuantile_gt_iff μ hu ht
  rw [measure_congr he,uniformQuantile,Measure.restrict_apply measurableSet_Ioo]
  have hi : Ioo (0:ℝ) (lawTail μ t) ∩ Ioc 0 1 = Ioo 0 (lawTail μ t) :=
    inter_eq_left.mpr (fun u hu => ⟨hu.1,hu.2.le.trans (lawTail_range μ t).2⟩)
  rw [hi,Real.volume_Ioo,sub_zero]

/-- Every nonnegative real probability law is realized by the constructed
quantile function on one uniform draw. -/
theorem weightQuantile_map (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) :
    Measure.map (weightQuantile μ) uniformQuantile = μ := by
  haveI : IsProbabilityMeasure (Measure.map (weightQuantile μ) uniformQuantile) :=
    Measure.isProbabilityMeasure_map (weightQuantile_measurable μ).aemeasurable
  apply Measure.ext_of_Iic
  intro t
  by_cases ht : 0 ≤ t
  · have htail : (Measure.map (weightQuantile μ) uniformQuantile) (Ioi t) = μ (Ioi t) := by
      rw [Measure.map_apply (weightQuantile_measurable μ) measurableSet_Ioi]
      exact (weightQuantile_tail μ ht).trans (lawTail_measure μ t)
    have hc1 := measure_compl measurableSet_Ioi
      (measure_ne_top (Measure.map (weightQuantile μ) uniformQuantile) (Ioi t))
    have hc2 := measure_compl measurableSet_Ioi (measure_ne_top μ (Ioi t))
    rw [compl_Ioi,measure_univ,htail] at hc1
    rw [compl_Ioi,measure_univ] at hc2
    exact hc1.trans hc2.symm
  · rw [Measure.map_apply (weightQuantile_measurable μ) measurableSet_Iic]
    have hp : weightQuantile μ ⁻¹' Iic t = ∅ := by
      ext u
      simp only [mem_preimage,mem_Iic,mem_empty_iff_false,iff_false]
      exact not_le.mpr ((lt_of_not_ge ht).trans_le (weightQuantile_nonneg μ u))
    rw [hp,measure_empty]
    symm
    apply measure_mono_null _ hμ
    intro x hx
    simp only [mem_Iic] at hx
    simp only [mem_compl_iff,mem_Ici,not_le]
    exact hx.trans_lt (lt_of_not_ge ht)

end MatroidProphet
