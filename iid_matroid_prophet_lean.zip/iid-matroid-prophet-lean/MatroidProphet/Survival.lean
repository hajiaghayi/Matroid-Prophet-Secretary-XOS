import MatroidProphet.BooleanCube
import MatroidProphet.Shape

namespace MatroidProphet

private theorem ent_le_one_sub {p : ℝ} (hp : 0 < p) : ent p ≤ 1-p := by
  have h := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hp) hp.le
  have he : p*(1-p⁻¹) = p-1 := by field_simp
  rw [he] at h
  unfold ent
  linarith

namespace Cube

/-- The probability an increasing absence-bit event holds at presence rate v. -/
noncomputable def survival {n : ℕ} (f : Cube n) (v : ℝ) : ℝ := f.probability (1-v)

theorem survival_hasDerivAt {n : ℕ} (f : Cube n) (v : ℝ) :
    HasDerivAt f.survival (-f.slope (1-v)) v := by
  have hl := (hasDerivAt_const v (1:ℝ)).sub (hasDerivAt_id v)
  convert (f.hasDerivAt_probability (1-v)).comp v hl using 1 <;> simp [survival]

theorem entropy_survival {n : ℕ} (f : Cube n) (hf : f.Increasing)
    {v : ℝ} (hv : v ∈ Set.Ioo (0:ℝ) 1) :
    -(f.survival v)*Real.log (f.survival v) ≤ v*f.slope (1-v) := by
  have hp : 0 < 1-v := by linarith [hv.2]
  have hp1 : 1-v < 1 := by linarith [hv.1]
  have hb := f.entropy_bound hf hp hp1
  have hs := f.slope_nonneg hf ⟨hp.le,hp1.le⟩
  have he := mul_le_mul_of_nonneg_right (ent_le_one_sub hp) hs
  dsimp [survival]
  exact hb.trans (by convert he using 1 <;> ring)

theorem probability_pos {n : ℕ} (f : Cube n) (h1 : f.probability 1 = 1)
    {p : ℝ} (hp : 0 < p) (hp1 : p < 1) : 0 < f.probability p := by
  induction f with
  | leaf b => cases b <;> simp_all [probability]
  | node lo hi ihlo ihhi =>
    have hh : hi.probability 1 = 1 := by simpa [probability] using h1
    have hpos := ihhi hh
    have hl := (lo.probability_bounds ⟨hp.le,hp1.le⟩).1
    dsimp [probability]
    exact add_pos_of_nonneg_of_pos (mul_nonneg (by linarith) hl) (mul_pos hp hpos)

/-- Exponential shape for all nontrivial increasing Boolean events. -/
theorem survival_shape {n : ℕ} (f : Cube n) (hf : f.Increasing)
    (h1 : f.probability 1 = 1) : ExponentialShape f.survival := by
  apply shape_of_entropy_bound (S' := fun v => -f.slope (1-v))
  · intro v hv
    exact f.survival_hasDerivAt v
  · intro v hv
    exact f.probability_pos h1 (by linarith [hv.2]) (by linarith [hv.1])
  · intro v hv
    simpa only [neg_neg] using f.entropy_survival hf hv

end Cube
end MatroidProphet
