import MatroidProphet.ObservationLaw
import MatroidProphet.Order
import MatroidProphet.FiniteMean

open MeasureTheory Set ProbabilityTheory
namespace MatroidProphet

/-- At each step the pair is (observed weight, locally randomized quantile). -/
def ObservationSpace : ℕ → Type
  | 0 => Unit
  | n+1 => (ℝ × ℝ) × ObservationSpace n

instance observationMeasurableSpace : (n : ℕ) → MeasurableSpace (ObservationSpace n)
  | 0 => inferInstanceAs (MeasurableSpace Unit)
  | n+1 => @Prod.instMeasurableSpace (ℝ × ℝ) (ObservationSpace n) _ (observationMeasurableSpace n)

/-- A weight is drawn from μ, then its auxiliary quantile from the local kernel.
The pairs at distinct steps are independent. -/
noncomputable def onlineMeasure (μ : Measure ℝ) : (n : ℕ) → Measure (ObservationSpace n)
  | 0 => Measure.dirac ()
  | n+1 => (μ.compProd (quantileKernel μ)).prod (onlineMeasure μ n)

instance onlineProbability (μ : Measure ℝ) [IsProbabilityMeasure μ] :
    (n : ℕ) → IsProbabilityMeasure (onlineMeasure μ n)
  | 0 => by dsimp [onlineMeasure]; infer_instance
  | n+1 => by
    haveI := onlineProbability μ n
    change IsProbabilityMeasure ((μ.compProd (quantileKernel μ)).prod (onlineMeasure μ n))
    exact Measure.prod.instIsProbabilityMeasure _ _

def quantileProjection : (n : ℕ) → ObservationSpace n → QuantileSpace n
  | 0 => id
  | n+1 => fun z => (z.1.2,quantileProjection n z.2)

def weightProjection : (n : ℕ) → ObservationSpace n → QuantileSpace n
  | 0 => id
  | n+1 => fun z => (z.1.1,weightProjection n z.2)

 theorem quantileProjection_measurable : (n : ℕ) → Measurable (quantileProjection n)
  | 0 => measurable_id
  | n+1 => (measurable_snd.comp measurable_fst).prodMk
      ((quantileProjection_measurable n).comp measurable_snd)

 theorem weightProjection_measurable : (n : ℕ) → Measurable (weightProjection n)
  | 0 => measurable_id
  | n+1 => (measurable_fst.comp measurable_fst).prodMk
      ((weightProjection_measurable n).comp measurable_snd)

noncomputable def observationLift (μ : Measure ℝ) : (n : ℕ) → QuantileSpace n → ObservationSpace n
  | 0 => id
  | n+1 => Prod.map (fun u => (weightQuantile μ u,u)) (observationLift μ n)

 theorem observationLift_measurable (μ : Measure ℝ) :
    (n : ℕ) → Measurable (observationLift μ n)
  | 0 => measurable_id
  | n+1 => ((weightQuantile_measurable μ).prodMk measurable_id).prodMap (observationLift_measurable μ n)

 theorem observationLift_map (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (n : ℕ) :
    Measure.map (observationLift μ n) (quantileMeasure n) = onlineMeasure μ n := by
  induction n with
  | zero => exact Measure.map_id
  | succ n ih =>
    change Measure.map (Prod.map (fun u => (weightQuantile μ u,u)) (observationLift μ n))
      (uniformQuantile.prod (quantileMeasure n)) =
      (μ.compProd (quantileKernel μ)).prod (onlineMeasure μ n)
    have hm : Measurable (fun u : ℝ => (weightQuantile μ u,u)) :=
      (weightQuantile_measurable μ).prodMk measurable_id
    rw [← Measure.map_prod_map _ _ hm
      (observationLift_measurable μ n),ih,observation_disintegration μ hμ]
    rfl

 theorem quantileProjection_lift (μ : Measure ℝ) (n : ℕ) (z : QuantileSpace n) :
    quantileProjection n (observationLift μ n z) = z := by
  induction n with
  | zero => rfl
  | succ n ih => exact Prod.ext rfl (ih z.2)

 theorem weightProjection_lift (μ : Measure ℝ) (n : ℕ) (z : QuantileSpace n) :
    weightProjection n (observationLift μ n z) = streamMap (weightQuantile μ) n z := by
  induction n with
  | zero => rfl
  | succ n ih => exact Prod.ext rfl (ih z.2)

/-- The weight observations themselves have exactly the required product law. -/
theorem online_weights_law (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (n : ℕ) :
    Measure.map (weightProjection n) (onlineMeasure μ n) = iidMeasure μ n := by
  rw [← observationLift_map μ hμ n,Measure.map_map (weightProjection_measurable n)
    (observationLift_measurable μ n)]
  have he : weightProjection n ∘ observationLift μ n = streamMap (weightQuantile μ) n :=
    funext (weightProjection_lift μ n)
  rw [he,streamQuantile_map μ hμ n]

/-- Local randomization recovers independent fresh uniform quantiles. -/
theorem online_quantiles_law (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (n : ℕ) :
    Measure.map (quantileProjection n) (onlineMeasure μ n) = quantileMeasure n := by
  rw [← observationLift_map μ hμ n,Measure.map_map (quantileProjection_measurable n)
    (observationLift_measurable μ n)]
  have he : quantileProjection n ∘ observationLift μ n = id := funext (quantileProjection_lift μ n)
  rw [he,Measure.map_id]

namespace RankModel
variable {α : Type*} [DecidableEq α]

/-- The sequential control flow: inspect the current observation, compare its
local quantile with the rank cutoff, and add the observed weight if accepted. -/
noncomputable def observedValue (R : RankModel α) (I : Finset α) (labels : List α)
    (z : ObservationSpace labels.length) : ℝ := match labels with
  | [] => 0
  | e::rest => if z.1.2 ∈ Ioc 0 (R.cutoff I rest e) then
      z.1.1+R.observedValue (insert e I) rest z.2 else R.observedValue I rest z.2

 theorem observedValue_measurable (R : RankModel α) (I : Finset α) (labels : List α) :
    Measurable (R.observedValue I labels) := by
  induction labels generalizing I with
  | nil => exact measurable_const
  | cons e rest ih =>
    exact Measurable.ite (measurableSet_Ioc.preimage (measurable_snd.comp measurable_fst))
      ((measurable_fst.comp measurable_fst).add ((ih (insert e I)).comp measurable_snd))
      ((ih I).comp measurable_snd)

 theorem observedValue_lift (R : RankModel α) (μ : Measure ℝ) (I : Finset α)
    (labels : List α) (z : QuantileSpace labels.length) :
    R.observedValue I labels (observationLift μ labels.length z) =
      R.policyValue I labels (weightQuantile μ) z := by
  induction labels generalizing I with
  | nil => rfl
  | cons e rest ih =>
    change (if z.1 ∈ Ioc 0 (R.cutoff I rest e) then
      weightQuantile μ z.1+R.observedValue (insert e I) rest (observationLift μ rest.length z.2)
      else R.observedValue I rest (observationLift μ rest.length z.2)) = _
    simp only [ih,policyValue]

 theorem observedValue_eq_sum (R : RankModel α) (I : Finset α) (labels : List α)
    (hn : labels.Nodup) (z : ObservationSpace labels.length) :
    R.observedValue I labels z =
      ∑ a ∈ R.selectedNew I labels (quantileProjection labels.length z),
        streamVector labels (weightProjection labels.length z) a := by
  induction labels generalizing I with
  | nil => simp [observedValue,selectedNew]
  | cons e rest ih =>
    have hn' := List.nodup_cons.mp hn
    let u := quantileProjection rest.length z.2
    have he (J : Finset α) : e ∉ R.selectedNew J rest u := by
      intro hm
      exact hn'.1 (List.mem_toFinset.mp (R.selectedNew_subset J rest u hm))
    have hsum (J : Finset α) :
        (∑ a ∈ R.selectedNew J rest u, streamVector (e::rest) (weightProjection (e::rest).length z) a) =
        ∑ a ∈ R.selectedNew J rest u, streamVector rest (weightProjection rest.length z.2) a := by
      apply Finset.sum_congr rfl
      intro a ha
      have hne : a ≠ e := by intro hh; subst a; exact he J ha
      simp [streamVector,weightProjection,hne]
    change R.observedValue I (e::rest) z =
      ∑ a ∈ (if z.1.2 ∈ Ioc 0 (R.cutoff I rest e) then
        insert e (R.selectedNew (insert e I) rest u) else R.selectedNew I rest u),
        streamVector (e::rest) (weightProjection (e::rest).length z) a
    by_cases hx : z.1.2 ∈ Ioc 0 (R.cutoff I rest e)
    · simp only [observedValue,hx,if_true]
      rw [Finset.sum_insert (he (insert e I)),hsum,← ih (insert e I) hn'.2 z.2]
      simp [streamVector,weightProjection]
    · simp only [observedValue,hx,if_false]
      rw [hsum]
      exact ih I hn'.2 z.2

end RankModel

/-- Exact law of the implemented online policy. -/
theorem expected_observedValue {α : Type*} [DecidableEq α] (R : RankModel α)
    (μ : Measure ℝ) [IsProbabilityMeasure μ] (hμ : μ (Ici (0:ℝ))ᶜ = 0)
    (I : Finset α) (labels : List α) :
    (∫⁻ z, ENNReal.ofReal (R.observedValue I labels z) ∂onlineMeasure μ labels.length) =
      R.tailAlgorithm I labels (lawTail μ) := by
  rw [← observationLift_map μ hμ labels.length,
    lintegral_map (R.observedValue_measurable I labels).ennreal_ofReal (observationLift_measurable μ labels.length)]
  simp only [RankModel.observedValue_lift]
  exact R.expected_policyValue μ I labels

/-- Competitive theorem entirely in the observation model: the input weights
have law μ and the algorithm uses only local randomization after each reveal. -/
theorem online_iid_matroid_prophet {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (labels : List α) (hn : labels.Nodup) :
    ENNReal.ofReal coefficient *
      (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length) ≤
      ∫⁻ z, ENNReal.ofReal ((matroidRankModel M).observedValue ∅ labels z)
        ∂onlineMeasure μ labels.length := by
  rw [expected_observedValue _ μ hμ ∅ labels,expected_prophet_iid M μ hμ labels]
  exact (mul_le_mul_left' (expected_prophet_le M μ labels hn) _).trans
    (matroid_tail_guarantee M labels (lawTail μ) (lawTail_range μ))

/-- The public decimal guarantee for arbitrary nonnegative i.i.d. laws. -/
theorem online_iid_matroid_prophet_decimal {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (labels : List α) (hn : labels.Nodup) :
    ENNReal.ofReal (6767410571/10000000000:ℝ) *
      (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length) ≤
      ∫⁻ z, ENNReal.ofReal ((matroidRankModel M).observedValue ∅ labels z)
        ∂onlineMeasure μ labels.length := by
  have hc : (6767410571/10000000000:ℝ) ≤ coefficient := by linarith [coefficient_bracket.1]
  exact (mul_le_mul_right' (ENNReal.ofReal_le_ofReal hc) _).trans
    (online_iid_matroid_prophet M μ hμ labels hn)

/-- The actual observation-based policy returns an independent set on every
stream, including streams outside the support of the input distribution. -/
theorem online_policy_independent {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (labels : List α) (z : ObservationSpace labels.length) :
    M.Indep (↑((matroidRankModel M).selectedNew ∅ labels
      (quantileProjection labels.length z)) : Set α) :=
  matroid_selectedNew_independent M labels _

/-- Averaging over an independent arrival order preserves the guarantee.
In particular the order distribution can be uniform over all permutations. -/
theorem random_order_iid_matroid_prophet {α β : Type*} [DecidableEq α] [Finite α]
    [MeasurableSpace β] (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (ρ : Measure β) (order : β → List α)
    (hn : ∀ᵐ b ∂ρ, (order b).Nodup) :
    ENNReal.ofReal coefficient *
      (∫⁻ b, (∫⁻ w, prophetValue M (order b) (streamVector (order b) w)
        ∂iidMeasure μ (order b).length) ∂ρ) ≤
      ∫⁻ b, (∫⁻ z, ENNReal.ofReal ((matroidRankModel M).observedValue ∅ (order b) z)
        ∂onlineMeasure μ (order b).length) ∂ρ := by
  rw [← lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply lintegral_mono_ae
  filter_upwards [hn] with b hb
  exact online_iid_matroid_prophet M μ hμ (order b) hb

/-- The survival-tail mean is the mean of the specified common law. -/
theorem lawTail_mean (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) :
    RankModel.tailMean (lawTail μ) = ∫⁻ x, ENNReal.ofReal x ∂μ := by
  unfold RankModel.tailMean
  rw [← restrict_Ioi_eq_restrict_Ici]
  simp_rw [lawTail_measure]
  have hn : ∀ᵐ x ∂μ, (0:ℝ) ≤ x := by
    simpa only [mem_Ici] using (mem_ae_iff.mpr hμ : ∀ᵐ x ∂μ, x ∈ Ici (0:ℝ))
  exact (lintegral_eq_lintegral_meas_lt μ hn measurable_id.aemeasurable).symm

/-- For finite-mean laws both sides are finite, giving the ordinary real-valued
competitive inequality by taking their real values. -/
theorem online_iid_matroid_prophet_real {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (μ : Measure ℝ) [IsProbabilityMeasure μ]
    (hμ : μ (Ici (0:ℝ))ᶜ = 0) (hmean : (∫⁻ x, ENNReal.ofReal x ∂μ) ≠ ⊤)
    (labels : List α) (hn : labels.Nodup) :
    coefficient *
      (∫⁻ w, prophetValue M labels (streamVector labels w) ∂iidMeasure μ labels.length).toReal ≤
      (∫⁻ z, ENNReal.ofReal ((matroidRankModel M).observedValue ∅ labels z)
        ∂onlineMeasure μ labels.length).toReal := by
  have hfin : (∫⁻ z, ENNReal.ofReal ((matroidRankModel M).observedValue ∅ labels z)
      ∂onlineMeasure μ labels.length) ≠ ⊤ := by
    rw [expected_observedValue _ μ hμ ∅ labels]
    exact ne_top_of_le_ne_top (ENNReal.mul_ne_top ENNReal.ofReal_ne_top
      (by rwa [lawTail_mean μ hμ]))
      (RankModel.tailAlgorithm_le _ ∅ labels (lawTail μ) (lawTail_range μ))
  have hh := ENNReal.toReal_mono hfin (online_iid_matroid_prophet M μ hμ labels hn)
  simpa only [ENNReal.toReal_mul,ENNReal.toReal_ofReal coefficient_pos.le] using hh

end MatroidProphet
