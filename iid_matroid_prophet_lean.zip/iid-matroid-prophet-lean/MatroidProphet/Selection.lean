import MatroidProphet.RankModel
import MatroidProphet.Telescoping

namespace MatroidProphet
namespace RankModel

attribute [local instance] Classical.propDecidable
variable {α : Type*} [DecidableEq α]

 theorem average_insert (labels : List α) (f : Finset α → ℝ) (I : Finset α) (e : α) (v : ℝ) :
    average labels (fun A => f (insert e A)) I v = average labels f (insert e I) v := by
  induction labels generalizing I with
  | nil => rfl
  | cons x xs ih => simp only [average,ih,Finset.insert_comm]

 theorem average_const_on (labels : List α) (f : Finset α → ℝ) (I : Finset α) (v c : ℝ)
    (hf : ∀ A, I ⊆ A → A ⊆ I ∪ labels.toFinset → f A = c) :
    average labels f I v = c := by
  induction labels generalizing I with
  | nil => simpa [average] using hf I (by rfl) (by simp)
  | cons e rest ih =>
    have hl := ih I (fun A hIA hA => hf A hIA (hA.trans (by
      intro x hx
      simp only [Finset.mem_union, List.mem_toFinset, List.mem_cons] at hx ⊢
      tauto)))
    have hr := ih (insert e I) (fun A hIA hA => hf A
      ((Finset.subset_insert _ _).trans hIA) (hA.trans (by intro x hx; simpa [Finset.mem_union,Finset.mem_insert,or_assoc,or_comm,or_left_comm] using hx)))
    dsimp [average]
    rw [hl,hr]
    ring

noncomputable def potential (R : RankModel α) (I : Finset α) (labels : List α) (v : ℝ) : ℝ :=
  average labels R.rank I v-R.rank I

 theorem profile_diff (R : RankModel α) (I : Finset α) (labels : List α) (e : α) (v : ℝ) :
    R.profile I labels e v = average labels R.rank (insert e I) v-average labels R.rank I v := by
  rw [profile_average]
  unfold increment
  rw [average_sub,average_insert]

 theorem potential_drop (R : RankModel α) (I : Finset α) (labels : List α) (e : α)
    (v q : ℝ) :
    R.potential I (e::labels) v-
      ((1-q)*R.potential I labels v+q*R.potential (insert e I) labels v) =
      q*R.increment I e+(v-q)*R.profile I labels e v := by
  rw [profile_diff]
  dsimp [potential,average,increment]
  ring

 theorem profile_constant (R : RankModel α) (I : Finset α) (labels : List α) (e : α)
    (h : R.increment I e = R.increment (I ∪ labels.toFinset) e) (v : ℝ) :
    R.profile I labels e v = R.increment I e := by
  rw [profile_average]
  apply average_const_on
  intro A hIA hA
  have h1 := R.diminishing I A hIA e
  have h2 := R.diminishing A (I ∪ labels.toFinset) hA e
  dsimp [increment] at h ⊢
  linarith

noncomputable def cutoff (R : RankModel α) (I : Finset α) (labels : List α) (e : α) : ℝ :=
  if h0 : R.increment I e = 0 then 0 else
  if h1 : R.increment (I ∪ labels.toFinset) e = 1 then 1 else
    Classical.choose (R.profile_cutoff I labels e
      ((R.unit I e).resolve_left h0) ((R.unit (I ∪ labels.toFinset) e).resolve_right h1))

 theorem cutoff_bounds (R : RankModel α) (I : Finset α) (labels : List α) (e : α) :
    R.cutoff I labels e ∈ Set.Icc (0:ℝ) 1 := by
  unfold cutoff
  split_ifs with h0 h1
  · simp
  · simp
  · have h := Classical.choose_spec (R.profile_cutoff I labels e
      ((R.unit I e).resolve_left h0) ((R.unit (I ∪ labels.toFinset) e).resolve_right h1))
    exact ⟨h.1.1.le,h.1.2.le⟩

 theorem cutoff_step (R : RankModel α) (I : Finset α) (labels : List α) (e : α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) :
    coefficient * (R.potential I (e::labels) v-
      ((1-R.cutoff I labels e)*R.potential I labels v+
        R.cutoff I labels e*R.potential (insert e I) labels v)) ≤ min v (R.cutoff I labels e) := by
  rw [potential_drop]
  unfold cutoff
  split_ifs with h0 h1
  · have hend : R.increment (I ∪ labels.toFinset) e = 0 := by
      have hd := R.diminishing I (I ∪ labels.toFinset) (Finset.subset_union_left) e
      rcases R.unit (I ∪ labels.toFinset) e with h | h
      · exact h
      · dsimp [increment] at h0 ⊢; linarith
    have hs := profile_constant R I labels e (h0.trans hend.symm) v
    rw [hs,h0]
    simp [min_eq_right hv.1]
  · have hstart : R.increment I e = 1 := (R.unit I e).resolve_left h0
    have hs := profile_constant R I labels e (hstart.trans h1.symm) v
    rw [hs,hstart]
    simp only [one_mul,min_eq_left hv.2]
    have hc := coefficient_lt_one.le
    nlinarith [mul_le_mul_of_nonneg_right hc hv.1]
  · have hstart : R.increment I e = 1 := (R.unit I e).resolve_left h0
    have hend : R.increment (I ∪ labels.toFinset) e = 0 := (R.unit (I ∪ labels.toFinset) e).resolve_right h1
    have hcal := Classical.choose_spec (R.profile_cutoff I labels e hstart hend)
    let q := Classical.choose (R.profile_cutoff I labels e hstart hend)
    have hq : q ∈ Set.Ioo (0:ℝ) 1 := hcal.1
    have hinc := eventCube_increasing labels (fun A => R.increment A e = 1) (R.increment_antitone e) I
    have hp1 : (R.profileCube I labels e).probability 1 = 1 := by
      unfold profileCube
      rw [eventCube_one]
      simp [hstart]
    have hshape := Cube.survival_shape (R.profileCube I labels e) hinc hp1
    have hs0 : R.profile I labels e 0 = 1 := by simpa [profile,Cube.survival] using hp1
    have hs1 : R.profile I labels e 1 = 0 := by
      unfold profile Cube.survival profileCube
      rw [show (1-(1:ℝ)) = 0 by norm_num,eventCube_zero]
      simp [hend]
    have hb := profile_band hshape hs0 hs1 (fun t ht =>
      Cube.probability_pos _ hp1 (by linarith [ht.2]) (by linarith [ht.1])) hq hv hcal.2
    simpa only [hstart,mul_one,drop,profile,q] using hb

/-- Expected count in an upper quantile band, evaluated by the exact
accept/reject recurrence for independent uniform quantiles. -/
noncomputable def algorithmBand (R : RankModel α) (I : Finset α) (labels : List α) (v : ℝ) : ℝ :=
  match labels with
  | [] => 0
  | e::rest => min v (R.cutoff I rest e)+
      (1-R.cutoff I rest e)*algorithmBand R I rest v+
      R.cutoff I rest e*algorithmBand R (insert e I) rest v

/-- The competitive theorem in the finite rank-oracle / band-expectation model. -/
theorem algorithmBand_guarantee (R : RankModel α) (I : Finset α) (labels : List α)
    {v : ℝ} (hv : v ∈ Set.Icc (0:ℝ) 1) :
    coefficient * R.potential I labels v ≤ R.algorithmBand I labels v := by
  induction labels generalizing I with
  | nil => simp [potential,average,algorithmBand]
  | cons e rest ih =>
    have hq := cutoff_bounds R I rest e
    have hl := mul_le_mul_of_nonneg_left (ih I) (show 0 ≤ 1-R.cutoff I rest e by linarith [hq.2])
    have hr := mul_le_mul_of_nonneg_left (ih (insert e I)) hq.1
    have hs := cutoff_step R I rest e hv
    dsimp [algorithmBand]
    nlinarith

end RankModel
end MatroidProphet
