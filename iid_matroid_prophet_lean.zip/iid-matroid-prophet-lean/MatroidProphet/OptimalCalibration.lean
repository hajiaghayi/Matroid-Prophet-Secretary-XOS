import MatroidProphet.Constants

namespace MatroidProphet

/-- The two one-step surcharge constraints cannot certify a larger coefficient. -/
theorem calibration_optimal {a c : ℝ} (ha : 0 < a) (hc : 0 < c)
    (hsmall : c*(1+a) ≤ 1) (hlarge : c*(1+Real.exp (-1-a)/a) ≤ 1) :
    c ≤ coefficient := by
  by_contra h
  have hcgt : coefficient < c := lt_of_not_ge h
  have hden : 0 < 1+eta := by linarith [eta_pos]
  have hd : c*(1+eta) > 1 := by
    have hm := mul_lt_mul_of_pos_right hcgt hden
    rw [coefficient_small] at hm
    exact hm
  have hae : a < eta := by nlinarith
  have he := Real.exp_strictMono (show -1-eta < -1-a by linarith)
  rw [← eta_equation] at he
  have hm := mul_le_mul_of_nonneg_right hlarge ha.le
  have hcancel : (c*(1+Real.exp (-1-a)/a))*a = c*(a+Real.exp (-1-a)) := by field_simp
  rw [hcancel] at hm
  have hh : a+Real.exp (-1-a) > a*(1+eta) := by
    have : eta*a < eta^2 := by nlinarith [eta_pos]
    nlinarith
  have hm2 := mul_lt_mul_of_pos_left hh hc
  nlinarith

end MatroidProphet
