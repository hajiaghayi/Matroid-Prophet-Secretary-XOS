import MatroidProphet.Survival

namespace MatroidProphet

attribute [local instance] Classical.propDecidable

/-- Finite matroid rank axioms in diminishing-returns form. Unit increments
and diminishing returns characterize matroid rank, with rank(empty)=0. -/
structure RankModel (α : Type*) [DecidableEq α] where
  rank : Finset α → ℝ
  empty : rank ∅ = 0
  unit : ∀ A e, rank (insert e A)-rank A = 0 ∨ rank (insert e A)-rank A = 1
  diminishing : ∀ A B, A ⊆ B → ∀ e,
    rank (insert e B)-rank B ≤ rank (insert e A)-rank A

namespace RankModel
variable {α : Type*} [DecidableEq α]

def increment (R : RankModel α) (A : Finset α) (e : α) : ℝ := R.rank (insert e A)-R.rank A

/-- Exact finite product expectation, sampling labels with probability p. -/
noncomputable def average (labels : List α) (f : Finset α → ℝ) (I : Finset α) (p : ℝ) : ℝ :=
  match labels with
  | [] => f I
  | e::rest => (1-p)*average rest f I p+p*average rest f (insert e I) p

 theorem average_const (labels : List α) (I : Finset α) (p c : ℝ) :
    average labels (fun _ => c) I p = c := by
  induction labels generalizing I with
  | nil => rfl
  | cons e rest ih => simp only [average,ih]; ring

 theorem average_sub (labels : List α) (f g : Finset α → ℝ) (I : Finset α) (p : ℝ) :
    average labels (fun A => f A-g A) I p = average labels f I p-average labels g I p := by
  induction labels generalizing I with
  | nil => rfl
  | cons e rest ih => simp only [average,ih]; ring

/-- Reverse the bits so that the increasing coordinates mean absent labels. -/
noncomputable def eventCube (labels : List α) (P : Finset α → Prop) (I : Finset α) : Cube labels.length :=
  match labels with
  | [] => .leaf (decide (P I))
  | e::rest => .node (eventCube rest P (insert e I)) (eventCube rest P I)

 theorem eventCube_probability (labels : List α) (P : Finset α → Prop) (I : Finset α) (v : ℝ) :
    (eventCube labels P I).probability (1-v) =
      average labels (fun A => if P A then 1 else 0) I v := by
  induction labels generalizing I with
  | nil => simp [eventCube,Cube.probability,average]
  | cons e rest ih => simp only [eventCube,Cube.probability,ih,average]; ring

 theorem eventCube_implies (labels : List α) (P : Finset α → Prop)
    (hP : ∀ A B, A ⊆ B → P B → P A) {A B : Finset α} (hAB : A ⊆ B) :
    (eventCube labels P B).Implies (eventCube labels P A) := by
  induction labels generalizing A B with
  | nil => simpa [eventCube,Cube.Implies] using hP A B hAB
  | cons e rest ih => exact ⟨ih (Finset.insert_subset_insert e hAB),ih hAB⟩

 theorem eventCube_increasing (labels : List α) (P : Finset α → Prop)
    (hP : ∀ A B, A ⊆ B → P B → P A) (I : Finset α) :
    (eventCube labels P I).Increasing := by
  induction labels generalizing I with
  | nil => trivial
  | cons e rest ih =>
    exact ⟨ih (insert e I),ih I,eventCube_implies rest P hP (Finset.subset_insert _ _)⟩

 theorem eventCube_one (labels : List α) (P : Finset α → Prop) (I : Finset α) :
    (eventCube labels P I).probability 1 = if P I then 1 else 0 := by
  induction labels generalizing I with
  | nil => simp [eventCube,Cube.probability]
  | cons e rest ih => simpa [eventCube,Cube.probability] using ih I

 theorem eventCube_zero (labels : List α) (P : Finset α → Prop) (I : Finset α) :
    (eventCube labels P I).probability 0 = if P (I ∪ labels.toFinset) then 1 else 0 := by
  induction labels generalizing I with
  | nil => simp [eventCube,Cube.probability]
  | cons e rest ih =>
    simp only [eventCube,Cube.probability,sub_zero,one_mul,zero_mul,add_zero,ih]
    have he : insert e I ∪ rest.toFinset = I ∪ (e::rest).toFinset := by ext a; simp
    rw [he]

 theorem increment_antitone (R : RankModel α) (e : α) :
    ∀ A B, A ⊆ B → R.increment B e = 1 → R.increment A e = 1 := by
  intro A B hAB hB
  have h := R.diminishing A B hAB e
  rcases R.unit A e with hA | hA
  · dsimp [increment] at hB ⊢
    linarith
  · exact hA

noncomputable def profileCube (R : RankModel α) (I : Finset α) (labels : List α) (e : α) :
    Cube labels.length := eventCube labels (fun A => R.increment A e = 1) I

noncomputable def profile (R : RankModel α) (I : Finset α) (labels : List α) (e : α) : ℝ → ℝ :=
  (R.profileCube I labels e).survival

 theorem profile_average (R : RankModel α) (I : Finset α) (labels : List α) (e : α) (v : ℝ) :
    R.profile I labels e v = average labels (fun A => R.increment A e) I v := by
  unfold profile Cube.survival profileCube
  rw [eventCube_probability]
  congr 1
  funext A
  rcases R.unit A e with h | h
  · simp [increment,h]
  · simp [increment,h]

 theorem profile_cutoff (R : RankModel α) (I : Finset α) (labels : List α) (e : α)
    (hstart : R.increment I e = 1) (hend : R.increment (I ∪ labels.toFinset) e = 0) :
    ∃ q ∈ Set.Ioo (0:ℝ) 1, R.profile I labels e q = Real.exp (-eta) := by
  have h0 : R.profile I labels e 0 = 1 := by
    unfold profile Cube.survival profileCube
    rw [show (1-(0:ℝ)) = 1 by norm_num,eventCube_one]
    simp [hstart]
  have h1 : R.profile I labels e 1 = 0 := by
    unfold profile Cube.survival profileCube
    rw [show (1-(1:ℝ)) = 0 by norm_num,eventCube_zero]
    simp [hend]
  have hc : Continuous (R.profile I labels e) := by
    apply continuous_iff_continuousAt.mpr
    intro v
    exact ((R.profileCube I labels e).survival_hasDerivAt v).continuousAt
  exact calibrated_cutoff hc.continuousOn h0 h1

end RankModel
end MatroidProphet
