import MatroidProphet.Bounds

open MeasureTheory

namespace MatroidProphet
namespace RankModel

variable {α : Type*} [DecidableEq α]

/-- The rank layer-cake functional for a nonnegative common-law survival tail. -/
noncomputable def tailRank (R : RankModel α) (I : Finset α) (labels : List α)
    (tail : ℝ → ℝ) : ENNReal :=
  ∫⁻ t in Set.Ici (0:ℝ), ENNReal.ofReal (R.potential I labels (tail t))

/-- The corresponding layer-cake functional of the exact band-count recurrence. -/
noncomputable def tailAlgorithm (R : RankModel α) (I : Finset α) (labels : List α)
    (tail : ℝ → ℝ) : ENNReal :=
  ∫⁻ t in Set.Ici (0:ℝ), ENNReal.ofReal (R.algorithmBand I labels (tail t))

/-- The band proof extends to arbitrary tails, with no finite-support restriction.
Both sides use the stated layer-cake definitions. -/
theorem tail_guarantee (R : RankModel α) (I : Finset α) (labels : List α)
    (tail : ℝ → ℝ) (ht : ∀ t, tail t ∈ Set.Icc (0:ℝ) 1) :
    ENNReal.ofReal coefficient * R.tailRank I labels tail ≤ R.tailAlgorithm I labels tail := by
  unfold tailRank tailAlgorithm
  rw [← lintegral_const_mul' _ _ ENNReal.ofReal_ne_top]
  apply lintegral_mono
  intro t
  dsimp only
  rw [← ENNReal.ofReal_mul coefficient_pos.le]
  exact ENNReal.ofReal_le_ofReal (R.algorithmBand_guarantee I labels (ht t))

end RankModel

/-- Arbitrary common survival tails for genuine finite mathlib matroids. -/
theorem matroid_tail_guarantee {α : Type*} [DecidableEq α] [Finite α]
    (M : Matroid α) (labels : List α) (tail : ℝ → ℝ)
    (ht : ∀ t, tail t ∈ Set.Icc (0:ℝ) 1) :
    ENNReal.ofReal coefficient * (matroidRankModel M).tailRank ∅ labels tail ≤
      (matroidRankModel M).tailAlgorithm ∅ labels tail :=
  RankModel.tail_guarantee _ _ _ _ ht

end MatroidProphet
