# Formal statements and probability model

## Public theorem

`MatroidProphet.main_theorem` proves the ordinary real-expectation inequality

\[
 c_0\,\mathbb E[\mathrm{OPT}]\le\mathbb E[\mathrm{ALG}].
\]

Its hypotheses are:

- `M : Matroid α`, with finite `α` and decidable equality;
- a probability measure `μ : Measure ℝ` with `μ (Ici 0)ᶜ = 0`;
- finite common mean, expressed as `∫⁻ x, ENNReal.ofReal x ∂μ ≠ ⊤`;
- a list `labels` with `labels.Nodup`.

`main_theorem_decimal` replaces the exact coefficient by the smaller rational
`6767410571 / 10000000000`. `online_iid_matroid_prophet` states the exact
coefficient inequality for nonnegative extended expectations and drops the
finite-mean hypothesis. No theorem assumes the desired expected-reward
inequality, a matroid profile shape property, or a prophet/recurrence identity.

The ground set need not be the whole ambient type. The label list may enumerate
all of the ground set or any subset. The theorem does not require representable,
graphical, or uniform matroids.

## What the expectations mean

`iidMeasure μ n` is the iterated product of `n` copies of `μ`.
`streamVector labels w` assigns those realized weights to the distinct labels.
`prophetValue M labels w` is the supremum of the total weights of all independent
subsets of the label set. The family is finite; `prophetValue_finite` proves
that this supremum is finite for every realized finite real weight vector.
Thus its real value is exactly the ordinary maximum-weight independent set.

`onlineMeasure μ n` is the iterated product of the one-step measure
`μ.compProd (quantileKernel μ)`: first reveal a weight with law `μ`, then
sample its auxiliary quantile from the kernel at that weight. This kernel is
a Markov kernel depending only on `μ` and the current weight. The pairs at
distinct steps are independent.

`online_weights_law` proves that forgetting the auxiliary quantiles gives
exactly `iidMeasure μ n`. `online_quantiles_law` proves that forgetting the
weights gives independent uniform quantiles.

`RankModel.observedValue` is an actual sequential reward function: it compares
the current auxiliary quantile with the rank cutoff and adds the current
observed weight exactly when it accepts. `observedValue_eq_sum` identifies
this reward with the sum on the selected labels. `online_policy_independent`
proves feasibility pointwise. `observedValue_nonneg_ae`, `observedValue_integrable`,
and `prophet_integrable` justify the ordinary expectation interpretation for
finite-mean laws.

## The former probability-model gap

Version 0.1 checked the analytic and recursive rank argument but did not
identify its quantities with actual random-variable expectations. Version 0.2
adds these connections:

1. **Arbitrary common laws.** `weightQuantile_le_iff` proves inverse-CDF
   inversion using right continuity. `weightQuantile_map` realizes every
   nonnegative real probability law, including atomic laws.
   `streamQuantile_map` proves the whole product-law identity.
2. **Local quantile randomization.** `observation_disintegration` constructs
   the conditional quantile kernel from the weight–quantile joint measure.
   `observationLift_map` proves the identity of the full sequential observation
   law with the uniform-quantile construction. This is not a conditional
   kernel that inspects the whole future weight vector.
3. **Actual selected counts.** `integral_bandCount` identifies the original
   band recurrence on the product space. `integral_weightBand` identifies the
   expected number of accepted weights above an actual weight threshold.
4. **Actual selected weight.** `policyValue_cake` proves the layer-cake identity
   pointwise. Tonelli then gives `expected_policyValue` and
   `expected_observedValue`, identifying the policy's expected reward with the
   previously checked tail functional.
5. **Actual prophet.** `finset_weight_cake` expresses the weight of every
   feasible independent set as an integral of its upper-level cardinalities.
   Each such cardinality is at most the matroid rank of the entire upper-level
   set. `integral_rankAt` identifies the expectation of that rank with its
   Bernoulli average. Hence `expected_prophet_le` bounds the actual prophet
   expectation by the rank functional. Equality with the greedy rank integral
   is unnecessary for the competitive theorem; the required upper bound is
   proved directly.
6. **Conventional statement.** `main_theorem` combines these facts and converts
   to ordinary real integrals. `main_theorem_decimal` certifies the advertised
   downward-rounded decimal.

The competitive statement is therefore no longer confined to recursive
surrogate quantities.

## Arrival order and online information

The guarantee holds for each fixed list order. A list is used in the recursive
notation, but `RankModel.cutoff_perm` proves that permuting the unseen list does
not change the cutoff. Thus the decision uses the current element, the accepted
set, and the remaining label set, all available online. It uses no future
weights or information about their eventual arrival order.

`random_order_iid_matroid_prophet` averages the same theorem over any independent
distribution of arrival orders supported on distinct-label lists. Uniform order
over all permutations is a special case. Its nonnegative expectations also
allow infinite common mean.

## Analytic proof retained from version 0.1

The finite-cube entropy induction proves the required shape of the nonspanning
probability. The chosen cutoff satisfies the calibrated local comparison
between expected upper-band reward and rank-potential drop. The deletion/
acceptance accounting identity telescopes through the exact sequential
recurrence. `matroidRankModel` derives every rank hypothesis from mathlib's
finite-matroid rank axioms. Existence and uniqueness of the positive calibration
root and the stated decimal interval are proved using exact real inequalities
and rational exponential bounds, without floating-point computation.

## Scope and trust

This release checks the complete competitive guarantee for the **ideal exact
randomized policy**. It does not formalize the separately analyzed sampling
approximation, its failure probability, or its polynomial running time. It does
not claim the sharp universal ratio or a 0.7451 guarantee.

All included project proofs are checked by Lean 4.24.0 against the pinned,
unmodified mathlib commit `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.
`check_sources.py` rejects unfinished proofs and unchecked proof shortcuts.
`check_axioms.py` verifies the dependency output for the public results and
accepts only Lean's standard logical foundations: `propext`, `Classical.choice`,
and `Quot.sound`.

A precise manuscript description is:

> The ideal-policy competitive theorem, including the arbitrary-law probability
> model, feasibility, and the comparison with the prophet's expected optimum,
> has been formalized in Lean. The repository also certifies the numerical
> constant. The sampled implementation and its running-time analysis are not
> part of the formalization.
