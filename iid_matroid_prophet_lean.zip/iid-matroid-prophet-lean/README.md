# I.i.d. matroid prophet inequality in Lean

Lean 4 proof of the competitive guarantee

\[
\mathbb E[\mathrm{ALG}]\ge c_0\,\mathbb E[\mathrm{OPT}],\qquad
c_0=\frac1{1+\eta_0},\qquad \eta_0^2=e^{-1-\eta_0},\quad \eta_0>0.
\]

The theorem covers every finite matroid and every known nonnegative common
weight distribution. Atoms are allowed. Lean certifies

```
0.67674105711283 < c₀ < 0.67674105711285.
```

**Version 0.2 closes the probability-model gap in version 0.1.** The checked
statements now compare the expected reward of an actual feasible online policy
with the expected maximum-weight independent set under the specified i.i.d.
product law. They include inverse-CDF sampling, local randomization at atoms,
product-measure identities, and the required layer-cake arguments. The usual
real-expectation theorem assumes finite mean; the nonnegative extended-
expectation theorem does not.

The guarantee holds for each fixed arrival order. The cutoff depends on the
unseen set, and is invariant under permutations of its list representation.
A separate theorem averages over any independent distribution of arrival
orders, including uniform random order.

This is a formal proof of the **ideal exact policy**. It does not certify the
sampling approximation algorithm or a polynomial running-time bound. It makes
no claim of a 0.7451 guarantee or of the sharp universal matroid ratio.

## Build

Install [elan](https://github.com/leanprover/elan), then run:

```sh
lake exe cache get
lake build
python3 scripts/check_sources.py
python3 scripts/check_axioms.py
```

The checked environment is Lean **4.24.0** and mathlib commit
`f897ebcf72cd16f89ab4577d0c826cd14afaafc7`. The toolchain and all dependency
revisions are pinned. Lake fetches the manifest's dependencies on first use;
`lake exe cache get` obtains mathlib's compiled cache. The archive contains
source files only, together with verification records and SHA-256 hashes.

The audit scripts need only Python's standard library. `check_axioms.py` runs
`Check.lean` and fails if any audited declaration uses logical dependencies
other than `propext`, `Classical.choice`, and `Quot.sound`.

## Main declarations

```lean
import MatroidProphet

-- Ordinary real expectations, arbitrary nonnegative finite-mean law:
#check MatroidProphet.main_theorem
#check MatroidProphet.main_theorem_decimal

-- Nonnegative extended expectations, without a finite-mean assumption:
#check MatroidProphet.online_iid_matroid_prophet
#check MatroidProphet.online_iid_matroid_prophet_decimal

-- Independent random arrival order, including uniform order:
#check MatroidProphet.random_order_iid_matroid_prophet

-- Feasibility and the actual reward represented by the recurrence:
#check MatroidProphet.online_policy_independent
#check MatroidProphet.RankModel.observedValue_eq_sum

-- The observations have exactly the requested common product law:
#check MatroidProphet.online_weights_law
#check MatroidProphet.observation_disintegration
#check MatroidProphet.RankModel.cutoff_perm
```

The inputs are a mathlib matroid `M : Matroid α` with `[Finite α]`, a real
probability measure `μ` supported on `[0,∞)`, and a list of distinct arriving
labels. To obtain the full-ground-set problem, take a list enumerating the
matroid's ground set. The theorem also applies when only a subset arrives.
No shape condition on the matroid is assumed.

## The online policy

The state is the accepted set `I` and the set of labels not yet processed.
For the current element `e`, the policy computes the rank-profile cutoff
`q = R.cutoff I rest e`. Upon seeing its weight `x`, it samples an auxiliary
quantile from `quantileKernel μ x`. It accepts exactly when `0 < u ≤ q`.
The kernel uses only the common law and the current observed weight.
`observation_disintegration` proves that this local procedure realizes the
required weight–quantile joint distribution, including atoms.

`selectedNew` gives the selected set. `observedValue` follows the same
accept/reject decisions and adds the observed weights. Lean proves that this
set is independent and that its weight equals `observedValue`.

## Proof map

| Files | Content |
| --- | --- |
| `Constants`, `Numerics` | Exact calibration and certified rational decimal bounds |
| `Entropy`, `BooleanCube`, `Shape`, `Survival`, `Band` | Boolean-event inequality and calibrated band comparison |
| `RankModel`, `MatroidRank`, `MatroidProfile` | Rank profiles, Bernoulli averages, actual mathlib matroids |
| `Selection`, `Telescoping`, `Weighted`, `Bounds` | Rank accounting and the recursive competitive inequality |
| `Order`, `Feasibility` | Cutoff invariance and the original assignment-based selection function |
| `Tail`, `FiniteMean`, `OptimalCalibration` | Tail bounds and optimality within the stated local calibration constraints |
| `ProbabilitySpace`, `Quantile` | Product uniform space and arbitrary-law inverse CDF |
| `WeightedProbability`, `RankProbability` | Actual band expectations and weight/rank layer-cake identities |
| `ProphetProbability` | Maximum-weight independent-set benchmark and its expected rank upper bound |
| `RuntimePolicy`, `ObservationLaw` | Selected weight, feasibility, i.i.d. law, and conditional quantile kernel |
| `OnlineTheorem`, `RealTheorem` | Observation-based, random-order, integrability, and real-expectation theorems |

File names in this table have suffix `.lean` and lie in `MatroidProphet/`.
[FORMALIZATION.md](FORMALIZATION.md) states the probability model and the proof
connections in detail. [verification/BUILD.txt](verification/BUILD.txt) records
the checks performed for this release.

## Attribution and scope

Mohammad Hajiaghayi, University of Maryland, College Park.
Contact: hajiagha@umd.edu.

Associated manuscript: *A 0.6767 Prophet Inequality for Matroids with I.I.D.
Weights*.

The proof and formalization were developed through extensive interaction with
OpenAI Astra and Codex under the author's direction. The repository uses
classical choice and noncomputable definitions; it is a mathematical proof
repository, not a numerical implementation.

## License

Apache-2.0. Mathlib and the Lean toolchain are obtained separately under their
own licenses; dependency sources and binaries are not bundled.
