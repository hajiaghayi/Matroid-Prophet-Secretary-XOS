import MatroidProphet

/-! Public audit entry points. No project-specific axioms should appear. -/
#print axioms MatroidProphet.Cube.entropy_bound
#print axioms MatroidProphet.coefficient_bracket
#print axioms MatroidProphet.matroid_local_cutoff
#print axioms MatroidProphet.matroid_band_guarantee
#print axioms MatroidProphet.matroid_finite_law_guarantee
#print axioms MatroidProphet.finite_law_decimal
#print axioms MatroidProphet.matroid_run_independent
#print axioms MatroidProphet.matroid_tail_real_guarantee
#print axioms MatroidProphet.calibration_optimal

#print axioms MatroidProphet.RankModel.cutoff_perm

#print axioms MatroidProphet.weightQuantile_map
#print axioms MatroidProphet.streamQuantile_map
#print axioms MatroidProphet.RankModel.expected_policyValue
#print axioms MatroidProphet.expected_prophet_le
#print axioms MatroidProphet.matroid_selectedNew_independent
#print axioms MatroidProphet.observation_disintegration
#print axioms MatroidProphet.online_weights_law
#print axioms MatroidProphet.online_quantiles_law
#print axioms MatroidProphet.RankModel.observedValue_eq_sum
#print axioms MatroidProphet.online_policy_independent
#print axioms MatroidProphet.online_iid_matroid_prophet
#print axioms MatroidProphet.online_iid_matroid_prophet_decimal
#print axioms MatroidProphet.random_order_iid_matroid_prophet
#print axioms MatroidProphet.online_iid_matroid_prophet_real
#print axioms MatroidProphet.observedValue_integrable
#print axioms MatroidProphet.prophet_integrable
#print axioms MatroidProphet.main_theorem
#print axioms MatroidProphet.main_theorem_decimal
