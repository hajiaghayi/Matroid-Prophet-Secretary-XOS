import MatroidProphetSecretary

/-!
# Public entry point: matroid prophet secretary and XOS hardness

This file imports the complete proof library in `MatroidProphetSecretary/`.
Keep that source directory and `MatroidProphetSecretary.lean` beside this file.
All project proofs are supplied as Lean source; only mathlib is external.

Use Lean 4.19.0 and mathlib v4.19.0, as pinned by the accompanying project:

    lake exe cache get
    lake build
    lake env lean Main.lean

Theorem 1: `MatroidProphetSecretary.matroid_prophet_secretary` proves the
exact ratio `1 - 1 / Real.exp 1 + 1 / 10000000` for a feasible online policy
under independent measurable nonnegative values with integrable optimum.
Its statement is in `MatroidProphetSecretary/MainTheorem.lean`.

Theorem 2: `MatroidProphetSecretary.XOS.xos_main_theorem` proves that for
every `xi > 0`, one finite identical-prior XOS instance forces every randomized
online algorithm below `1 - 1 / Real.exp 1 + xi`, even with the full arrival
permutation known in advance. Its clauses have binary coefficients.
Its statement is in `MatroidProphetSecretary/XOSMainTheorem.lean`.
The arbitrary-random-tape version is checked below as well.

Scope: these are the mathematical competitiveness and direct XOS hardness
proofs. The matroid existence proof does not establish the paper's complete
algorithm implementation or its computational guarantees. The separate
coverage-welfare transposition is not needed for the direct XOS proof.

The final commands expose the theorem statements, check the exact strict
improvement, and list all transitive axiom dependencies of the main results.
Only `propext`, `Classical.choice`, and `Quot.sound` are permitted by the audit.
-/

#check MatroidProphetSecretary.matroid_prophet_secretary
#check MatroidProphetSecretary.XOS.xos_main_theorem
#check MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes

example : (1 : ℝ) - 1 / Real.exp 1 + 1 / 10000000 < MatroidProphetSecretary.beta := by
  exact MatroidProphetSecretary.parameter_choice.2.2.2

example : (1 : ℝ) - 1 / Real.exp 1 < (1 : ℝ) - 1 / Real.exp 1 + 1 / 10000000 := by
  linarith

#print axioms MatroidProphetSecretary.matroid_prophet_secretary
#print axioms MatroidProphetSecretary.parameter_choice
#print axioms MatroidProphetSecretary.XOS.xos_main_theorem
#print axioms MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes
