import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-! Interval geometry of the midpoint search, for every possible sequence of batch outcomes. -/

noncomputable section

namespace MatroidProphetSecretary

structure SearchBracket where
  lower : ℝ
  upper : ℝ

def SearchBracket.midpoint (b : SearchBracket) : ℝ := (b.lower+b.upper)/2

def bisectBracket (moveLower : Bool) (b : SearchBracket) : SearchBracket :=
  if moveLower then ⟨b.midpoint,b.upper⟩ else ⟨b.lower,b.midpoint⟩

def bisectionRun (answers : ℕ → Bool) : ℕ → SearchBracket → SearchBracket
  | 0, b => b
  | n+1, b => bisectBracket (answers n) (bisectionRun answers n b)

theorem midpoint_mem_bracket (b : SearchBracket) (hb : b.lower ≤ b.upper) :
    b.lower ≤ b.midpoint ∧ b.midpoint ≤ b.upper := by
  unfold SearchBracket.midpoint
  constructor <;> linarith

theorem bisectBracket_nested (moveLower : Bool) (b : SearchBracket) (hb : b.lower ≤ b.upper) :
    b.lower ≤ (bisectBracket moveLower b).lower ∧
      (bisectBracket moveLower b).lower ≤ (bisectBracket moveLower b).upper ∧
        (bisectBracket moveLower b).upper ≤ b.upper := by
  have hm := midpoint_mem_bracket b hb
  cases moveLower <;> simp only [bisectBracket, Bool.false_eq_true, if_false, if_true]
  · exact ⟨le_rfl, hm.1, hm.2⟩
  · exact ⟨hm.1, hm.2, le_rfl⟩

theorem bisectBracket_width (moveLower : Bool) (b : SearchBracket) :
    (bisectBracket moveLower b).upper - (bisectBracket moveLower b).lower = (b.upper-b.lower)/2 := by
  cases moveLower <;> simp only [bisectBracket, Bool.false_eq_true, if_false, if_true, SearchBracket.midpoint] <;> ring

theorem bisectionRun_nested (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket) (hb : b.lower ≤ b.upper) :
    b.lower ≤ (bisectionRun answers n b).lower ∧
      (bisectionRun answers n b).lower ≤ (bisectionRun answers n b).upper ∧
        (bisectionRun answers n b).upper ≤ b.upper := by
  induction n with
  | zero => exact ⟨le_rfl,hb,le_rfl⟩
  | succ n ih =>
    have hs := bisectBracket_nested (answers n) (bisectionRun answers n b) ih.2.1
    exact ⟨ih.1.trans hs.1, hs.2.1, hs.2.2.trans ih.2.2⟩

theorem bisectionRun_width (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket) :
    (bisectionRun answers n b).upper - (bisectionRun answers n b).lower = (b.upper-b.lower)/2^n := by
  induction n with
  | zero => simp [bisectionRun]
  | succ n ih =>
    rw [bisectionRun, bisectBracket_width, ih, pow_succ, div_div]

theorem bisectionRun_lower_monotone (answers : ℕ → Bool) (b : SearchBracket) (hb : b.lower ≤ b.upper) :
    Monotone (fun n => (bisectionRun answers n b).lower) := by
  apply monotone_nat_of_le_succ
  intro n
  exact (bisectBracket_nested (answers n) (bisectionRun answers n b) (bisectionRun_nested answers n b hb).2.1).1

theorem bisectionRun_upper_antitone (answers : ℕ → Bool) (b : SearchBracket) (hb : b.lower ≤ b.upper) :
    Antitone (fun n => (bisectionRun answers n b).upper) := by
  apply antitone_nat_of_succ_le
  intro n
  exact (bisectBracket_nested (answers n) (bisectionRun answers n b) (bisectionRun_nested answers n b hb).2.1).2.2

theorem bisectionRun_width_bound (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket) (ε : ℝ)
    (hbudget : b.upper-b.lower ≤ ε*2^n) :
    (bisectionRun answers n b).upper - (bisectionRun answers n b).lower ≤ ε := by
  rw [bisectionRun_width]
  exact (div_le_iff₀ (by positivity : (0:ℝ)<2^n)).mpr hbudget

end MatroidProphetSecretary
