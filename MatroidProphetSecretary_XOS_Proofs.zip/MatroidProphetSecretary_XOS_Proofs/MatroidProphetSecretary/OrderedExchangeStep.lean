import MatroidProphetSecretary.OracleScan
import MatroidProphetSecretary.ExchangeConstruction
import Mathlib.Data.Finset.Sort

/-! The deterministic target scan in Lemma 12, implemented using an independence oracle. -/

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [LinearOrder E]

def exchangeTest (oracle : Finset E → Bool) (C B : Finset E) (e b : E) : Bool :=
  oracle (insert e (B.erase b)) && oracle (insert b (C.erase e))

def firstExchangeTarget (oracle : Finset E → Bool) (C B : Finset E) (e : E) : Option E :=
  firstSuccess (exchangeTest oracle C B e) ((B \ C).sort (· ≤ ·))

def exchangeScanQueries (oracle : Finset E → Bool) (C B : Finset E) (e : E) : ℕ :=
  2 * scanTests (exchangeTest oracle C B e) ((B \ C).sort (· ≤ ·))

theorem firstExchangeTarget_exists (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (C B : Finset E) (hC : M.IsBase (C : Set E)) (hB : M.IsBase (B : Set E))
    (e : E) (he : e ∈ C \ B) : ∃ b, firstExchangeTarget oracle C B e = some b := by
  obtain ⟨b, hb, hBe, hCb⟩ := symmetric_exchange hC hB (mem_sdiff.mp he).1 (mem_sdiff.mp he).2
  apply firstSuccess_exists
  refine ⟨b, (mem_sort (· ≤ ·)).mpr (mem_sdiff.mpr hb), ?_⟩
  simp only [exchangeTest, Bool.and_eq_true, horacle]
  constructor
  · simpa only [coe_insert, coe_erase] using hBe.indep
  · simpa only [coe_insert, coe_erase] using hCb.indep

theorem firstExchangeTarget_spec (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (C B : Finset E) (hC : M.IsBase (C : Set E)) (hB : M.IsBase (B : Set E))
    (e b : E) (he : e ∈ C \ B) (hb : firstExchangeTarget oracle C B e = some b) :
    b ∈ B \ C ∧ M.IsBase ((insert e (B.erase b) : Finset E) : Set E) ∧
      M.IsBase ((insert b (C.erase e) : Finset E) : Set E) := by
  obtain ⟨hbmem, hbtest⟩ := firstSuccess_spec _ _ _ hb
  have hb' : b ∈ B \ C := (mem_sort (· ≤ ·)).mp hbmem
  simp only [exchangeTest, Bool.and_eq_true, horacle] at hbtest
  refine ⟨hb', ?_, ?_⟩
  · have h := hB.exchange_isBase_of_indep (mem_sdiff.mp he).2
      (show M.Indep (insert e ((B : Set E) \ {b})) by
        simpa only [coe_insert, coe_erase] using hbtest.1)
    simpa only [coe_insert, coe_erase] using h
  · have h := hC.exchange_isBase_of_indep (mem_sdiff.mp hb').2
      (show M.Indep (insert b ((C : Set E) \ {e})) by
        simpa only [coe_insert, coe_erase] using hbtest.2)
    simpa only [coe_insert, coe_erase] using h

theorem exchangeScanQueries_le (M : Matroid E) (oracle : Finset E → Bool)
    (C B : Finset E) (hC : M.IsBase (C : Set E)) (hB : M.IsBase (B : Set E)) (e : E) :
    exchangeScanQueries oracle C B e ≤ 2 * (C \ B).card := by
  have hc : C.card = B.card := by simpa using hC.ncard_eq_ncard_of_isBase hB
  have h := Nat.mul_le_mul_left 2 (scanTests_le_length (exchangeTest oracle C B e) ((B \ C).sort (· ≤ ·)))
  simpa only [length_sort, card_sdiff_comm hc.symm] using h

theorem exchange_sdiff_step (C B : Finset E) (e b : E) (hb : b ∈ B) :
    insert b (C.erase e) \ B = (C \ B).erase e := by
  ext x
  simp only [mem_sdiff, mem_insert, mem_erase]
  constructor
  · rintro ⟨hxb | ⟨hxe, hxC⟩, hxB⟩
    · exact (hxB (hxb ▸ hb)).elim
    · exact ⟨hxe, hxC, hxB⟩
  · rintro ⟨hxe, hxC, hxB⟩
    exact ⟨Or.inr ⟨hxe, hxC⟩, hxB⟩

theorem exchange_distance_step (C B : Finset E) (e b : E) (he : e ∈ C \ B) (hb : b ∈ B) :
    (insert b (C.erase e) \ B).card + 1 = (C \ B).card := by
  rw [exchange_sdiff_step C B e b hb]
  exact card_erase_add_one he

end MatroidProphetSecretary
