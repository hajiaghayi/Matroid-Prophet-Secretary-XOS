import MatroidProphetSecretary.AdaptiveExpectation

/-! Finite laws for two successive adaptive phases and their reward composition. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {Ω Ψ S : Type*} [Fintype Ω] [Fintype Ψ]

def dependentPair (first : FiniteLaw Ω) (second : Ω → FiniteLaw Ψ) : FiniteLaw (Ω × Ψ) :=
  first.bind (fun x => (second x).map (fun y => (x,y)))

theorem dependentPair_expect (first : FiniteLaw Ω) (second : Ω → FiniteLaw Ψ) (f : Ω → Ψ → ℝ) :
    (dependentPair first second).expect (fun x => f x.1 x.2) =
      first.expect (fun x => (second x).expect (f x)) := by
  simp only [dependentPair,bind_expect,map_expect]

theorem two_stage_reward_bound (first : FiniteLaw Ω) (second : Ω → FiniteLaw Ψ)
    (early : Ω → ℝ) (late : Ω → Ψ → ℝ) (W U : Ω → ℝ) (r w u c : ℝ) (hc : 0 ≤ c)
    (hearly : r ≤ first.expect early) (hW : w ≤ first.expect W) (hU : u ≤ first.expect U)
    (hlate : ∀ x, c*(W x+U x) ≤ (second x).expect (late x)) :
    r+c*(w+u) ≤ (dependentPair first second).expect (fun x => early x.1+late x.1 x.2) := by
  rw [dependentPair_expect first second (fun x y => early x+late x y)]
  simp only [expect_add,expect_const]
  have hl := first.expect_mono hlate
  rw [expect_const_mul,expect_add] at hl
  exact add_le_add hearly ((mul_le_mul_of_nonneg_left (add_le_add hW hU) hc).trans hl)

theorem trajectoryReward_bounds (update : S → Ω → S) (reward : S → Ω → ℝ) (C : ℝ)
    (h0 : ∀ s x, 0 ≤ reward s x) (hC : ∀ s x, reward s x ≤ C)
    (n : ℕ) (s : S) (x : Fin n → Ω) :
    0 ≤ trajectoryReward update reward n s x ∧ trajectoryReward update reward n s x ≤ n*C := by
  induction n generalizing s with
  | zero => simp [trajectoryReward]
  | succ n ih =>
    have h := ih (update s (x 0)) (fun i => x i.succ)
    simp only [trajectoryReward,Nat.cast_add,Nat.cast_one]
    exact ⟨add_nonneg (h0 s (x 0)) h.1,by nlinarith only [h.2,hC s (x 0)]⟩

end MatroidProphetSecretary.FiniteLaw
