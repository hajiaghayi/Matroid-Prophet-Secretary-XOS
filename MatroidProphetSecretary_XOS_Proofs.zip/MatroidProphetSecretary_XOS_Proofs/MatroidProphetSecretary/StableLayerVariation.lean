import MatroidProphetSecretary.ReferenceLayerVariation

/-! Quantitative variation of the reference stable-surplus layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def weightedColoopCount (M : Matroid E) (p : E → ℝ) (x : E → Bool) : ℝ :=
  ∑ e, activeColoopIndicator M e x * p e

theorem weightedColoopCount_bounds (M : Matroid E) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (x : E → Bool) :
    0 ≤ weightedColoopCount M p x ∧ weightedColoopCount M p x ≤ activeColoopCount M x :=
  ⟨sum_nonneg (fun e he => mul_nonneg (activeColoopIndicator_bounds M e x).1 (hp0 e)),
    sum_le_sum (fun e he => mul_le_of_le_one_right (activeColoopIndicator_bounds M e x).1 (hp1 e))⟩

theorem weightedColoopCount_difference (M : Matroid E) (p q : E → ℝ)
    (hpq : ∀ e, p e ≤ q e) (x : E → Bool) :
    0 ≤ weightedColoopCount M q x - weightedColoopCount M p x ∧
      weightedColoopCount M q x - weightedColoopCount M p x ≤ ∑ e, (q e-p e) := by
  unfold weightedColoopCount
  rw [← sum_sub_distrib]
  simp only [← mul_sub]
  exact ⟨sum_nonneg (fun e he => mul_nonneg (activeColoopIndicator_bounds M e x).1
    (sub_nonneg.mpr (hpq e))), sum_le_sum (fun e he =>
      mul_le_of_le_one_left (sub_nonneg.mpr (hpq e)) (activeColoopIndicator_bounds M e x).2)⟩

theorem referenceLayerH_eq_weighted_coloop_expect (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q : ℝ) (hq : 0 ≤ q) :
    referenceLayerH M p q = bernoulliEval (fun e => scaledTail (p e) q)
      (weightedColoopCount M (fun e => scaledTail (p e) q)) := by
  rw [bernoulliEval_eq_expect _ (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).2)]
  change _ = (FiniteLaw.product _).expect (fun x => ∑ e, activeColoopIndicator M e x * scaledTail (p e) q)
  rw [FiniteLaw.expect_finset_sum]
  simp only [FiniteLaw.expect_mul_const, activeColoopIndicator_expect]
  apply sum_congr rfl
  intro e he
  unfold referenceLayerRho
  rw [bernoulli_replace_rank_eq_nonspan M hground (fun e => scaledTail (p e) q)
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).2)]
  unfold activityProbability
  rw [FiniteLaw.product_prob_coordinate]
  simp only [bernoulliLaws, bernoulliLaw, if_true]
  ring

theorem weighted_coloop_expect_variation (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p q : E → ℝ) (hp : ∀ e, 0 ≤ p e) (hpq : ∀ e, p e ≤ q e) (hq : ∀ e, q e ≤ 1) :
    |bernoulliEval q (weightedColoopCount M q) - bernoulliEval p (weightedColoopCount M p)| ≤
      ((Fintype.card E : ℝ)+1) * ∑ e, (q e-p e) := by
  have hp1 : ∀ e, p e ≤ 1 := fun e => (hpq e).trans (hq e)
  have hq0 : ∀ e, 0 ≤ q e := fun e => (hp e).trans (hpq e)
  have hvar := bernoulliEval_variation_ordered p q hp hpq hq (weightedColoopCount M p)
    (Fintype.card E) (Nat.cast_nonneg _) (fun x => (weightedColoopCount_bounds M p hp hp1 x).1)
    (fun x => ((weightedColoopCount_bounds M p hp hp1 x).2.trans
      (activeColoopCount_le_rank M hground x)).trans (activeRank_le_card M hground x))
  have hw : |bernoulliEval q (weightedColoopCount M q) - bernoulliEval q (weightedColoopCount M p)| ≤
      ∑ e, (q e-p e) := by
    rw [bernoulliEval_eq_expect q hq0 hq, bernoulliEval_eq_expect q hq0 hq, ← FiniteLaw.expect_sub]
    have h0 := (FiniteLaw.product (bernoulliLaws q hq0 hq)).expect_nonneg
      (fun x => (weightedColoopCount_difference M p q hpq x).1)
    rw [abs_of_nonneg h0]
    calc
      _ ≤ (FiniteLaw.product (bernoulliLaws q hq0 hq)).expect (fun _ => ∑ e, (q e-p e)) :=
        FiniteLaw.expect_mono _ (fun x => (weightedColoopCount_difference M p q hpq x).2)
      _ = _ := FiniteLaw.expect_const _ _
  calc
    _ ≤ |bernoulliEval q (weightedColoopCount M q) - bernoulliEval q (weightedColoopCount M p)| +
        |bernoulliEval q (weightedColoopCount M p) - bernoulliEval p (weightedColoopCount M p)| :=
      abs_sub_le _ _ _
    _ ≤ (∑ e, (q e-p e)) + (Fintype.card E : ℝ)*∑ e, (q e-p e) :=
      add_le_add hw (by simpa only [abs_sub_comm] using hvar)
    _ = _ := by ring

theorem referenceLayerH_variation_ordered (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q r : ℝ) (hq : 0 ≤ q) (hqr : q ≤ r) :
    |referenceLayerH M p r - referenceLayerH M p q| ≤
      ((Fintype.card E : ℝ)+1)*(r-q)*(∑ e, p e) := by
  rw [referenceLayerH_eq_weighted_coloop_expect M hground p hp r (hq.trans hqr),
    referenceLayerH_eq_weighted_coloop_expect M hground p hp q hq]
  have h := weighted_coloop_expect_variation M hground (fun e => scaledTail (p e) q)
    (fun e => scaledTail (p e) r) (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => scaledTail_monotone (p e) (hp e) hqr)
    (fun e => (scaledTail_bounds (p e) r (hp e) (hq.trans hqr)).2)
  refine h.trans ?_
  calc
    _ ≤ ((Fintype.card E : ℝ)+1) * ∑ e, (r-q)*p e :=
      mul_le_mul_of_nonneg_left (sum_le_sum (fun e he => (scaledTail_sub_bound (p e) q r (hp e) hqr).2))
        (by positivity)
    _ = _ := by rw [← mul_sum]; ring

theorem referenceLayerH_variation (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q r : ℝ) (hq : 0 ≤ q) (hr : 0 ≤ r) :
    |referenceLayerH M p r - referenceLayerH M p q| ≤
      ((Fintype.card E : ℝ)+1)*|r-q| * (∑ e, p e) := by
  rcases le_total q r with hqr | hrq
  · simpa only [abs_of_nonneg (sub_nonneg.mpr hqr)] using
      referenceLayerH_variation_ordered M hground p hp q r hq hqr
  · have h := referenceLayerH_variation_ordered M hground p hp r q hr hrq
    rw [abs_sub_comm] at h
    simpa only [abs_of_nonpos (sub_nonpos.mpr hrq), neg_sub] using h

end MatroidProphetSecretary
