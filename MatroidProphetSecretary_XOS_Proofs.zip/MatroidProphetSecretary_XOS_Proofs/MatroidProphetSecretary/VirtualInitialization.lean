import MatroidProphetSecretary.VirtualValuePersistence

/-! Initialization at actual optimal reference bases and feasibility of every virtual state. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def initialVirtualState (M : Matroid E) : VirtualState M := ⟨∅,ExchangeHistory.nil⟩

theorem virtualState_feasible (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (s : VirtualState M) : M.Indep (s.1 : Set E) := by
  let y := Classical.choice (FiniteLaw.nonempty_of_law μ)
  exact s.2.replay_acceptances_independent (base y) (hbase y)

theorem virtualLiveValue_nonneg (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (s : VirtualState M) (e : E) :
    0 ≤ virtualLiveValue μ M base hbase value s e := by
  apply μ.expect_nonneg
  intro y
  split_ifs
  · exact hv y e
  · exact le_rfl

theorem virtualTotalLiveValue_eq_weight (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M) :
    virtualTotalLiveValue μ M base hbase value s =
      μ.expect (fun y => weight (value y) (virtualLive M base hbase value s y)) := by
  unfold virtualTotalLiveValue virtualLiveValue
  rw [← FiniteLaw.expect_finset_sum]
  congr 1
  funext y
  simp [weight,← sum_filter]

theorem virtualTotalLiveValue_le_optimum (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (s : VirtualState M) :
    virtualTotalLiveValue μ M base hbase value s ≤ expectedOptimum μ M value := by
  rw [virtualTotalLiveValue_eq_weight]
  exact μ.expect_mono (fun y => s.2.live_weight_le_optimum (base y) (hbase y) (value y) (hv y))

theorem initialVirtualState_value (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hopt : ∀ y, weight (value y) (base y) = optimum M (value y)) :
    virtualTotalLiveValue μ M base hbase value (initialVirtualState M) = expectedOptimum μ M value := by
  rw [virtualTotalLiveValue_eq_weight]
  unfold expectedOptimum
  congr 1
  funext y
  change weight (value y) ((base y \ ∅).filter (fun e => 0 < value y e)) = _
  rw [sdiff_empty,← hopt y]
  unfold weight
  rw [sum_filter]
  apply sum_congr rfl
  intro e he
  by_cases hvpos : 0 < value y e
  · simp [hvpos]
  · have hz : value y e = 0 := le_antisymm (le_of_not_gt hvpos) (hv y e)
    simp [hz]

theorem optimal_virtual_initialization (μ : FiniteLaw W) (M : Matroid E)
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e) :
    virtualTotalLiveValue μ M (fun y => optimalBasis M (value y) (hv y))
      (fun y => optimalBasis_isBase M (value y) (hv y)) value (initialVirtualState M) = expectedOptimum μ M value :=
  initialVirtualState_value μ M _ _ value hv (fun y => optimalBasis_weight M (value y) (hv y))

end MatroidProphetSecretary
