import MatroidProphetSecretary.BernoulliRankBound

/-! Directional derivatives of finite Bernoulli expectations. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def bernoulliWeight (a : ℝ) (b : Bool) : ℝ := if b = true then a else 1 - a

def bernoulliMass (a : E → ℝ) (x : E → Bool) : ℝ := ∏ e, bernoulliWeight (a e) (x e)

def bernoulliExcept (a : E → ℝ) (e : E) (x : E → Bool) : ℝ :=
  ∏ f ∈ univ.erase e, bernoulliWeight (a f) (x f)

def replaceDifference (e : E) (f : (E → Bool) → ℝ) (x : E → Bool) : ℝ :=
  f (Function.update x e true) - f (Function.update x e false)

theorem bernoulliMass_factor (a : E → ℝ) (e : E) (x : E → Bool) :
    bernoulliMass a x = bernoulliWeight (a e) (x e) * bernoulliExcept a e x :=
  (mul_prod_erase univ (fun f => bernoulliWeight (a f) (x f)) (mem_univ e)).symm

theorem bernoulliExcept_assembleBit (a : E → ℝ) (e : E) (b c : Bool)
    (rest : {f // f ≠ e} → Bool) :
    bernoulliExcept a e (assembleBit e b rest) = bernoulliExcept a e (assembleBit e c rest) := by
  apply prod_congr rfl
  intro f hf
  have hfe := (mem_erase.mp hf).1
  rw [assembleBit_other e b rest f hfe, assembleBit_other e c rest f hfe]

theorem bernoulli_generator_column (a : E → ℝ) (e : E) (f : (E → Bool) → ℝ) :
    (∑ x, bernoulliExcept a e x * (if x e = true then 1 else -1) * f x) =
      bernoulliEval a (replaceDifference e f) := by
  change _ = ∑ x, bernoulliMass a x * replaceDifference e f x
  rw [sum_split_bit e, sum_split_bit e]
  apply sum_congr rfl
  intro rest hrest
  simp only [assembleBit_self, if_true, Bool.false_eq_true, if_false,
    replaceDifference, assembleBit_update]
  rw [bernoulliMass_factor a e (assembleBit e true rest),
    bernoulliMass_factor a e (assembleBit e false rest), assembleBit_self, assembleBit_self]
  simp only [bernoulliWeight, Bool.false_eq_true, if_false, if_true]
  rw [bernoulliExcept_assembleBit a e true false rest]
  ring

theorem bernoulliWeight_hasDerivAt (a b t : ℝ) (s : Bool) :
    HasDerivAt (fun u => bernoulliWeight (a + u * b) s)
      ((if s = true then 1 else -1) * b) t := by
  have hlin := (hasDerivAt_const t a).add ((hasDerivAt_id t).mul_const b)
  cases s
  · convert hlin.const_sub 1 using 1 <;> simp [bernoulliWeight]
  · convert hlin using 1 <;> simp [bernoulliWeight]

theorem bernoulliEval_hasDerivAt (a b : E → ℝ) (f : (E → Bool) → ℝ) (t : ℝ) :
    HasDerivAt (fun u => bernoulliEval (fun e => a e + u * b e) f)
      (∑ e, b e * bernoulliEval (fun i => a i + t * b i) (replaceDifference e f)) t := by
  have hworld : ∀ x : E → Bool,
      HasDerivAt (fun u => bernoulliMass (fun e => a e + u * b e) x * f x)
        ((∑ e, bernoulliExcept (fun i => a i + t * b i) e x *
          ((if x e = true then 1 else -1) * b e)) * f x) t := by
    intro x
    simpa only [bernoulliMass, bernoulliExcept, smul_eq_mul] using
      (HasDerivAt.finset_prod (u := univ) (fun e _ => bernoulliWeight_hasDerivAt (a e) (b e) t (x e))).mul_const (f x)
  have hsum := HasDerivAt.sum (u := univ) (fun x _ => hworld x)
  have hvalue :
      (∑ x, (∑ e, bernoulliExcept (fun i => a i + t * b i) e x *
          ((if x e = true then 1 else -1) * b e)) * f x) =
      ∑ e, b e * bernoulliEval (fun i => a i + t * b i) (replaceDifference e f) := by
    simp_rw [sum_mul]
    rw [sum_comm]
    apply sum_congr rfl
    intro e he
    rw [← bernoulli_generator_column, mul_sum]
    apply sum_congr rfl
    intro x hx
    ring
  rw [hvalue] at hsum
  exact hsum

theorem bitSet_update_false (x : E → Bool) (e : E) :
    bitSet (Function.update x e false) = bitSet x \ {e} := by
  ext f
  by_cases hfe : f = e
  · subst f
    simp [bitSet]
  · simp [bitSet, hfe, Function.update_of_ne hfe]

theorem rank_replaceDifference (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (e : E) (x : E → Bool) :
    replaceDifference e (rankObservable M) x =
      if e ∈ M.closure (bitSet x \ {e}) then 0 else 1 := by
  simp only [replaceDifference, rankObservable, bitSet_update, bitSet_update_false]
  rw [← Set.insert_diff_singleton (a := e) (s := bitSet x)]
  rw [realRank_insert M (bitSet x \ {e}) (fun f _ => hground f) e (hground e)]
  ring

end MatroidProphetSecretary
