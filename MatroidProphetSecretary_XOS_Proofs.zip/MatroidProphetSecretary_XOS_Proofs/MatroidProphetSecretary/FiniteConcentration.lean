import MatroidProphetSecretary.FiniteExponentialBounds
import MatroidProphetSecretary.BlockIndependence
import Mathlib.Tactic.FieldSimp

/-! Relative-plus-additive concentration for finite independent bounded observations. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {A : ι → Type*} [∀ i, Fintype (A i)]

theorem product_centered_tail (laws : ∀ i, FiniteLaw (A i)) (W : ∀ i, A i → ℝ)
    (hW0 : ∀ i x, 0 ≤ W i x) (hW1 : ∀ i x, W i x ≤ 1) (t a : ℝ) (ht : |t| ≤ 1) :
    (product laws).prob (fun x => a ≤ t * ∑ i, (W i (x i) - (laws i).expect (W i))) ≤
      Real.exp (-a + (∑ i, (laws i).expect (W i)) * t^2) := by
  calc
    _ ≤ Real.exp (-a) * (product laws).expect
        (fun x => Real.exp (t * ∑ i, (W i (x i) - (laws i).expect (W i)))) :=
      prob_le_exp_moment _ _ a
    _ ≤ Real.exp (-a) * Real.exp ((∑ i, (laws i).expect (W i)) * t^2) :=
      mul_le_mul_of_nonneg_left (product_centered_exp_moment laws W hW0 hW1 t ht) (Real.exp_nonneg _)
    _ = _ := (Real.exp_add _ _).symm

theorem product_signed_relative_tail (laws : ∀ i, FiniteLaw (A i)) (W : ∀ i, A i → ℝ)
    (hW0 : ∀ i x, 0 ≤ W i x) (hW1 : ∀ i x, W i x ≤ 1)
    (μ : ℝ) (hμ : ∀ i, (laws i).expect (W i) = μ)
    (s γ t : ℝ) (hs : |s| = 1) (hγ0 : 0 < γ) (hγ1 : γ ≤ 1) :
    (product laws).prob (fun x => (Fintype.card ι : ℝ) * (γ*μ+t) <
      s * ∑ i, (W i (x i) - μ)) ≤ Real.exp (-(Fintype.card ι : ℝ)*γ*t) := by
  have hsq : s^2 = 1 := by nlinarith [sq_abs s]
  have ht : |s*γ| ≤ 1 := by rw [abs_mul, hs, one_mul, abs_of_pos hγ0]; exact hγ1
  have h := product_centered_tail laws W hW0 hW1 (s*γ)
    (γ*((Fintype.card ι : ℝ)*(γ*μ+t))) ht
  simp only [hμ, sum_const, card_univ, nsmul_eq_mul] at h
  have he : - (γ*((Fintype.card ι : ℝ)*(γ*μ+t))) +
      ((Fintype.card ι : ℝ)*μ)*(s*γ)^2 = -(Fintype.card ι : ℝ)*γ*t := by
    rw [mul_pow, hsq]
    ring
  rw [he] at h
  refine (prob_mono _ (fun x hx => ?_)).trans h
  calc
    γ*((Fintype.card ι : ℝ)*(γ*μ+t)) ≤ γ*(s * ∑ i, (W i (x i)-μ)) :=
      mul_le_mul_of_nonneg_left hx.le hγ0.le
    _ = (s*γ) * ∑ i, (W i (x i)-μ) := by ring

theorem product_absolute_relative_tail (laws : ∀ i, FiniteLaw (A i)) (W : ∀ i, A i → ℝ)
    (hW0 : ∀ i x, 0 ≤ W i x) (hW1 : ∀ i x, W i x ≤ 1)
    (μ : ℝ) (hμ : ∀ i, (laws i).expect (W i) = μ)
    (γ t : ℝ) (hγ0 : 0 < γ) (hγ1 : γ ≤ 1) :
    (product laws).prob (fun x => (Fintype.card ι : ℝ) * (γ*μ+t) <
      |∑ i, (W i (x i)-μ)|) ≤ 2 * Real.exp (-(Fintype.card ι : ℝ)*γ*t) := by
  let bad (b : Bool) (x : ∀ i, A i) : Prop :=
    (Fintype.card ι : ℝ)*(γ*μ+t) < (if b then 1 else -1) * ∑ i, (W i (x i)-μ)
  have hb (b : Bool) : (product laws).prob (bad b) ≤ Real.exp (-(Fintype.card ι : ℝ)*γ*t) :=
    product_signed_relative_tail laws W hW0 hW1 μ hμ (if b then 1 else -1) γ t
      (by cases b <;> norm_num) hγ0 hγ1
  have hp (x : ∀ i, A i) :
      (if (Fintype.card ι : ℝ)*(γ*μ+t) < |∑ i, (W i (x i)-μ)| then (1 : ℝ) else 0) ≤
        (if bad false x then 1 else 0) + (if bad true x then 1 else 0) := by
    by_cases hx : (Fintype.card ι : ℝ)*(γ*μ+t) < |∑ i, (W i (x i)-μ)|
    · rw [if_pos hx]
      rcases lt_abs.mp hx with h | h
      · have ht : bad true x := by simpa [bad] using h
        simp only [if_pos ht]
        split_ifs <;> norm_num
      · have hf : bad false x := by simpa [bad] using h
        simp only [if_pos hf]
        split_ifs <;> norm_num
    · rw [if_neg hx]
      split_ifs <;> norm_num
  have h := (product laws).expect_mono hp
  rw [expect_add] at h
  exact h.trans (by simpa only [prob, two_mul] using add_le_add (hb false) (hb true))

theorem iid_average_relative_tail {Ω : Type*} [Fintype Ω] (law : FiniteLaw Ω)
    (W : Ω → ℝ) (hW0 : ∀ x, 0 ≤ W x) (hW1 : ∀ x, W x ≤ 1)
    (m : ℕ) (hm : 0 < m) (γ t : ℝ) (hγ0 : 0 < γ) (hγ1 : γ ≤ 1) :
    (product (fun _ : Fin m => law)).prob
      (fun x => γ * law.expect W + t < |(∑ i, W (x i))/(m:ℝ) - law.expect W|) ≤
        2 * Real.exp (-(m:ℝ)*γ*t) := by
  have hm' : 0 < (m:ℝ) := Nat.cast_pos.mpr hm
  have h := product_absolute_relative_tail (fun _ : Fin m => law) (fun _ => W)
    (fun _ => hW0) (fun _ => hW1) (law.expect W) (fun _ => rfl) γ t hγ0 hγ1
  simp only [Fintype.card_fin] at h
  refine (prob_mono _ (fun x hx => ?_)).trans h
  have hid : (∑ i, W (x i))/(m:ℝ) - law.expect W =
      (∑ i, (W (x i) - law.expect W))/(m:ℝ) := by
    rw [sum_sub_distrib]
    simp only [sum_const, card_univ, Fintype.card_fin, nsmul_eq_mul]
    field_simp
  rw [hid, abs_div, abs_of_pos hm'] at hx
  simpa only [mul_comm] using (lt_div_iff₀ hm').mp hx

end MatroidProphetSecretary.FiniteLaw
