import MatroidProphetSecretary.FirstArrivalReward
import MatroidProphetSecretary.SelectedReferenceAction

/-! Actual residual policies implement the threshold action's child potentials. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem threshold_policy_of_children {n k : ℕ} (prior : RationalPriors (n+1) k)
    (M : Matroid (Fin (n+1))) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin (n+1))))
    (a q : ℝ) (p : Fin (n+1) → ℝ)
    (hdelete : ∀ e, ∃ policy : OnlinePolicy n 0, PolicyFeasible (remainingDelete M e) policy ∧
      a*referenceExpectedOptimum (prior.remaining e).law (remainingDelete M e)
        (fun i v => ((prior.remaining e).value i v : ℝ)) q ≤ expectedPolicyReward (prior.remaining e) policy)
    (hcontract : ∀ e, ∃ policy : OnlinePolicy n 0, PolicyFeasible (remainingContract M e) policy ∧
      a*referenceExpectedOptimum (prior.remaining e).law (remainingContract M e)
        (fun i v => ((prior.remaining e).value i v : ℝ)) q ≤ expectedPolicyReward (prior.remaining e) policy) :
    ∃ policy : OnlinePolicy (n+1) 0, PolicyFeasible M policy ∧
      (FiniteLaw.uniform (Fin (n+1))).expect (fun e => (prior.law e).expect (fun v =>
        thresholdEpochValue (FiniteLaw.product (alignedReferenceLaws prior.law (fun e v => (prior.value e v : ℝ)) q)) M
          (optionalCoordinateValues (fun e v => (prior.value e v : ℝ))) hnonloop a p e (prior.value e v))) ≤
        expectedPolicyReward prior policy := by
  choose deletion hdf hdr using hdelete
  choose contraction hcf hcr using hcontract
  let decision := fun e v => decide (p e < v)
  let child : Fin (n+1) → Bool → OnlinePolicy n 0 := fun e b => if b then contraction e else deletion e
  refine ⟨firstArrivalPolicy decision child,?_,?_⟩
  · apply firstArrivalPolicy_feasible M decision child
    · exact fun e _ _ => hnonloop e
    · exact hdf
    · exact fun e _ => hcf e
  · rw [expected_firstArrivalPolicy]
    apply FiniteLaw.expect_mono
    intro e
    apply FiniteLaw.expect_mono
    intro v
    rw [thresholdEpochValue_child_potentials]
    by_cases hv : p e < (prior.value e v : ℝ)
    · simp only [decision,hv,decide_true,if_true,child]
      exact add_le_add_left (hcr e) _
    · simp only [decision,hv,decide_false,Bool.false_eq_true,if_false,child,zero_add]
      exact hdr e

theorem reference_threshold_policy_of_children {n k B : ℕ} (prior : RationalPriors (n+1) k)
    (M : Matroid (Fin (n+1))) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin (n+1))))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    (q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (Fin (n+1) → Bool)))
    (hdelete : ∀ e, ∃ policy : OnlinePolicy n 0, PolicyFeasible (remainingDelete M e) policy ∧
      discount q*referenceExpectedOptimum (prior.remaining e).law (remainingDelete M e)
        (fun i v => ((prior.remaining e).value i v : ℝ)) q ≤ expectedPolicyReward (prior.remaining e) policy)
    (hcontract : ∀ e, ∃ policy : OnlinePolicy n 0, PolicyFeasible (remainingContract M e) policy ∧
      discount q*referenceExpectedOptimum (prior.remaining e).law (remainingContract M e)
        (fun i v => ((prior.remaining e).value i v : ℝ)) q ≤ expectedPolicyReward (prior.remaining e) policy) :
    ∃ policy : OnlinePolicy (n+1) 0, PolicyFeasible M policy ∧
      referenceThresholdEpochReward (B := B) (Nat.zero_lt_succ n) prior M hnonloop G q x ≤
        expectedPolicyReward prior policy := by
  exact threshold_policy_of_children prior M hnonloop (discount q) q
    (referenceSavedThreshold prior.law (fun e v => (prior.value e v : ℝ)) G M q B x) hdelete hcontract

end MatroidProphetSecretary
