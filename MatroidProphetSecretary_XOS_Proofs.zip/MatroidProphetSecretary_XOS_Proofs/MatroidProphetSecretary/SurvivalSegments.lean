import Mathlib.Analysis.SpecialFunctions.Integrals
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity

/-! Exact survival identities between accepted events and across finite accepted histories. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory

theorem exponential_segment_mass (s lam k a b : ℝ) :
    (∫ t in a..b, lam*k*s*Real.exp (-lam*k*(t-a))) = s-s*Real.exp (-lam*k*(b-a)) := by
  have hd (t : ℝ) : HasDerivAt (fun u => -s*Real.exp (-lam*k*(u-a)))
      (lam*k*s*Real.exp (-lam*k*(t-a))) t := by
    convert ((((hasDerivAt_id t).sub_const a).const_mul (-lam*k)).exp.const_mul (-s)) using 1 <;>
      simp only [id_eq] <;> ring
  have h := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    (show IntervalIntegrable (fun t => lam*k*s*Real.exp (-lam*k*(t-a))) volume a b from
      (by fun_prop : Continuous (fun t => lam*k*s*Real.exp (-lam*k*(t-a)))).intervalIntegrable a b)
  convert h using 1 <;> simp <;> ring

def accumulatedExposure (dose : ℕ → ℝ) (n : ℕ) : ℝ := ∑ i ∈ range n, dose i

def historySurvival (dose : ℕ → ℝ) (n : ℕ) : ℝ := Real.exp (-accumulatedExposure dose n)

theorem historySurvival_zero (dose : ℕ → ℝ) : historySurvival dose 0 = 1 := by
  simp [historySurvival,accumulatedExposure]

theorem historySurvival_pos (dose : ℕ → ℝ) (n : ℕ) : 0 < historySurvival dose n := Real.exp_pos _

theorem historySurvival_step (dose : ℕ → ℝ) (n : ℕ) :
    historySurvival dose (n+1) = historySurvival dose n * Real.exp (-dose n) := by
  simp only [historySurvival,accumulatedExposure,sum_range_succ,neg_add,Real.exp_add]

theorem historySurvival_mass (dose : ℕ → ℝ) (n : ℕ) :
    (∑ i ∈ range n, historySurvival dose i * (1-Real.exp (-dose i))) = 1-historySurvival dose n := by
  induction n with
  | zero => simp [historySurvival_zero]
  | succ n ih => rw [sum_range_succ,ih,historySurvival_step]; ring

theorem historySurvival_monotone (dose : ℕ → ℝ) (hdose : ∀ i, 0 ≤ dose i) :
    Antitone (historySurvival dose) := by
  apply antitone_nat_of_succ_le
  intro n
  rw [historySurvival_step]
  exact mul_le_of_le_one_right (historySurvival_pos dose n).le
    (Real.exp_le_one_iff.mpr (neg_nonpos.mpr (hdose n)))

theorem early_intensity_cancellation (lam k exposure : ℝ) :
    (lam*Real.exp (-exposure)*k)/Real.exp (-exposure) = lam*k := by
  field_simp
  <;> ring

theorem late_survival_rate_bounds (lam exposure α elapsed δ integralK ω : ℝ)
    (hlam : 0 ≤ lam) (hexposure : 0 ≤ exposure) (hα : α ≤ Real.exp (-exposure))
    (hK0 : 0 ≤ integralK) (hK1 : integralK ≤ elapsed) (ht : elapsed ≤ δ)
    (hω : ω = α-lam*δ) (hωpos : 0 < ω) :
    let S := Real.exp (-exposure)-lam*integralK
    ω ≤ S ∧ 0 < S ∧ lam*(1+exposure) ≤ lam/S ∧ lam/S ≤ lam/ω := by
  have hK : integralK ≤ δ := hK1.trans ht
  have hlow : ω ≤ Real.exp (-exposure)-lam*integralK := by
    rw [hω]
    nlinarith [mul_nonneg hlam (sub_nonneg.mpr hK)]
  have hS : 0 < Real.exp (-exposure)-lam*integralK := hωpos.trans_le hlow
  refine ⟨hlow,hS,?_,div_le_div_of_nonneg_left hlam hωpos hlow⟩
  have hu : Real.exp (-exposure)-lam*integralK ≤ Real.exp (-exposure) :=
    sub_le_self _ (mul_nonneg hlam hK0)
  have hdiv := div_le_div_of_nonneg_left hlam hS hu
  have hexp : 1+exposure ≤ Real.exp exposure := by linarith [Real.add_one_le_exp exposure]
  calc
    lam*(1+exposure) ≤ lam*Real.exp exposure := mul_le_mul_of_nonneg_left hexp hlam
    _ = lam/Real.exp (-exposure) := by rw [Real.exp_neg,div_inv_eq_mul]
    _ ≤ lam/(Real.exp (-exposure)-lam*integralK) := hdiv

end MatroidProphetSecretary

