import MatroidProphetSecretary.AdaptiveBatches

/-! Exact finite adaptive trajectory expectations, persistence, and potential drift. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {Ω S : Type*} [Fintype Ω]

def stateAfter (update : S → Ω → S) : (n : ℕ) → S → (Fin n → Ω) → S
  | 0, s, _ => s
  | n+1, s, x => stateAfter update n (update s (x 0)) (fun i => x i.succ)

def trajectoryReward (update : S → Ω → S) (reward : S → Ω → ℝ) :
    (n : ℕ) → S → (Fin n → Ω) → ℝ
  | 0, _, _ => 0
  | n+1, s, x => reward s (x 0) + trajectoryReward update reward n (update s (x 0)) (fun i => x i.succ)

theorem adaptive_terminal_succ (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (f : S → ℝ) (n : ℕ) (s : S) :
    (adaptiveBatches batch update (n+1) s).expect (fun x => f (stateAfter update (n+1) s x)) =
      (batch s).expect (fun y => (adaptiveBatches batch update n (update s y)).expect
        (fun x => f (stateAfter update n (update s y) x))) := by
  simp only [adaptiveBatches,bind_expect,map_expect,stateAfter,Fin.cons_zero,Fin.cons_succ]

theorem adaptive_terminal_lower (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (f : S → ℝ) (a : ℝ) (ha : 0 ≤ a)
    (hstep : ∀ s, a*f s ≤ (batch s).expect (fun x => f (update s x))) (n : ℕ) (s : S) :
    a^n*f s ≤ (adaptiveBatches batch update n s).expect (fun x => f (stateAfter update n s x)) := by
  induction n generalizing s with
  | zero => simp [stateAfter]
  | succ n ih =>
    rw [adaptive_terminal_succ]
    calc
      a^(n+1)*f s = a^n*(a*f s) := by rw [pow_succ]; ring
      _ ≤ a^n*(batch s).expect (fun x => f (update s x)) :=
        mul_le_mul_of_nonneg_left (hstep s) (pow_nonneg ha n)
      _ = (batch s).expect (fun x => a^n*f (update s x)) := (expect_const_mul ..).symm
      _ ≤ _ := (batch s).expect_mono (fun x => ih (update s x))

theorem adaptive_reward_potential_succ (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (reward : S → Ω → ℝ) (f : S → ℝ) (n : ℕ) (s : S) :
    (adaptiveBatches batch update (n+1) s).expect (fun x =>
      trajectoryReward update reward (n+1) s x + f (stateAfter update (n+1) s x)) =
    (batch s).expect (fun y => reward s y + (adaptiveBatches batch update n (update s y)).expect
      (fun x => trajectoryReward update reward n (update s y) x + f (stateAfter update n (update s y) x))) := by
  simp only [adaptiveBatches,bind_expect,map_expect,trajectoryReward,stateAfter,Fin.cons_zero,Fin.cons_succ,
    add_assoc,expect_add,expect_const]

theorem adaptive_reward_potential (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (reward : S → Ω → ℝ) (f : S → ℝ)
    (hstep : ∀ s, f s ≤ (batch s).expect (fun x => reward s x + f (update s x))) (n : ℕ) (s : S) :
    f s ≤ (adaptiveBatches batch update n s).expect
      (fun x => trajectoryReward update reward n s x + f (stateAfter update n s x)) := by
  induction n generalizing s with
  | zero => simp [trajectoryReward,stateAfter]
  | succ n ih =>
    rw [adaptive_reward_potential_succ]
    exact (hstep s).trans ((batch s).expect_mono (fun x => add_le_add_left (ih (update s x)) _))

theorem adaptive_reward_lower (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (reward : S → Ω → ℝ) (w : S → ℝ) (a : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1)
    (hsurvive : ∀ s, a*w s ≤ (batch s).expect (fun x => w (update s x)))
    (hreward : ∀ s, (1-a)*w s ≤ (batch s).expect (reward s)) (n : ℕ) (s : S) :
    (1-a^n)*w s ≤ (adaptiveBatches batch update n s).expect (trajectoryReward update reward n s) := by
  induction n generalizing s with
  | zero => simp [trajectoryReward]
  | succ n ih =>
    simp only [adaptiveBatches,bind_expect,map_expect,trajectoryReward,Fin.cons_zero,Fin.cons_succ,expect_add,expect_const]
    have hc : 0 ≤ 1-a^n := sub_nonneg.mpr (pow_le_one₀ ha0 ha1)
    have hfuture := (batch s).expect_mono (fun x => ih (update s x))
    rw [expect_const_mul] at hfuture
    have hsurv := mul_le_mul_of_nonneg_left (hsurvive s) hc
    have hr := hreward s
    rw [pow_succ]
    nlinarith only [hfuture,hsurv,hr]

end MatroidProphetSecretary.FiniteLaw
