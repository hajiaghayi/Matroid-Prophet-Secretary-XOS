import MatroidProphetSecretary.EulerRecordReward
import MatroidProphetSecretary.BinExposureFreezing
import MatroidProphetSecretary.SupportedPathLaw
import MatroidProphetSecretary.LiftedVirtualProcess

/-! Before the cutoff, the physical exchange trace has exactly the constant-rate virtual law. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem early_grid_mass
    (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) :
    (1/(L:ℝ))*(1/cfg.q)*Fintype.card (Fin N) ≤ 1 := by
  have hlam : 0 ≤ 1/cfg.q := one_div_nonneg.mpr cfg.q_pos.le
  have hr : 1/cfg.q ≤ (1/cfg.q)/omega := (le_div_iff₀ homega).mpr (mul_le_of_le_one_right hlam homega1)
  have h := mul_le_mul_of_nonneg_left hr
    (mul_nonneg (Nat.cast_nonneg N) (one_div_nonneg.mpr (Nat.cast_nonneg L)))
  simp only [Fintype.card_fin]
  nlinarith only [h,hbudget]

theorem euler_early_law (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (hcut : cfg.cut ≤ L) :
    FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
      cfg.eulerBlockUpdate cfg.cut (0,[]) =
    FiniteLaw.adaptiveBatches
      (fun s => virtualStepLaw (FiniteLaw.product cfg.reference) M base hbase value s
        (1/(L:ℝ)) (fun _ => 1/cfg.q) (1/cfg.q)
        (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)
        (fun _ => one_div_nonneg.mpr cfg.q_pos.le) (fun _ => le_rfl)
        (cfg.early_grid_mass omega homega homega1 hbudget))
      (virtualUpdate M base hbase value) cfg.cut (initialVirtualState M) := by
  let project := fun state : BlockState N V => recordReplay M base hbase value state.2
  let batch := fun s => virtualStepLaw (FiniteLaw.product cfg.reference) M base hbase value s
    (1/(L:ℝ)) (fun _ => 1/cfg.q) (1/cfg.q)
    (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)
    (fun _ => one_div_nonneg.mpr cfg.q_pos.le) (fun _ => le_rfl)
    (cfg.early_grid_mass omega homega homega1 hbudget)
  have h := FiniteLaw.adaptive_law_eq_supported
    (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
    (fun state => batch (project state)) cfg.eulerBlockUpdate
    (fun j state => state.1 = j*N) cfg.cut 0 (0,[]) (by simp)
  have heq : FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
      cfg.eulerBlockUpdate cfg.cut (0,[]) =
      FiniteLaw.adaptiveBatches (fun state => batch (project state)) cfg.eulerBlockUpdate cfg.cut (0,[]) := by
    apply h
    · intro j hj hjn state hstate event hevent
      change state.1+N = (j+1)*N
      rw [hstate,Nat.add_mul,Nat.one_mul]
    · intro j hj hjn state hstate
      have hjcut : j < cfg.cut := by omega
      have hjL : j < L := hjcut.trans_le hcut
      have hc : gridClock N L cfg.clocks_pos state.1 = (⟨j,hjL⟩ : Fin L) := by
        rw [hstate]
        exact cfg.gridClock_round ⟨j,hjL⟩
      unfold eulerBlockBatch eulerStep batch project
      rw [hc]
      unfold virtualStepLaw
      congr 1
      funext event
      unfold virtualStepWeight
      rw [cfg.eulerRate_early state.2 ⟨j,hjL⟩ hjcut event.1]
  rw [heq,FiniteLaw.adaptiveBatches_projection project cfg.eulerBlockUpdate (virtualUpdate M base hbase value)
    (cfg.eulerBlockUpdate_replay M base hbase value) batch cfg.cut (0,[])]
  rfl

theorem euler_early_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (hcut : cfg.cut ≤ L) :
    (1-(1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut)*
      virtualTotalLiveValue (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M) ≤
    (FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
      cfg.eulerBlockUpdate cfg.cut (0,[])).expect
      (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x).2) := by
  rw [cfg.euler_trajectory_reward M base hbase value hsmall omega homega homega1 hlower hbudget cfg.cut (0,[])]
  simp only [recordReward,List.map_nil,List.sum_nil,zero_add]
  have hproj : FiniteLaw.trajectoryReward cfg.eulerBlockUpdate
      (fun s => virtualCredit M base hbase value (recordReplay M base hbase value s.2)) cfg.cut (0,[]) =
      FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value)
        cfg.cut (initialVirtualState M) := by
    funext x
    exact FiniteLaw.trajectoryReward_projection
      (fun state : BlockState N V => recordReplay M base hbase value state.2) cfg.eulerBlockUpdate
      (virtualUpdate M base hbase value) (cfg.eulerBlockUpdate_replay M base hbase value)
      (virtualCredit M base hbase value) cfg.cut (0,[]) x
  rw [hproj]
  rw [cfg.euler_early_law M base hbase value hsmall omega homega homega1 hlower hbudget hcut]
  exact virtualProcess_early_reward (FiniteLaw.product cfg.reference) M base hbase value hv
    (1/(L:ℝ)) (1/cfg.q) (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)
    hsmall.le (cfg.early_grid_mass omega homega homega1 hbudget) cfg.cut (initialVirtualState M)

end MatroidProphetSecretary.PrivateGridConfig
