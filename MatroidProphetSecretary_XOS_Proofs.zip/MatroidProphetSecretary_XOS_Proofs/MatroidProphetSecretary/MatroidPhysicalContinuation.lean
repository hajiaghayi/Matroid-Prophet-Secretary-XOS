import MatroidProphetSecretary.PhysicalFullReward
import MatroidProphetSecretary.PhysicalMeshChoice

/-! A concrete finite private-clock continuation approaches the paper's factor, including room for clock collisions. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

def matroidGridConfig (hN : 0 < N) (hL : 0 < L) (prior : Fin N → FiniteLaw V)
    (reference : Fin N → FiniteLaw (Option V)) (q : ℝ) (hq : 0 < q)
    (hdom : ∀ e v, (reference e).mass (some v) ≤ q*(prior e).mass v)
    (hstep : (1/(L:ℝ))*(1/q) ≤ 1) (cut : ℕ)
    (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hzero : ∀ y e, y e = none → value y e = 0) : PrivateGridConfig N L V where
  labels_pos := hN
  clocks_pos := hL
  prior := prior
  reference := reference
  q := q
  q_pos := hq
  domination := hdom
  step_le := hstep
  cut := cut
  live history e y := e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y
  positive history e y hy hn := by
    have hp : 0 < value y e := (Finset.mem_filter.mp hy).2
    rw [hzero y e hn] at hp
    exact lt_irrefl _ hp

theorem exists_finite_physical_continuation (hN : 0 < N) (prior : Fin N → FiniteLaw V)
    (reference : Fin N → FiniteLaw (Option V))
    (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hzero : ∀ y e, y e = none → value y e = 0)
    (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (hF : 0 < expectedOptimum (FiniteLaw.product reference) M value) {q c : ℝ}
    (hq : q ∈ interval) (hdom : ∀ e v, (reference e).mass (some v) ≤ q*(prior e).mass v)
    (hc : c < phi q (overlap (FiniteLaw.product reference) value base/expectedOptimum (FiniteLaw.product reference) M value)) :
    ∃ (L : ℕ) (cfg : PrivateGridConfig N L V),
      N ≤ L ∧ cfg.prior = prior ∧ cfg.reference = reference ∧ cfg.q = q ∧
      (∀ history e y, cfg.live history e y ↔
        e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y) ∧
      c*expectedOptimum (FiniteLaw.product reference) M value+(N:ℝ)^2*finiteValueBudget value/L <
        (FiniteLaw.product cfg.laws).expect (fun tapes => recordReward value (cfg.run tapes (L*N))) := by
  let F := expectedOptimum (FiniteLaw.product reference) M value
  let Q := overlap (FiniteLaw.product reference) value base
  let B := finiteValueBudget value
  let C := fun w : ℝ => (2*(N:ℝ)^2*((1/q)/w)^2+(N:ℝ)^2)*B/F
  obtain ⟨w,n,hw,hw1,hn,hNL,hp,hbudget,hsurv,hfactor⟩ := exists_physical_mesh_factor N C hq hc
  let L := physicalMeshSize n
  have hL : 0 < L := Nat.mul_pos (by norm_num) hn
  let cfg := matroidGridConfig hN hL prior reference q (q_pos hq) hdom hp.le
    (physicalMeshCut n) M base hbase value hzero
  refine ⟨L,cfg,hNL,rfl,rfl,rfl,(fun _ _ _ => Iff.rfl),?_⟩
  have hbound := cfg.physical_full_reward M base hbase value hv (fun _ _ _ => Iff.rfl)
    hp w hw hw1 hsurv hbudget (physicalMesh_cut_le n)
  dsimp only at hbound
  rw [initialVirtualState_value (FiniteLaw.product cfg.reference) M base hbase value hv hopt,
    initialVirtualState_overlap] at hbound
  have hscaled := mul_lt_mul_of_pos_right hfactor hF
  have hformula :
      (physicalMeshFactor (1/q) w (Q/F) n-C w/(physicalMeshSize n:ℝ))*F =
      (1-physicalMeshAlpha (1/q) n)*F+
        physicalMeshLate (1/q) w n*((1-physicalMeshStep (1/q) n)*physicalMeshAlpha (1/q) n*F+
          physicalMeshAlpha (1/q) n*(1-physicalMeshAlpha (1/q) n)*Q)-
        (2*(N:ℝ)^2*((1/q)/w)^2+(N:ℝ)^2)*B/(physicalMeshSize n:ℝ) := by
    unfold physicalMeshFactor C
    have hF' : F ≠ 0 := hF.ne'
    field_simp
    <;> ring
  change c*F < (physicalMeshFactor (1/q) w (Q/F) n-C w/(physicalMeshSize n:ℝ))*F at hscaled
  rw [hformula] at hscaled
  have hrem : physicalMeshSize n-physicalMeshCut n = n := physicalMesh_remainder n
  change (1-(1-(1/(L:ℝ))*(1/q))^(physicalMeshCut n))*F+
    (w*(1-(1-(1/(L:ℝ))*((1/q)/w))^(physicalMeshSize n-physicalMeshCut n)))*
      ((1-(1/(L:ℝ))*(1/q))*(1-(1/(L:ℝ))*(1/q))^(physicalMeshCut n)*F+
        (1-(1/(L:ℝ))*(1/q))^(physicalMeshCut n)*(1-(1-(1/(L:ℝ))*(1/q))^(physicalMeshCut n))*Q)-
      2*(N:ℝ)^2*((1/q)/w)^2*B/L ≤ _ at hbound
  rw [hrem] at hbound
  dsimp only [physicalMeshFactor,physicalMeshAlpha,physicalMeshStep,physicalMeshLate] at hscaled
  change c*F+(N:ℝ)^2*B/L < _
  dsimp only [L] at hbound ⊢
  simp only [add_mul,add_div] at hscaled
  linarith only [hscaled,hbound]

end MatroidProphetSecretary
