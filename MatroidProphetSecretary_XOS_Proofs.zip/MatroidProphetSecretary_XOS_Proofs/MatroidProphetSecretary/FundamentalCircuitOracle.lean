import Mathlib.Data.Matroid.Loop
import Mathlib.Data.Finset.Basic
import Mathlib.Tactic

/-! The independence oracle detects intersections with a fundamental circuit. -/

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

variable {E : Type*} [DecidableEq E]

theorem fundamental_circuit_group_test (M : Matroid E) (B S : Finset E)
    (hB : M.IsBase (B : Set E)) (hSB : S ⊆ B) (f : E) (hfE : f ∈ M.E) (hfB : f ∉ B) :
    M.Indep (insert f (B \ S) : Set E) ↔ ∃ e ∈ S, e ∈ M.fundCircuit f (B : Set E) := by
  have hC := hB.fundCircuit_isCircuit hfE hfB
  have hsub : (insert f (B \ S) : Set E) ⊆ insert f (B : Set E) := by
    intro e he
    rcases he with rfl | he
    · exact Set.mem_insert _ _
    · exact Set.mem_insert_of_mem _ he.1
  constructor
  · intro hind
    by_contra hn
    push_neg at hn
    apply hC.not_indep
    apply hind.subset
    intro e he
    rcases M.fundCircuit_subset_insert f (B : Set E) he with hef | heB
    · exact Or.inl hef
    · exact Or.inr ⟨heB,fun heS => hn e heS he⟩
  · rintro ⟨e,heS,heC⟩
    by_contra hn
    have hground : (insert f (B \ S) : Set E) ⊆ M.E := by
      intro x hx
      rcases hx with rfl | hx
      · exact hfE
      · exact hB.subset_ground hx.1
    obtain ⟨D,hDsub,hD⟩ := ((Matroid.not_indep_iff hground).mp hn).exists_isCircuit_subset
    have hDC : D = M.fundCircuit f (B : Set E) := hD.eq_fundCircuit_of_subset hB.indep (hDsub.trans hsub)
    have heD := hDsub (hDC.symm ▸ heC)
    rcases heD with hef | heBS
    · exact hfB (hef ▸ hSB heS)
    · exact heBS.2 heS

def fundamentalCircuitTest (oracle : Finset E → Bool) (B : Finset E) (f : E) (S : Finset E) : Bool :=
  oracle (insert f (B \ (S ∩ B)))

theorem fundamentalCircuitTest_spec (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (B : Finset E) (hB : M.IsBase (B : Set E)) (f : E) (hfE : f ∈ M.E) (hfB : f ∉ B) (S : Finset E) :
    fundamentalCircuitTest oracle B f S = true ↔ ∃ e ∈ S, e ∈ B ∧ e ∈ M.fundCircuit f (B : Set E) := by
  rw [fundamentalCircuitTest,horacle]
  have h := fundamental_circuit_group_test M B (S ∩ B) hB inter_subset_right f hfE hfB
  simpa only [mem_inter,exists_prop,and_assoc,Finset.coe_insert,Finset.coe_sdiff] using h

end MatroidProphetSecretary
