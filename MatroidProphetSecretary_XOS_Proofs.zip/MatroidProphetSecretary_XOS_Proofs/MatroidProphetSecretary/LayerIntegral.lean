import MatroidProphetSecretary.WeightLayers
import Mathlib.MeasureTheory.Integral.Bochner.Set
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

/-! Lebesgue layer formulas for realized weighted rank. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory

variable {E : Type*} [Fintype E] [DecidableEq E]

def positiveLayer (v z : ℝ) : ℝ := if 0 < z ∧ z < v then 1 else 0

theorem positiveLayer_eq_indicator (v : ℝ) :
    positiveLayer v = (Set.Ioo 0 v).indicator (fun _ : ℝ => (1 : ℝ)) := by
  funext z
  simp [positiveLayer, Set.indicator]

theorem positiveLayer_integrable (v : ℝ) : Integrable (positiveLayer v) := by
  rw [positiveLayer_eq_indicator]
  apply (integrable_indicator_iff measurableSet_Ioo).mpr
  exact integrableOn_const.mpr (Or.inr (by simp))

theorem integral_positiveLayer (v : ℝ) (hv : 0 ≤ v) : ∫ z, positiveLayer v z = v := by
  rw [positiveLayer_eq_indicator]
  rw [integral_indicator measurableSet_Ioo, setIntegral_const]
  simp [Real.volume_real_Ioo_of_le hv]

def positiveRankLayer (M : Matroid E) (v : E → ℝ) (z : ℝ) : ℝ :=
  if 0 < z then ((M.eRk (valueLayer M v z)).toNat : ℝ) else 0

theorem positiveRankLayer_eq_basis_sum {M : Matroid E} {v : E → ℝ} {B : Finset E}
    (hB : M.IsBase (B : Set E)) (hopt : optimum M v = weight v B) (z : ℝ) :
    positiveRankLayer M v z = ∑ e ∈ B, positiveLayer (v e) z := by
  classical
  unfold positiveRankLayer positiveLayer
  by_cases hz : 0 < z
  · simp only [hz, if_true, true_and]
    rw [optimal_basis_layer_rank hB hopt]
    simp only [ENat.toNat_coe]
    rw [Finset.card_eq_sum_ones, Nat.cast_sum]
    simp only [Nat.cast_one, sum_filter]
  · simp [hz]

theorem positiveRankLayer_integrable (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    Integrable (positiveRankLayer M v) := by
  obtain ⟨B, hB, hopt⟩ := optimum_attained_base M v hv
  have hid : positiveRankLayer M v = fun z => ∑ e ∈ B, positiveLayer (v e) z :=
    funext (positiveRankLayer_eq_basis_sum hB hopt)
  rw [hid]
  exact integrable_finset_sum B (fun e _ => positiveLayer_integrable (v e))

/-- The weighted-rank layer formula, with the integral on the positive half-line. -/
theorem optimum_eq_integral_rank (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    optimum M v = ∫ z, positiveRankLayer M v z := by
  obtain ⟨B, hB, hopt⟩ := optimum_attained_base M v hv
  have hid : positiveRankLayer M v = fun z => ∑ e ∈ B, positiveLayer (v e) z :=
    funext (positiveRankLayer_eq_basis_sum hB hopt)
  rw [hid, integral_finset_sum B (fun e _ => positiveLayer_integrable (v e))]
  simp only [integral_positiveLayer _ (hv _)]
  exact hopt

variable {Ω : Type*} [Fintype Ω]

/-- The first identity in (3.2) for a finite law, with an actual Lebesgue integral. -/
theorem expectedOptimum_eq_integral_expected_rank (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e) :
    expectedOptimum μ M v = ∫ z, μ.expect (fun w => positiveRankLayer M (v w) z) := by
  unfold expectedOptimum FiniteLaw.expect
  rw [integral_finset_sum univ (fun w _ =>
    (positiveRankLayer_integrable M (v w) (hv w)).const_mul (μ.mass w))]
  simp only [integral_const_mul]
  apply sum_congr rfl
  intro w hw
  rw [optimum_eq_integral_rank M (v w) (hv w)]

end MatroidProphetSecretary
