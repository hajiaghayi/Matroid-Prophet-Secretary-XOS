import MatroidProphetSecretary.WeightLayers

/-! Greedy membership and preservation of optimality under a priority refinement. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem priority_refinement_optimal {M : Matroid E} {v p : E → ℝ} {B : Finset E}
    (hv : ∀ e, 0 ≤ v e) (hB : M.IsBase (B : Set E)) (hp : optimum M p = weight p B)
    (hrefine : ∀ e f, p e ≤ p f → v e ≤ v f) : optimum M v = weight v B := by
  obtain ⟨C, hC, hopt⟩ := optimum_attained_base M v hv
  let φ := chosenExchangeMap M C B hC hB
  have hpoint : ∀ e ∈ C, v e ≤ v (φ.map e) := by
    intro e he
    by_cases heB : e ∈ B
    · rw [φ.fixes e he heB]
    · exact hrefine e (φ.map e) (optimal_exchange_value_le hp heB (φ.image_mem e he)
        (φ.exchange e he).indep)
  apply le_antisymm
  · rw [hopt]
    calc
      weight v C ≤ ∑ e ∈ C, v (φ.map e) := sum_le_sum hpoint
      _ = weight v B := by
        unfold weight
        have hs : (∑ e ∈ C.image φ.map, v e) = ∑ e ∈ C, v (φ.map e) :=
          sum_image (fun e he f hf h => φ.inj e he f hf h)
        rw [φ.image_eq hC hB] at hs
        exact hs.symm
  · exact weight_le_optimumOver _ _ v hB.indep

theorem optimal_basis_mem_iff_not_span_higher {M : Matroid E} {v : E → ℝ} {B : Finset E}
    (hB : M.IsBase (B : Set E)) (hopt : optimum M v = weight v B)
    (hinj : Function.Injective v) (e : E) (he : e ∈ M.E) :
    e ∈ B ↔ e ∉ M.closure (valueLayer M v (v e)) := by
  constructor
  · intro heB hecl
    have hL := optimal_basis_superlevel_isBasis hB hopt (v e)
    rw [← hL.closure_eq_closure] at hecl
    apply hB.indep.not_mem_closure_diff_of_mem heB
    apply M.closure_subset_closure _ hecl
    intro f hf
    obtain ⟨hfB, hfv⟩ := mem_filter.mp hf
    refine ⟨hfB, ?_⟩
    intro hfe
    have hfe' : f = e := hfe
    subst f
    exact lt_irrefl _ hfv
  · intro hnot
    by_contra heB
    let Γ := M.fundCircuit e (B : Set E)
    have hΓ : M.IsCircuit Γ := hB.fundCircuit_isCircuit he heB
    have heΓ : e ∈ Γ := M.mem_fundCircuit e (B : Set E)
    have hsub : Γ \ {e} ⊆ valueLayer M v (v e) := by
      intro b hb
      have hbB : b ∈ B := by
        rcases M.fundCircuit_subset_insert e (B : Set E) hb.1 with h | h
        · exact (hb.2 h).elim
        · exact h
      have heb : e ≠ b := (show b ≠ e from hb.2).symm
      have hi := (hB.indep.mem_fundCircuit_iff (by rw [hB.closure_eq]; exact he) heB).mp hb.1
      have hinew : M.Indep ((insert e (B.erase b) : Finset E) : Set E) := by
        simpa [Finset.coe_insert, Finset.coe_erase, Set.insert_diff_singleton_comm heb] using hi
      have hval := optimal_exchange_value_le hopt heB hbB hinew
      exact ⟨hB.subset_ground hbB, lt_of_le_of_ne hval (fun hv => heb (hinj hv))⟩
    exact hnot (M.closure_subset_closure hsub (hΓ.mem_closure_diff_singleton_of_mem heΓ))

end MatroidProphetSecretary
