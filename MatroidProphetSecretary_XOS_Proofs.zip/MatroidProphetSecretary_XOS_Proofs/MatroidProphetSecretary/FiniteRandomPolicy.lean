import MatroidProphetSecretary.Problem
import MatroidProphetSecretary.FairBitApproximation

/-! Finite randomization is implemented by a history-only policy with one bounded seed. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

abbrev FiniteRandomPolicy (N : ℕ) (Ω : Type*) := Ω → List (Observation N) → Fin N → ℝ → Bool

def fixedPolicy {N : ℕ} {Ω : Type*} (policy : FiniteRandomPolicy N Ω) (w : Ω) : OnlinePolicy N 0 :=
  fun _ => policy w

def seededPolicy {N K : ℕ} {Ω : Type*} (policy : FiniteRandomPolicy N Ω) (sample : Fin (2^K) → Ω) : OnlinePolicy N K :=
  fun seed => policy (sample seed)

theorem runPolicy_seed_congr {N K J : ℕ} (policy : OnlinePolicy N K) (other : OnlinePolicy N J)
    (seed : Fin (2^K)) (seed' : Fin (2^J)) (hpolicy : ∀ history e v, policy seed history e v = other seed' history e v)
    (values : Fin N → ℝ) (order : List (Fin N)) (history : List (Observation N)) :
    runPolicy policy seed values order history = runPolicy other seed' values order history := by
  induction order generalizing history with
  | nil => rfl
  | cons e rest ih => simp only [runPolicy,hpolicy]; exact ih _

theorem completed_seededPolicy {N K : ℕ} {Ω : Type*} (policy : FiniteRandomPolicy N Ω)
    (sample : Fin (2^K) → Ω) (seed : Fin (2^K)) (values : Fin N → ℝ) (order : Equiv.Perm (Fin N)) :
    completedHistory (seededPolicy policy sample) seed values order =
      completedHistory (fixedPolicy policy (sample seed)) 0 values order :=
  runPolicy_seed_congr _ _ seed 0 (fun _ _ _ => rfl) values _ []

theorem completed_fixedPolicy {N : ℕ} {Ω : Type*} (policy : FiniteRandomPolicy N Ω)
    (w : Ω) (seed : Fin (2^0)) (values : Fin N → ℝ) (order : Equiv.Perm (Fin N)) :
    completedHistory (fixedPolicy policy w) seed values order =
      completedHistory (fixedPolicy policy w) 0 values order :=
  runPolicy_seed_congr _ _ seed 0 (fun _ _ _ => rfl) values _ []

theorem seededPolicy_feasible {N K : ℕ} {Ω : Type*} (M : Matroid (Fin N))
    (policy : FiniteRandomPolicy N Ω) (sample : Fin (2^K) → Ω)
    (hfeasible : ∀ w, PolicyFeasible M (fixedPolicy policy w)) : PolicyFeasible M (seededPolicy policy sample) := by
  intro seed values order
  rw [completed_seededPolicy]
  exact hfeasible (sample seed) 0 values order

theorem expected_fixedPolicy {N k : ℕ} {Ω : Type*} (prior : RationalPriors N k)
    (policy : FiniteRandomPolicy N Ω) (w : Ω) :
    expectedPolicyReward prior (fixedPolicy policy w) =
      (FiniteLaw.product prior.law).expect (fun values =>
        (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
          weight (prior.realization values) (acceptedSet (completedHistory (fixedPolicy policy w) 0 (prior.realization values) order)))) := by
  unfold expectedPolicyReward
  simp_rw [completed_fixedPolicy policy w]
  simp only [FiniteLaw.expect_const]

theorem expected_seededPolicy {N k K : ℕ} {Ω : Type*} (prior : RationalPriors N k)
    (policy : FiniteRandomPolicy N Ω) (sample : Fin (2^K) → Ω) :
    expectedPolicyReward prior (seededPolicy policy sample) =
      (FiniteLaw.uniform (Fin (2^K))).expect (fun seed => expectedPolicyReward prior (fixedPolicy policy (sample seed))) := by
  unfold expectedPolicyReward
  simp_rw [completed_seededPolicy,completed_fixedPolicy,FiniteLaw.expect_const]
  have hinner (values : Fin N → Fin k) := FiniteLaw.expect_comm
    (FiniteLaw.uniform (Equiv.Perm (Fin N))) (FiniteLaw.uniform (Fin (2^K)))
    (fun order seed => weight (prior.realization values)
      (acceptedSet (completedHistory (fixedPolicy policy (sample seed)) 0 (prior.realization values) order)))
  simp_rw [hinner]
  exact FiniteLaw.expect_comm _ _ _

def RationalPriors.rewardBudget {N k : ℕ} (prior : RationalPriors N k) : ℝ :=
  ∑ e, ∑ v, (prior.value e v : ℝ)

theorem RationalPriors.rewardBudget_nonneg {N k : ℕ} (prior : RationalPriors N k) : 0 ≤ prior.rewardBudget := by
  apply sum_nonneg
  intro e he
  apply sum_nonneg
  intro v hv
  exact_mod_cast prior.value_nonneg e v

theorem RationalPriors.weight_bounds {N k : ℕ} (prior : RationalPriors N k)
    (sample : Fin N → Fin k) (I : Finset (Fin N)) :
    0 ≤ weight (prior.realization sample) I ∧ weight (prior.realization sample) I ≤ prior.rewardBudget := by
  have hv (e : Fin N) : 0 ≤ prior.realization sample e := by
    change (0 : ℝ) ≤ (prior.value e (sample e) : ℝ)
    exact_mod_cast prior.value_nonneg e (sample e)
  constructor
  · exact sum_nonneg (fun e _ => hv e)
  · calc
      _ ≤ ∑ e : Fin N, prior.realization sample e :=
        sum_le_sum_of_subset_of_nonneg (subset_univ _) (fun e _ _ => hv e)
      _ ≤ prior.rewardBudget := by
        apply sum_le_sum
        intro e he
        change (prior.value e (sample e) : ℝ) ≤ ∑ v, (prior.value e v : ℝ)
        exact single_le_sum (f := fun v => (prior.value e v : ℝ))
          (fun v _ => by
            change (0 : ℝ) ≤ (prior.value e v : ℝ)
            exact_mod_cast prior.value_nonneg e v) (mem_univ (sample e))

theorem expectedPolicyReward_bounds {N k K : ℕ} (prior : RationalPriors N k) (policy : OnlinePolicy N K) :
    0 ≤ expectedPolicyReward prior policy ∧ expectedPolicyReward prior policy ≤ prior.rewardBudget := by
  constructor
  · apply FiniteLaw.expect_nonneg
    intro values
    apply FiniteLaw.expect_nonneg
    intro order
    apply FiniteLaw.expect_nonneg
    intro seed
    exact (prior.weight_bounds values _).1
  · have hpoint (values : Fin N → Fin k) (order : Equiv.Perm (Fin N)) (seed : Fin (2^K)) :
        weight (prior.realization values) (acceptedSet (completedHistory policy seed (prior.realization values) order)) ≤ prior.rewardBudget :=
      (prior.weight_bounds values _).2
    unfold expectedPolicyReward
    calc
      _ ≤ (FiniteLaw.product prior.law).expect (fun _ => prior.rewardBudget) := by
        apply FiniteLaw.expect_mono
        intro values
        have h := (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect_mono (fun order =>
          (FiniteLaw.uniform (Fin (2^K))).expect_mono (hpoint values order))
        simpa only [FiniteLaw.expect_const] using h
      _ = _ := FiniteLaw.expect_const _ _

end MatroidProphetSecretary
