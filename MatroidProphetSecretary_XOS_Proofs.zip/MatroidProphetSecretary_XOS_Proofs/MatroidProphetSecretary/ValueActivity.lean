import MatroidProphetSecretary.FinitePushforward
import MatroidProphetSecretary.RankInequality
import MatroidProphetSecretary.IndependentLayers

/-! Connecting independent finite value priors to their Bernoulli value layers. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

def valueActivity (value : ∀ e, V e → ℝ) (z : ℝ) (x : ∀ e, V e) (e : E) : Bool :=
  decide (z < value e (x e))

def activityLaws (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) (z : ℝ) : E → FiniteLaw Bool :=
  fun e => (laws e).map (fun x => decide (z < value e x))

def coordinateTail (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) : ℝ :=
  (laws e).prob (fun x => z < value e x)

theorem activityLaws_true_mass (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (z : ℝ) (e : E) :
    (activityLaws laws value z e).mass true = coordinateTail laws value z e := by
  unfold activityLaws FiniteLaw.map coordinateTail FiniteLaw.prob FiniteLaw.expect
  apply sum_congr rfl
  intro x hx
  by_cases h : z < value e x <;> simp [h]

theorem boolLaw_eq_bernoulli (μ : FiniteLaw Bool) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1)
    (hp : μ.mass true = p) : μ = bernoulliLaw p hp0 hp1 := by
  apply FiniteLaw.ext_mass
  funext b
  have ht := μ.total
  simp only [Fintype.sum_bool] at ht
  cases b <;> simp only [bernoulliLaw, Bool.false_eq_true, if_false, if_true]
  · linarith
  · exact hp

theorem activityLaws_eq_bernoulli (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) (z : ℝ) :
    activityLaws laws value z = bernoulliLaws (coordinateTail laws value z)
      (fun e => (laws e).prob_nonneg _) (fun e => (laws e).prob_le_one _) := by
  funext e
  exact boolLaw_eq_bernoulli _ _ _ _ (activityLaws_true_mass laws value z e)

theorem activeBlock_valueActivity (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) (x : ∀ e, V e) :
    activeBlock M e (fun _ => True) (valueActivity value z x) =
      valueLayer M (coordinateValues value x) z \ {e} := by
  ext f
  simp only [activeBlock, valueActivity, decide_eq_true_eq, Set.mem_setOf_eq,
    valueLayer, coordinateValues, Set.mem_diff, Set.mem_singleton_iff]
  tauto

theorem activity_nonspan (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) :
    nonspanProbability (activityLaws laws value z) M e (fun _ => True) =
      otherNonspanProbability laws M value e z := by
  unfold nonspanProbability activityLaws
  rw [FiniteLaw.product_map_prob]
  apply FiniteLaw.prob_congr
  intro x
  change nonspanEvent M e (fun _ => True) (valueActivity value z x) ↔ _
  unfold nonspanEvent
  rw [activeBlock_valueActivity laws]

theorem positiveTail_eq_coordinateTail (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (z : ℝ) (hz : 0 < z) (e : E) :
    positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z =
      coordinateTail laws value z e := by
  have h := FiniteLaw.product_map_prob laws (fun e x => decide (z < value e x))
    (fun x => x e = true)
  have hp : (FiniteLaw.product (activityLaws laws value z)).prob (fun x => x e = true) =
      coordinateTail laws value z e := by
    rw [FiniteLaw.product_prob_coordinate, activityLaws_true_mass]
  rw [← hp]
  change _ = (FiniteLaw.product (fun e => (laws e).map (fun x => decide (z < value e x)))).prob _
  rw [h]
  unfold positiveTailProbability FiniteLaw.prob
  congr 1
  funext x
  simp [positiveLayer, coordinateValues, hz]

/-- Lemma 8 applied to an actual value layer of the independent finite prior. -/
theorem value_layer_rank_inequality (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ)
    (C : Finset E) (hC : M.IsBase (C : Set E)) (z s : ℝ) (hs : 0 ≤ s) :
    (∑ e, coordinateTail laws value z e * otherNonspanProbability laws M value e z) ≤
      (∑ e, (coordinateTail laws value z e)^2 * otherNonspanProbability laws M value e z) +
        realRank M M.E * Real.exp (-s) +
        s * ∑ e ∈ C, (1 - coordinateTail laws value z e) * otherNonspanProbability laws M value e z := by
  have h := rank_nonspan_inequality M hground C hC (coordinateTail laws value z)
    (fun e => (laws e).prob_nonneg _) (fun e => (laws e).prob_le_one _) s hs
  dsimp only at h
  rw [← activityLaws_eq_bernoulli] at h
  simpa only [activity_nonspan] using h

end MatroidProphetSecretary
