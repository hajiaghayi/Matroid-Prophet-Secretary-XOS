import MatroidProphetSecretary.ActiveGreedyRank
import MatroidProphetSecretary.RankDeficit
import MatroidProphetSecretary.BlockResampling

/-! Pointwise statistics of a nonempty matroid layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def activeColoopIndicator (M : Matroid E) (e : E) (x : E → Bool) : ℝ :=
  if x e = true ∧ nonspanEvent M e (fun _ => True) x then 1 else 0

def activeColoopCount (M : Matroid E) (x : E → Bool) : ℝ := ∑ e, activeColoopIndicator M e x

def activeUnstableCount (M : Matroid E) (p : E → ℝ) (x : E → Bool) : ℝ :=
  ∑ e, activeColoopIndicator M e x * (1 - p e)

def activeOtherClosure (M : Matroid E) (e : E) (x : E → Bool) : ℝ :=
  if e ∈ M.closure (bitSet x \ {e}) then 1 else 0

theorem activeColoopIndicator_bounds (M : Matroid E) (e : E) (x : E → Bool) :
    0 ≤ activeColoopIndicator M e x ∧ activeColoopIndicator M e x ≤ 1 := by
  unfold activeColoopIndicator
  split_ifs <;> norm_num

theorem activeColoopCount_le_rank (M : Matroid E) (hground : ∀ e, e ∈ M.E) (x : E → Bool) :
    activeColoopCount M x ≤ realRank M (bitSet x) := by
  let B := activeGreedyBasis M (fun _ => 0) x
  have hsum : (∑ e, if e ∈ B then (1 : ℝ) else 0) = realRank M (bitSet x) := by
    rw [realRank_eq_ncard (activeGreedyBasis_isBasis M hground (fun _ => 0) x)]
    simp [B]
  rw [← hsum]
  apply sum_le_sum
  intro e he
  by_cases hc : x e = true ∧ nonspanEvent M e (fun _ => True) x
  · have heB : e ∈ B := by
      apply (activeGreedyBasis_mem_iff M hground (fun _ => 0) x e).mpr
      refine ⟨hc.1, ?_⟩
      intro hcl
      apply hc.2
      apply M.closure_subset_closure _ hcl
      intro f hf
      exact ⟨hf.1, hf.2.1, trivial, hf.2.2.2⟩
    simp [activeColoopIndicator, hc, heB]
  · simp only [activeColoopIndicator, if_neg hc]
    split_ifs <;> norm_num

theorem activeRank_le_card (M : Matroid E) (hground : ∀ e, e ∈ M.E) (x : E → Bool) :
    realRank M (bitSet x) ≤ Fintype.card E := by
  rw [realRank_eq_ncard (activeGreedyBasis_isBasis M hground (fun _ => 0) x)]
  simp only [Set.ncard_coe_Finset]
  exact_mod_cast card_le_univ (activeGreedyBasis M (fun _ => 0) x)

theorem activeRank_nonempty (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (x : E → Bool) (hx : ∃ e, x e = true) : 1 ≤ realRank M (bitSet x) := by
  obtain ⟨e, he⟩ := hx
  have h := indep_ncard_le_realRank (hnonloop e)
    (Set.singleton_subset_iff.mpr (show e ∈ bitSet x from he))
    (fun f _ => (hnonloop f).subset_ground (Set.mem_singleton f))
  simpa using h

theorem activeUnstableCount_bounds (M : Matroid E) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (x : E → Bool) :
    0 ≤ activeUnstableCount M p x ∧ activeUnstableCount M p x ≤ activeColoopCount M x := by
  constructor
  · exact sum_nonneg (fun e _ => mul_nonneg (activeColoopIndicator_bounds M e x).1 (sub_nonneg.mpr (hp1 e)))
  · exact sum_le_sum (fun e _ => mul_le_of_le_one_right (activeColoopIndicator_bounds M e x).1
      (by linarith [hp0 e]))

theorem activeColoopCount_nonneg (M : Matroid E) (x : E → Bool) : 0 ≤ activeColoopCount M x :=
  sum_nonneg (fun e _ => (activeColoopIndicator_bounds M e x).1)

theorem activeOtherClosure_bounds (M : Matroid E) (e : E) (x : E → Bool) :
    0 ≤ activeOtherClosure M e x ∧ activeOtherClosure M e x ≤ 1 := by
  unfold activeOtherClosure
  split_ifs <;> norm_num

theorem activeColoopIndicator_expect (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E) :
    (FiniteLaw.product laws).expect (activeColoopIndicator M e) =
      activityProbability laws e * nonspanProbability laws M e (fun _ => True) :=
  selectedProbability_eq_factor laws M e (fun _ => True)

theorem activeColoopCount_expect (laws : E → FiniteLaw Bool) (M : Matroid E) :
    (FiniteLaw.product laws).expect (activeColoopCount M) =
      ∑ e, activityProbability laws e * nonspanProbability laws M e (fun _ => True) := by
  change (FiniteLaw.product laws).expect (fun x => ∑ e, activeColoopIndicator M e x) = _
  rw [FiniteLaw.expect_finset_sum]
  simp only [activeColoopIndicator_expect]

theorem activeUnstableCount_expect (laws : E → FiniteLaw Bool) (M : Matroid E) (p : E → ℝ) :
    (FiniteLaw.product laws).expect (activeUnstableCount M p) =
      ∑ e, activityProbability laws e * nonspanProbability laws M e (fun _ => True) * (1-p e) := by
  change (FiniteLaw.product laws).expect (fun x => ∑ e, activeColoopIndicator M e x * (1 - p e)) = _
  rw [FiniteLaw.expect_finset_sum]
  simp only [FiniteLaw.expect_mul_const, activeColoopIndicator_expect]

end MatroidProphetSecretary
