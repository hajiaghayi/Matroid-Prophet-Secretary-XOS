import MatroidProphetSecretary.FiniteContinuationPolicy
import MatroidProphetSecretary.AlignedReferenceStatistics
import MatroidProphetSecretary.LocalContinuationBounds
import MatroidProphetSecretary.FiniteOrderInstances

/-! The finite continuation policy for the paper's constructed reference family. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

def referenceOverlap {E : Type*} [Fintype E] [LinearOrder E]
    {V : E → Type*} [∀ e, Fintype (V e)] (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) : ℝ :=
  overlap (FiniteLaw.product (referenceInstanceLaws laws value q)) (coordinateValues (referenceInstanceValues value))
    (fun y => canonicalBasis M (coordinateValues (referenceInstanceValues value) y))

theorem reference_continuation_policy {N k : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (M : Matroid (Fin N)) {q c : ℝ} (hq : q ∈ interval)
    (hF : 0 < referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)
    (hc : c < phi q (referenceOverlap prior.law M (fun e v => (prior.value e v : ℝ)) q/
      referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)) :
    ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧
      c*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q < expectedPolicyReward prior policy := by
  let observed := fun e v => (prior.value e v : ℝ)
  let reference := alignedReferenceLaws prior.law observed q
  let value := optionalCoordinateValues observed
  let base := fun y => canonicalBasis M (value y)
  have hv (y : Fin N → Option (Fin k)) (e : Fin N) : 0 ≤ value y e :=
    optionalCoordinateValues_nonneg observed (fun e v => by
      change (0:ℝ) ≤ (prior.value e v : ℝ)
      exact_mod_cast prior.value_nonneg e v) y e
  have hbase (y : Fin N → Option (Fin k)) : M.IsBase (base y : Set (Fin N)) := canonicalBasis_isBase M (value y)
  have hzero (y : Fin N → Option (Fin k)) (e : Fin N) (hy : y e = none) : value y e = 0 := by
    simp only [value,optionalCoordinateValues,hy,optionalValue]
  have hvalue (y : Fin N → Option (Fin k)) (e : Fin N) (v : Fin k) (hy : y e = some v) :
      value y e = (prior.value e v : ℝ) := by
    simp only [value,optionalCoordinateValues,hy,optionalValue,observed]
  have hopt (y : Fin N → Option (Fin k)) : weight (value y) (base y) = optimum M (value y) :=
    canonicalBasis_weight M (value y) (hv y)
  have hF' : 0 < expectedOptimum (FiniteLaw.product reference) M value := by
    rw [aligned_reference_optimum]
    exact hF
  have hc' : c < phi q (overlap (FiniteLaw.product reference) value base/expectedOptimum (FiniteLaw.product reference) M value) := by
    rw [aligned_reference_overlap,aligned_reference_optimum]
    dsimp only [referenceOverlap] at hc
    convert hc using 1
    rw [fin_order_decidableEq]
  obtain ⟨K,policy,hfeasible,hreward⟩ := finite_continuation_policy hN prior reference M base hbase value hv hzero hvalue hopt
    hF' hq (aligned_reference_atom_domination prior.law observed q (q_pos hq).le) hc'
  refine ⟨K,policy,hfeasible,?_⟩
  rw [aligned_reference_optimum] at hreward
  exact hreward

theorem reference_guard_policy {N k : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (M : Matroid (Fin N)) {q : ℝ} (hq : q ∈ interval) (hguard : 3*delta ≤ |q-1|)
    (hF : 0 < referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q) :
    ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧
      discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q < expectedPolicyReward prior policy := by
  apply reference_continuation_policy hN prior M hq hF
  unfold referenceOverlap referenceExpectedOptimum
  convert finite_guard_continuation_factor (referenceInstanceLaws prior.law (fun e v => (prior.value e v : ℝ)) q) M
    (referenceInstanceValues (fun e v => (prior.value e v : ℝ)))
    (fun y => canonicalBasis M (coordinateValues (referenceInstanceValues (fun e v => (prior.value e v : ℝ))) y)) hq hguard using 1
  rw [fin_order_decidableEq]

set_option maxHeartbeats 1000000 in
theorem reference_stability_policy {N k : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N))) {q : ℝ} (hq : q ∈ interval)
    (hF : 0 < referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)
    (hD : stationaryRatio q-20*epsilon ≤ referenceDeletion prior.law M (fun e v => (prior.value e v : ℝ)) q/
      referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)
    (hH : hMinus ≤ referenceStable prior.law M (fun e v => (prior.value e v : ℝ)) hnonloop q/
      referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q) :
    ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧
      discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q < expectedPolicyReward prior policy := by
  apply reference_continuation_policy hN prior M hq hF
  unfold referenceOverlap referenceExpectedOptimum
  dsimp only [referenceExpectedOptimum,referenceDeletion,referenceStable] at hF hD hH
  rw [fin_order_decidableEq]
  have hv (e : Fin N) (v : ReferenceAtom (fun _ : Fin N => Fin k) e) :
      0 ≤ referenceInstanceValues (fun e v => (prior.value e v : ℝ)) e v :=
    referenceValue_nonneg _ (fun i => by
      dsimp only
      exact_mod_cast prior.value_nonneg e ((valueSortedEquiv (fun v => (prior.value e v : ℝ))) i)) v
  have h := finite_large_stability_continuation_factor
    (referenceInstanceLaws prior.law (fun e v => (prior.value e v : ℝ)) q) M
    (referenceInstanceValues (fun e v => (prior.value e v : ℝ))) hv hnonloop hq
  rw [fin_order_decidableEq] at h
  exact h hF hD hH

end MatroidProphetSecretary
