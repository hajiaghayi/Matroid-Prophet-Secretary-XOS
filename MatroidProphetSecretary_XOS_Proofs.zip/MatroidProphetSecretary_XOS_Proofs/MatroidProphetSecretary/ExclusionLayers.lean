import MatroidProphetSecretary.DeletionLayers
import MatroidProphetSecretary.FiniteIntegrals

/-! The exclusion-threshold layer statistic used by the common sampler in Lemma 15. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def othersClosureLayer (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) : ℝ :=
  if 0 < z ∧ e ∈ M.closure (valueLayer M v z \ {e}) then 1 else 0

theorem othersClosureLayer_bounds (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) :
    0 ≤ othersClosureLayer M v e z ∧ othersClosureLayer M v e z ≤ 1 := by
  unfold othersClosureLayer
  split_ifs <;> norm_num

theorem othersClosureLayer_eq_difference (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) :
    othersClosureLayer M v e z = closureLayer M v e z - coloopLayer M v e z := by
  by_cases hz : 0 < z
  · by_cases he : e ∈ valueLayer M v z
    · have hecl : e ∈ M.closure (valueLayer M v z) := M.mem_closure_of_mem he (fun f hf => hf.1)
      by_cases hc : e ∈ M.closure (valueLayer M v z \ {e}) <;>
        simp [othersClosureLayer, closureLayer, coloopLayer, hz, he, hecl, hc]
    · rw [othersClosureLayer, Set.diff_singleton_eq_self he]
      by_cases hc : e ∈ M.closure (valueLayer M v z) <;>
        simp [closureLayer, coloopLayer, hz, he, hc]
  · simp [othersClosureLayer, closureLayer, coloopLayer, hz]

theorem othersClosureLayer_integrable (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (e : E) (he : M.Indep ({e} : Set E)) : Integrable (othersClosureLayer M v e) := by
  rw [funext (othersClosureLayer_eq_difference M v e)]
  exact (closureLayer_integrable M v hv e he).sub (coloopLayer_integrable M v hv e)

theorem exclusionThreshold_eq_integral (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (e : E) (he : M.Indep ({e} : Set E)) :
    exclusionThreshold M v e he = ∫ z, othersClosureLayer M v e z := by
  calc
    exclusionThreshold M v e he = contractionCost M v e he - (optimum M v - deletionValue M v e) := by
      unfold exclusionThreshold contractionCost
      ring
    _ = (∫ z, closureLayer M v e z) - (∫ z, coloopLayer M v e z) := by
      rw [contractionCost_eq_integral_closure M v hv e he, deletion_surplus_eq_integral_coloop M v hv e]
    _ = ∫ z, othersClosureLayer M v e z := by
      rw [← integral_sub (closureLayer_integrable M v hv e he) (coloopLayer_integrable M v hv e)]
      congr 1
      funext z
      exact (othersClosureLayer_eq_difference M v e z).symm

theorem othersClosureLayer_empty (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) (z : ℝ) (hempty : valueLayer M v z = ∅) :
    othersClosureLayer M v e z = 0 := by
  have hnot : e ∉ M.closure ∅ := by
    simpa only [Set.diff_self] using he.not_mem_closure_diff_of_mem (Set.mem_singleton e)
  simp [othersClosureLayer, hempty, hnot]

variable {Ω : Type*} [Fintype Ω]

theorem meanThreshold_eq_integral (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hv : ∀ x e, 0 ≤ v x e) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) :
    meanThreshold μ M v hnonloop e = ∫ z, μ.expect (fun x => othersClosureLayer M (v x) e z) := by
  rw [μ.integral_expect _ (fun x => othersClosureLayer_integrable M (v x) (hv x) e (hnonloop e))]
  unfold meanThreshold
  congr 1
  funext x
  exact exclusionThreshold_eq_integral M (v x) (hv x) e (hnonloop e)

end MatroidProphetSecretary
