import MatroidProphetSecretary.ExchangeReplay
import MatroidProphetSecretary.ExchangeMortality

/-! Exact characterization of which live targets disappear after a canonical replay step. -/

noncomputable section

namespace MatroidProphetSecretary.ExchangeHistory

open scoped Classical

variable {E : Type*} [DecidableEq E]

theorem liveSet_snoc_iff {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (C : Finset E) (hC : M.IsBase (C : Set E))
    (hAC : A ⊆ C) (e : E) (heC : e ∈ C) (heA : e ∉ A)
    (B : Finset E) (hB : M.IsBase (B : Set E)) (v : E → ℝ) (f : E) :
    f ∈ (h.snoc C hC hAC e heC heA).liveSet B hB v ↔
      f ∈ h.liveSet B hB v ∧
        (chosenExchangeMap M C (h.replay B hB).basis hC (h.replay B hB).isBase).map e ≠ f := by
  let phi := chosenExchangeMap M C (h.replay B hB).basis hC (h.replay B hB).isBase
  constructor
  · intro hf
    refine ⟨liveSet_snoc_subset h C hC hAC e heC heA B hB v hf,?_⟩
    obtain ⟨hfset,_⟩ := Finset.mem_filter.mp hf
    obtain ⟨hfbase,hfresh⟩ := Finset.mem_sdiff.mp hfset
    change f ∈ insert e ((h.replay B hB).basis.erase (phi.map e)) at hfbase
    have hfe : f ≠ e := fun hfe => hfresh (hfe ▸ Finset.mem_insert_self e A)
    have hfkeep := Finset.mem_of_mem_insert_of_ne hfbase hfe
    exact (Finset.mem_erase.mp hfkeep).1.symm
  · rintro ⟨hf,hkill⟩
    obtain ⟨hfset,hvalue⟩ := Finset.mem_filter.mp hf
    obtain ⟨hfbase,hfresh⟩ := Finset.mem_sdiff.mp hfset
    have hfe : f ≠ e := by
      intro hfe
      subst f
      exact hkill (phi.fixes e heC hfbase)
    apply Finset.mem_filter.mpr
    refine ⟨Finset.mem_sdiff.mpr ⟨?_,?_⟩,hvalue⟩
    · change f ∈ insert e ((h.replay B hB).basis.erase (phi.map e))
      exact Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨hkill.symm,hfbase⟩)
    · intro hinsert
      rcases Finset.mem_insert.mp hinsert with heq | hmem
      · exact hfe heq
      · exact hfresh hmem

end MatroidProphetSecretary.ExchangeHistory
