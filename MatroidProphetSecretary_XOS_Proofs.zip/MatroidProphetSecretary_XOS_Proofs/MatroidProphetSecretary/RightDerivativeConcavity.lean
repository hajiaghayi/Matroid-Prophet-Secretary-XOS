import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Analysis.Convex.Slope
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.Linarith

/-! Concavity from an antitone right derivative, including finitely many corners. -/

namespace MatroidProphetSecretary

open Set

theorem secant_upper_of_right_derivative (f d : ℝ → ℝ) (a b c : ℝ) (hab : a ≤ b)
    (hf : ContinuousOn f (Icc a b))
    (hd : ∀ t ∈ Ico a b, HasDerivWithinAt f (d t) (Ici t) t)
    (hc : ∀ t ∈ Ico a b, d t ≤ c) : f b - f a ≤ c * (b - a) := by
  let B := fun t => f a + c * (t - a)
  have hB : Continuous B := by dsimp [B]; fun_prop
  have hB' (t : ℝ) : HasDerivAt B c t := by
    simpa [B] using (((hasDerivAt_id t).sub_const a).const_mul c).const_add (f a)
  have h := image_le_of_deriv_right_le_deriv_boundary hf hd
    (show f a ≤ B a by simp [B]) hB.continuousOn
    (fun t _ => (hB' t).hasDerivWithinAt) hc (show b ∈ Icc a b from ⟨hab, le_rfl⟩)
  dsimp [B] at h
  linarith

theorem secant_lower_of_right_derivative (f d : ℝ → ℝ) (a b c : ℝ) (hab : a ≤ b)
    (hf : ContinuousOn f (Icc a b))
    (hd : ∀ t ∈ Ico a b, HasDerivWithinAt f (d t) (Ici t) t)
    (hc : ∀ t ∈ Ico a b, c ≤ d t) : c * (b - a) ≤ f b - f a := by
  have h := secant_upper_of_right_derivative (fun t => -f t) (fun t => -d t) a b (-c) hab
    hf.neg (fun t ht => (hd t ht).neg) (fun t ht => neg_le_neg (hc t ht))
  dsimp only at h
  linarith

theorem concaveOn_of_antitone_right_derivative {D : Set ℝ} (hD : Convex ℝ D)
    (f d : ℝ → ℝ) (hf : ContinuousOn f D)
    (hd : ∀ t ∈ D, HasDerivWithinAt f (d t) (Ici t) t)
    (hanti : AntitoneOn d D) : ConcaveOn ℝ D f := by
  apply concaveOn_of_slope_anti_adjacent hD
  intro x y z hx hz hxy hyz
  have hxzD : Icc x z ⊆ D := hD.ordConnected.out hx hz
  have hxyD : Icc x y ⊆ D := (Icc_subset_Icc_right hyz.le).trans hxzD
  have hyzD : Icc y z ⊆ D := (Icc_subset_Icc_left hxy.le).trans hxzD
  have hy : y ∈ D := hxzD ⟨hxy.le, hyz.le⟩
  have hlo := secant_lower_of_right_derivative f d x y (d y) hxy.le (hf.mono hxyD)
    (fun t ht => hd t (hxyD ⟨ht.1, ht.2.le⟩))
    (fun t ht => hanti (hxyD ⟨ht.1, ht.2.le⟩) hy ht.2.le)
  have hup := secant_upper_of_right_derivative f d y z (d y) hyz.le (hf.mono hyzD)
    (fun t ht => hd t (hyzD ⟨ht.1, ht.2.le⟩))
    (fun t ht => hanti hy (hyzD ⟨ht.1, ht.2.le⟩) ht.1)
  exact ((div_le_iff₀ (sub_pos.mpr hyz)).mpr hup).trans
    ((le_div_iff₀ (sub_pos.mpr hxy)).mpr hlo)

end MatroidProphetSecretary
