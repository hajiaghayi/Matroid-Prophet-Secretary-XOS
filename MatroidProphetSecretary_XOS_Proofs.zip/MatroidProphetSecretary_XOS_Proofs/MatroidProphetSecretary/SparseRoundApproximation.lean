import MatroidProphetSecretary.SparseRoundLaw

/-! Sequential rounds differ from the one-event Euler law by a quadratic probability error. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open scoped Classical

variable {W S : Type*} [Fintype W]

theorem sparseRound_mass_none (kernel : ℕ → S → FiniteLaw (Option W)) (h : ℝ)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h) (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) :
    (sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass (fun _ => none) =
      1-∑ iw, sparseRoundWeight kernel n offset s iw :=
  map_mass_of_injective (sparseRoundLaw kernel h hsmall n offset s hbudget) sparseTrace (sparseTrace_injective n) none

theorem sparseRound_mass_one (kernel : ℕ → S → FiniteLaw (Option W)) (h : ℝ)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h) (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1)
    (i : Fin n) (w : W) :
    (sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass (oneMarkTrace i w) =
      (kernel (offset+i.val) s).mass (some w) :=
  map_mass_of_injective (sparseRoundLaw kernel h hsmall n offset s hbudget) sparseTrace (sparseTrace_injective n) (some (i,w))

theorem sparse_round_massDistance (kernel : ℕ → S → FiniteLaw (Option W)) (update : S → Option W → S)
    (hnone : ∀ s, update s none = s) (h : ℝ) (h0 : 0 ≤ h)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) :
    massDistance (timedBatches kernel update n offset s)
      (sparseRoundTraceLaw kernel h hsmall n offset s hbudget) ≤ 2*(n:ℝ)^2*h^2 := by
  have hn : 0 ≤ (n:ℝ)*h := mul_nonneg (Nat.cast_nonneg _) h0
  have hd := massDistance_le_shortfall_bound (timedBatches kernel update n offset s)
    (sparseRoundTraceLaw kernel h hsmall n offset s hbudget) (fun x => x ≠ fun _ => none) ((n:ℝ)*h) hn
    (by
      intro x hx
      have hx' : x = fun _ => none := not_not.mp hx
      subst x
      rw [sparseRound_mass_none,sparseRoundWeight_total]
      exact timed_none_mass_union kernel update hnone n offset s)
    (by
      intro x hx
      by_cases hr : x ∈ Set.range (sparseTrace (W := W) (n := n))
      · obtain ⟨event,rfl⟩ := hr
        cases event with
        | none => exact False.elim (hx rfl)
        | some iw =>
          change (1-(n:ℝ)*h)*(sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass (oneMarkTrace iw.1 iw.2) ≤ _
          rw [sparseRound_mass_one]
          exact timed_one_mark_mass_lower kernel update hnone h h0 hsmall n offset s hbudget iw.1 iw.2
      · have hz := map_mass_eq_zero_of_not_range (sparseRoundLaw kernel h hsmall n offset s hbudget) sparseTrace x hr
        change (sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass x = 0 at hz
        rw [hz,mul_zero]
        exact (timedBatches kernel update n offset s).nonneg x)
  have he : @FiniteLaw.prob _ _ (sparseRoundTraceLaw kernel h hsmall n offset s hbudget)
      (fun x => x ≠ fun _ => none) (fun x => Classical.propDecidable (x ≠ fun _ => none)) =
      ∑ iw, sparseRoundWeight kernel n offset s iw := by
    convert sparseRound_event_probability kernel h hsmall n offset s hbudget using 1
    unfold prob
    congr 1
    funext x
    split_ifs <;> rfl
  rw [he] at hd
  have hb := mul_le_mul_of_nonneg_left (sparseRoundWeight_bound kernel h hsmall n offset s)
    (mul_nonneg (by norm_num : (0:ℝ) ≤ 2) hn)
  exact hd.trans (by convert hb using 1 <;> ring)

theorem repeated_sparse_round_approximation (kernel : ℕ → S → FiniteLaw (Option W))
    (update : S → Option W → S) (hnone : ∀ s, update s none = s)
    (h : ℝ) (h0 : 0 ≤ h) (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (hbudget : (n:ℝ)*h ≤ 1) (roundUpdate : S → (Fin n → Option W) → S)
    (rounds : ℕ) (s : S) (B : ℝ) (hB : 0 ≤ B) (f : (Fin rounds → Fin n → Option W) → ℝ)
    (hf : ∀ x, |f x| ≤ B) :
    |(adaptiveBatches (timedBatches kernel update n offset) roundUpdate rounds s).expect f-
      (adaptiveBatches (fun s => sparseRoundTraceLaw kernel h hsmall n offset s hbudget) roundUpdate rounds s).expect f| ≤
      rounds*(2*(n:ℝ)^2*h^2)*B :=
  adaptiveBatches_expect_approximation _ _ roundUpdate _ B hB
    (fun s => sparse_round_massDistance kernel update hnone h h0 hsmall n offset s hbudget) rounds s f hf

end MatroidProphetSecretary.FiniteLaw
