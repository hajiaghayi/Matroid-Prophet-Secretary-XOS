import MatroidProphetSecretary.PoissonGenerator
import MatroidProphetSecretary.BlockIndependence

/-! Probability laws and marginal identities for independent Bernoulli rounding. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem FiniteLaw.product_expect_coordinate (laws : E → FiniteLaw Bool) (e : E)
    (f : Bool → ℝ) :
    (FiniteLaw.product laws).expect (fun x => f (x e)) = (laws e).expect f := by
  let g : E → Bool → ℝ := fun i b => (laws i).mass b * if i = e then f b else 1
  have hpoint (x : E → Bool) :
      (FiniteLaw.product laws).mass x * f (x e) = ∏ i, g i (x i) := by
    simp only [g, FiniteLaw.product, prod_mul_distrib, Fintype.prod_ite_eq']
  have hsum (i : E) : (∑ b, g i b) = if i = e then (laws e).expect f else 1 := by
    by_cases hi : i = e
    · subst i
      simp [g, FiniteLaw.expect]
    · simpa only [g, if_neg hi, mul_one] using (laws i).total
  simp only [FiniteLaw.expect, hpoint]
  rw [← Fintype.prod_sum]
  simp_rw [hsum]
  simp [FiniteLaw.expect]

theorem FiniteLaw.product_prob_coordinate (laws : E → FiniteLaw Bool) (e : E) (b : Bool) :
    (FiniteLaw.product laws).prob (fun x => x e = b) = (laws e).mass b := by
  unfold FiniteLaw.prob
  rw [FiniteLaw.product_expect_coordinate laws e (fun s => if s = b then 1 else 0)]
  cases b <;> simp [FiniteLaw.expect, Fintype.sum_bool]

def bernoulliLaw (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) : FiniteLaw Bool where
  mass b := if b = true then p else 1 - p
  nonneg b := by split_ifs <;> linarith
  total := by simp [Fintype.sum_bool]

def poissonBitLaw (a : ℝ) (ha : 0 ≤ a) : FiniteLaw Bool where
  mass := poissonWeight a
  nonneg b := by
    have hexp := Real.exp_le_one_iff.mpr (neg_nonpos.mpr ha)
    cases b <;> simp only [poissonWeight, Bool.false_eq_true, if_false, if_true]
    · exact (Real.exp_pos _).le
    · linarith
  total := by simp [poissonWeight, Fintype.sum_bool]

def poissonLaw (a : E → ℝ) (ha : ∀ e, 0 ≤ a e) : FiniteLaw (E → Bool) :=
  FiniteLaw.product (fun e => poissonBitLaw (a e) (ha e))

theorem poissonEval_eq_expect (a : E → ℝ) (ha : ∀ e, 0 ≤ a e)
    (f : (E → Bool) → ℝ) : poissonEval a f = (poissonLaw a ha).expect f := rfl

theorem poissonEval_const (a : E → ℝ) (ha : ∀ e, 0 ≤ a e) (c : ℝ) :
    poissonEval a (fun _ => c) = c := by
  rw [poissonEval_eq_expect a ha, FiniteLaw.expect_const]

theorem poissonEval_mono (a : E → ℝ) (ha : ∀ e, 0 ≤ a e)
    {f g : (E → Bool) → ℝ} (h : ∀ x, f x ≤ g x) : poissonEval a f ≤ poissonEval a g :=
  (poissonLaw a ha).expect_mono h

theorem poissonEval_sum {ι : Type*} [Fintype ι] (a : E → ℝ) (f : ι → (E → Bool) → ℝ) :
    poissonEval a (fun x => ∑ i, f i x) = ∑ i, poissonEval a (f i) := by
  simp only [poissonEval, mul_sum]
  exact sum_comm

theorem poissonLaw_prob_true (a : E → ℝ) (ha : ∀ e, 0 ≤ a e) (e : E) :
    (poissonLaw a ha).prob (fun x => x e = true) = 1 - Real.exp (-a e) := by
  rw [poissonLaw, FiniteLaw.product_prob_coordinate]
  simp [poissonBitLaw, poissonWeight]

theorem poissonLaw_prob_false (a : E → ℝ) (ha : ∀ e, 0 ≤ a e) (e : E) :
    (poissonLaw a ha).prob (fun x => x e = false) = Real.exp (-a e) := by
  rw [poissonLaw, FiniteLaw.product_prob_coordinate]
  simp [poissonBitLaw, poissonWeight]

end MatroidProphetSecretary
