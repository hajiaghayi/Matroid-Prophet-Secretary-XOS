import MatroidProphetSecretary.BernoulliCoupling
import MatroidProphetSecretary.ProductMoments
import MatroidProphetSecretary.BlockResampling

/-! Quantitative variation of finite product Bernoulli expectations. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem FiniteLaw.abs_expect_le {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) (f : Ω → ℝ) :
    |μ.expect f| ≤ μ.expect (fun x => |f x|) := by
  have h := abs_sum_le_sum_abs (fun x => μ.mass x * f x) univ
  simpa only [expect, abs_mul, abs_of_nonneg (μ.nonneg _)] using h

theorem FiniteLaw.product_expect_single_coordinate {ι Ω : Type*} [Fintype ι] [DecidableEq ι]
    [Fintype Ω] (laws : ι → FiniteLaw Ω) (e : ι) (f : Ω → ℝ) :
    (product laws).expect (fun x => f (x e)) = (laws e).expect f := by
  have h := product_expect_prod laws (fun i x => if i = e then f x else 1)
  have hi (i : ι) : (laws i).expect (fun x => if i = e then f x else 1) =
      if i = e then (laws e).expect f else 1 := by
    by_cases hie : i = e <;> simp [hie]
  simpa only [Fintype.prod_ite_eq', hi] using h

theorem coupledBitLaw_disagreement (p q : ℝ) (hp : 0 ≤ p) (hpq : p ≤ q) (hq : q ≤ 1) :
    (coupledBitLaw p q hp hpq hq).expect (fun x => if x.1 ≠ x.2 then 1 else 0) = q-p := by
  simp [FiniteLaw.expect, coupledBitLaw, Fintype.sum_prod_type, Fintype.sum_bool]

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem bounded_observable_difference (f : (E → Bool) → ℝ) (B : ℝ) (hB : 0 ≤ B)
    (hf0 : ∀ x, 0 ≤ f x) (hfB : ∀ x, f x ≤ B) (x y : E → Bool) :
    |f x-f y| ≤ B * ∑ e, if x e ≠ y e then (1 : ℝ) else 0 := by
  by_cases hxy : x = y
  · simp [hxy]
  · have hex : ∃ e, x e ≠ y e := by
      by_contra hn
      push_neg at hn
      exact hxy (funext hn)
    obtain ⟨e,he⟩ := hex
    have hsum : 1 ≤ ∑ e, if x e ≠ y e then (1 : ℝ) else 0 := by
      have h := single_le_sum (s := univ) (f := fun e => if x e ≠ y e then (1 : ℝ) else 0)
        (fun i hi => by dsimp only; split_ifs <;> norm_num) (mem_univ e)
      simpa only [if_pos he] using h
    calc
      |f x-f y| ≤ B := abs_le.mpr ⟨by linarith [hf0 x, hfB y], by linarith [hfB x, hf0 y]⟩
      _ ≤ B * ∑ e, if x e ≠ y e then (1 : ℝ) else 0 := by
        simpa using mul_le_mul_of_nonneg_left hsum hB

theorem bernoulliEval_variation_ordered (p q : E → ℝ)
    (hp : ∀ e, 0 ≤ p e) (hpq : ∀ e, p e ≤ q e) (hq : ∀ e, q e ≤ 1)
    (f : (E → Bool) → ℝ) (B : ℝ) (hB : 0 ≤ B) (hf0 : ∀ x, 0 ≤ f x) (hfB : ∀ x, f x ≤ B) :
    |bernoulliEval p f - bernoulliEval q f| ≤ B * ∑ e, (q e-p e) := by
  let laws := fun e => coupledBitLaw (p e) (q e) (hp e) (hpq e) (hq e)
  let μ := FiniteLaw.product laws
  have hf := FiniteLaw.product_map_expect laws (fun _ => Prod.fst) f
  have hg := FiniteLaw.product_map_expect laws (fun _ => Prod.snd) f
  simp only [laws, coupledBitLaw_fst] at hf
  simp only [laws, coupledBitLaw_snd] at hg
  have hf' : bernoulliEval p f = μ.expect (fun x => f (fun e => (x e).1)) := hf
  have hg' : bernoulliEval q f = μ.expect (fun x => f (fun e => (x e).2)) := hg
  rw [hf', hg']
  change |μ.expect (fun x => f (fun e => (x e).1)) - μ.expect (fun x => f (fun e => (x e).2))| ≤ _
  rw [← μ.expect_sub]
  calc
    _ ≤ μ.expect (fun x => |f (fun e => (x e).1) - f (fun e => (x e).2)|) := μ.abs_expect_le _
    _ ≤ μ.expect (fun x => B * ∑ e, if (x e).1 ≠ (x e).2 then (1 : ℝ) else 0) :=
      μ.expect_mono (fun x => bounded_observable_difference f B hB hf0 hfB _ _)
    _ = B * ∑ e, (q e-p e) := by
      rw [μ.expect_const_mul, FiniteLaw.expect_finset_sum]
      congr 1
      apply sum_congr rfl
      intro e he
      rw [FiniteLaw.product_expect_single_coordinate laws e
        (fun b => if b.1 ≠ b.2 then (1 : ℝ) else 0)]
      exact coupledBitLaw_disagreement (p e) (q e) (hp e) (hpq e) (hq e)

end MatroidProphetSecretary
