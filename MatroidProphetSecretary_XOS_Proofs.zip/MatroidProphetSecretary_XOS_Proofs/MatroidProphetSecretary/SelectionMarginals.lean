import MatroidProphetSecretary.OrderedSelectionLayers
import MatroidProphetSecretary.LatentOverlapLayer

/-! Integrable forward and reverse marginals of the original finite value distribution. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E Ω : Type*} [Fintype E] [LinearOrder E] [Fintype Ω]

def orderedMarginal (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (reverse : Bool) (e : E) (z : ℝ) : ℝ :=
  μ.expect (fun x => orderedSelectionLayer M (v x) reverse e z)

theorem orderedMarginal_bounds (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (reverse : Bool) (e : E) (z : ℝ) :
    0 ≤ orderedMarginal μ M v reverse e z ∧ orderedMarginal μ M v reverse e z ≤ 1 := by
  constructor
  · exact μ.expect_nonneg (fun x => (orderedSelectionLayer_bounds M (v x) reverse e z).1)
  · simpa only [FiniteLaw.expect_const] using
      μ.expect_mono (fun x => (orderedSelectionLayer_bounds M (v x) reverse e z).2)

theorem orderedMarginal_integrable (μ : FiniteLaw Ω) (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : Ω → E → ℝ) (hv : ∀ x e, 0 ≤ v x e) (reverse : Bool) (e : E) :
    Integrable (orderedMarginal μ M v reverse e) :=
  μ.integrable_expect _ (fun x => orderedSelectionLayer_integrable M hground (v x) (hv x) reverse e)

theorem orderedMarginal_mul_integrable (μ : FiniteLaw Ω) (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : Ω → E → ℝ) (hv : ∀ x e, 0 ≤ v x e) (r s : Bool) (e : E) :
    Integrable (fun z => orderedMarginal μ M v r e z * orderedMarginal μ M v s e z) := by
  have hr := orderedMarginal_integrable μ M hground v hv r e
  have hs := orderedMarginal_integrable μ M hground v hv s e
  exact hs.bdd_mul hr.aestronglyMeasurable ⟨1, fun z => by
    rw [Real.norm_eq_abs, abs_of_nonneg (orderedMarginal_bounds μ M v r e z).1]
    exact (orderedMarginal_bounds μ M v r e z).2⟩

theorem orderedMarginal_sq_integrable (μ : FiniteLaw Ω) (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : Ω → E → ℝ) (hv : ∀ x e, 0 ≤ v x e) (r : Bool) (e : E) :
    Integrable (fun z => (orderedMarginal μ M v r e z)^2) := by
  simpa only [pow_two] using orderedMarginal_mul_integrable μ M hground v hv r r e

theorem orderedMarginal_sum (μ : FiniteLaw Ω) (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : Ω → E → ℝ) (reverse : Bool) (z : ℝ) :
    (∑ e, orderedMarginal μ M v reverse e z) = μ.expect (fun x => positiveRankLayer M (v x) z) := by
  unfold orderedMarginal
  rw [← FiniteLaw.expect_finset_sum]
  simp only [orderedSelectionLayer_sum M hground]

theorem orderedMarginal_forward (μ : FiniteLaw Ω) (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : Ω → E → ℝ) (e : E) (z : ℝ) :
    orderedMarginal μ M v false e z = basisMarginal μ v (fun x => canonicalBasis M (v x)) e z := by
  simp only [orderedMarginal, basisMarginal, forwardSelectionLayer_eq_basisLayer M hground]

theorem orderedMarginal_nonpositive (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (reverse : Bool) (e : E) (z : ℝ) (hz : ¬ 0 < z) : orderedMarginal μ M v reverse e z = 0 := by
  simp [orderedMarginal, orderedSelectionLayer, hz]

variable {V : E → Type*} [∀ e, Fintype (V e)]

def conditionalLatent (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) (z : ℝ) :
    ∀ e, FiniteLaw (V e) := fun e => (laws e).conditionOrSelf (fun x => z < value e x)

theorem activityProbability_coordinateTail (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) :
    activityProbability (activityLaws laws value z) e = coordinateTail laws value z e := by
  rw [activityProbability, FiniteLaw.product_prob_coordinate, activityLaws_true_mass]

theorem orderedMarginal_latent_forward (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (hz : 0 < z) (e : E) :
    orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) false e z =
      latentForward (activityLaws laws value z) (conditionalLatent laws value z) M value e := by
  have h := conditional_selected_representation laws M value z e false
  simpa only [orderedMarginal, orderedSelectionLayer, hz, true_and, valueActivity, decide_eq_true_eq,
    orderedBefore, Bool.false_eq_true, if_false, latentForward, conditionalLatent, coordinateValues] using h.symm

theorem orderedMarginal_latent_reverse (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (hz : 0 < z) (e : E) :
    orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) true e z =
      latentReverse (activityLaws laws value z) (conditionalLatent laws value z) M value e := by
  have h := conditional_selected_representation laws M value z e true
  simpa only [orderedMarginal, orderedSelectionLayer, hz, true_and, valueActivity, decide_eq_true_eq,
    orderedBefore, if_true, latentReverse, conditionalLatent, coordinateValues] using h.symm

theorem selection_marginal_product (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) :
    (positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z)^2 *
        otherNonspanProbability laws M value e z ≤
      orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) false e z *
        orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) true e z := by
  by_cases hz : 0 < z
  · rw [orderedMarginal_latent_forward laws M value z hz, orderedMarginal_latent_reverse laws M value z hz,
      positiveTail_eq_coordinateTail laws value z hz]
    have h := latent_overlap_product (activityLaws laws value z) (conditionalLatent laws value z) M value e
    simpa only [activityProbability_coordinateTail, activity_nonspan] using h
  · simp [orderedMarginal_nonpositive _ _ _ _ _ z hz, positiveTailProbability, positiveLayer, hz]

theorem selection_marginal_variance (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) :
    positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z *
        (1 - positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z) *
        otherNonspanProbability laws M value e z ≤
      orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) true e z *
        (1 - orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) true e z) := by
  by_cases hz : 0 < z
  · rw [orderedMarginal_latent_reverse laws M value z hz, positiveTail_eq_coordinateTail laws value z hz]
    have h := latent_reverse_variance (activityLaws laws value z) (conditionalLatent laws value z) M value e
    simpa only [activityProbability_coordinateTail, activity_nonspan] using h
  · simp [orderedMarginal_nonpositive _ _ _ _ _ z hz, positiveTailProbability, positiveLayer, hz]

end MatroidProphetSecretary
