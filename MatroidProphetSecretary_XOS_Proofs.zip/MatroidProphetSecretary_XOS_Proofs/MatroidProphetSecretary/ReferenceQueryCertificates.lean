import MatroidProphetSecretary.ReferenceSearchRatios
import MatroidProphetSecretary.RatioAccuracy

/-! Signed query certificates and their consequences for the actual reference potential. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem referenceSearchRatio_factorization (unstable : Bool)
    (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E) (value : ∀ e, V e → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ q : ℝ)
    (hF : 0 < referenceExpectedOptimum laws M value q) (ha : 0 < 1-θ*q) :
    referenceSearchRatio unstable laws M value hnonloop θ q *
        (1-θ*q) * referenceExpectedOptimum laws M value q =
      (1-θ*q)*referenceSearchNumerator unstable laws M value hnonloop q -
        θ*q*referenceExpectedOptimum laws M value q := by
  unfold referenceSearchRatio
  field_simp
  <;> ring

theorem reference_positive_ratio_slope (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ q : ℝ) (hq : 0 < q)
    (ha : 0 < 1-θ*q) (hF : 0 < referenceExpectedOptimum laws M value q)
    (hpos : 0 < referenceSearchRatio true laws M value hnonloop θ q) :
    0 < referencePotentialSlope false laws M value θ q ∧
      0 < referencePotentialSlope true laws M value θ q := by
  have hp := mul_pos (mul_pos hpos ha) hF
  rw [referenceSearchRatio_factorization true laws M value hnonloop θ q hF ha] at hp
  simp only [referenceSearchNumerator, if_true] at hp
  have hb := referencePotential_derivative_bounds laws M value hv hnonloop θ q hq ha.le
  have hr : 0 < referencePotentialSlope false laws M value θ q :=
    (mul_pos_iff_of_pos_left hq).mp (hp.trans_le hb.1)
  exact ⟨hr,hr.trans_le hb.2.1⟩

theorem reference_negative_ratio_slope (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ q : ℝ) (hq : 0 < q)
    (ha : 0 < 1-θ*q) (hF : 0 < referenceExpectedOptimum laws M value q)
    (hneg : referenceSearchRatio false laws M value hnonloop θ q < 0) :
    referencePotentialSlope false laws M value θ q < 0 ∧
      referencePotentialSlope true laws M value θ q < 0 := by
  have hp := mul_neg_of_neg_of_pos (mul_neg_of_neg_of_pos hneg ha) hF
  rw [referenceSearchRatio_factorization false laws M value hnonloop θ q hF ha] at hp
  simp only [referenceSearchNumerator, Bool.false_eq_true, if_false] at hp
  have hb := referencePotential_derivative_bounds laws M value hv hnonloop θ q hq ha.le
  have hr : referencePotentialSlope true laws M value θ q < 0 := by
    have h := hb.2.2.trans_lt hp
    nlinarith
  exact ⟨hb.2.1.trans_lt hr,hr⟩

theorem reference_positive_query_potential (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ : ℝ) (hθ : 0 ≤ θ)
    (J : Set ℝ) (hJ : Convex ℝ J) (hJ0 : J ⊆ Set.Ici 0)
    (ha : ∀ q ∈ J, 0 < 1-θ*q) (x q : ℝ) (hx : x ∈ J) (hqJ : q ∈ J)
    (hq : 0 < q) (hxq : x < q) (hF : 0 < referenceExpectedOptimum laws M value q)
    (hpos : 0 < referenceSearchRatio true laws M value hnonloop θ q) :
    referencePotential laws M value θ x < referencePotential laws M value θ q := by
  have hg := referencePotential_concave laws M
    (fun e => (hnonloop e).subset_ground (Set.mem_singleton e)) value hv θ hθ J hJ hJ0
    (fun r hr => (ha r hr).le)
  exact concave_increase_from_positive_left_derivative hg hx hqJ hxq
    (referencePotential_hasDerivWithinAt true laws M value θ q hq)
    (reference_positive_ratio_slope laws M value hv hnonloop θ q hq (ha q hqJ) hF hpos).2

theorem reference_negative_query_potential (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ : ℝ) (hθ : 0 ≤ θ)
    (J : Set ℝ) (hJ : Convex ℝ J) (hJ0 : J ⊆ Set.Ici 0)
    (ha : ∀ q ∈ J, 0 < 1-θ*q) (q x : ℝ) (hqJ : q ∈ J) (hx : x ∈ J)
    (hq : 0 < q) (hqx : q < x) (hF : 0 < referenceExpectedOptimum laws M value q)
    (hneg : referenceSearchRatio false laws M value hnonloop θ q < 0) :
    referencePotential laws M value θ x < referencePotential laws M value θ q := by
  have hg := referencePotential_concave laws M
    (fun e => (hnonloop e).subset_ground (Set.mem_singleton e)) value hv θ hθ J hJ hJ0
    (fun r hr => (ha r hr).le)
  exact concave_increase_from_negative_right_derivative hg hqJ hx hqx
    (referencePotential_hasDerivWithinAt false laws M value θ q hq)
    (reference_negative_ratio_slope laws M value hv hnonloop θ q hq (ha q hqJ) hF hneg).1

end MatroidProphetSecretary
