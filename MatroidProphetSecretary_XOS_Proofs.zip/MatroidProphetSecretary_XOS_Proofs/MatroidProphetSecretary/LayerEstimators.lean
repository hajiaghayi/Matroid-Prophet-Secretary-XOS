import MatroidProphetSecretary.NonemptyLayerSampler
import MatroidProphetSecretary.LayerStatistics

/-! Unbiased bounded statistics from the common nonempty-layer sampler. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E J : Type*} [Fintype E] [LinearOrder E] [Fintype J]

theorem bitSet_eq_empty_of_no_active (x : E → Bool) (hx : ¬ ∃ e, x e = true) :
    bitSet x = ∅ := by
  ext e
  simp only [bitSet, Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false]
  exact fun he => hx ⟨e, he⟩

theorem activeColoopIndicator_empty (M : Matroid E) (e : E) (x : E → Bool)
    (hx : ¬ ∃ e, x e = true) : activeColoopIndicator M e x = 0 := by
  have he : x e ≠ true := fun h => hx ⟨e, h⟩
  simp [activeColoopIndicator, he]

theorem activeColoopCount_empty (M : Matroid E) (x : E → Bool)
    (hx : ¬ ∃ e, x e = true) : activeColoopCount M x = 0 := by
  simp [activeColoopCount, activeColoopIndicator_empty M _ x hx]

theorem activeUnstableCount_empty (M : Matroid E) (p : E → ℝ) (x : E → Bool)
    (hx : ¬ ∃ e, x e = true) : activeUnstableCount M p x = 0 := by
  simp [activeUnstableCount, activeColoopIndicator_empty M _ x hx]

theorem activeOtherClosure_empty (M : Matroid E) (e : E)
    (he : M.Indep ({e} : Set E)) (x : E → Bool) (hx : ¬ ∃ e, x e = true) :
    activeOtherClosure M e x = 0 := by
  have hnot : e ∉ M.closure ∅ := by
    simpa only [Set.diff_self] using he.not_mem_closure_diff_of_mem (Set.mem_singleton e)
  simp [activeOtherClosure, bitSet_eq_empty_of_no_active x hx, hnot]

theorem nonemptyLayerSampler_unbiased (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws)
    (f : J → (E → Bool) → ℝ) (hempty : ∀ j x, (¬ ∃ e, x e = true) → f j x = 0) :
    (nonemptyLayerSampler width laws hw hV).expect
      (fun y => nonemptyLayerVolume width laws * f y.1 y.2) =
      ∑ j, width j * (FiniteLaw.product (laws j)).expect (f j) := by
  rw [FiniteLaw.expect_const_mul, nonemptyLayerSampler_expect]
  apply sum_congr rfl
  intro j hj
  congr 2
  funext x
  by_cases hx : ∃ e, x e = true <;> simp [hx, hempty j x]

theorem layer_rank_estimator_unbiased (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws) (M : Matroid E) :
    (nonemptyLayerSampler width laws hw hV).expect
      (fun y => nonemptyLayerVolume width laws * realRank M (bitSet y.2)) =
      ∑ j, width j * (FiniteLaw.product (laws j)).expect (fun x => realRank M (bitSet x)) := by
  apply nonemptyLayerSampler_unbiased width laws hw hV (fun _ x => realRank M (bitSet x))
  intro j x hx
  simp [bitSet_eq_empty_of_no_active x hx, realRank]

theorem layer_coloop_estimator_unbiased (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws) (M : Matroid E) :
    (nonemptyLayerSampler width laws hw hV).expect
      (fun y => nonemptyLayerVolume width laws * activeColoopCount M y.2) =
      ∑ j, width j * ∑ e, activityProbability (laws j) e *
        nonspanProbability (laws j) M e (fun _ => True) := by
  rw [nonemptyLayerSampler_unbiased _ _ _ _ _ (fun _ x hx => activeColoopCount_empty M x hx)]
  simp only [activeColoopCount_expect]

theorem layer_unstable_estimator_unbiased (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws) (M : Matroid E) :
    (nonemptyLayerSampler width laws hw hV).expect
      (fun y => nonemptyLayerVolume width laws *
        activeUnstableCount M (activityProbability (laws y.1)) y.2) =
      ∑ j, width j * ∑ e, activityProbability (laws j) e *
        nonspanProbability (laws j) M e (fun _ => True) * (1 - activityProbability (laws j) e) := by
  rw [nonemptyLayerSampler_unbiased _ _ _ _ _
    (fun j x hx => activeUnstableCount_empty M (activityProbability (laws j)) x hx)]
  simp only [activeUnstableCount_expect]

theorem layer_closure_estimator_unbiased (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws)
    (M : Matroid E) (e : E) (he : M.Indep ({e} : Set E)) :
    (nonemptyLayerSampler width laws hw hV).expect
      (fun y => nonemptyLayerVolume width laws * activeOtherClosure M e y.2) =
      ∑ j, width j * (FiniteLaw.product (laws j)).expect (activeOtherClosure M e) :=
  nonemptyLayerSampler_unbiased _ _ _ _ _ (fun _ x hx => activeOtherClosure_empty M e he x hx)

theorem layer_estimator_ranges (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (j : J) (x : E → Bool) (hx : (nonemptyLayerSampler width laws hw hV).mass (j,x) ≠ 0) :
    let V := nonemptyLayerVolume width laws
    let ZF := V * realRank M (bitSet x)
    let ZD := V * activeColoopCount M x
    let ZC := V * activeUnstableCount M (activityProbability (laws j)) x
    V ≤ ZF ∧ ZF ≤ Fintype.card E * V ∧ 0 ≤ ZC ∧ ZC ≤ ZD ∧ ZD ≤ ZF ∧
      ∀ e, 0 ≤ V * activeOtherClosure M e x ∧ V * activeOtherClosure M e x ≤ V := by
  dsimp only
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  have hnonempty := nonemptyLayerSampler_support width laws hw hV j x hx
  have hC := activeUnstableCount_bounds M (activityProbability (laws j))
    (fun e => (FiniteLaw.product (laws j)).prob_nonneg _)
    (fun e => (FiniteLaw.product (laws j)).prob_le_one _) x
  refine ⟨?_, ?_, mul_nonneg hV.le hC.1, mul_le_mul_of_nonneg_left hC.2 hV.le,
    mul_le_mul_of_nonneg_left (activeColoopCount_le_rank M hg x) hV.le, ?_⟩
  · simpa using mul_le_mul_of_nonneg_left (activeRank_nonempty M hnonloop x hnonempty) hV.le
  · simpa [mul_comm] using mul_le_mul_of_nonneg_left (activeRank_le_card M hg x) hV.le
  · intro e
    exact ⟨mul_nonneg hV.le (activeOtherClosure_bounds M e x).1,
      mul_le_of_le_one_right hV.le (activeOtherClosure_bounds M e x).2⟩

end MatroidProphetSecretary
