import MatroidProphetSecretary.AdaptiveExpectation
import MatroidProphetSecretary.FiniteSupport

/-! Adaptive potential arguments require their hypotheses only at states reached with positive mass. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {S W : Type*} [Fintype W]

theorem expect_mono_support (μ : FiniteLaw W) (f g : W → ℝ)
    (h : ∀ x, μ.mass x ≠ 0 → f x ≤ g x) : μ.expect f ≤ μ.expect g := by
  apply sum_le_sum
  intro x hx
  by_cases hm : μ.mass x = 0
  · simp [hm]
  · exact mul_le_mul_of_nonneg_left (h x hm) (μ.nonneg x)

theorem adaptive_reward_potential_support (batch : S → FiniteLaw W) (update : S → W → S)
    (reward : S → W → ℝ) (potential : S → ℝ) (Good : S → Prop)
    (hpreserve : ∀ s, Good s → ∀ x, (batch s).mass x ≠ 0 → Good (update s x))
    (hstep : ∀ s, Good s → potential s ≤ (batch s).expect (fun x => reward s x+potential (update s x)))
    (n : ℕ) (s : S) (hs : Good s) :
    potential s ≤ (adaptiveBatches batch update n s).expect
      (fun x => trajectoryReward update reward n s x+potential (stateAfter update n s x)) := by
  induction n generalizing s with
  | zero => simp [trajectoryReward,stateAfter]
  | succ n ih =>
    rw [adaptive_reward_potential_succ]
    apply (hstep s hs).trans
    apply expect_mono_support
    intro x hx
    exact add_le_add_left (ih (update s x) (hpreserve s hs x hx)) _

theorem adaptive_terminal_lower_support (batch : S → FiniteLaw W) (update : S → W → S)
    (potential : S → ℝ) (Good : S → Prop)
    (hpreserve : ∀ s, Good s → ∀ x, (batch s).mass x ≠ 0 → Good (update s x))
    (a : ℝ) (ha : 0 ≤ a)
    (hstep : ∀ s, Good s → a*potential s ≤ (batch s).expect (fun x => potential (update s x)))
    (n : ℕ) (s : S) (hs : Good s) :
    a^n*potential s ≤ (adaptiveBatches batch update n s).expect (fun x => potential (stateAfter update n s x)) := by
  induction n generalizing s with
  | zero => simp [stateAfter]
  | succ n ih =>
    rw [adaptive_terminal_succ]
    calc
      _ = a^n*(a*potential s) := by rw [pow_succ]; ring
      _ ≤ a^n*(batch s).expect (fun x => potential (update s x)) :=
        mul_le_mul_of_nonneg_left (hstep s hs) (pow_nonneg ha n)
      _ = (batch s).expect (fun x => a^n*potential (update s x)) := (expect_const_mul ..).symm
      _ ≤ _ := expect_mono_support (batch s) _ _ (fun x hx => ih (update s x) (hpreserve s hs x hx))

end MatroidProphetSecretary.FiniteLaw
