import MatroidProphetSecretary.OracleGroupTesting
import Mathlib.Data.Nat.Log
import Mathlib.Data.Finset.Image

/-! A fixed balanced subdivision of a finite candidate list. -/

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [DecidableEq E]

def QueryTree.ofList : ℕ → List E → QueryTree E
  | 0, xs => .leaf xs.head?
  | d+1, xs => .node (QueryTree.ofList d (xs.take (2^d))) (QueryTree.ofList d (xs.drop (2^d)))

theorem QueryTree.ofList_depth (d : ℕ) (xs : List E) : (QueryTree.ofList d xs).depth ≤ d := by
  induction d generalizing xs with
  | zero => rfl
  | succ d ih =>
    simp only [QueryTree.ofList,QueryTree.depth]
    have h := max_le (ih (xs.take (2^d))) (ih (xs.drop (2^d)))
    omega

theorem QueryTree.ofList_labels (d : ℕ) (xs : List E) (hsize : xs.length ≤ 2^d) :
    (QueryTree.ofList d xs).labels = xs.toFinset := by
  induction d generalizing xs with
  | zero =>
    cases xs with
    | nil => rfl
    | cons x xs =>
      have hxs : xs = [] := List.eq_nil_of_length_eq_zero (by simpa using hsize)
      subst xs
      rfl
  | succ d ih =>
    have hl : (xs.take (2^d)).length ≤ 2^d := by simp only [List.length_take]; exact min_le_left _ _
    have hr : (xs.drop (2^d)).length ≤ 2^d := by
      simp only [List.length_drop]
      rw [pow_succ] at hsize
      omega
    simp only [QueryTree.ofList,QueryTree.labels,ih _ hl,ih _ hr]
    rw [← List.toFinset_append,List.take_append_drop]

def balancedQueryTree (xs : List E) : QueryTree E := QueryTree.ofList (Nat.clog 2 xs.length) xs

theorem balancedQueryTree_labels (xs : List E) : (balancedQueryTree xs).labels = xs.toFinset :=
  QueryTree.ofList_labels _ xs (Nat.le_pow_clog (by omega) xs.length)

theorem balancedQueryTree_depth (xs : List E) : (balancedQueryTree xs).depth ≤ Nat.clog 2 xs.length :=
  QueryTree.ofList_depth _ xs

theorem balanced_groupTest_query_bound (oracle : Finset E → Bool) (bad : E → Prop) [DecidablePred bad]
    (horacle : ∀ S, oracle S = true ↔ ∃ e ∈ S, bad e) (xs : List E) (U : Finset E) :
    (groupTest oracle (balancedQueryTree xs) U).2 ≤
      1+2*Nat.clog 2 xs.length*(U.card-(groupTest oracle (balancedQueryTree xs) U).1.card) := by
  apply (groupTest_query_bound oracle bad horacle _ U).trans
  gcongr
  exact balancedQueryTree_depth xs

end MatroidProphetSecretary
