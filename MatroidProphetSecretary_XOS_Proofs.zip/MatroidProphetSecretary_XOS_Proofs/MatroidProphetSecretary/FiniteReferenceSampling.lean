import MatroidProphetSecretary.SearchSamplingAccuracy
import MatroidProphetSecretary.AdaptiveSamplerAccuracy
import MatroidProphetSecretary.ConcreteReferenceSelection
import MatroidProphetSecretary.FiniteAbsence
import MatroidProphetSecretary.MarkedHistory

/-! Fresh common-sampler batches certify the actual reference search with its stated failure budget. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E] [Nonempty E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem reference_volume_positive (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (G : ValueHeightGrid (referenceInstanceValues value))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (q : ℝ) (hq : q ∈ interval) :
    0 < finiteValueVolume (referenceInstanceLaws laws value q) (referenceInstanceValues value) G := by
  apply finiteValueVolume_pos _ _ G M
  exact (mul_pos (by norm_num : (0:ℝ) < 1/2) hF).trans_le
    (referenceExpectedOptimum_lower_away_zero laws M
      (fun e => (hnonloop e).subset_ground (Set.mem_singleton e)) value hv (1/2) q
      (by norm_num) (by norm_num) (by linarith [(interval_bounds hq).1]))

def referenceQuerySampler (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value))
    (hV : ∀ q ∈ interval, 0 < finiteValueVolume (referenceInstanceLaws laws value q)
      (referenceInstanceValues value) G) (m : ℕ) (q : ℝ) :
    FiniteLaw (Fin m → (Fin G.last × (E → Bool))) :=
  samplerQueryBatch (fun r => referenceInstanceLaws laws value (clampedSearchPoint delta (Sum.inl r)))
    (referenceInstanceValues value) G
    (fun r => hV _ (clampedSearchPoint_mem delta (by norm_num [delta]) (Sum.inl r))) m q

theorem referenceQuerySampler_budget (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (G : ValueHeightGrid (referenceInstanceValues value))
    (hV : ∀ q ∈ interval, 0 < finiteValueVolume (referenceInstanceLaws laws value q)
      (referenceInstanceValues value) G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N K : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (hK : 0 < K)
    (ρ : ℝ) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1) (q : ℝ) (hq : q ∈ interval) :
    (referenceQuerySampler laws value G hV (commonBatchSize N K epsilon ρ) q).prob
      (fun x => ¬ referenceRecordGood laws value G M hnonloop N epsilon ⟨q,x⟩) ≤ ρ/((N:ℝ)*K) := by
  have h := samplerQueryBatch_budget
    (fun r => referenceInstanceLaws laws value (clampedSearchPoint delta (Sum.inl r)))
    (referenceInstanceValues value) (fun e x => referencePriorValue_nonneg (value e) (hv e) x) G
    (fun r => hV _ (clampedSearchPoint_mem delta (by norm_num [delta]) (Sum.inl r)))
    M hnonloop N K hN0 hN hK epsilon ρ (by norm_num [epsilon]) (by norm_num [epsilon]) hρ0 hρ1 q
  have heq := clampedSearchPoint_eq delta (Sum.inl q) hq
  dsimp only [searchQueryPoint] at heq
  change (referenceQuerySampler laws value G hV (commonBatchSize N K epsilon ρ) q).prob _ ≤ _ at h
  rw [heq] at h
  simpa only [referenceRecordGood,not_not] using h

theorem finite_reference_search_failure (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (G : ValueHeightGrid (referenceInstanceValues value))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N)
    (ρ : ℝ) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1) (q : ℝ) (hq : q ∈ interval) :
    let n := referenceSearchSteps N delta epsilon
    let m := commonBatchSize N (n+1) epsilon ρ
    let positive : ℝ → (Fin m → (Fin G.last × (E → Bool))) → Bool := fun q x => referencePositiveTest laws value G M theta epsilon q x
    let negative : ℝ → (Fin m → (Fin G.last × (E → Bool))) → Bool := fun q x => referenceNegativeTest laws value G M theta epsilon q x
    let batch := referenceQuerySampler laws value G (reference_volume_positive laws M value hv hnonloop G hF) m
    (referenceSearchTapeLaw positive negative batch delta q n).prob (fun tape =>
      ¬ referenceSearchAccurate positive negative (fun i => finiteTapeStream tape (i+1))
        ⟨q,tape 0⟩ (referenceRecordGood laws value G M hnonloop N epsilon) delta n) ≤ ρ/N := by
  dsimp only
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN0
  have hk : 0 < ((referenceSearchSteps N delta epsilon+1:ℕ):ℝ) := Nat.cast_pos.mpr (Nat.zero_lt_succ _)
  have h := reference_search_tape_failure
    (fun q x => referencePositiveTest laws value G M theta epsilon q x)
    (fun q x => referenceNegativeTest laws value G M theta epsilon q x)
    (referenceQuerySampler laws value G (reference_volume_positive laws M value hv hnonloop G hF)
      (commonBatchSize N (referenceSearchSteps N delta epsilon+1) epsilon ρ))
    (referenceRecordGood laws value G M hnonloop N epsilon) delta q
    (ρ/((N:ℝ)*(referenceSearchSteps N delta epsilon+1:ℕ)))
    (by norm_num [delta]) hq (by positivity)
    (referenceQuerySampler_budget laws value hv G (reference_volume_positive laws M value hv hnonloop G hF)
      M hnonloop N _ hN0 hN (Nat.zero_lt_succ _) ρ hρ0 hρ1)
    (referenceSearchSteps N delta epsilon)
  convert h using 1 <;> field_simp <;> ring

end MatroidProphetSecretary
