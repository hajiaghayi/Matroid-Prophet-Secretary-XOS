import MatroidProphetSecretary.CoordinateConditioning

/-! Exact finite accepted-history path factorization for per-label private randomness.
The state can contain only accepted records: a rejection is simply an unchanged state.
No independence of a label's counterfactual decisions is assumed. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E Ω S : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

def privateStepRun (label : ℕ → E) (step : ℕ → S → Ω → S) (initial : S)
    (tapes : E → Ω) : ℕ → S
  | 0 => initial
  | n+1 => step n (privateStepRun label step initial tapes n) (tapes (label n))

def privatePathEvent (label : ℕ → E) (step : ℕ → S → Ω → S) (initial : S)
    (path : ℕ → S) (n : ℕ) (tapes : E → Ω) : Prop :=
  ∀ i ≤ n, privateStepRun label step initial tapes i = path i

def privateCoordinateEvent (label : ℕ → E) (step : ℕ → S → Ω → S)
    (path : ℕ → S) (n : ℕ) (e : E) (tapes : Ω) : Prop :=
  ∀ i < n, label i = e → step i (path i) tapes = path (i+1)

theorem privatePathEvent_iff (label : ℕ → E) (step : ℕ → S → Ω → S) (initial : S)
    (path : ℕ → S) (hstart : path 0 = initial) (n : ℕ) (tapes : E → Ω) :
    privatePathEvent label step initial path n tapes ↔
      ∀ e, privateCoordinateEvent label step path n e (tapes e) := by
  constructor
  · intro h e i hi hei
    subst e
    have hs := h (i+1) (Nat.succ_le_of_lt hi)
    rw [privateStepRun,h i hi.le] at hs
    exact hs
  · intro h i hi
    induction i with
    | zero => exact hstart.symm
    | succ i ih =>
      rw [privateStepRun,ih (Nat.le_trans (Nat.le_succ i) hi)]
      exact h (label i) i (Nat.lt_of_succ_le hi) rfl

theorem privatePath_probability (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial) (n : ℕ) :
    (FiniteLaw.product laws).prob (privatePathEvent label step initial path n) =
      ∏ e, (laws e).prob (privateCoordinateEvent label step path n e) := by
  calc
    _ = (FiniteLaw.product laws).prob (fun x => ∀ e, privateCoordinateEvent label step path n e (x e)) :=
      FiniteLaw.prob_congr _ (privatePathEvent_iff label step initial path hstart n)
    _ = _ := by
      convert FiniteLaw.product_prob_coordinates laws (privateCoordinateEvent label step path n) using 1

theorem privatePath_weighted_expect (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (f : (E → Ω) → ℝ) :
    (FiniteLaw.product laws).prob (privatePathEvent label step initial path n) *
      (FiniteLaw.product (fun e => (laws e).conditionOrSelf (privateCoordinateEvent label step path n e))).expect f =
        (FiniteLaw.product laws).expect (fun x => if privatePathEvent label step initial path n x then f x else 0) := by
  have hp := FiniteLaw.prob_congr (FiniteLaw.product laws)
    (privatePathEvent_iff label step initial path hstart n)
  rw [hp,FiniteLaw.product_condition_weighted_expect]
  congr 1
  funext x
  rw [privatePathEvent_iff label step initial path hstart n]
  split_ifs <;> rfl

theorem privatePath_conditional_expect (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n))
    (f : (E → Ω) → ℝ) :
    ((FiniteLaw.product laws).conditionOrSelf (privatePathEvent label step initial path n)).expect f =
      (FiniteLaw.product (fun e => (laws e).conditionOrSelf (privateCoordinateEvent label step path n e))).expect f := by
  apply mul_left_cancel₀ hp.ne'
  rw [FiniteLaw.conditionOrSelf_weighted_expect,
    privatePath_weighted_expect laws label step initial path hstart n f]

end MatroidProphetSecretary

