import Mathlib.Analysis.Convex.Mul
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Push
import Mathlib.Tactic.Ring

namespace MatroidProphetSecretary

/-- Lemma 4, for any nonnegative nondecreasing concave function. -/
theorem affine_potential_concave {J : Set ℝ} {F : ℝ → ℝ} {c theta : ℝ}
    (hF : ConcaveOn ℝ J F) (hmono : MonotoneOn F J)
    (hFnonneg : ∀ x ∈ J, 0 ≤ F x) (htheta : 0 ≤ theta)
    (ha : ∀ x ∈ J, 0 ≤ c - theta * x) :
    ConcaveOn ℝ J (fun x => (c - theta * x) * F x) := by
  have hAffine : ConcaveOn ℝ J (fun x => c - theta * x) := by
    refine ⟨hF.1, ?_⟩
    intro x hx y hy u v hu hv huv
    simp only [smul_eq_mul]
    apply le_of_eq
    calc
      u * (c - theta * x) + v * (c - theta * y) =
          (u + v) * c - theta * (u * x + v * y) := by ring
      _ = c - theta * (u * x + v * y) := by rw [huv, one_mul]
  have hAnti : AntitoneOn (fun x => c - theta * x) J := by
    intro x hx y hy hxy
    exact sub_le_sub_left (mul_le_mul_of_nonneg_left hxy htheta) c
  exact hAffine.mul hF (fun {x} hx => ha x hx)
    (fun {x} hx => hFnonneg x hx) (hAnti.antivaryOn hmono)

/-- Summing expected one-epoch drifts. This is the telescoping step in
Proposition 19; the probabilistic drift premise must be proved separately. -/
theorem telescope_expected_drift (reward potential : ℕ → ℝ) (loss : ℝ)
    (n : ℕ) (hdrift : ∀ i < n, potential i - loss ≤ reward i + potential (i + 1)) :
    potential 0 - (n : ℝ) * loss ≤
      (∑ i ∈ Finset.range n, reward i) + potential n := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hp := ih (fun i hi => hdrift i (Nat.lt_succ_of_lt hi))
    have hn := hdrift n (Nat.lt_succ_self n)
    rw [Finset.sum_range_succ]
    push_cast
    linarith

/-- A good-event estimate with nonnegative output loses at most p times
the benchmark. All variables are already (conditional) expectations. -/
theorem charge_bad_event (p P F good bad : ℝ)
    (hp : 0 ≤ p) (hp1 : p ≤ 1) (hP : P ≤ F)
    (hgood : P ≤ good) (hbad : 0 ≤ bad) :
    P - p * F ≤ (1 - p) * good + p * bad := by
  nlinarith [mul_nonneg hp hbad,
    mul_le_mul_of_nonneg_left hgood (sub_nonneg.mpr hp1),
    mul_le_mul_of_nonneg_left hP hp]

/-- Both error budgets in Sections 7 and 8, at the level of expectations. -/
theorem two_error_budgets (ideal implemented F theta rho : ℝ)
    (hideal : (1 - theta - rho) * F ≤ ideal)
    (himplementation : ideal - rho * F ≤ implemented) :
    (1 - theta - 2 * rho) * F ≤ implemented := by nlinarith

/-- Quantitative final approximation argument for general priors. -/
theorem approximation_transfer (actual rounded reference optRounded optReference F
    beta target tau B gamma : ℝ)
    (hbeta : 0 ≤ beta)
    (hactual : rounded ≤ actual)
    (hfinite : beta * optReference ≤ reference)
    (hrewardTV : reference - B * gamma ≤ rounded)
    (hoptTV : optRounded - B * gamma ≤ optReference)
    (hrounding : F - tau ≤ optRounded)
    (herror : beta * tau + (1 + beta) * B * gamma < (beta - target) * F) :
    target * F < actual := by
  have h1 := mul_le_mul_of_nonneg_left hoptTV hbeta
  have h2 := mul_le_mul_of_nonneg_left hrounding hbeta
  nlinarith

end MatroidProphetSecretary
