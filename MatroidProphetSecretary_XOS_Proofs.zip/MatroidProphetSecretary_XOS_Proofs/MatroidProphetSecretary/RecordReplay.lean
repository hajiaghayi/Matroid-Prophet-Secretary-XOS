import MatroidProphetSecretary.VirtualInitialization
import MatroidProphetSecretary.StampedHistory

/-! Stamped accepted records replay to the same exchange state and accumulate their actual value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def recordReplay (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (history : StampedHistory E W) : VirtualState M :=
  history.foldl (fun state record => virtualUpdate M base hbase value state (some (record.1,record.2.2)))
    (initialVirtualState M)

def recordLabels (history : StampedHistory E W) : Finset E := (history.map Prod.fst).toFinset

def recordReward (value : W → E → ℝ) (history : StampedHistory E W) : ℝ :=
  (history.map (fun record => value record.2.2 record.1)).sum

theorem recordReplay_append (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (history : StampedHistory E W) (e : E) (t : ℕ) (y : W) :
    recordReplay M base hbase value (history ++ [(e,(t,y))]) =
      virtualUpdate M base hbase value (recordReplay M base hbase value history) (some (e,y)) := by
  simp [recordReplay,List.foldl_append]

inductive ValidExchangeRecords (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) : StampedHistory E W → Prop
  | nil : ValidExchangeRecords M base hbase value []
  | snoc {history : StampedHistory E W} (valid : ValidExchangeRecords M base hbase value history)
      (e : E) (t : ℕ) (y : W)
      (live : e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y) :
      ValidExchangeRecords M base hbase value (history ++ [(e,(t,y))])

theorem ValidExchangeRecords.labels (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history) :
    (recordReplay M base hbase value history).1 = recordLabels history := by
  induction h with
  | nil => rfl
  | @snoc history valid e t y hl ih =>
    rw [recordReplay_append]
    simp only [virtualUpdate,dif_pos hl,ih]
    simp [recordLabels,Finset.insert_eq,Finset.union_comm]

theorem ValidExchangeRecords.fresh (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history)
    (e : E) (y : W) (hl : e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y) :
    e ∉ recordLabels history := by
  rw [← h.labels M base hbase value history]
  exact (Finset.mem_sdiff.mp (Finset.mem_filter.mp hl).1).2

theorem ValidExchangeRecords.feasible (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history) :
    M.Indep (recordLabels history : Set E) := by
  rw [← h.labels M base hbase value history]
  exact virtualState_feasible μ M base hbase _

theorem ValidExchangeRecords.reward_eq_weight (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history)
    (actual : E → ℝ) (hactual : ∀ record ∈ history, value record.2.2 record.1 = actual record.1) :
    recordReward value history = weight actual (recordLabels history) := by
  induction h with
  | nil => simp [recordReward,recordLabels,weight]
  | @snoc history valid e t y hl ih =>
    have hf := valid.fresh M base hbase value history e y hl
    have hc : value y e = actual e := hactual (e,(t,y)) (by simp)
    have hold : ∀ record ∈ history, value record.2.2 record.1 = actual record.1 :=
      fun record hr => hactual record (List.mem_append_left _ hr)
    have hs : recordLabels (history ++ [(e,(t,y))]) = insert e (recordLabels history) := by
      simp [recordLabels,Finset.insert_eq,Finset.union_comm]
    rw [hs]
    simp only [recordReward,List.map_append,List.map_singleton,List.sum_append,List.sum_cons,List.sum_nil,add_zero]
    change recordReward value history+value y e = _
    rw [ih hold,hc]
    simp only [weight,Finset.sum_insert hf]
    ring

end MatroidProphetSecretary
