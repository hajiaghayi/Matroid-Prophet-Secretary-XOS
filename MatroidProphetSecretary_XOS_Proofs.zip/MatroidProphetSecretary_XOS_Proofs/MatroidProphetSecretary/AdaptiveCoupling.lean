import MatroidProphetSecretary.AdaptiveBatches
import MatroidProphetSecretary.FinitePairs

/-! Coupled adaptive finite experiments have the correct marginals and a first-disagreement bound. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open scoped Classical

variable {S T Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]

theorem adaptiveBatches_project_expect (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (other : T → FiniteLaw Ψ) (otherUpdate : T → Ψ → T) (stateMap : S → T) (drawMap : Ω → Ψ)
    (hbatch : ∀ s, (batch s).map drawMap = other (stateMap s))
    (hupdate : ∀ s x, stateMap (update s x) = otherUpdate (stateMap s) (drawMap x))
    (n : ℕ) (s : S) (f : (Fin n → Ψ) → ℝ) :
    (adaptiveBatches batch update n s).expect (fun x => f (fun i => drawMap (x i))) =
      (adaptiveBatches other otherUpdate n (stateMap s)).expect f := by
  induction n generalizing s with
  | zero => simp only [adaptiveBatches,pointMass_expect]; congr 1; funext i; exact Fin.elim0 i
  | succ n ih =>
    simp only [adaptiveBatches,bind_expect,map_expect]
    have hcons (x : Ω) (ys : Fin n → Ω) :
        (fun i => drawMap ((Fin.cons x ys : Fin (n+1) → Ω) i)) =
          (Fin.cons (drawMap x) (fun i => drawMap (ys i)) : Fin (n+1) → Ψ) := by
      funext i
      exact Fin.cases rfl (fun j => rfl) i
    simp_rw [hcons]
    have ht (x : Ω) := ih (update s x) (fun ys => f (Fin.cons (drawMap x) ys))
    simp only [hupdate] at ht
    simp_rw [ht]
    have hm := map_expect (batch s) drawMap (fun x =>
      (adaptiveBatches other otherUpdate n (otherUpdate (stateMap s) x)).expect (fun ys => f (Fin.cons x ys)))
    rw [hbatch] at hm
    exact hm.symm

theorem adaptiveBatches_project (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (other : T → FiniteLaw Ψ) (otherUpdate : T → Ψ → T) (stateMap : S → T) (drawMap : Ω → Ψ)
    (hbatch : ∀ s, (batch s).map drawMap = other (stateMap s))
    (hupdate : ∀ s x, stateMap (update s x) = otherUpdate (stateMap s) (drawMap x))
    (n : ℕ) (s : S) :
    (adaptiveBatches batch update n s).map (fun x i => drawMap (x i)) =
      adaptiveBatches other otherUpdate n (stateMap s) := by
  apply ext_expect
  intro f
  rw [map_expect]
  exact adaptiveBatches_project_expect batch update other otherUpdate stateMap drawMap hbatch hupdate n s f

variable (left right : S → FiniteLaw Ω) (joint : S → FiniteLaw (Ω × Ω))

def coupledBatch (s : S × S) : FiniteLaw (Ω × Ω) :=
  if s.1 = s.2 then joint s.1 else (left s.1).pair (right s.2)

def coupledUpdate (update : S → Ω → S) (s : S × S) (x : Ω × Ω) : S × S :=
  (update s.1 x.1,update s.2 x.2)

def couplingStepBad (s : S × S) (x : Ω × Ω) : Prop := s.1 = s.2 ∧ x.1 ≠ x.2

theorem coupledBatch_left (hj : ∀ s, (joint s).map Prod.fst = left s) (s : S × S) :
    (coupledBatch left right joint s).map Prod.fst = left s.1 := by
  unfold coupledBatch
  split_ifs
  · exact hj s.1
  · apply ext_expect
    intro f
    simp only [map_expect,pair_expect,expect_const]

theorem coupledBatch_right (hj : ∀ s, (joint s).map Prod.snd = right s) (s : S × S) :
    (coupledBatch left right joint s).map Prod.snd = right s.2 := by
  unfold coupledBatch
  split_ifs with hs
  · rw [hj,hs]
  · apply ext_expect
    intro f
    simp only [map_expect,pair_expect,expect_const]

theorem coupledBatch_error (η : ℝ) (hη : 0 ≤ η)
    (hj : ∀ s, (joint s).prob (fun x => x.1 ≠ x.2) ≤ η) (s : S × S) :
    (coupledBatch left right joint s).prob (couplingStepBad s) ≤ η := by
  by_cases hs : s.1 = s.2
  · have he : couplingStepBad s = (fun x : Ω × Ω => x.1 ≠ x.2) := by funext x; simp [couplingStepBad,hs]
    simp only [coupledBatch,if_pos hs,he]
    exact hj s.1
  · have he : couplingStepBad s = (fun _ : Ω × Ω => False) := by funext x; simp [couplingStepBad,hs]
    simpa only [coupledBatch,if_neg hs,he,prob,if_false,expect_const] using hη

theorem coupled_no_failure (update : S → Ω → S) (n : ℕ) (s : S × S)
    (hs : s.1 = s.2) (x : Fin n → Ω × Ω)
    (hgood : ¬ trajectoryBad (coupledUpdate update) couplingStepBad n s x) :
    (fun i => (x i).1) = (fun i => (x i).2) := by
  induction n generalizing s with
  | zero => funext i; exact Fin.elim0 i
  | succ n ih =>
    have hh := not_or.mp hgood
    have hx : (x 0).1 = (x 0).2 := by
      by_contra hn
      exact hh.1 ⟨hs,hn⟩
    have hstate : (coupledUpdate update s (x 0)).1 = (coupledUpdate update s (x 0)).2 := by
      simp only [coupledUpdate,hs,hx]
    have ht := ih _ hstate (fun i => x i.succ) hh.2
    funext i
    exact Fin.cases hx (fun j => congrFun ht j) i

theorem coupled_adaptive_error (update : S → Ω → S) (η : ℝ) (hη : 0 ≤ η)
    (hj : ∀ s, (joint s).prob (fun x => x.1 ≠ x.2) ≤ η) (n : ℕ) (s : S) :
    (adaptiveBatches (coupledBatch left right joint) (coupledUpdate update) n (s,s)).prob
      (fun x => (fun i => (x i).1) ≠ (fun i => (x i).2)) ≤ n*η := by
  apply (prob_mono _ (fun x hx => ?_)).trans
    (adaptiveBatches_failure_bound (coupledBatch left right joint) (coupledUpdate update)
      couplingStepBad η hη (coupledBatch_error left right joint η hη hj) n (s,s))
  by_contra hn
  exact hx (coupled_no_failure update n (s,s) rfl x hn)

theorem coupled_adaptive_left (update : S → Ω → S)
    (hj : ∀ s, (joint s).map Prod.fst = left s) (n : ℕ) (s : S × S) :
    (adaptiveBatches (coupledBatch left right joint) (coupledUpdate update) n s).map
      (fun x i => (x i).1) = adaptiveBatches left update n s.1 :=
  adaptiveBatches_project _ _ _ _ Prod.fst Prod.fst (coupledBatch_left left right joint hj)
    (fun _ _ => rfl) n s

theorem coupled_adaptive_right (update : S → Ω → S)
    (hj : ∀ s, (joint s).map Prod.snd = right s) (n : ℕ) (s : S × S) :
    (adaptiveBatches (coupledBatch left right joint) (coupledUpdate update) n s).map
      (fun x i => (x i).2) = adaptiveBatches right update n s.2 :=
  adaptiveBatches_project _ _ _ _ Prod.snd Prod.snd (coupledBatch_right left right joint hj)
    (fun _ _ => rfl) n s

end MatroidProphetSecretary.FiniteLaw
