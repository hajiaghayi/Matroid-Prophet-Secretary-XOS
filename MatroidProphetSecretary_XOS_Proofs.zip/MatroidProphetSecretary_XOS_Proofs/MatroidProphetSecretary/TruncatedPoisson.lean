import MatroidProphetSecretary.PoissonProbes
import Mathlib.Data.Complex.ExponentialBounds
import Mathlib.Algebra.BigOperators.Fin

/-! Finite rational Poisson-two count tables, their mean, and the truncation error. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def poissonTwoWeight (n : ℕ) : ℝ := 2^n/(n.factorial:ℝ)

theorem poissonTwoWeight_pos (n : ℕ) : 0 < poissonTwoWeight n := by
  unfold poissonTwoWeight
  positivity

theorem poissonTwoWeight_succ (n : ℕ) : (n+1:ℕ)*poissonTwoWeight (n+1) = 2*poissonTwoWeight n := by
  simp only [poissonTwoWeight,Nat.factorial_succ,Nat.cast_mul,Nat.cast_add,Nat.cast_one,pow_succ]
  have hn : (n:ℝ)+1 ≠ 0 := by positivity
  field_simp
  <;> ring

def poissonTwoNormalizer (T : ℕ) : ℝ := ∑ n ∈ range (T+1), poissonTwoWeight n

theorem poissonTwoNormalizer_pos (T : ℕ) : 0 < poissonTwoNormalizer T := by
  apply sum_pos (fun n _ => poissonTwoWeight_pos n)
  exact nonempty_range_iff.mpr (by omega)

def truncatedPoissonTwo (T : ℕ) : FiniteLaw (Fin (T+1)) where
  mass n := poissonTwoWeight n / poissonTwoNormalizer T
  nonneg n := div_nonneg (poissonTwoWeight_pos n).le (poissonTwoNormalizer_pos T).le
  total := by
    rw [← sum_div,Fin.sum_univ_eq_sum_range]
    change poissonTwoNormalizer T / poissonTwoNormalizer T = 1
    exact div_self (ne_of_gt (poissonTwoNormalizer_pos T))

theorem poissonTwo_firstMoment_sum (T : ℕ) :
    (∑ n ∈ range (T+1), (n:ℝ)*poissonTwoWeight n) = 2*∑ n ∈ range T, poissonTwoWeight n := by
  induction T with
  | zero => simp
  | succ T ih =>
    rw [sum_range_succ,ih,sum_range_succ,poissonTwoWeight_succ]
    ring

theorem truncatedPoissonTwo_mean_le_two (T : ℕ) :
    (truncatedPoissonTwo T).expect (fun n => n.val) ≤ 2 := by
  have hz := poissonTwoNormalizer_pos T
  change (∑ n : Fin (T+1), poissonTwoWeight n / poissonTwoNormalizer T * (n:ℝ)) ≤ 2
  have he : (∑ n : Fin (T+1), poissonTwoWeight n / poissonTwoNormalizer T * (n:ℝ)) =
      (∑ n ∈ range (T+1), (n:ℝ)*poissonTwoWeight n) / poissonTwoNormalizer T := by
    calc
      _ = ∑ n : Fin (T+1), ((n:ℝ)*poissonTwoWeight n) / poissonTwoNormalizer T := by
        apply sum_congr rfl
        intro n hn
        ring
      _ = _ := by
        rw [← sum_div]
        congr 1
        exact Fin.sum_univ_eq_sum_range (fun n : ℕ => (n:ℝ)*poissonTwoWeight n) (T+1)
  rw [he,poissonTwo_firstMoment_sum,div_le_iff₀ hz]
  have hs : (∑ n ∈ range T, poissonTwoWeight n) ≤ poissonTwoNormalizer T := by
    rw [poissonTwoNormalizer,sum_range_succ]
    linarith [poissonTwoWeight_pos T]
  linarith

theorem poisson_two_tail_bound (T : ℕ) :
    (∑' n : ℕ, if T < n then ProbabilityTheory.poissonPMFReal 2 n else 0) ≤ 4/(2:ℝ)^T := by
  let p := fun n => ProbabilityTheory.poissonPMFReal 2 n
  have hp (n : ℕ) : 0 ≤ p n := by simp [p,ProbabilityTheory.poissonPMFReal]; positivity
  have hs : Summable p := by
    simpa using (poisson_weighted_power_hasSum 2 1).summable
  have ht : Summable (fun n : ℕ => if T < n then p n else 0) :=
    Summable.of_nonneg_of_le (fun n => by split_ifs; exact hp n; exact le_rfl)
      (fun n => by split_ifs; exact le_rfl; exact hp n) hs
  have hw := (poisson_weighted_power_hasSum 2 2).summable.div_const ((2:ℝ)^(T+1))
  have hterm (n : ℕ) : (if T < n then p n else 0) ≤ p n*2^n/(2:ℝ)^(T+1) := by
    by_cases hT : T < n
    · rw [if_pos hT,le_div_iff₀ (by positivity)]
      exact mul_le_mul_of_nonneg_left (pow_le_pow_right₀ (by norm_num : (1:ℝ) ≤ 2) (by omega)) (hp n)
    · rw [if_neg hT]
      exact div_nonneg (mul_nonneg (hp n) (by positivity)) (by positivity)
  have h := tsum_le_tsum hterm ht hw
  rw [tsum_div_const,poisson_weighted_power] at h
  have he : Real.exp 2 < 8 := by
    have h1 := Real.exp_one_lt_d9
    have h0 := Real.exp_pos 1
    have hid : Real.exp 2 = (Real.exp 1)^2 := by rw [pow_two,← Real.exp_add]; norm_num
    rw [hid]
    nlinarith
  change (∑' n, if T < n then p n else 0) ≤ _
  norm_num only [NNReal.coe_ofNat,show (2:ℝ)*(2-1)=2 by norm_num] at h
  apply h.trans
  calc
    _ ≤ 8/(2:ℝ)^(T+1) := div_le_div_of_nonneg_right he.le (by positivity)
    _ = 4/(2:ℝ)^T := by rw [pow_succ]; ring

end MatroidProphetSecretary
