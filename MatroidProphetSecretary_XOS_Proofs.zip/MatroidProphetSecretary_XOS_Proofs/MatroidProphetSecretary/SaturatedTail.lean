import MatroidProphetSecretary.PoissonGenerator

/-! One-sided derivatives of the saturated reference tail. -/

noncomputable section

namespace MatroidProphetSecretary

open Set Filter
open scoped Classical Topology

def scaledTail (p q : ℝ) : ℝ := min 1 (q * p)

def scaledTailRightSlope (p q : ℝ) : ℝ := if q * p < 1 then p else 0

def scaledTailLeftSlope (p q : ℝ) : ℝ := if q * p ≤ 1 then p else 0

theorem scaledTail_bounds (p q : ℝ) (hp : 0 ≤ p) (hq : 0 ≤ q) :
    0 ≤ scaledTail p q ∧ scaledTail p q ≤ 1 :=
  ⟨le_min zero_le_one (mul_nonneg hq hp), min_le_left _ _⟩

theorem scaledTail_monotone (p : ℝ) (hp : 0 ≤ p) : Monotone (scaledTail p) := by
  intro q r hqr
  exact min_le_min_left 1 (mul_le_mul_of_nonneg_right hqr hp)

theorem scaledTail_continuous (p : ℝ) : Continuous (scaledTail p) :=
  continuous_const.min (continuous_id.mul continuous_const)

theorem scaledTail_right_derivative (p q : ℝ) (hp : 0 ≤ p) :
    HasDerivWithinAt (scaledTail p) (scaledTailRightSlope p q) (Ici q) q := by
  have hlin : HasDerivAt (fun t => t * p) p q := by simpa using (hasDerivAt_id q).mul_const p
  by_cases hqp : q * p < 1
  · rw [scaledTailRightSlope, if_pos hqp]
    apply HasDerivAt.hasDerivWithinAt
    apply hlin.congr_of_eventuallyEq
    have hnear : ∀ᶠ t in 𝓝 q, t * p < 1 :=
      (isOpen_lt (continuous_id.mul continuous_const) continuous_const).mem_nhds hqp
    filter_upwards [hnear] with t ht
    exact min_eq_right ht.le
  · rw [scaledTailRightSlope, if_neg hqp]
    apply (hasDerivWithinAt_const q (Ici q) (1 : ℝ)).congr_of_mem
    · intro t ht
      exact min_eq_left ((le_of_not_gt hqp).trans (mul_le_mul_of_nonneg_right ht hp))
    · exact Set.mem_Ici.mpr le_rfl

theorem scaledTail_left_derivative (p q : ℝ) (hp : 0 ≤ p) :
    HasDerivWithinAt (scaledTail p) (scaledTailLeftSlope p q) (Iic q) q := by
  have hlin : HasDerivAt (fun t => t * p) p q := by simpa using (hasDerivAt_id q).mul_const p
  by_cases hqp : q * p ≤ 1
  · rw [scaledTailLeftSlope, if_pos hqp]
    apply (hlin.hasDerivWithinAt (s := Iic q)).congr_of_mem
    · intro t ht
      exact min_eq_right ((mul_le_mul_of_nonneg_right ht hp).trans hqp)
    · exact Set.mem_Iic.mpr le_rfl
  · rw [scaledTailLeftSlope, if_neg hqp]
    apply HasDerivAt.hasDerivWithinAt
    apply (hasDerivAt_const q (1 : ℝ)).congr_of_eventuallyEq
    have hnear : ∀ᶠ t in 𝓝 q, 1 < t * p :=
      (isOpen_lt continuous_const (continuous_id.mul continuous_const)).mem_nhds (lt_of_not_ge hqp)
    filter_upwards [hnear] with t ht
    exact min_eq_left ht.le

theorem scaledTail_derivative_bounds (p q : ℝ) (hp : 0 ≤ p) (hq : 0 ≤ q) :
    scaledTail p q - (scaledTail p q)^2 ≤ q * scaledTailRightSlope p q ∧
      q * scaledTailRightSlope p q ≤ q * scaledTailLeftSlope p q ∧
      q * scaledTailLeftSlope p q ≤ scaledTail p q := by
  rcases lt_trichotomy (q * p) 1 with h | h | h
  · simp only [scaledTail, min_eq_right h.le, scaledTailRightSlope, scaledTailLeftSlope,
      if_pos h, if_pos h.le]
    constructor
    · nlinarith [sq_nonneg (q * p)]
    · exact ⟨le_rfl, le_rfl⟩
  · simp [scaledTail, scaledTailRightSlope, scaledTailLeftSlope, h]
  · simp [scaledTail, scaledTailRightSlope, scaledTailLeftSlope, h.le,
      not_lt.mpr h.le, not_le.mpr h]

end MatroidProphetSecretary
