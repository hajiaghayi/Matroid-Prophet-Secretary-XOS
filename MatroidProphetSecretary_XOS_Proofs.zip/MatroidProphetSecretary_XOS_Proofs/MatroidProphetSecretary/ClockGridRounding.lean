import MatroidProphetSecretary.UniformGridDraw

/-! Upward clock rounding preserves order off collisions and respects a grid phase boundary. -/

noncomputable section

namespace MatroidProphetSecretary

def uniformGridUp (G : ℕ) (u : ℝ) : ℝ := ((⌊(G:ℝ)*u⌋₊:ℝ)+1)/G

theorem uniformGridUp_bounds (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : 0 ≤ u) :
    u < uniformGridUp G u ∧ uniformGridUp G u ≤ u+1/G := by
  have hG' : (0:ℝ) < G := by exact_mod_cast hG
  have h := uniformGridDown_bounds G hG u hu
  have he : uniformGridUp G u = uniformGridDown G u+1/G := by
    unfold uniformGridUp uniformGridDown
    rw [add_div]
  rw [he]
  exact ⟨h.2,add_le_add_right h.1 _⟩

theorem uniformGridUp_monotone (G : ℕ) : Monotone (uniformGridUp G) := by
  intro u v huv
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg G)
  apply add_le_add_right
  exact_mod_cast Nat.floor_mono (mul_le_mul_of_nonneg_left huv (Nat.cast_nonneg G))

theorem uniformGridUp_order_iff (G : ℕ) (u v : ℝ) (hne : uniformGridUp G u ≠ uniformGridUp G v) :
    uniformGridUp G u < uniformGridUp G v ↔ u < v := by
  constructor
  · intro h
    by_contra hn
    exact (not_le.mpr h) (uniformGridUp_monotone G (le_of_not_gt hn))
  · intro h
    exact lt_of_le_of_ne (uniformGridUp_monotone G h.le) hne

theorem uniformGridUp_phase (G : ℕ) (hG : 0 < G) (j : ℕ) (u : ℝ) (hu : 0 ≤ u) :
    uniformGridUp G u ≤ (j:ℝ)/G ↔ u < (j:ℝ)/G := by
  have hG' : (0:ℝ) < G := by exact_mod_cast hG
  rw [uniformGridUp,div_le_div_iff_of_pos_right hG',lt_div_iff₀ hG']
  have hf := Nat.floor_lt (mul_nonneg hG'.le hu) (n := j)
  constructor
  · intro h
    have hn : ⌊(G:ℝ)*u⌋₊ < j := by exact_mod_cast h
    have hh := hf.mp hn
    nlinarith
  · intro h
    have hn : ⌊(G:ℝ)*u⌋₊ < j := hf.mpr (by nlinarith)
    exact_mod_cast hn

theorem uniformGridUp_index (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : u ∈ Set.Ico (0:ℝ) 1) :
    uniformGridUp G u = (((uniformGridIndex G hG u).val:ℝ)+1)/G := by
  rw [uniformGridIndex_on_unit G hG u hu]
  rfl

end MatroidProphetSecretary
