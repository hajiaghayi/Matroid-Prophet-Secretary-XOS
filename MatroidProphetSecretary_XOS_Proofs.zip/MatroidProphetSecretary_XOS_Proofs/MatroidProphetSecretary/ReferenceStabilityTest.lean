import MatroidProphetSecretary.ReferenceBatchRatios
import MatroidProphetSecretary.Parameters

/-! The stability test uses the saved batch and its two certified ratios. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def referenceStabilityEstimate (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) : ℝ :=
  (referenceBatchEstimate laws value G M q 1 x-referenceBatchEstimate laws value G M q 2 x)/
    referenceBatchEstimate laws value G M q 0 x

theorem referenceStabilityEstimate_accuracy (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (q : ℝ) (N : ℕ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value)
      G M hnonloop N epsilon x) :
    |referenceStabilityEstimate laws value G M q x-
      referenceStable laws M value hnonloop q/referenceExpectedOptimum laws M value q| ≤ 10*epsilon := by
  have h0 := (referenceBatchRatio_accuracy false laws value G M hnonloop theta q epsilon N x hF
    (by norm_num [epsilon]) (by norm_num [epsilon]) hgood).2
  have h1 := (referenceBatchRatio_accuracy true laws value G M hnonloop theta q epsilon N x hF
    (by norm_num [epsilon]) (by norm_num [epsilon]) hgood).2
  obtain ⟨h0l,h0u⟩ := abs_le.mp h0
  obtain ⟨h1l,h1u⟩ := abs_le.mp h1
  simp only [referenceBatchRatio,referenceSearchRatio,referenceSearchNumerator,Bool.false_eq_true,if_false,if_true,
    sub_div] at h0l h0u h1l h1u
  unfold referenceStabilityEstimate
  rw [sub_div,abs_le]
  constructor <;> linarith only [h0l,h0u,h1l,h1u]

theorem referenceStabilityEstimate_branches (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (q : ℝ) (N : ℕ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value)
      G M hnonloop N epsilon x) :
    if eta < referenceStabilityEstimate laws value G M q x then
      hMinus < referenceStable laws M value hnonloop q/referenceExpectedOptimum laws M value q
    else referenceStable laws M value hnonloop q/referenceExpectedOptimum laws M value q ≤ hPlus := by
  have h := abs_le.mp (referenceStabilityEstimate_accuracy laws value G M hnonloop q N x hF hgood)
  unfold hMinus hPlus
  split_ifs with ht
  · linarith only [h.2,ht]
  · have ht' := le_of_not_gt ht
    linarith only [h.1,ht']

end MatroidProphetSecretary
