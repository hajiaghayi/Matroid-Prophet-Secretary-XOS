import MatroidProphetSecretary.PoissonConcavity
import MatroidProphetSecretary.PoissonLaw
import MatroidProphetSecretary.RankDeficit

/-! The tangent bound evaluated at a uniformly rounded matroid basis. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem rankObservable_le_rank (M : Matroid E) (hground : ∀ e, e ∈ M.E) (x : E → Bool) :
    rankObservable M x ≤ realRank M M.E := by
  obtain ⟨I, hI⟩ := M.exists_isBasis (bitSet x) (fun e _ => hground e)
  rw [rankObservable, realRank_eq_ncard hI]
  exact indep_ncard_le_realRank hI.indep hI.indep.subset_ground (Subset.refl M.E)

theorem rankObservable_of_indep (M : Matroid E) (x : E → Bool) (hx : M.Indep (bitSet x)) :
    rankObservable M x = ∑ e, if x e = true then (1 : ℝ) else 0 := by
  rw [rankObservable, realRank_eq_ncard hx.isBasis_self, Set.ncard_eq_toFinset_card']
  simp [bitSet, Set.toFinset_setOf]

def basisIntensity (C : Finset E) (s : ℝ) (e : E) : ℝ := if e ∈ C then s else 0

theorem basisIntensity_nonneg (C : Finset E) {s : ℝ} (hs : 0 ≤ s) (e : E) :
    0 ≤ basisIntensity C s e := by
  unfold basisIntensity
  split_ifs <;> linarith

theorem poissonMass_basis_support (C : Finset E) (s : ℝ) (x : E → Bool)
    (hx : ¬bitSet x ⊆ (C : Set E)) : poissonMass (basisIntensity C s) x = 0 := by
  obtain ⟨e, he, heC⟩ := Set.not_subset.mp hx
  change e ∉ C at heC
  rw [poissonMass_factor _ e]
  simp only [bitSet, mem_setOf_eq] at he
  simp [basisIntensity, heC, he, poissonWeight]

theorem poissonRank_basis (M : Matroid E) (C : Finset E) (hC : M.Indep (C : Set E))
    (s : ℝ) (hs : 0 ≤ s) :
    poissonEval (basisIntensity C s) (rankObservable M) =
      (C.card : ℝ) * (1 - Real.exp (-s)) := by
  have heq : poissonEval (basisIntensity C s) (rankObservable M) =
      poissonEval (basisIntensity C s) (fun x => ∑ e, if x e = true then (1 : ℝ) else 0) := by
    apply sum_congr rfl
    intro x hx
    by_cases hsub : bitSet x ⊆ (C : Set E)
    · rw [rankObservable_of_indep M x (hC.subset hsub)]
    · rw [poissonMass_basis_support C s x hsub]
      simp
  rw [heq, poissonEval_sum]
  have he (e : E) :
      poissonEval (basisIntensity C s) (fun x => if x e = true then (1 : ℝ) else 0) =
      if e ∈ C then 1 - Real.exp (-s) else 0 := by
    rw [poissonEval_eq_expect _ (basisIntensity_nonneg C hs)]
    change (poissonLaw (basisIntensity C s) (basisIntensity_nonneg C hs)).prob
      (fun x => x e = true) = _
    rw [poissonLaw_prob_true]
    by_cases heC : e ∈ C <;> simp [basisIntensity, heC]
  simp_rw [he]
  simp
  ring

theorem rank_insertDifference (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (e : E) (x : E → Bool) :
    insertDifference e (rankObservable M) x = if e ∈ M.closure (bitSet x) then 0 else 1 := by
  simp only [insertDifference, rankObservable, bitSet_update]
  rw [realRank_insert M (bitSet x) (fun f _ => hground f) e (hground e)]
  ring

theorem rank_insertDifference_nonneg (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (e : E) (x : E → Bool) : 0 ≤ insertDifference e (rankObservable M) x := by
  rw [rank_insertDifference M hground]
  split_ifs <;> norm_num

theorem poissonRank_le_rank (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (a : E → ℝ) (ha : ∀ e, 0 ≤ a e) :
    poissonEval a (rankObservable M) ≤ realRank M M.E := by
  calc
    _ ≤ poissonEval a (fun _ => realRank M M.E) :=
      poissonEval_mono a ha (rankObservable_le_rank M hground)
    _ = _ := poissonEval_const a ha _

theorem poisson_rank_missing_mass (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (C : Finset E) (hC : M.IsBase (C : Set E)) (a : E → ℝ) (ha : ∀ e, 0 ≤ a e)
    (s : ℝ) (hs : 0 ≤ s) :
    (∑ e, (1 - Real.exp (-a e)) * poissonEval a (insertDifference e (rankObservable M))) ≤
      realRank M M.E * Real.exp (-s) +
        s * ∑ e ∈ C, poissonEval a (insertDifference e (rankObservable M)) := by
  have htan := poissonRank_tangent M hground a (basisIntensity C s) ha (basisIntensity_nonneg C hs)
  rw [poissonRank_basis M C hC.indep s hs] at htan
  have hr : realRank M M.E = (C.card : ℝ) := by
    rw [realRank_eq_ncard hC.isBasis_ground, Set.ncard_coe_Finset]
  have hsum : (∑ e, (basisIntensity C s e - a e) *
      poissonEval a (insertDifference e (rankObservable M))) =
      s * ∑ e ∈ C, poissonEval a (insertDifference e (rankObservable M)) -
      ∑ e, a e * poissonEval a (insertDifference e (rankObservable M)) := by
    simp only [sub_mul, sum_sub_distrib]
    congr 1
    simp [basisIntensity, ite_mul, mul_sum]
  rw [hsum] at htan
  have hf := poissonRank_le_rank M hground a ha
  have hcompare :
      (∑ e, (1 - Real.exp (-a e)) * poissonEval a (insertDifference e (rankObservable M))) ≤
      ∑ e, a e * poissonEval a (insertDifference e (rankObservable M)) := by
    apply sum_le_sum
    intro e he
    apply mul_le_mul_of_nonneg_right
    · have hexp := Real.add_one_le_exp (-a e)
      linarith
    · exact poissonEval_nonneg a ha _ (rank_insertDifference_nonneg M hground e)
  rw [hr] at hf ⊢
  nlinarith

end MatroidProphetSecretary
