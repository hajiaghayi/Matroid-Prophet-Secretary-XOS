import MatroidProphetSecretary.FiniteMixtures
import MatroidProphetSecretary.BlockIndependence
import Mathlib.Data.Fin.Tuple.Basic

/-! Fresh finite batches with adaptively chosen laws, and a conditional union bound. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

def pointMass (x : Ω) : FiniteLaw Ω where
  mass y := if y = x then 1 else 0
  nonneg y := by split_ifs <;> norm_num
  total := by simp

theorem pointMass_expect (x : Ω) (f : Ω → ℝ) : (pointMass x).expect f = f x := by
  simp [expect, pointMass]

variable {S : Type*}

def adaptiveBatches (batch : S → FiniteLaw Ω) (update : S → Ω → S) :
    (n : ℕ) → S → FiniteLaw (Fin n → Ω)
  | 0, _ => pointMass Fin.elim0
  | n+1, s => (batch s).bind (fun x =>
      (adaptiveBatches batch update n (update s x)).map (fun y => Fin.cons x y))

def trajectoryBad (update : S → Ω → S) (bad : S → Ω → Prop) :
    (n : ℕ) → S → (Fin n → Ω) → Prop
  | 0, _, _ => False
  | n+1, s, x => bad s (x 0) ∨ trajectoryBad update bad n (update s (x 0)) (fun i => x i.succ)

def stateBefore (update : S → Ω → S) : (n : ℕ) → S → (Fin n → Ω) → Fin n → S
  | 0, _, _, i => Fin.elim0 i
  | n+1, s, x, i => Fin.cases s
      (fun j => stateBefore update n (update s (x 0)) (fun k => x k.succ) j) i

theorem trajectoryBad_iff (update : S → Ω → S) (bad : S → Ω → Prop) (n : ℕ)
    (s : S) (x : Fin n → Ω) :
    trajectoryBad update bad n s x ↔ ∃ i, bad (stateBefore update n s x i) (x i) := by
  induction n generalizing s with
  | zero => simp [trajectoryBad]
  | succ n ih =>
    rw [trajectoryBad, ih]
    constructor
    · rintro (h | ⟨i,hi⟩)
      · exact ⟨0, by simpa [stateBefore] using h⟩
      · exact ⟨i.succ, by simpa [stateBefore] using hi⟩
    · rintro ⟨i,hi⟩
      revert hi
      refine Fin.cases ?_ (fun j => ?_) i
      · intro hi
        exact Or.inl (by simpa [stateBefore] using hi)
      · intro hi
        exact Or.inr ⟨j, by simpa [stateBefore] using hi⟩

theorem adaptiveBatches_failure_bound (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (bad : S → Ω → Prop) (η : ℝ) (hη : 0 ≤ η)
    (hbatch : ∀ s, (batch s).prob (bad s) ≤ η) (n : ℕ) (s : S) :
    (adaptiveBatches batch update n s).prob (trajectoryBad update bad n s) ≤ n * η := by
  induction n generalizing s with
  | zero => simp [adaptiveBatches, prob, trajectoryBad, pointMass_expect]
  | succ n ih =>
    unfold prob
    simp only [adaptiveBatches, bind_expect, map_expect, trajectoryBad, Fin.cons_zero, Fin.cons_succ]
    have hp (x : Ω) :
        (adaptiveBatches batch update n (update s x)).expect
          (fun y => if bad s x ∨ trajectoryBad update bad n (update s x) y then (1 : ℝ) else 0) ≤
        (if bad s x then 1 else 0) + (n:ℝ)*η := by
      by_cases hx : bad s x
      · simp only [hx, true_or, if_true, expect_const]
        exact le_add_of_nonneg_right (mul_nonneg (Nat.cast_nonneg _) hη)
      · simp only [hx, false_or, if_false, zero_add]
        exact ih (update s x)
    have h := (batch s).expect_mono hp
    rw [expect_add, expect_const] at h
    calc
      _ ≤ (batch s).prob (bad s) + (n:ℝ)*η := h
      _ ≤ η + (n:ℝ)*η := add_le_add_right (hbatch s) _
      _ = (↑(n+1):ℝ)*η := by push_cast; ring

theorem adaptiveBatches_selected_bound (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (bad : S → Ω → Prop) (η : ℝ) (hη : 0 ≤ η)
    (hbatch : ∀ s, (batch s).prob (bad s) ≤ η) (n : ℕ) (s : S)
    (select : (Fin n → Ω) → Fin n) :
    (adaptiveBatches batch update n s).prob
      (fun x => bad (stateBefore update n s x (select x)) (x (select x))) ≤ n * η := by
  refine (prob_mono _ (fun x hx => (trajectoryBad_iff update bad n s x).mpr ⟨select x,hx⟩)).trans ?_
  exact adaptiveBatches_failure_bound batch update bad η hη hbatch n s

end MatroidProphetSecretary.FiniteLaw
