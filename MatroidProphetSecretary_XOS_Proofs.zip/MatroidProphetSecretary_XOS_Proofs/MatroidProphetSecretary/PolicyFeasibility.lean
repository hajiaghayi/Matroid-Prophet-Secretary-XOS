import MatroidProphetSecretary.Problem
import Mathlib.Tactic

/-! Bridging local feasibility tests to the online policy model. -/

namespace MatroidProphetSecretary

open Finset

theorem acceptedSet_append_observation {N : ℕ} (history : List (Observation N)) (x : Observation N) :
    acceptedSet (history ++ [x]) = if x.accepted = true then insert x.label (acceptedSet history) else acceptedSet history := by
  cases hx : x.accepted <;> simp [acceptedSet, List.filter_append, hx, Finset.union_comm]
  ext e
  simp

theorem runPolicy_preserves_independence {N K : ℕ} (M : Matroid (Fin N)) (policy : OnlinePolicy N K)
    (hstep : ∀ seed history e v, M.Indep (acceptedSet history : Set (Fin N)) →
      policy seed history e v = true → M.Indep ((insert e (acceptedSet history) : Finset (Fin N)) : Set (Fin N)))
    (seed : Fin (2^K)) (values : Fin N → ℝ) (order : List (Fin N))
    (history : List (Observation N)) (hh : M.Indep (acceptedSet history : Set (Fin N))) :
    M.Indep (acceptedSet (runPolicy policy seed values order history) : Set (Fin N)) := by
  induction order generalizing history with
  | nil => exact hh
  | cons e rest ih =>
    apply ih
    rw [acceptedSet_append_observation]
    cases htake : policy seed history e (values e)
    · simpa only [Bool.false_eq_true, if_false] using hh
    · simpa only [if_true] using hstep seed history e (values e) hh htake

theorem policyFeasible_of_local {N K : ℕ} (M : Matroid (Fin N)) (policy : OnlinePolicy N K)
    (hstep : ∀ seed history e v, M.Indep (acceptedSet history : Set (Fin N)) →
      policy seed history e v = true → M.Indep ((insert e (acceptedSet history) : Finset (Fin N)) : Set (Fin N))) :
    PolicyFeasible M policy := by
  intro seed values order
  apply runPolicy_preserves_independence M policy hstep
  simpa [acceptedSet] using M.empty_indep

def feasibilityGuard {N K : ℕ} (oracle : Finset (Fin N) → Bool) (policy : OnlinePolicy N K) : OnlinePolicy N K :=
  fun seed history e v => policy seed history e v && oracle (insert e (acceptedSet history))

theorem feasibilityGuard_feasible {N K : ℕ} (M : Matroid (Fin N))
    (oracle : Finset (Fin N) → Bool) (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set (Fin N)))
    (policy : OnlinePolicy N K) : PolicyFeasible M (feasibilityGuard oracle policy) := by
  apply policyFeasible_of_local
  intro seed history e v hh ht
  have ht' : policy seed history e v = true ∧ oracle (insert e (acceptedSet history)) = true := by
    simpa only [feasibilityGuard, Bool.and_eq_true] using ht
  exact (horacle _).mp ht'.2

end MatroidProphetSecretary
