import MatroidProphetSecretary.ReferenceInstance
import MatroidProphetSecretary.ReferenceCandidateKernel
import MatroidProphetSecretary.FiniteMassShortfall
import MatroidProphetSecretary.FiniteSupport
import Mathlib.Logic.Equiv.Option

/-! Reference atoms are transported back to the input's atom type without changing their values. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def optionalValue {A : Type*} (v : A → ℝ) : Option A → ℝ
  | none => 0
  | some x => v x

def optionalCoordinateValues (value : ∀ e, V e → ℝ) (y : ∀ e, Option (V e)) (e : E) : ℝ :=
  optionalValue (value e) (y e)

def alignedReferenceLaws (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) (q : ℝ) :
    ∀ e, FiniteLaw (Option (V e)) := fun e =>
  (referenceInstanceLaws laws value q e).map (Equiv.optionCongr (valueSortedEquiv (value e)))

theorem aligned_reference_atom_domination (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (q : ℝ) (hq : 0 ≤ q) (e : E) (v : V e) :
    (alignedReferenceLaws laws value q e).mass (some v) ≤ q*(laws e).mass v := by
  let σ := valueSortedEquiv (value e)
  have hm := FiniteLaw.map_mass_of_injective (referenceInstanceLaws laws value q e)
    (Equiv.optionCongr σ) (Equiv.optionCongr σ).injective (some (σ.symm v))
  change (alignedReferenceLaws laws value q e).mass (some (σ (σ.symm v))) = _ at hm
  rw [Equiv.apply_symm_apply] at hm
  rw [hm]
  change (finiteReferenceLaw (sortedValueLaw (laws e) (value e)) (max 0 q) (le_max_left _ _)).mass (some (σ.symm v)) ≤ _
  have h := finiteReferenceLaw_atom_domination (sortedValueLaw (laws e) (value e)) (max 0 q)
    (le_max_left _ _) (σ.symm v)
  have hp := FiniteLaw.map_mass_of_injective (laws e) σ.symm σ.symm.injective v
  change (sortedValueLaw (laws e) (value e)).mass (σ.symm v) = (laws e).mass v at hp
  simpa only [max_eq_right hq,hp] using h

theorem optionalValue_sorted {A : Type*} [Fintype A] (value : A → ℝ)
    (y : Option (Fin (Fintype.card A))) :
    optionalValue value ((Equiv.optionCongr (valueSortedEquiv value)) y) = referencePriorValue value y := by
  cases y <;> rfl

theorem aligned_reference_expect (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (q : ℝ) (f : (E → ℝ) → ℝ) :
    (FiniteLaw.product (alignedReferenceLaws laws value q)).expect (fun y => f (optionalCoordinateValues value y)) =
      (FiniteLaw.product (referenceInstanceLaws laws value q)).expect
        (fun y => f (coordinateValues (referenceInstanceValues value) y)) := by
  unfold alignedReferenceLaws
  rw [FiniteLaw.product_map_expect]
  apply FiniteLaw.expect_congr_support
  intro y hy
  apply congrArg f
  funext e
  exact optionalValue_sorted (value e) (y e)

theorem aligned_reference_optimum (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) :
    expectedOptimum (FiniteLaw.product (alignedReferenceLaws laws value q)) M (optionalCoordinateValues value) =
      referenceExpectedOptimum laws M value q :=
  aligned_reference_expect laws value q (optimum M)

theorem optionalCoordinateValues_nonneg (value : ∀ e, V e → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (y : ∀ e, Option (V e)) (e : E) : 0 ≤ optionalCoordinateValues value y e := by
  cases hy : y e with
  | none => simp [optionalCoordinateValues,hy,optionalValue]
  | some v => simpa only [optionalCoordinateValues,hy,optionalValue] using hv e v

end MatroidProphetSecretary
