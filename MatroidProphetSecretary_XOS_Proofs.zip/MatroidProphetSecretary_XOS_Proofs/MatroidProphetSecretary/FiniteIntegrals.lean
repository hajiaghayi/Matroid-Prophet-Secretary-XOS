import MatroidProphetSecretary.LayerIntegral

/-! Interchanging finite expectations and Lebesgue layer integrals. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset MeasureTheory

variable {Ω : Type*} [Fintype Ω]

theorem integrable_expect (μ : FiniteLaw Ω) (f : Ω → ℝ → ℝ)
    (hf : ∀ w, Integrable (f w)) : Integrable (fun z => μ.expect (fun w => f w z)) :=
  integrable_finset_sum univ (fun w _ => (hf w).const_mul (μ.mass w))

theorem integral_expect (μ : FiniteLaw Ω) (f : Ω → ℝ → ℝ) (hf : ∀ w, Integrable (f w)) :
    (∫ z, μ.expect (fun w => f w z)) = μ.expect (fun w => ∫ z, f w z) := by
  unfold expect
  rw [integral_finset_sum univ (fun w _ => (hf w).const_mul (μ.mass w))]
  simp only [integral_const_mul]

end MatroidProphetSecretary.FiniteLaw
