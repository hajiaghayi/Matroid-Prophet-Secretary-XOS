import MatroidProphetSecretary.ColoopRecoveryRun
import Mathlib.Data.Finset.Sort

/-! Explicit balanced fundamental-circuit searches recover every coloop. -/

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

variable {E : Type*} [LinearOrder E]

def coloopOracle (oracle : Finset E → Bool) (R B : Finset E) : Finset E × ℕ :=
  coloopRecoveryRun oracle B (balancedQueryTree (B.sort (· ≤ ·))) ((R \ B).sort (· ≤ ·)) B

theorem coloopOracle_correct (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R B : Finset E)
    (hR : (R : Set E) = M.E) (hB : M.IsBase (B : Set E)) :
    (coloopOracle oracle R B).1 = R.filter M.IsColoop := by
  have htree : (balancedQueryTree (B.sort (· ≤ ·))).labels = B := by
    rw [balancedQueryTree_labels,sort_toFinset]
  have hxs : ∀ f ∈ (R \ B).sort (· ≤ ·), f ∈ M.E ∧ f ∉ B := by
    intro f hf
    have hf' : f ∈ R \ B := by simpa using hf
    exact ⟨hR ▸ (mem_sdiff.mp hf').1,(mem_sdiff.mp hf').2⟩
  rw [coloopOracle,coloopRecoveryRun_correct M oracle horacle B hB _ htree _ hxs B Subset.rfl]
  ext e
  simp only [mem_filter]
  constructor
  · rintro ⟨he,hc⟩
    have heR : e ∈ R := by
      change e ∈ (R : Set E)
      rw [hR]
      exact hB.subset_ground he
    refine ⟨heR,(hB.isColoop_iff_forall_not_mem_fundCircuit he).mpr ?_⟩
    intro f hf
    have hfR : f ∈ R := by
      change f ∈ (R : Set E)
      rw [hR]
      exact hf.1
    exact hc f (by simpa using mem_sdiff.mpr ⟨hfR,hf.2⟩)
  · rintro ⟨he,hc⟩
    have heB := hB.mem_of_isColoop hc
    refine ⟨heB,fun f hf => ?_⟩
    exact (hB.isColoop_iff_forall_not_mem_fundCircuit heB).mp hc f (hxs f hf)

theorem coloopOracle_query_bound (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R B : Finset E)
    (hR : (R : Set E) = M.E) (hB : M.IsBase (B : Set E)) :
    (coloopOracle oracle R B).2 ≤ (R \ B).card+2*Nat.clog 2 B.card*B.card := by
  have htree : (balancedQueryTree (B.sort (· ≤ ·))).labels = B := by
    rw [balancedQueryTree_labels,sort_toFinset]
  have hxs : ∀ f ∈ (R \ B).sort (· ≤ ·), f ∈ M.E ∧ f ∉ B := by
    intro f hf
    have hf' : f ∈ R \ B := by simpa using hf
    exact ⟨hR ▸ (mem_sdiff.mp hf').1,(mem_sdiff.mp hf').2⟩
  have h := coloopRecoveryRun_query_bound M oracle horacle B hB _ htree _ hxs B Subset.rfl
  change (coloopOracle oracle R B).2 ≤ _ at h
  apply h.trans
  simp only [length_sort]
  gcongr
  · simpa using balancedQueryTree_depth (B.sort (· ≤ ·))
  · exact Nat.sub_le _ _

end MatroidProphetSecretary
