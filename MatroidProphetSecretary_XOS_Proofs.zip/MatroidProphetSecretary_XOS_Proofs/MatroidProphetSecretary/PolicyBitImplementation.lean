import MatroidProphetSecretary.FiniteRandomPolicy

/-! Finite randomization of an online policy can be implemented with a bounded fair-bit tape. -/

noncomputable section

namespace MatroidProphetSecretary

variable {N k : ℕ} {Ω : Type*} [Fintype Ω]

theorem expected_fairBitPolicy (prior : RationalPriors N k) (policy : FiniteRandomPolicy N Ω)
    (μ : FiniteLaw Ω) (K : ℕ) :
    expectedPolicyReward prior (seededPolicy policy (FiniteLaw.fairBitSample μ K)) =
      (FiniteLaw.fairBitLaw μ K).expect (fun w => expectedPolicyReward prior (fixedPolicy policy w)) := by
  rw [expected_seededPolicy, FiniteLaw.fairBitLaw, FiniteLaw.map_expect]

theorem finite_random_policy_bit_implementation (M : Matroid (Fin N)) (prior : RationalPriors N k)
    (policy : FiniteRandomPolicy N Ω) (μ : FiniteLaw Ω)
    (hfeasible : ∀ w, PolicyFeasible M (fixedPolicy policy w))
    (loss : ℝ) (hloss : 0 < loss) :
    ∃ (K : ℕ) (implemented : OnlinePolicy N K), PolicyFeasible M implemented ∧
      μ.expect (fun w => expectedPolicyReward prior (fixedPolicy policy w)) - loss ≤
        expectedPolicyReward prior implemented := by
  let B := prior.rewardBudget
  have hB : 0 ≤ B := prior.rewardBudget_nonneg
  have hpos : 0 < B+1 := by linarith
  obtain ⟨K,hK⟩ := FiniteLaw.exists_fair_bit_approximation μ (loss/(B+1)) (div_pos hloss hpos)
  refine ⟨K,seededPolicy policy (FiniteLaw.fairBitSample μ K),
    seededPolicy_feasible M policy _ hfeasible,?_⟩
  rw [expected_fairBitPolicy]
  have hbound (w : Ω) : |expectedPolicyReward prior (fixedPolicy policy w)| ≤ B := by
    rw [abs_of_nonneg (expectedPolicyReward_bounds prior _).1]
    exact (expectedPolicyReward_bounds prior _).2
  have h := FiniteLaw.expect_difference_massDistance μ (FiniteLaw.fairBitLaw μ K)
    (fun w => expectedPolicyReward prior (fixedPolicy policy w)) B hbound
  have hb : B*(loss/(B+1)) ≤ loss := by
    rw [← mul_div_assoc]
    apply (div_le_iff₀ hpos).mpr
    nlinarith only [hloss]
  have he := h.trans ((mul_le_mul_of_nonneg_left hK.le hB).trans hb)
  have hs := (abs_le.mp he).2
  linarith

end MatroidProphetSecretary
