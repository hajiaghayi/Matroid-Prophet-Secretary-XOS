import MatroidProphetSecretary.XOSWelfare
import MatroidProphetSecretary.XOSParameters

/-! The universal online upper bound, including adaptive supporting witnesses. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open Finset
open scoped Classical

def chosen {n L : ℕ} [NeZero n] (hnL : n ≤ L) (rule : Rule n L)
    (x : Sample n L) (t : Fin n) : Clause n L := witness hnL (x t) (rule x t)

theorem chosen_causal {n L : ℕ} [NeZero n] (hnL : n ≤ L) (rule : Rule n L)
    (hc : Causal rule) (x y : Sample n L) (t : Fin n)
    (hxy : ∀ i, i ≤ t → x i = y i) : chosen hnL rule x t = chosen hnL rule y t := by
  simp only [chosen, hxy t le_rfl, hc x y t hxy]

theorem noninjective_iff_ordered_pair {n : ℕ} {A : Type*} (f : Fin n → A) :
    ¬ Function.Injective f ↔ ∃ p : Fin n × Fin n, p.1 < p.2 ∧ f p.1 = f p.2 := by
  constructor
  · intro h
    have hex : ∃ i j, f i = f j ∧ i ≠ j := by
      by_contra hnone
      apply h
      intro i j hij
      by_contra hne
      exact hnone ⟨i,j,hij,hne⟩
    obtain ⟨i,j,hij,hne⟩ := hex
    rcases lt_or_gt_of_ne hne with hlt | hgt
    · exact ⟨(i,j),hlt,hij⟩
    · exact ⟨(j,i),hgt,hij.symm⟩
  · rintro ⟨p,hp,heq⟩ hf
    exact (ne_of_lt hp) (hf heq)

theorem witness_collision_bound {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L)
    (rule : Rule n L) (hc : Causal rule) :
    (labelsLaw n L).prob (fun x => ¬Function.Injective (fun t => (chosen hnL rule x t).1)) ≤
      (n : ℝ)^3 / L := by
  let bad : (Fin n × Fin n) → Sample n L → Prop := fun p x =>
    p.1 < p.2 ∧ (chosen hnL rule x p.1).1 = (chosen hnL rule x p.2).1
  have hb (p : Fin n × Fin n) : (labelsLaw n L).prob (bad p) ≤ (n : ℝ) / L := by
    by_cases hp : p.1 < p.2
    · let W : Sample n L → Finset (Fin L) :=
        fun x => univ.image (chosen hnL rule x p.1).1
      have hhit := future_hit_probability p.2 W n
        (by intro x; simp [W,card_image_of_injective _ (chosen hnL rule x p.1).1.injective])
        (by
          intro x y hxy
          have heq := chosen_causal hnL rule hc x y p.1 (fun i hi =>
            hxy i (ne_of_lt (lt_of_le_of_lt hi hp)))
          simp only [W,heq])
      rw [← hhit]
      apply (labelsLaw n L).prob_mono
      intro x hx
      apply mem_image.mpr
      refine ⟨(chosen hnL rule x p.2).2,mem_univ _,?_⟩
      rw [hx.2]
      exact witness_label hnL (x p.2) (rule x p.2)
    · simp [bad,hp,FiniteLaw.prob]; positivity
  have hevent (x : Sample n L) :
      ¬Function.Injective (fun t => (chosen hnL rule x t).1) ↔ ∃ p, bad p x :=
    noninjective_iff_ordered_pair _
  rw [(labelsLaw n L).prob_congr hevent]
  refine (FiniteLaw.union_bound _ bad).trans ?_
  calc
    _ ≤ ∑ _p : Fin n × Fin n, (n : ℝ) / L := sum_le_sum (fun p _ => hb p)
    _ = (n : ℝ)^3 / L := by simp [Fintype.card_prod]; ring

/-- Disjoint credited bundles are covered by the union of their supporting clauses. -/
theorem welfare_le_partition_union {n L : ℕ} [NeZero n] (hnL : n ≤ L)
    (rule : Rule n L) (x : Sample n L) (hS : Feasible (rule x)) :
    welfare x (rule x) ≤
      (univ.biUnion (fun t => part n (chosen hnL rule x t).1 (chosen hnL rule x t).2)).card := by
  let C : Fin n → Finset (Goods n L) := fun t =>
    rule x t ∩ part n (chosen hnL rule x t).1 (chosen hnL rule x t).2
  have hC : Pairwise (fun i j => Disjoint (C i) (C j)) := by
    intro i j hij
    exact (hS hij).mono inter_subset_left inter_subset_left
  have hw : welfare x (rule x) = ∑ t, (C t).card := by
    apply sum_congr rfl
    intro t _
    exact witness_value hnL (x t) (rule x t)
  rw [hw,← card_biUnion (fun i _ j _ hij => hC hij)]
  apply card_le_card
  intro a ha
  obtain ⟨t,ht,hat⟩ := mem_biUnion.mp ha
  exact mem_biUnion.mpr ⟨t,ht,inter_subset_right hat⟩

theorem welfare_of_distinct_witnesses {n L : ℕ} [NeZero n] (hnL : n ≤ L)
    (rule : Rule n L) (x : Sample n L) (hS : Feasible (rule x))
    (hw : Function.Injective (fun t => (chosen hnL rule x t).1)) :
    (welfare x (rule x) : ℝ) ≤ (Fintype.card (Goods n L) : ℝ) * coverageRatio n := by
  have h := welfare_le_partition_union hnL rule x hS
  have hcount := partition_union_card (fun t => (chosen hnL rule x t).1) hw
    (fun t => (chosen hnL rule x t).2)
  have hc : (welfare x (rule x) : ℝ) ≤
      ((univ.biUnion (fun t => part n (chosen hnL rule x t).1 (chosen hnL rule x t).2)).card : ℝ) :=
    by exact_mod_cast h
  simpa [coverageRatio] using hc.trans_eq hcount

theorem expectedReward_upper {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L)
    (rule : Rule n L) (hr : Legal rule) :
    expectedReward rule ≤ (Fintype.card (Goods n L) : ℝ) *
      (coverageRatio n + (n : ℝ)^3 / L) := by
  let μ := labelsLaw n L
  let m : ℝ := Fintype.card (Goods n L)
  let bad := fun x => ¬Function.Injective (fun t => (chosen hnL rule x t).1)
  have hc : 0 ≤ m * coverageRatio n := mul_nonneg (by positivity) (coverageRatio_nonneg n)
  have h := μ.expect_mono (f := fun x => (welfare x (rule x) : ℝ))
    (g := fun x => m * coverageRatio n + m * (if bad x then 1 else 0)) (by
      intro x
      by_cases hx : bad x
      · have hb : (welfare x (rule x) : ℝ) ≤ m := by
          dsimp [m]
          exact_mod_cast welfare_le_goods x (rule x) (hr.2 x)
        simp only [hx,if_true,mul_one]
        linarith
      · have hx' : Function.Injective (fun t => (chosen hnL rule x t).1) := by simpa [bad] using hx
        simpa only [hx,if_false,mul_zero,add_zero,m] using
          welfare_of_distinct_witnesses hnL rule x (hr.2 x) hx')
  rw [μ.expect_add, μ.expect_const, μ.expect_const_mul] at h
  have hb := witness_collision_bound hnL rule hr.1
  have hh := mul_le_mul_of_nonneg_left hb (show 0 ≤ m by positivity)
  change m * μ.prob bad ≤ _ at hh
  change expectedReward rule ≤ m * coverageRatio n + m * μ.prob bad at h
  dsimp [m] at *
  nlinarith

end MatroidProphetSecretary.XOS
