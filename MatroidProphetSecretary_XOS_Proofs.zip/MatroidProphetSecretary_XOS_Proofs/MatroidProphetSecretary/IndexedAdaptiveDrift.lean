import MatroidProphetSecretary.SupportedKernelTransfer

/-! Finite-horizon potential arguments along supported adaptive paths. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {S W : Type*} [Fintype W]

theorem adaptive_terminal_support (batch : S → FiniteLaw W) (update : S → W → S)
    (Good : ℕ → S → Prop) (n offset : ℕ) (s : S) (hs : Good offset s)
    (hpreserve : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      ∀ x, (batch state).mass x ≠ 0 → Good (j+1) (update state x))
    (x : Fin n → W) (hx : (adaptiveBatches batch update n s).mass x ≠ 0) :
    Good (offset+n) (stateAfter update n s x) := by
  induction n generalizing offset s with
  | zero => simpa only [Nat.add_zero,stateAfter] using hs
  | succ n ih =>
    rw [adaptiveBatches_mass_succ] at hx
    have hparts := mul_ne_zero_iff.mp hx
    have hnext := hpreserve offset le_rfl (by omega) s hs (x 0) hparts.1
    have ht := ih (offset+1) (update s (x 0)) hnext
      (fun j hj hjn state hstate y hy => hpreserve j (by omega) (by omega) state hstate y hy)
      (fun i => x i.succ) hparts.2
    have he : offset+1+n = offset+(n+1) := by omega
    rw [he] at ht
    exact ht

theorem adaptive_gain_lower_on_interval (batch : S → FiniteLaw W) (update : S → W → S)
    (reward potential : S → ℝ) (Good : ℕ → S → Prop) (n offset : ℕ) (s : S) (hs : Good offset s)
    (a : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1)
    (hpreserve : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      ∀ x, (batch state).mass x ≠ 0 → Good (j+1) (update state x))
    (hsurvive : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      a*potential state ≤ (batch state).expect (fun x => potential (update state x)))
    (hgain : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      reward state+(1-a)*potential state ≤ (batch state).expect (fun x => reward (update state x))) :
    reward s+(1-a^n)*potential s ≤
      (adaptiveBatches batch update n s).expect (fun x => reward (stateAfter update n s x)) := by
  induction n generalizing offset s with
  | zero => simp [stateAfter]
  | succ n ih =>
    rw [adaptive_terminal_succ]
    have hc : 0 ≤ 1-a^n := sub_nonneg.mpr (pow_le_one₀ ha0 ha1)
    have hfuture : (batch s).expect (fun x => reward (update s x)+(1-a^n)*potential (update s x)) ≤
        (batch s).expect (fun x => (adaptiveBatches batch update n (update s x)).expect
          (fun y => reward (stateAfter update n (update s x) y))) := by
      apply expect_mono_support
      intro x hx
      apply ih (offset+1) (update s x) (hpreserve offset le_rfl (by omega) s hs x hx)
      · intro j hj hjn state hstate y hy
        exact hpreserve j (by omega) (by omega) state hstate y hy
      · intro j hj hjn state hstate
        exact hsurvive j (by omega) (by omega) state hstate
      · intro j hj hjn state hstate
        exact hgain j (by omega) (by omega) state hstate
    rw [expect_add,expect_const_mul] at hfuture
    have hp := mul_le_mul_of_nonneg_left (hsurvive offset le_rfl (by omega) s hs) hc
    have hr := hgain offset le_rfl (by omega) s hs
    rw [pow_succ]
    nlinarith only [hfuture,hp,hr]

theorem adaptive_reward_telescope (batch : S → FiniteLaw W) (update : S → W → S)
    (reward : S → W → ℝ) (total : S → ℝ)
    (hstep : ∀ s, (batch s).expect (fun x => total (update s x)) = total s+(batch s).expect (reward s))
    (n : ℕ) (s : S) :
    (adaptiveBatches batch update n s).expect (fun x => total (stateAfter update n s x)) =
      total s+(adaptiveBatches batch update n s).expect (trajectoryReward update reward n s) := by
  induction n generalizing s with
  | zero => simp [stateAfter,trajectoryReward]
  | succ n ih =>
    rw [adaptive_terminal_succ]
    simp only [ih,expect_add,hstep]
    simp only [adaptiveBatches,bind_expect,map_expect,trajectoryReward,Fin.cons_zero,Fin.cons_succ,
      expect_add,expect_const]
    ring

end MatroidProphetSecretary.FiniteLaw
