import MatroidProphetSecretary.UniformArrivalDecomposition

/-! Independent input values split into the revealed value and the untouched residual priors. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def valueReindexEquiv {I A : Type*} (σ : I ≃ I) : (I → A) ≃ (I → A) where
  toFun x := fun i => x (σ i)
  invFun x := fun i => x (σ.symm i)
  left_inv x := by funext i; simp
  right_inv x := by funext i; simp

theorem FiniteLaw.product_reindex_expect {I A : Type*} [Fintype I] [DecidableEq I] [Fintype A]
    (laws : I → FiniteLaw A) (σ : I ≃ I) (f : (I → A) → ℝ) :
    (product laws).expect f =
      (product (fun i => laws (σ i))).expect (fun x => f (fun i => x (σ.symm i))) := by
  have hm (x : I → A) : (product laws).mass (fun i => x (σ.symm i)) =
      (product (fun i => laws (σ i))).mass x := by
    have h := σ.prod_comp (fun i => (laws i).mass (x (σ.symm i)))
    simpa only [Equiv.symm_apply_apply] using h.symm
  unfold expect
  rw [← (valueReindexEquiv (A := A) σ).symm.sum_comp
    (fun x => (product laws).mass x*f x)]
  simp only [valueReindexEquiv,Equiv.coe_fn_symm_mk,hm]

theorem FiniteLaw.product_expect_fin_succ {A : Type*} [Fintype A] (n : ℕ)
    (laws : Fin (n+1) → FiniteLaw A) (f : (Fin (n+1) → A) → ℝ) :
    (product laws).expect f =
      (laws 0).expect (fun v => (product (fun i : Fin n => laws i.succ)).expect (fun x => f (Fin.cons v x))) := by
  unfold expect
  rw [← (Fin.consEquiv (fun _ : Fin (n+1) => A)).sum_comp
    (fun x => (product laws).mass x*f x)]
  simp only [Fintype.sum_prod_type,Fin.consEquiv,Equiv.coe_fn_mk,product,
    Fin.prod_univ_succ,Fin.cons_zero,Fin.cons_succ,mul_sum,mul_assoc]

def joinArrivalValues {n : ℕ} {A : Type*} (e : Fin (n+1)) (v : A) (rest : Fin n → A) : Fin (n+1) → A :=
  fun i => (Fin.cons v rest : Fin (n+1) → A) (Equiv.swap 0 e i)

theorem joinArrivalValues_current {n : ℕ} {A : Type*} (e : Fin (n+1)) (v : A) (rest : Fin n → A) :
    joinArrivalValues e v rest e = v := by simp [joinArrivalValues]

theorem joinArrivalValues_remaining {n : ℕ} {A : Type*} (e : Fin (n+1)) (v : A) (rest : Fin n → A) (i : Fin n) :
    joinArrivalValues e v rest (remainingLabel e i) = rest i := by
  simp [joinArrivalValues,remainingLabel]

theorem first_arrival_value_decomposition {n : ℕ} {A : Type*} [Fintype A]
    (laws : Fin (n+1) → FiniteLaw A) (e : Fin (n+1)) (f : (Fin (n+1) → A) → ℝ) :
    (FiniteLaw.product laws).expect f =
      (laws e).expect (fun v => (FiniteLaw.product (fun i : Fin n => laws (remainingLabel e i))).expect
        (fun rest => f (joinArrivalValues e v rest))) := by
  rw [FiniteLaw.product_reindex_expect laws (Equiv.swap 0 e),FiniteLaw.product_expect_fin_succ]
  simp only [Equiv.swap_apply_left,Equiv.symm_swap,remainingLabel,joinArrivalValues]
  rfl

end MatroidProphetSecretary
