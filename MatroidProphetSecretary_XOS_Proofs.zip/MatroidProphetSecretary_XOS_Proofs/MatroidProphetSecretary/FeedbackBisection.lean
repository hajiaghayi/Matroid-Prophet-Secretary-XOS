import MatroidProphetSecretary.BisectionCertificates

/-! An explicit adaptive midpoint search and its saved query records. -/

noncomputable section

namespace MatroidProphetSecretary

variable {B : Type*}

structure SearchRecord (B : Type*) where
  point : ℝ
  batch : B

def feedbackBracket (test : ℝ → B → Bool) (batches : ℕ → B) : ℕ → SearchBracket → SearchBracket
  | 0, b => b
  | n+1, b => let current := feedbackBracket test batches n b
      bisectBracket (test current.midpoint (batches n)) current

def feedbackAnswers (test : ℝ → B → Bool) (batches : ℕ → B) (b : SearchBracket) (n : ℕ) : Bool :=
  test (feedbackBracket test batches n b).midpoint (batches n)

theorem feedbackBracket_eq_run (test : ℝ → B → Bool) (batches : ℕ → B) (b : SearchBracket) (n : ℕ) :
    feedbackBracket test batches n b = bisectionRun (feedbackAnswers test batches b) n b := by
  induction n with
  | zero => rfl
  | succ n ih =>
    change bisectBracket (feedbackAnswers test batches b n) (feedbackBracket test batches n b) = _
    rw [ih]
    rfl

theorem feedbackAnswers_eq_test (test : ℝ → B → Bool) (batches : ℕ → B) (b : SearchBracket) (n : ℕ) :
    feedbackAnswers test batches b n =
      test (bisectionRun (feedbackAnswers test batches b) n b).midpoint (batches n) := by
  unfold feedbackAnswers
  rw [feedbackBracket_eq_run]
  rfl

def savedLowerRecord (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) : ℕ → SearchRecord B
  | 0 => initial
  | n+1 => if answers n then ⟨(bisectionRun answers n b).midpoint,batches n⟩
      else savedLowerRecord answers batches b initial n

def savedUpperRecord (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) : ℕ → SearchRecord B
  | 0 => initial
  | n+1 => if answers n then savedUpperRecord answers batches b initial n
      else ⟨(bisectionRun answers n b).midpoint,batches n⟩

theorem savedLowerRecord_point (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (hinit : initial.point = b.lower) (n : ℕ) :
    (savedLowerRecord answers batches b initial n).point = (bisectionRun answers n b).lower := by
  induction n with
  | zero => exact hinit
  | succ n ih => cases ha : answers n <;> simp [savedLowerRecord,bisectionRun,bisectBracket,ha,ih]

theorem savedUpperRecord_point (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (hinit : initial.point = b.upper) (n : ℕ) :
    (savedUpperRecord answers batches b initial n).point = (bisectionRun answers n b).upper := by
  induction n with
  | zero => exact hinit
  | succ n ih => cases ha : answers n <;> simp [savedUpperRecord,bisectionRun,bisectBracket,ha,ih]

theorem savedLowerRecord_property (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (P : SearchRecord B → Prop) (hinit : P initial) (n : ℕ)
    (hquery : ∀ i < n, answers i = true → P ⟨(bisectionRun answers i b).midpoint,batches i⟩) :
    P (savedLowerRecord answers batches b initial n) := by
  induction n with
  | zero => exact hinit
  | succ n ih =>
    cases ha : answers n
    · simp only [savedLowerRecord,ha,Bool.false_eq_true,if_false]
      exact ih (fun i hi => hquery i (Nat.lt_succ_of_lt hi))
    · simp only [savedLowerRecord,ha,if_true]
      exact hquery n (Nat.lt_succ_self n) ha

theorem savedUpperRecord_property (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (P : SearchRecord B → Prop) (hinit : P initial) (n : ℕ)
    (hquery : ∀ i < n, answers i = false → P ⟨(bisectionRun answers i b).midpoint,batches i⟩) :
    P (savedUpperRecord answers batches b initial n) := by
  induction n with
  | zero => exact hinit
  | succ n ih =>
    cases ha : answers n
    · simp only [savedUpperRecord,ha,Bool.false_eq_true,if_false]
      exact hquery n (Nat.lt_succ_self n) ha
    · simp only [savedUpperRecord,ha,if_true]
      exact ih (fun i hi => hquery i (Nat.lt_succ_of_lt hi))

theorem savedLowerRecord_provenance (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (n : ℕ) :
    savedLowerRecord answers batches b initial n = initial ∨
      ∃ i < n, answers i = true ∧ savedLowerRecord answers batches b initial n =
        ⟨(bisectionRun answers i b).midpoint,batches i⟩ := by
  apply savedLowerRecord_property answers batches b initial
    (fun r => r = initial ∨ ∃ i < n, answers i = true ∧ r =
      ⟨(bisectionRun answers i b).midpoint,batches i⟩) (Or.inl rfl) n
  intro i hi hai
  exact Or.inr ⟨i,hi,hai,rfl⟩

theorem savedUpperRecord_provenance (answers : ℕ → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (n : ℕ) :
    savedUpperRecord answers batches b initial n = initial ∨
      ∃ i < n, answers i = false ∧ savedUpperRecord answers batches b initial n =
        ⟨(bisectionRun answers i b).midpoint,batches i⟩ := by
  apply savedUpperRecord_property answers batches b initial
    (fun r => r = initial ∨ ∃ i < n, answers i = false ∧ r =
      ⟨(bisectionRun answers i b).midpoint,batches i⟩) (Or.inl rfl) n
  intro i hi hai
  exact Or.inr ⟨i,hi,hai,rfl⟩

end MatroidProphetSecretary
