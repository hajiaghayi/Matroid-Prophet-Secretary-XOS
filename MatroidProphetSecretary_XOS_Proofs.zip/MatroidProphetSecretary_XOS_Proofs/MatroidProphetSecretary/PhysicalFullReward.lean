import MatroidProphetSecretary.EulerFullReward
import MatroidProphetSecretary.RecordRewardBound

/-! The complete finite private-clock process satisfies the two-phase matroid reward bound, with explicit grid error. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem physical_euler_reward_error (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1) :
    |(FiniteLaw.product cfg.laws).expect (fun tapes => recordReward value (cfg.run tapes (L*N)))-
      (FiniteLaw.adaptiveBatches
        (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
        cfg.eulerBlockUpdate L (0,[])).expect
        (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x).2)| ≤
      2*(N:ℝ)^2*((1/cfg.q)/omega)^2*finiteValueBudget value/L := by
  have hphysical : (FiniteLaw.product cfg.laws).expect
      (fun tapes => boundedRecordReward value (cfg.run tapes (L*N))) =
      (FiniteLaw.product cfg.laws).expect (fun tapes => recordReward value (cfg.run tapes (L*N))) := by
    apply FiniteLaw.expect_congr_support
    intro tapes ht
    exact (cfg.run_valid M base hbase value hlive tapes (L*N) le_rfl).bounded_reward_eq M base hbase value hv _
  have hinit : cfg.blockReachable 0 (0,[]) := by
    constructor
    · simp
    · simpa only [cfg.initial_history_probability] using (zero_lt_one : (0:ℝ) < 1)
  have heuler : (FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
      cfg.eulerBlockUpdate L (0,[])).expect
      (fun x => boundedRecordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x).2) =
      (FiniteLaw.adaptiveBatches
        (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
        cfg.eulerBlockUpdate L (0,[])).expect
        (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x).2) := by
    apply FiniteLaw.expect_congr_support
    intro x hx
    let state := FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x
    have hs : cfg.blockReachable L state := by
      simpa only [Nat.zero_add] using cfg.euler_trajectory_reachable M base hbase value hlive
        hsmall omega homega homega1 hlower hbudget L 0 (by omega) (0,[]) hinit x hx
    have hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (L*N) = state.2) := by
      simpa only [hs.1] using hs.2
    exact (cfg.reachable_history_valid M base hbase value hlive state.2 (L*N) le_rfl hp).bounded_reward_eq
      M base hbase value hv _
  have h := cfg.physical_euler_discretization_error M base hbase value hlive hsmall omega homega homega1 hlower hbudget
    (finiteValueBudget value) (finiteValueBudget_nonneg value hv) (boundedRecordReward value) (boundedRecordReward_abs value hv)
  rwa [hphysical,heuler] at h

theorem physical_full_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1) (hcut : cfg.cut ≤ L) :
    let p := (1/(L:ℝ))*(1/cfg.q)
    let alpha := (1-p)^cfg.cut
    let beta := omega*(1-(1-(1/(L:ℝ))*((1/cfg.q)/omega))^(L-cfg.cut))
    (1-alpha)*virtualTotalLiveValue (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M)+
      beta*((1-p)*alpha*virtualTotalLiveValue (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M)+
        alpha*(1-alpha)*virtualCurrentOverlap (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M))-
      2*(N:ℝ)^2*((1/cfg.q)/omega)^2*finiteValueBudget value/L ≤
    (FiniteLaw.product cfg.laws).expect (fun tapes => recordReward value (cfg.run tapes (L*N))) := by
  have hreward := cfg.euler_full_reward M base hbase value hv hlive hsmall omega homega homega1 hlower hbudget hcut
  have herror := (abs_le.mp (cfg.physical_euler_reward_error M base hbase value hv hlive
    hsmall omega homega homega1 hlower hbudget)).1
  dsimp only at hreward ⊢
  linarith only [hreward,herror]

end MatroidProphetSecretary.PrivateGridConfig
