import MatroidProphetSecretary.FiniteTraceLaw

/-! Grouping consecutive finite transitions into blocks preserves the terminal-state law. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {S W : Type*} [Fintype W]

theorem stateAfter_stream (update : S → W → S) (n : ℕ) (s : S) (x : ℕ → W) :
    stateAfter update n s (fun i => x i.val) = scanState update s x n := by
  induction n generalizing s x with
  | zero => rfl
  | succ n ih =>
    change stateAfter update n (update s (x 0)) (fun i => x (i.val+1)) = _
    rw [ih (update s (x 0)) (fun j => x (j+1)),scanState_shift]

theorem timed_terminal_succ (kernel : ℕ → S → FiniteLaw W) (update : S → W → S)
    (n offset : ℕ) (s : S) (f : S → ℝ) :
    (timedBatches kernel update (n+1) offset s).expect (fun x => f (stateAfter update (n+1) s x)) =
      (kernel offset s).expect (fun y =>
        (timedBatches kernel update n (offset+1) (update s y)).expect
          (fun x => f (stateAfter update n (update s y) x))) := by
  simp only [timedBatches,bind_expect,map_expect,stateAfter,Fin.cons_zero,Fin.cons_succ]

theorem timed_terminal_add (kernel : ℕ → S → FiniteLaw W) (update : S → W → S)
    (n m offset : ℕ) (s : S) (f : S → ℝ) :
    (timedBatches kernel update (n+m) offset s).expect (fun x => f (stateAfter update (n+m) s x)) =
      (timedBatches kernel update n offset s).expect (fun x =>
        (timedBatches kernel update m (offset+n) (stateAfter update n s x)).expect
          (fun y => f (stateAfter update m (stateAfter update n s x) y))) := by
  induction n generalizing offset s with
  | zero =>
    rw [Nat.zero_add]
    simp [timedBatches,stateAfter]
  | succ n ih =>
    rw [show n+1+m = (n+m)+1 by omega,timed_terminal_succ]
    rw [timed_terminal_succ kernel update n offset s
      (fun state => (timedBatches kernel update m (offset+(n+1)) state).expect
        (fun y => f (stateAfter update m state y)))]
    congr 1
    funext event
    rw [ih]
    have ho : offset+1+n = offset+(n+1) := by omega
    rw [ho]

def blockBatch (kernel : ℕ → S → FiniteLaw W) (update : S → W → S) (width : ℕ)
    (state : ℕ × S) : FiniteLaw (Fin width → W) := timedBatches kernel update width state.1 state.2

def blockUpdate (update : S → W → S) (width : ℕ) (state : ℕ × S) (x : Fin width → W) : ℕ × S :=
  (state.1+width,stateAfter update width state.2 x)

theorem block_terminal_eq (kernel : ℕ → S → FiniteLaw W) (update : S → W → S) (width rounds offset : ℕ)
    (s : S) (f : S → ℝ) :
    (adaptiveBatches (blockBatch kernel update width) (blockUpdate update width) rounds (offset,s)).expect
      (fun x => f (stateAfter (blockUpdate update width) rounds (offset,s) x).2) =
    (timedBatches kernel update (rounds*width) offset s).expect
      (fun x => f (stateAfter update (rounds*width) s x)) := by
  induction rounds generalizing offset s with
  | zero =>
    rw [Nat.zero_mul]
    simp [stateAfter,timedBatches]
  | succ rounds ih =>
    rw [adaptive_terminal_succ (blockBatch kernel update width) (blockUpdate update width)
      (fun state : ℕ × S => f state.2) rounds (offset,s)]
    change (timedBatches kernel update width offset s).expect (fun x =>
      (adaptiveBatches (blockBatch kernel update width) (blockUpdate update width) rounds
        (offset+width,stateAfter update width s x)).expect
        (fun y => f (stateAfter (blockUpdate update width) rounds (offset+width,stateAfter update width s x) y).2)) = _
    simp_rw [ih]
    rw [show (rounds+1)*width = width+rounds*width by rw [Nat.add_mul,Nat.one_mul,Nat.add_comm],timed_terminal_add]

end MatroidProphetSecretary.FiniteLaw
