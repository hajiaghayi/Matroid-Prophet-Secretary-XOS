import Mathlib.Data.Matroid.Basic
import Mathlib.Data.Finset.Insert
import Mathlib.Data.Finset.SDiff
import Mathlib.Tactic.Push

/-!
The deterministic invariant used by the virtual process. This file proves
what an exchange map does. Existence is proved in `ExchangeConstruction`;
`ExchangeReplay` implements the deterministic accepted-history invariant.
-/

namespace MatroidProphetSecretary

variable {E : Type*} [DecidableEq E]

structure ExchangeMap (M : Matroid E) (C B : Finset E) where
  map : E → E
  image_mem : ∀ e ∈ C, map e ∈ B
  inj : ∀ e ∈ C, ∀ f ∈ C, map e = map f → e = f
  fixes : ∀ e ∈ C, e ∈ B → map e = e
  exchange : ∀ e ∈ C, M.IsBase ((insert e (B.erase (map e)) : Finset E) : Set E)

theorem exchange_preserves_accepted {M : Matroid E} {C B A : Finset E}
    (phi : ExchangeMap M C B) (hAC : A ⊆ C) (hAB : A ⊆ B)
    {e : E} (heC : e ∈ C) (heA : e ∉ A) :
    insert e A ⊆ insert e (B.erase (phi.map e)) := by
  intro f hf
  rcases Finset.mem_insert.mp hf with rfl | hfA
  · exact Finset.mem_insert_self _ _
  · apply Finset.mem_insert_of_mem
    apply Finset.mem_erase.mpr
    refine ⟨?_, hAB hfA⟩
    intro heq
    have hm : phi.map e = phi.map f := by
      rw [phi.fixes f (hAC hfA) (hAB hfA)]
      exact heq.symm
    have hef := phi.inj e heC f (hAC hfA) hm
    exact heA (hef ▸ hfA)

theorem exchange_acceptance_feasible {M : Matroid E} {C B A : Finset E}
    (phi : ExchangeMap M C B) (hAC : A ⊆ C) (hAB : A ⊆ B)
    {e : E} (heC : e ∈ C) (heA : e ∉ A) :
    M.Indep ((insert e A : Finset E) : Set E) := by
  apply (phi.exchange e heC).indep.subset
  intro f hf
  exact exchange_preserves_accepted phi hAC hAB heC heA hf

/-- Injectivity permits at most one source label to evict a fixed target. -/
theorem exchange_unique_killer {M : Matroid E} {C B : Finset E}
    (phi : ExchangeMap M C B) (target : E) :
    Set.Subsingleton {e | e ∈ C ∧ phi.map e = target} := by
  intro e he f hf
  exact phi.inj e he.1 f hf.1 (he.2.trans hf.2.symm)

end MatroidProphetSecretary
