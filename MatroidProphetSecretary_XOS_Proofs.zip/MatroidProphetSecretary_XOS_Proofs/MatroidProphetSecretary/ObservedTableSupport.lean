import MatroidProphetSecretary.ObservedValueTapes

/-! Every entry used from an observed-value random table lies in the original tape support. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

set_option synthInstance.maxSize 2048

namespace FiniteLaw

theorem conditionOrSelf_original_support {A : Type*} [Fintype A]
    (μ : FiniteLaw A) (P : A → Prop) [DecidablePred P] (a : A)
    (ha : (μ.conditionOrSelf P).mass a ≠ 0) : μ.mass a ≠ 0 := by
  intro hz
  apply ha
  unfold conditionOrSelf
  split_ifs with hp
  · simp [condition,hz]
  · exact hz

theorem observed_table_input_support {A O : Type*} [Fintype A] [Fintype O]
    (μ : FiniteLaw A) (observe : A → O) (table : O → A)
    (ht : (observedTableLaw μ observe).mass table ≠ 0) (o : O) : μ.mass (table o) ≠ 0 :=
  conditionOrSelf_original_support μ (fun a => observe a = o) (table o)
    (product_support (observedKernel μ observe) table ht o)

end FiniteLaw

namespace PrivateGridConfig

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

local instance (observed : Fin N → V → ℝ) (e : Fin N) : DecidableEq (ObservedValue observed e) :=
  fun a b => Classical.propDecidable (a = b)

theorem value_table_support (observed : Fin N → V → ℝ) (tables : ValueTapeTables N L observed)
    (ht : (cfg.valueTableLaw observed).mass tables ≠ 0) (sample : Fin N → V) :
    (FiniteLaw.product cfg.tapes).mass (fun e => tables e (observedValueAtom observed e (sample e))) ≠ 0 := by
  change (∏ e, (cfg.tapes e).mass (tables e (observedValueAtom observed e (sample e)))) ≠ 0
  apply Finset.prod_ne_zero_iff.mpr
  intro e he
  exact FiniteLaw.observed_table_input_support (cfg.tapes e) (observeGridTape observed e) (tables e)
    (FiniteLaw.product_support (fun i => FiniteLaw.observedTableLaw (cfg.tapes i) (observeGridTape observed i)) tables ht e) _

theorem value_table_clock_support (observed : Fin N → V → ℝ) (tables : ValueTapeTables N L observed)
    (ht : (cfg.valueTableLaw observed).mass tables ≠ 0) (sample : Fin N → V) (clocks : Fin N → Fin L) :
    (FiniteLaw.product cfg.laws).mass (fun e => (clocks e,tables e (observedValueAtom observed e (sample e)))) ≠ 0 := by
  change (∏ e, (cfg.laws e).mass (clocks e,tables e (observedValueAtom observed e (sample e)))) ≠ 0
  apply Finset.prod_ne_zero_iff.mpr
  intro e he
  apply mul_ne_zero
  · change (1 / (Fintype.card (Fin L) : ℝ)) ≠ 0
    simp only [Fintype.card_fin]
    exact one_div_ne_zero (Nat.cast_ne_zero.mpr cfg.clocks_pos.ne')
  · exact FiniteLaw.product_support cfg.tapes _ (cfg.value_table_support observed tables ht sample) e

end PrivateGridConfig
end MatroidProphetSecretary
