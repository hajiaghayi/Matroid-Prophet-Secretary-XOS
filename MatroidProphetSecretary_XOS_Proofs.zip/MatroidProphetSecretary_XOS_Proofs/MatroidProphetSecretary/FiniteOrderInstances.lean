import Mathlib.Order.Fin.Basic

/-! Normalize the equality instance inherited from a finite linear order. -/

namespace MatroidProphetSecretary

theorem fin_order_decidableEq (N : ℕ) :
    (fun a b : Fin N => LinearOrder.toDecidableEq a b) = instDecidableEqFin N :=
  Subsingleton.elim _ _

end MatroidProphetSecretary
