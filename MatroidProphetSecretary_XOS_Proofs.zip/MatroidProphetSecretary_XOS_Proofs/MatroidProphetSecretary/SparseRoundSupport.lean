import MatroidProphetSecretary.SparseRoundApproximation

/-! Every positive sparse trajectory is also a possible trajectory of the physical kernels. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {S W : Type*} [Fintype W]

theorem sparse_round_mass_domination (kernel : ℕ → S → FiniteLaw (Option W)) (update : S → Option W → S)
    (hnone : ∀ s, update s none = s) (h : ℝ) (h0 : 0 ≤ h)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) (x : Fin n → Option W) :
    (1-(n:ℝ)*h)*(sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass x ≤
      (timedBatches kernel update n offset s).mass x := by
  by_cases hx : x = fun _ => none
  · subst x
    have hfactor : 0 ≤ 1-(n:ℝ)*h := sub_nonneg.mpr hbudget
    exact (mul_le_of_le_one_right hfactor (mass_le_one _ _)).trans
      (timed_none_mass_lower kernel update hnone h h0 hsmall n offset s hbudget)
  · by_cases hr : x ∈ Set.range (sparseTrace (W := W) (n := n))
    · obtain ⟨event,rfl⟩ := hr
      cases event with
      | none => exact False.elim (hx rfl)
      | some iw =>
        change (1-(n:ℝ)*h)*(sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass (oneMarkTrace iw.1 iw.2) ≤ _
        rw [sparseRound_mass_one]
        exact timed_one_mark_mass_lower kernel update hnone h h0 hsmall n offset s hbudget iw.1 iw.2
    · have hz := map_mass_eq_zero_of_not_range (sparseRoundLaw kernel h hsmall n offset s hbudget) sparseTrace x hr
      change (sparseRoundTraceLaw kernel h hsmall n offset s hbudget).mass x = 0 at hz
      rw [hz,mul_zero]
      exact (timedBatches kernel update n offset s).nonneg x

theorem sparse_round_support (kernel : ℕ → S → FiniteLaw (Option W)) (update : S → Option W → S)
    (hnone : ∀ s, update s none = s) (h : ℝ) (h0 : 0 ≤ h)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h < 1) (x : Fin n → Option W)
    (hx : (sparseRoundTraceLaw kernel h hsmall n offset s hbudget.le).mass x ≠ 0) :
    (timedBatches kernel update n offset s).mass x ≠ 0 := by
  have hp : 0 < (sparseRoundTraceLaw kernel h hsmall n offset s hbudget.le).mass x :=
    lt_of_le_of_ne ((sparseRoundTraceLaw kernel h hsmall n offset s hbudget.le).nonneg x) (Ne.symm hx)
  exact (lt_of_lt_of_le (mul_pos (sub_pos.mpr hbudget) hp)
    (sparse_round_mass_domination kernel update hnone h h0 hsmall n offset s hbudget.le x)).ne'

theorem adaptive_support_transfer (batch other : S → FiniteLaw W) (update : S → W → S)
    (hstep : ∀ s x, (other s).mass x ≠ 0 → (batch s).mass x ≠ 0)
    (n : ℕ) (s : S) (x : Fin n → W) (hx : (adaptiveBatches other update n s).mass x ≠ 0) :
    (adaptiveBatches batch update n s).mass x ≠ 0 := by
  rw [adaptiveBatches_mass_product]
  apply prod_ne_zero_iff.mpr
  intro i hi
  exact hstep _ _ (adaptiveBatches_support_steps other update n s x hx i)

end MatroidProphetSecretary.FiniteLaw
