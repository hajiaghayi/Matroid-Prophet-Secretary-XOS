import MatroidProphetSecretary.TwoStageLaws
import MatroidProphetSecretary.ScreenedCandidate

/-! Counterfactual private decisions share the actual own value and have fresh auxiliary randomness. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

namespace FiniteLaw

variable {V I D P : Type*} [Fintype V] [Fintype I] [DecidableEq I] [Fintype D] [Fintype P]

def sharedValueTapes (prior : FiniteLaw V) (slots : V → I → FiniteLaw D) : FiniteLaw (V × (I → D)) :=
  dependentPair prior (fun v => product (slots v))

theorem sharedValueTapes_slot_expect (prior : FiniteLaw V) (slots : V → I → FiniteLaw D)
    (i : I) (f : V → D → ℝ) :
    (sharedValueTapes prior slots).expect (fun x => f x.1 (x.2 i)) =
      prior.expect (fun v => (slots v i).expect (f v)) := by
  rw [sharedValueTapes,dependentPair_expect prior (fun v => product (slots v))
    (fun v x => f v (x i))]
  congr 1
  funext v
  exact product_expect_single_coordinate (slots v) i (f v)

theorem sharedValueTapes_slot_law (prior : FiniteLaw V) (slots : V → I → FiniteLaw D) (i : I) :
    (sharedValueTapes prior slots).map (fun x => x.2 i) = prior.bind (fun v => slots v i) := by
  apply ext_expect
  intro f
  rw [map_expect,bind_expect]
  exact sharedValueTapes_slot_expect prior slots i (fun _ => f)

theorem pair_bind_right (prior : FiniteLaw V) (probe : FiniteLaw P) (candidate : V → FiniteLaw D) :
    prior.bind (fun v => probe.pair (candidate v)) = probe.pair (prior.bind candidate) := by
  apply ext_expect
  intro f
  simp only [bind_expect,pair_expect]
  exact expect_comm prior probe (fun v p => (candidate v).expect (fun d => f (p,d)))

end FiniteLaw

variable {V E : Type*} [Fintype V] [Fintype E] [DecidableEq E]

def conditionalScreenedCandidate (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (v : V) : FiniteLaw (Option (E → Option V)) :=
  (bernoulliLaw (atomScreenProbability prior (references e) q v)
    (atomScreenProbability_bounds prior (references e) q hq hdom v).1
    (atomScreenProbability_bounds prior (references e) q hq hdom v).2).bind
    (fun b => (FiniteLaw.product references).map
      (fun world => if b = true then some (Function.update world e (some v)) else none))

theorem conditionalScreenedCandidate_mixture (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v) :
    prior.bind (conditionalScreenedCandidate prior references e q hq hdom) =
      screenedCandidateLaw prior references e q hq hdom := by
  apply FiniteLaw.ext_expect
  intro f
  simp only [FiniteLaw.bind_expect,conditionalScreenedCandidate,FiniteLaw.bind_expect,FiniteLaw.map_expect,
    screenedCandidateLaw,FiniteLaw.bind_expect,screenedAtomLaw,FiniteLaw.bind_expect,FiniteLaw.map_expect]
  congr 1
  funext v
  congr 1
  funext b
  cases b <;> simp [FiniteLaw.pointMass_expect,FiniteLaw.map_expect]

end MatroidProphetSecretary
