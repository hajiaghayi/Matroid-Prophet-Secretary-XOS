import MatroidProphetSecretary.SurplusDecomposition
import MatroidProphetSecretary.FiniteIntegrals

/-! Expected reward plus child potential of one actual uniform-label threshold arrival. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Nonempty E] [Fintype Ω]

theorem meanThreshold_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (value : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) : 0 ≤ meanThreshold μ M value hnonloop e :=
  μ.expect_nonneg (fun w => exclusionThreshold_nonneg M (value w) e (hnonloop e))

theorem meanThreshold_expected_difference (μ : FiniteLaw Ω) (M : Matroid E) (value : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) :
    meanThreshold μ M value hnonloop e = μ.expect (fun y => deletionValue M (value y) e)-
      μ.expect (fun y => contractionValue M (value y) e (hnonloop e)) :=
  μ.expect_sub _ _

theorem sum_expected_deletion (μ : FiniteLaw Ω) (M : Matroid E) (value : Ω → E → ℝ) :
    (∑ e, μ.expect (fun y => deletionValue M (value y) e)) =
      (Fintype.card E:ℝ)*expectedOptimum μ M value-deletionSurplus μ M value := by
  unfold deletionSurplus
  simp_rw [FiniteLaw.expect_sub]
  rw [sum_sub_distrib]
  simp only [sum_const,card_univ,nsmul_eq_mul,expectedOptimum]
  ring

theorem FiniteLaw.uniform_expect_sum (f : E → ℝ) :
    (FiniteLaw.uniform E).expect f = (∑ e, f e)/(Fintype.card E:ℝ) := by
  simp only [FiniteLaw.expect,FiniteLaw.uniform,one_div]
  rw [← mul_sum,mul_comm]
  rfl

def thresholdEpochValue (μ : FiniteLaw Ω) (M : Matroid E) (value : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (a : ℝ) (p : E → ℝ) (e : E) (v : ℝ) : ℝ :=
  if p e < v then v+a*μ.expect (fun y => contractionValue M (value y) e (hnonloop e))
  else a*μ.expect (fun y => deletionValue M (value y) e)

theorem threshold_epoch_expected_progress {V : E → Type*} [∀ e, Fintype (V e)]
    (prior : ∀ e, FiniteLaw (V e)) (observed : ∀ e, V e → ℝ)
    (μ : FiniteLaw Ω) (M : Matroid E) (value : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (a : ℝ) (p : E → ℝ)
    (hprice : ∀ e, a*meanThreshold μ M value hnonloop e ≤ p e) :
    a*expectedOptimum μ M value+
        ((∑ e, (prior e).expect (fun v => posPart (observed e v-p e)))-a*deletionSurplus μ M value)/(Fintype.card E:ℝ) ≤
      (FiniteLaw.uniform E).expect (fun e => (prior e).expect (fun v => thresholdEpochValue μ M value hnonloop a p e (observed e v))) := by
  have hp (e : E) := hprice e
  simp_rw [meanThreshold_expected_difference] at hp
  have hpoint (e : E) := (prior e).expect_mono (fun v => threshold_decision_progress (observed e v) (p e) a
    (μ.expect (fun y => deletionValue M (value y) e))
    (μ.expect (fun y => contractionValue M (value y) e (hnonloop e))) (hp e))
  simp only [FiniteLaw.expect_add,FiniteLaw.expect_const] at hpoint
  have h := (FiniteLaw.uniform E).expect_mono hpoint
  rw [FiniteLaw.uniform_expect_sum] at h
  rw [sum_add_distrib,← mul_sum,sum_expected_deletion] at h
  have hn : (Fintype.card E:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have he : (a*((Fintype.card E:ℝ)*expectedOptimum μ M value-deletionSurplus μ M value)+
      ∑ e, (prior e).expect (fun v => posPart (observed e v-p e)))/(Fintype.card E:ℝ) =
      a*expectedOptimum μ M value+
        ((∑ e, (prior e).expect (fun v => posPart (observed e v-p e)))-a*deletionSurplus μ M value)/(Fintype.card E:ℝ) := by
    field_simp
    <;> ring
  rw [he] at h
  exact h

end MatroidProphetSecretary
