import MatroidProphetSecretary.LooplessReferenceStep
import MatroidProphetSecretary.SkipLabelPolicy
import MatroidProphetSecretary.ParameterCertificate

/-! The finite-prior competitiveness theorem, with an actual history-only feasible policy. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem reference_policy_exists (N : ℕ) : ReferencePolicyClaim N := by
  induction N with
  | zero =>
    intro k M prior q hq
    exact zero_benchmark_reference_policy prior M (expectedProphet_empty M prior) q (q_pos hq).le
  | succ n ih =>
    intro k M prior q hq
    by_cases hn : ∀ e, M.Indep ({e} : Set (Fin (n+1)))
    · by_cases hz : expectedProphet M prior = 0
      · exact zero_benchmark_reference_policy prior M hz q (q_pos hq).le
      · have hF : 0 < expectedProphet M prior := lt_of_le_of_ne
          (FiniteLaw.expect_nonneg _ (fun x => optimum_nonneg M _)) (Ne.symm hz)
        exact loopless_reference_policy_step ih M prior hn hF q hq
    · obtain ⟨e,he⟩ := not_forall.mp hn
      obtain ⟨child,hfeasible,hreward⟩ := ih k (remainingDelete M e) (prior.remaining e) q hq
      refine ⟨skipLabelPolicy e child,skipLabelPolicy_feasible M e child hfeasible,?_⟩
      rw [expected_skipLabelPolicy]
      rw [reference_remaining_delete_loop prior M e he] at hreward
      exact hreward

theorem finite_matroid_prophet_secretary_competitive : FiniteCompetitivenessClaim := by
  intro N k hk M prior
  obtain ⟨policy,hfeasible,hreward⟩ := reference_policy_exists N k M prior 1 (by norm_num [interval,delta])
  have hone := referenceExpectedOptimum_one_general prior.law M (fun e v => (prior.value e v : ℝ))
    (fun e v => by change (0:ℝ) ≤ (prior.value e v:ℝ); exact_mod_cast prior.value_nonneg e v)
  change referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) 1 = expectedProphet M prior at hone
  rw [hone] at hreward
  have hratio : targetRatio ≤ discount 1 := by
    have h := parameter_choice.2.2.2
    have hb : beta ≤ discount 1 := by norm_num [beta,discount,rho]
    exact h.le.trans hb
  exact ⟨0,policy,hfeasible,
    (mul_le_mul_of_nonneg_right hratio (FiniteLaw.expect_nonneg _ (fun x => optimum_nonneg M _))).trans hreward⟩

end MatroidProphetSecretary
