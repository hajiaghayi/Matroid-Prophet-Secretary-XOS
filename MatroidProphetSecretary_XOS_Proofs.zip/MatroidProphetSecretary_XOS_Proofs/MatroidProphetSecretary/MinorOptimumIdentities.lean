import MatroidProphetSecretary.FiniteOptimum
import MatroidProphetSecretary.ReferenceInstance
import Mathlib.Data.Matroid.Minor.Contract

/-! The child potentials in the threshold calculation are the optima of actual matroid minors. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem optimumOver_congr (P Q : Finset E → Prop) (hP : P ∅) (hQ : Q ∅)
    (h : ∀ I, P I ↔ Q I) (v : E → ℝ) : optimumOver P hP v = optimumOver Q hQ v := by
  have hPQ : P = Q := funext (fun I => propext (h I))
  subst Q
  rfl

theorem optimum_delete_singleton (M : Matroid E) (v : E → ℝ) (e : E) :
    optimum (M ＼ {e}) v = deletionValue M v e := by
  apply optimumOver_congr
  intro I
  simp only [Matroid.delete_indep_iff,Set.disjoint_singleton_right,Finset.mem_coe,and_comm]

theorem optimum_contract_singleton (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) :
    optimum (M ／ {e}) v = contractionValue M v e he := by
  apply optimumOver_congr
  intro I
  rw [he.contract_indep_iff]
  simp only [Set.disjoint_singleton_right,Finset.mem_coe,Set.union_singleton,Finset.coe_insert]

theorem referenceExpectedOptimum_delete_singleton {V : E → Type*} [∀ e, Fintype (V e)]
    (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E) (value : ∀ e, V e → ℝ) (q : ℝ) (e : E) :
    referenceExpectedOptimum laws (M ＼ {e}) value q =
      (FiniteLaw.product (referenceInstanceLaws laws value q)).expect
        (fun y => deletionValue M (coordinateValues (referenceInstanceValues value) y) e) := by
  unfold referenceExpectedOptimum expectedOptimum
  simp only [optimum_delete_singleton]

theorem referenceExpectedOptimum_contract_singleton {V : E → Type*} [∀ e, Fintype (V e)]
    (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E) (value : ∀ e, V e → ℝ) (q : ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) :
    referenceExpectedOptimum laws (M ／ {e}) value q =
      (FiniteLaw.product (referenceInstanceLaws laws value q)).expect
        (fun y => contractionValue M (coordinateValues (referenceInstanceValues value) y) e he) := by
  unfold referenceExpectedOptimum expectedOptimum
  simp only [optimum_contract_singleton M _ e he]

end MatroidProphetSecretary
