import MatroidProphetSecretary.GridPrivateProbes

/-! Exact early acceptance intensity of the concrete one-arrival private-tape construction. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V]

theorem early_private_accept_probability (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none) (c : Fin L) :
    (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1).prob
      (fun tape => earlyPrivateDecision live c tape ≠ none) =
      (1/q)*gridSurvival (gridLiveDose (FiniteLaw.product references) p live) c.val*
        (FiniteLaw.product references).prob (live c.val) := by
  have h := early_private_mark_kernel prior references e q hq hdom L p hp0 hp1 live hpositive c (fun _ => True)
  have heq := FiniteLaw.prob_congr (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1)
    (A := fun tape => earlyPrivateDecision live c tape ≠ none)
    (B := fun tape => ∃ y, earlyPrivateDecision live c tape = some y ∧ True)
    (fun tape => by cases hd : earlyPrivateDecision live c tape <;> simp [hd])
  rw [heq]
  simpa only [FiniteLaw.prob,and_true] using h

theorem early_private_grid_mass (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (hL : 0 < L) (hp1 : (1/(L:ℝ))*(1/q) ≤ 1)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none) (c : Fin L) :
    (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1).prob
      (fun tape => earlyPrivateDecision live c tape ≠ none) =
      (L:ℝ)*gridSurvival (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) c.val*
        gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live c.val := by
  rw [early_private_accept_probability prior references e q hq hdom L _ _ hp1 live hpositive c]
  unfold gridLiveDose
  have hL' : (L:ℝ) ≠ 0 := by exact_mod_cast hL.ne'
  field_simp
  <;> ring

theorem early_private_survival (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (hL : 0 < L) (hp1 : (1/(L:ℝ))*(1/q) ≤ 1)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none)
    (n : ℕ) (hn : n ≤ L) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    ((FiniteLaw.uniform (Fin L)).pair
      (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1)).prob
      (FiniteLaw.oneArrivalAbsent (fun t => t.val < n) (earlyPrivateDecision live)) =
      gridSurvival (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) n := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  apply oneArrival_grid_survival L hL _ _ _ n hn
  intro i hi
  convert early_private_grid_mass prior references e q hq hdom L hL hp1 live hpositive i using 1
  unfold FiniteLaw.prob
  congr 1
  funext x
  split_ifs <;> rfl

theorem early_private_conditional_intensity (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (hL : 0 < L) (hp1 : (1/(L:ℝ))*(1/q) < 1)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none)
    (t : Fin L) (B : (E → Option V) → Prop) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    (((FiniteLaw.uniform (Fin L)).pair
      (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1.le)).conditionOrSelf
      (FiniteLaw.oneArrivalAbsent (fun u => u.val < t.val) (earlyPrivateDecision live))).prob
      (fun x => x.1 = t ∧ ∃ y, earlyPrivateDecision live t x.2 = some y ∧ B y) =
      (1/(L:ℝ))*(1/q)*(FiniteLaw.product references).prob (fun y => live t.val y ∧ B y) := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  apply oneArrival_grid_intensity L hL _ (earlyPrivateDecision live)
    (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live)
    (fun i => (gridLiveDose_bounds _ _ (by positivity) hp1 live i).2) t B (1/q)
  · intro i hi
    convert early_private_grid_mass prior references e q hq hdom L hL hp1.le live hpositive i using 1
    unfold FiniteLaw.prob
    congr 1
    funext x
    split_ifs <;> rfl
  · exact early_private_mark_kernel prior references e q hq hdom L _ _ hp1.le live hpositive t B

end MatroidProphetSecretary
