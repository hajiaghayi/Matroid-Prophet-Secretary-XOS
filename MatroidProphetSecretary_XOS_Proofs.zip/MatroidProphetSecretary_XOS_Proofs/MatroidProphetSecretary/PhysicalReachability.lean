import MatroidProphetSecretary.PhysicalQuietReachability
import MatroidProphetSecretary.SparseRoundSupport

/-! Positive physical and sparse transition traces preserve reachability of their accepted histories. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem marked_step_reachable (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (mark : Option (GridMark N L V)) (hmark : (cfg.historyKernel n history).mass mark ≠ 0) :
    0 < (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes (n+1) = updateGridHistory history mark) := by
  have hm : (cfg.historyKernel n history).mass mark =
      ((FiniteLaw.product cfg.laws).conditionOrSelf (fun tapes => cfg.run tapes n = history)).prob
        (fun tapes => cfg.trace tapes n = mark) := by
    rw [historyKernel,dif_pos hp,FiniteLaw.map_mass_probability]
    apply FiniteLaw.prob_irrel
  have hpos : 0 < (cfg.historyKernel n history).mass mark :=
    lt_of_le_of_ne ((cfg.historyKernel n history).nonneg mark) (Ne.symm hmark)
  have hj : 0 < (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes n = history ∧ cfg.trace tapes n = mark) := by
    rw [FiniteLaw.condition_joint_probability,← hm]
    exact mul_pos hp hpos
  apply hj.trans_le
  apply FiniteLaw.prob_mono
  intro tapes ht
  have hs := cfg.trace_update tapes n hn
  rw [ht.1,ht.2] at hs
  exact hs.symm

theorem timed_trace_reachable (width offset : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V))
    (horizon : offset+width ≤ L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes offset = history))
    (x : Fin width → Option (GridMark N L V))
    (hx : (FiniteLaw.timedBatches cfg.finiteHistoryKernel updateGridHistory width offset history).mass x ≠ 0) :
    0 < (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes (offset+width) = FiniteLaw.stateAfter updateGridHistory width history x) := by
  induction width generalizing offset history with
  | zero => simpa only [Nat.add_zero,FiniteLaw.stateAfter] using hp
  | succ width ih =>
    rw [FiniteLaw.timedBatches_mass_succ] at hx
    have hparts := mul_ne_zero_iff.mp hx
    have hn : offset < L*N := by omega
    have hmark : (cfg.historyKernel offset history).mass (x 0) ≠ 0 := by
      simpa only [finiteHistoryKernel,if_pos hn] using hparts.1
    have hnext := cfg.marked_step_reachable history offset hn hp (x 0) hmark
    have htail := ih (offset+1) (updateGridHistory history (x 0)) (by omega) hnext
      (fun i => x i.succ) hparts.2
    have he : offset+1+width = offset+(width+1) := by omega
    rw [he] at htail
    exact htail

theorem sparse_round_reachable
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (offset : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V)) (horizon : offset+N ≤ L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes offset = history))
    (x : Fin N → Option (GridMark N L V))
    (hx : (cfg.sparsePhysicalRound hsmall omega homega homega1 hlower offset history hbudget.le).mass x ≠ 0) :
    0 < (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes (offset+N) = FiniteLaw.stateAfter updateGridHistory N history x) := by
  apply cfg.timed_trace_reachable N offset history horizon hp x
  apply FiniteLaw.sparse_round_support cfg.finiteHistoryKernel updateGridHistory (fun _ => rfl)
    ((1/(L:ℝ))*((1/cfg.q)/omega))
    (mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le))
    (cfg.finiteHistoryKernel_acceptance_bound hsmall omega homega homega1 hlower) N offset history hbudget x hx

theorem initial_history_probability :
    (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes 0 = []) = 1 := by
  simp [run,stampedRun,privateStepRun,FiniteLaw.prob]

end MatroidProphetSecretary.PrivateGridConfig
