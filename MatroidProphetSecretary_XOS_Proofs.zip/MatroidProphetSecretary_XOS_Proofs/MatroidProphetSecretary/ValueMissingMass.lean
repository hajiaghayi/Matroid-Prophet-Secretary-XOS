import MatroidProphetSecretary.ValueActivity

/-! The missing-mass marginal of an actual independent value layer. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

theorem bitSet_valueActivity (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (x : ∀ e, V e) :
    bitSet (valueActivity value z x) = valueLayer M (coordinateValues value x) z := by
  ext e
  simp [bitSet, valueActivity, valueLayer, coordinateValues, hground e]

theorem value_missing_mass (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) :
    bernoulliEval (coordinateTail laws value z) (insertDifference e (rankObservable M)) =
      (FiniteLaw.product laws).expect (fun x =>
        if e ∈ M.closure (valueLayer M (coordinateValues value x) z) then 0 else 1) := by
  rw [bernoulliEval_eq_expect (coordinateTail laws value z) (fun e => (laws e).prob_nonneg _)
    (fun e => (laws e).prob_le_one _), ← activityLaws_eq_bernoulli]
  unfold activityLaws
  rw [FiniteLaw.product_map_expect]
  congr 1
  funext x
  change insertDifference e (rankObservable M) (valueActivity value z x) = _
  rw [rank_insertDifference M hground, bitSet_valueActivity M hground]

theorem value_missing_mass_factor (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) :
    (FiniteLaw.product laws).expect (fun x =>
        if e ∈ M.closure (valueLayer M (coordinateValues value x) z) then 0 else 1) =
      (1 - coordinateTail laws value z e) * otherNonspanProbability laws M value e z := by
  rw [← value_missing_mass laws M hground value z e,
    bernoulli_rank_marginal M hground (coordinateTail laws value z) (fun e => (laws e).prob_nonneg _)
      (fun e => (laws e).prob_le_one _), ← activityLaws_eq_bernoulli, activity_nonspan]

theorem expected_one_sub_closure (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (z : ℝ) (hz : 0 < z) (e : E) :
    (FiniteLaw.product laws).expect (fun x => 1 - closureLayer M (coordinateValues value x) e z) =
      (1 - coordinateTail laws value z e) * otherNonspanProbability laws M value e z := by
  rw [← value_missing_mass_factor laws M hground value z e]
  congr 1
  funext x
  unfold closureLayer
  split_ifs <;> simp_all

end MatroidProphetSecretary
