import MatroidProphetSecretary.AdaptiveExpectation
import MatroidProphetSecretary.BlockResampling

/-! Conditional persistence accumulates a quantitative overlap gain along finite adaptive paths. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {E Ω S : Type*} [Fintype E] [Fintype Ω]

def accumulatedCrossMoment (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (w k : S → E → ℝ) (n : ℕ) (s : S) : ℝ :=
  (adaptiveBatches batch update n s).expect (fun x => ∑ e,
    w (stateAfter update n s x) e * trajectoryReward update (fun state _ => k state e) n s x)

theorem accumulatedCrossMoment_succ (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (w k : S → E → ℝ) (n : ℕ) (s : S) :
    accumulatedCrossMoment batch update w k (n+1) s =
      (∑ e, k s e * (adaptiveBatches batch update (n+1) s).expect
        (fun x => w (stateAfter update (n+1) s x) e)) +
      (batch s).expect (fun x => accumulatedCrossMoment batch update w k n (update s x)) := by
  simp only [accumulatedCrossMoment,adaptiveBatches,bind_expect,map_expect,stateAfter,trajectoryReward,
    Fin.cons_zero,Fin.cons_succ,mul_add,sum_add_distrib,expect_add,expect_finset_sum,
    expect_mul_const,expect_const_mul,mul_comm]

theorem adaptive_overlap_accumulation (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (w k : S → E → ℝ) (Q : S → ℝ) (a : ℝ) (ha0 : 0 ≤ a) (ha1 : a ≤ 1)
    (hk : ∀ s e, 0 ≤ k s e)
    (hwstep : ∀ s e, a*w s e ≤ (batch s).expect (fun x => w (update s x) e))
    (hQstep : ∀ s, a^2*Q s ≤ (batch s).expect (fun x => Q (update s x)))
    (hpoint : ∀ s, Q s ≤ ∑ e, w s e*k s e) (n : ℕ) (s : S) :
    a^n*(1-a^n)*Q s ≤ (1-a)*accumulatedCrossMoment batch update w k n s := by
  induction n generalizing s with
  | zero => simp [accumulatedCrossMoment,trajectoryReward]
  | succ n ih =>
    rw [accumulatedCrossMoment_succ]
    have hfirst : a^(n+1)*Q s ≤ ∑ e, k s e *
        (adaptiveBatches batch update (n+1) s).expect (fun x => w (stateAfter update (n+1) s x) e) := by
      calc
        _ ≤ a^(n+1)*(∑ e, w s e*k s e) := mul_le_mul_of_nonneg_left (hpoint s) (pow_nonneg ha0 _)
        _ = ∑ e, k s e*(a^(n+1)*w s e) := by rw [mul_sum]; apply sum_congr rfl; intro e he; ring
        _ ≤ _ := sum_le_sum (fun e _ => mul_le_mul_of_nonneg_left
          (adaptive_terminal_lower batch update (fun state => w state e) a ha0
            (fun state => hwstep state e) (n+1) s) (hk s e))
    have hfirst' := mul_le_mul_of_nonneg_left hfirst (sub_nonneg.mpr ha1)
    have hchild := (batch s).expect_mono (fun x => ih (update s x))
    simp only [expect_const_mul] at hchild
    have hc : 0 ≤ a^n*(1-a^n) := mul_nonneg (pow_nonneg ha0 _) (sub_nonneg.mpr (pow_le_one₀ ha0 ha1))
    have hQ := mul_le_mul_of_nonneg_left (hQstep s) hc
    have hlast := hQ.trans hchild
    calc
      a^(n+1)*(1-a^(n+1))*Q s =
          (1-a)*(a^(n+1)*Q s) + (a^n*(1-a^n))*(a^2*Q s) := by rw [pow_succ]; ring
      _ ≤ (1-a)*(∑ e, k s e*(adaptiveBatches batch update (n+1) s).expect
          (fun x => w (stateAfter update (n+1) s x) e)) +
          (1-a)*(batch s).expect (fun x => accumulatedCrossMoment batch update w k n (update s x)) :=
        add_le_add hfirst' hlast
      _ = _ := by ring

end MatroidProphetSecretary.FiniteLaw
