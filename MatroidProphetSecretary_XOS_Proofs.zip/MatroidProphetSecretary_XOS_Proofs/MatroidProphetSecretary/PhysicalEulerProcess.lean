import MatroidProphetSecretary.PhysicalSparseHistoryLaw
import MatroidProphetSecretary.PhysicalReachability
import MatroidProphetSecretary.PhysicalDiscretization
import MatroidProphetSecretary.SupportedKernelTransfer

/-! The entire sparse physical process is the history-valued exchange process. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def eulerBlockUpdate (state : BlockState N V) (event : Option (Fin N × (Fin N → Option V))) : BlockState N V :=
  (state.1+N,eulerHistoryUpdate (gridClock N L cfg.clocks_pos state.1) state.2 event)

def eulerBlockBatch (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (state : BlockState N V) :
    FiniteLaw (Option (Fin N × (Fin N → Option V))) :=
  cfg.eulerStep M base hbase value hsmall omega homega homega1 hlower hbudget
    state.2 (gridClock N L cfg.clocks_pos state.1)

def blockReachable (j : ℕ) (state : BlockState N V) : Prop :=
  state.1 = j*N ∧ 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes state.1 = state.2)

theorem gridClock_round (clock : Fin L) : gridClock N L cfg.clocks_pos (clock.val*N) = clock := by
  have h := gridClock_slot N L cfg.clocks_pos clock (⟨0,cfg.labels_pos⟩ : Fin N)
  simpa only [gridSlot,Nat.add_zero] using h

theorem eulerBlockUpdate_replay (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (state : BlockState N V) (event : Option (Fin N × (Fin N → Option V))) :
    recordReplay M base hbase value (cfg.eulerBlockUpdate state event).2 =
      virtualUpdate M base hbase value (recordReplay M base hbase value state.2) event := by
  unfold eulerBlockUpdate eulerHistoryUpdate
  rw [recordReplay_updateGridHistory]
  cases event with
  | none => rfl
  | some event => rfl

theorem sparse_block_reachable
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (j : ℕ) (hj : j < L) (state : BlockState N V) (hs : cfg.blockReachable j state)
    (x : Fin N → Option (GridMark N L V))
    (hx : (cfg.sparseBlockBatch hsmall omega homega homega1 hlower hbudget.le state).mass x ≠ 0) :
    cfg.blockReachable (j+1) (physicalBlockUpdate state x) := by
  constructor
  · change state.1+N = (j+1)*N
    rw [hs.1,Nat.add_mul,Nat.one_mul]
  · apply cfg.sparse_round_reachable hsmall omega homega homega1 hlower hbudget state.1 state.2 _ hs.2 x hx
    rw [hs.1,← Nat.succ_mul]
    exact Nat.mul_le_mul_right N hj

theorem sparse_euler_block_expect (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (j : ℕ) (hj : j < L) (state : BlockState N V) (hs : cfg.blockReachable j state) (F : BlockState N V → ℝ) :
    (cfg.sparseBlockBatch hsmall omega homega homega1 hlower hbudget.le state).expect
      (fun x => F (physicalBlockUpdate state x)) =
    (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le state).expect
      (fun event => F (cfg.eulerBlockUpdate state event)) := by
  rcases state with ⟨offset,history⟩
  obtain ⟨hoff,hp⟩ := hs
  dsimp only at hoff hp
  subst offset
  have hN : (1:ℝ) ≤ N := by exact_mod_cast cfg.labels_pos
  have hnonneg : 0 ≤ (1/(L:ℝ))*((1/cfg.q)/omega) :=
    mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)
  have hsingle : (1/(L:ℝ))*((1/cfg.q)/omega) < 1 := by nlinarith
  have h := cfg.physical_sparse_history_expect M base hbase value hlive hsmall omega homega homega1 hlower
    hbudget.le hsingle history ⟨j,hj⟩ hp (fun records => F (j*N+N,records))
  simpa only [sparseBlockBatch,physicalBlockUpdate,eulerBlockBatch,eulerBlockUpdate,
    cfg.gridClock_round (⟨j,hj⟩ : Fin L)] using h

theorem sparse_euler_terminal_expect (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (rounds offset : ℕ) (hhorizon : offset+rounds ≤ L)
    (state : BlockState N V) (hs : cfg.blockReachable offset state) (F : BlockState N V → ℝ) :
    (FiniteLaw.adaptiveBatches (cfg.sparseBlockBatch hsmall omega homega homega1 hlower hbudget.le)
      physicalBlockUpdate rounds state).expect (fun x => F (FiniteLaw.stateAfter physicalBlockUpdate rounds state x)) =
    (FiniteLaw.adaptiveBatches (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
      cfg.eulerBlockUpdate rounds state).expect (fun x => F (FiniteLaw.stateAfter cfg.eulerBlockUpdate rounds state x)) := by
  apply FiniteLaw.adaptive_terminal_transfer _ _ _ _ cfg.blockReachable rounds offset state hs
  · intro j hj hjn s hstate x hx
    exact cfg.sparse_block_reachable hsmall omega homega homega1 hlower hbudget j (by omega) s hstate x hx
  · intro j hj hjn s hstate f
    exact cfg.sparse_euler_block_expect M base hbase value hlive hsmall omega homega homega1 hlower hbudget
      j (by omega) s hstate f

theorem physical_euler_discretization_error (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (B : ℝ) (hB : 0 ≤ B) (f : StampedHistory (Fin N) (Fin N → Option V) → ℝ)
    (hf : ∀ history, |f history| ≤ B) :
    |(FiniteLaw.product cfg.laws).expect (fun tapes => f (cfg.run tapes (L*N))) -
      (FiniteLaw.adaptiveBatches (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
        cfg.eulerBlockUpdate L (0,[])).expect
        (fun x => f (FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x).2)| ≤
      2*(N:ℝ)^2*((1/cfg.q)/omega)^2*B/L := by
  have h := cfg.physical_discretization_error hsmall omega homega homega1 hlower hbudget.le B hB f hf
  have hs : cfg.blockReachable 0 (0,[]) := by
    constructor
    · simp
    · simpa only [cfg.initial_history_probability] using (zero_lt_one : (0:ℝ) < 1)
  rw [cfg.sparse_euler_terminal_expect M base hbase value hlive hsmall omega homega homega1 hlower hbudget
    L 0 (by omega) (0,[]) hs (fun state => f state.2)] at h
  exact h

end MatroidProphetSecretary.PrivateGridConfig
