import MatroidProphetSecretary.PrivateCandidateTape
import MatroidProphetSecretary.OneArrivalGrid

/-! A finite private probe tape has the exact attenuation product at every counterfactual clock slot. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem prod_fin_initial_segment (f : ℕ → ℝ) (N n : ℕ) (hn : n ≤ N) :
    (∏ i : Fin N, if i.val < n then f i.val else 1) = ∏ i ∈ range n, f i := by
  rw [Fin.prod_univ_eq_prod_range (fun i => if i < n then f i else 1)]
  rw [← prod_filter]
  congr 1
  ext i
  simp only [mem_filter,mem_range]
  constructor
  · exact And.right
  · intro hi
    exact ⟨hi.trans_le hn,hi⟩

variable {W : Type*} [Fintype W]

def gridProbeLaw (μ : FiniteLaw W) (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) :
    FiniteLaw (Fin L → Bool × W) :=
  FiniteLaw.product (fun _ : Fin L => finiteProbeLaw μ p hp0 hp1)

def gridProbePass (live : ℕ → W → Prop) {L : ℕ} (n : ℕ) (probes : Fin L → Bool × W) : Prop :=
  ∀ i : Fin L, i.val < n → finiteProbePass (live i.val) (probes i)

def gridLiveDose (μ : FiniteLaw W) (p : ℝ) (live : ℕ → W → Prop) (i : ℕ) : ℝ := p*μ.prob (live i)

theorem gridProbePass_probability (μ : FiniteLaw W) (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1)
    (live : ℕ → W → Prop) (n : ℕ) (hn : n ≤ L) :
    (gridProbeLaw μ L p hp0 hp1).prob (gridProbePass live n) = gridSurvival (gridLiveDose μ p live) n := by
  unfold gridProbeLaw gridProbePass
  have hprod := FiniteLaw.product_prob_coordinates
    (fun _ : Fin L => finiteProbeLaw μ p hp0 hp1)
    (fun i x => i.val < n → finiteProbePass (live i.val) x)
  have hc (i : Fin L) :
      (finiteProbeLaw μ p hp0 hp1).prob (fun x => i.val < n → finiteProbePass (live i.val) x) =
      if i.val < n then 1-gridLiveDose μ p live i.val else 1 := by
    by_cases hi : i.val < n
    · simpa only [hi,true_implies,if_true,gridLiveDose] using finiteProbePass_probability μ p hp0 hp1 (live i.val)
    · simp [hi,FiniteLaw.prob]
  simp_rw [hc] at hprod
  rw [prod_fin_initial_segment (fun i => 1-gridLiveDose μ p live i) L n hn] at hprod
  convert hprod using 1
  unfold FiniteLaw.prob
  congr 1
  funext x
  split_ifs <;> rfl

theorem gridLiveDose_bounds (μ : FiniteLaw W) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p < 1)
    (live : ℕ → W → Prop) (i : ℕ) :
    0 ≤ gridLiveDose μ p live i ∧ gridLiveDose μ p live i < 1 := by
  constructor
  · exact mul_nonneg hp0 (μ.prob_nonneg _)
  · exact (mul_le_of_le_one_right hp0 (μ.prob_le_one _)).trans_lt hp1

variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V]

def earlyPrivateTapeLaw (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) :=
  referencePrivateTapeLaw (C := Fin L) prior references e q hq hdom
    (gridProbeLaw (FiniteLaw.product references) L p hp0 hp1)

def earlyPrivateDecision (live : ℕ → (E → Option V) → Prop) {L : ℕ} (c : Fin L) :
    (V × (Fin L → (Fin L → Bool × (E → Option V)) × Option (E → Option V))) → Option (E → Option V) :=
  referencePrivateDecision (live c.val) (gridProbePass live c.val) c

theorem early_private_mark_kernel (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none)
    (c : Fin L) (B : (E → Option V) → Prop) :
    (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1).prob
      (fun tape => ∃ y, earlyPrivateDecision live c tape = some y ∧ B y) =
      (1/q)*gridSurvival (gridLiveDose (FiniteLaw.product references) p live) c.val*
        (FiniteLaw.product references).prob (fun y => live c.val y ∧ B y) := by
  have h := reference_private_tape_kernel prior references e q hq hdom
    (gridProbeLaw (FiniteLaw.product references) L p hp0 hp1) c (live c.val) (hpositive c.val)
    (gridProbePass live c.val) B
  rw [gridProbePass_probability _ L p hp0 hp1 live c.val c.isLt.le] at h
  exact h

end MatroidProphetSecretary
