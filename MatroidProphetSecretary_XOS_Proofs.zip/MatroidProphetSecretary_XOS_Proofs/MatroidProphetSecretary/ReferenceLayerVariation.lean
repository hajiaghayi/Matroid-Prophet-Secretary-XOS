import MatroidProphetSecretary.BernoulliVariation
import MatroidProphetSecretary.LayerStatistics
import MatroidProphetSecretary.ReferenceSurplusLayers

/-! Quantitative change of the reference deletion layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem scaledTail_sub_bound (p q r : ℝ) (hp : 0 ≤ p) (hqr : q ≤ r) :
    0 ≤ scaledTail p r - scaledTail p q ∧ scaledTail p r - scaledTail p q ≤ (r-q)*p := by
  refine ⟨sub_nonneg.mpr (scaledTail_monotone p hp hqr), ?_⟩
  have hpq : q*p ≤ r*p := mul_le_mul_of_nonneg_right hqr hp
  unfold scaledTail
  by_cases hq : q*p ≤ 1
  · rw [min_eq_right hq]
    have h := min_le_right (1:ℝ) (r*p)
    nlinarith
  · rw [min_eq_left (le_of_not_ge hq), min_eq_left (by linarith : 1 ≤ r*p)]
    simpa using mul_nonneg (sub_nonneg.mpr hqr) hp

variable {E : Type*} [Fintype E] [LinearOrder E]

theorem referenceLayerD_eq_coloop_expect (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q : ℝ) (hq : 0 ≤ q) :
    referenceLayerD M p q = bernoulliEval (fun e => scaledTail (p e) q) (activeColoopCount M) := by
  rw [bernoulliEval_eq_expect _ (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).2), activeColoopCount_expect]
  apply sum_congr rfl
  intro e he
  unfold referenceLayerRho
  rw [bernoulli_replace_rank_eq_nonspan M hground (fun e => scaledTail (p e) q)
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).2)]
  unfold activityProbability
  rw [FiniteLaw.product_prob_coordinate]
  simp only [bernoulliLaws, bernoulliLaw, if_true]

theorem referenceLayerD_variation_ordered (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q r : ℝ) (hq : 0 ≤ q) (hqr : q ≤ r) :
    |referenceLayerD M p r - referenceLayerD M p q| ≤
      (Fintype.card E : ℝ)*(r-q)*(∑ e, p e) := by
  rw [referenceLayerD_eq_coloop_expect M hground p hp r (hq.trans hqr),
    referenceLayerD_eq_coloop_expect M hground p hp q hq, abs_sub_comm]
  have h := bernoulliEval_variation_ordered (fun e => scaledTail (p e) q)
    (fun e => scaledTail (p e) r) (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => scaledTail_monotone (p e) (hp e) hqr)
    (fun e => (scaledTail_bounds (p e) r (hp e) (hq.trans hqr)).2)
    (activeColoopCount M) (Fintype.card E) (Nat.cast_nonneg _)
    (activeColoopCount_nonneg M)
    (fun x => (activeColoopCount_le_rank M hground x).trans (activeRank_le_card M hground x))
  refine h.trans ?_
  calc
    _ ≤ (Fintype.card E : ℝ) * ∑ e, (r-q)*p e :=
      mul_le_mul_of_nonneg_left (sum_le_sum (fun e he => (scaledTail_sub_bound (p e) q r (hp e) hqr).2))
        (Nat.cast_nonneg _)
    _ = _ := by rw [← mul_sum]; ring

theorem referenceLayerD_variation (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q r : ℝ) (hq : 0 ≤ q) (hr : 0 ≤ r) :
    |referenceLayerD M p r - referenceLayerD M p q| ≤
      (Fintype.card E : ℝ)*|r-q| * (∑ e, p e) := by
  rcases le_total q r with hqr | hrq
  · simpa only [abs_of_nonneg (sub_nonneg.mpr hqr)] using
      referenceLayerD_variation_ordered M hground p hp q r hq hqr
  · have h := referenceLayerD_variation_ordered M hground p hp r q hr hrq
    rw [abs_sub_comm] at h
    simpa only [abs_of_nonpos (sub_nonpos.mpr hrq), neg_sub] using h

end MatroidProphetSecretary
