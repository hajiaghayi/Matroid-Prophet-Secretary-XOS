import MatroidProphetSecretary.LayerOracle
import MatroidProphetSecretary.LayerStatistics

/-! The computed oracle observations coincide with all four common-layer statistics. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [LinearOrder E]

def activeFinset (x : E → Bool) : Finset E := univ.filter (fun e => x e = true)

theorem activeFinset_coe (x : E → Bool) : (activeFinset x : Set E) = bitSet x := by
  ext e
  simp [activeFinset,bitSet]

theorem activeColoopIndicator_oracle (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (hg : ∀ e, e ∈ M.E) (x : E → Bool) (e : E) :
    activeColoopIndicator M e x = if e ∈ (layerColoops oracle (activeFinset x)).1 then 1 else 0 := by
  have hR : (activeFinset x : Set E) ⊆ M.E := fun e _ => hg e
  rw [layerColoops_correct M oracle horacle _ hR]
  have hblock : activeBlock M e (fun _ => True) x = (activeFinset x : Set E) \ {e} := by
    ext f
    simp [activeBlock,activeFinset,hg f,and_comm,and_left_comm]
  by_cases he : x e = true
  · have heR : e ∈ activeFinset x := by simp [activeFinset,he]
    have hc := (M ↾ (activeFinset x : Set E)).isColoop_iff_not_mem_closure_compl
      (show e ∈ (M ↾ (activeFinset x : Set E)).E from heR)
    rw [Matroid.restrict_ground_eq,M.restrict_closure_eq Set.diff_subset hR] at hc
    simp only [Set.mem_inter_iff,Finset.mem_coe,heR,and_true] at hc
    simp only [activeColoopIndicator,he,true_and,nonspanEvent,hblock,mem_filter,heR,true_and,hc]
  · simp [activeColoopIndicator,he,activeFinset]

theorem common_layer_oracle_statistics (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (hg : ∀ e, e ∈ M.E) (x : E → Bool) (p : E → ℝ) :
    ((layerBasis oracle (activeFinset x)).card : ℝ) = realRank M (bitSet x) ∧
    ((layerColoops oracle (activeFinset x)).1.card : ℝ) = activeColoopCount M x ∧
    (∑ e ∈ (layerColoops oracle (activeFinset x)).1, (1-p e)) = activeUnstableCount M p x ∧
    (∀ e, (if layerClosure oracle (activeFinset x) (layerColoops oracle (activeFinset x)).1
      (layerBasis oracle (activeFinset x)) e then (1:ℝ) else 0) = activeOtherClosure M e x) ∧
    layerOracleQueries oracle (activeFinset x) ≤
      2*Fintype.card E + 2*Nat.clog 2 (Fintype.card E)*Fintype.card E := by
  have hR : (activeFinset x : Set E) ⊆ M.E := fun e _ => hg e
  refine ⟨?_,?_,?_,?_,layerOracle_query_bound M oracle horacle _ hR⟩
  · simpa only [activeFinset_coe] using layerBasis_rank M oracle horacle _ hR
  · unfold activeColoopCount
    simp_rw [activeColoopIndicator_oracle M oracle horacle hg x]
    simp
  · unfold activeUnstableCount
    simp_rw [activeColoopIndicator_oracle M oracle horacle hg x,ite_mul,one_mul,zero_mul]
    simp
  · intro e
    have hc := layerClosure_correct M oracle horacle _ hR e (hg e)
    rw [activeFinset_coe] at hc
    simp only [activeOtherClosure,hc]

end MatroidProphetSecretary
