import MatroidProphetSecretary.StampedHistory

/-! Chronological reconstruction is compatible with prefixes and nested cutoffs. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E T W A : Type*}

theorem recordsBefore_nested (history : StampedHistory E A) (i j : ℕ) (hij : i ≤ j) :
    recordsBefore i (recordsBefore j history) = recordsBefore i history := by
  unfold recordsBefore
  rw [List.filter_filter]
  apply List.filter_congr
  intro r hr
  by_cases hi : r.2.1 < i
  · have hj : r.2.1 < j := hi.trans_le hij
    simp [hi,hj]
  · simp [hi]

theorem stampedRun_step_prefix (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → W → Option A)
    (tapes : E → T × W) (n : ℕ) :
    (stampedRun label time decision tapes n).IsPrefix (stampedRun label time decision tapes (n+1)) := by
  change (stampedRun label time decision tapes n).IsPrefix
    (markedStep label time (stampDecision decision) n (stampedRun label time decision tapes n) (tapes (label n)))
  unfold markedStep stampDecision
  split_ifs
  · cases hd : decision n (stampedRun label time decision tapes n) (tapes (label n)).2 with
    | none => exact List.prefix_refl _
    | some mark => exact ⟨[(label n,(n,mark))],rfl⟩
  · exact List.prefix_refl _

theorem stampedRun_prefix (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → W → Option A)
    (tapes : E → T × W) (i j : ℕ) (hij : i ≤ j) :
    (stampedRun label time decision tapes i).IsPrefix (stampedRun label time decision tapes j) := by
  induction j, hij using Nat.le_induction with
  | base => exact List.prefix_refl _
  | succ j hj ih => exact ih.trans (stampedRun_step_prefix label time decision tapes j)

end MatroidProphetSecretary
