import MatroidProphetSecretary.MaximumValue
import MatroidProphetSecretary.StableLayers

/-! Integrating variation bounds against the total upper-tail mass. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E Ω : Type*} [Fintype E] [LinearOrder E] [Fintype Ω]

theorem positiveTailProbability_integrable (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (e : E) :
    Integrable (positiveTailProbability μ v e) :=
  μ.integrable_expect _ (fun x => positiveLayer_integrable (v x e))

theorem integral_positiveTailProbability (μ : FiniteLaw Ω) (v : Ω → E → ℝ)
    (hv : ∀ x e, 0 ≤ v x e) (e : E) :
    (∫ z, positiveTailProbability μ v e z) = μ.expect (fun x => v x e) := by
  change (∫ z, μ.expect (fun x => positiveLayer (v x e) z)) = _
  rw [μ.integral_expect _ (fun x => positiveLayer_integrable _)]
  simp only [integral_positiveLayer _ (hv _ _)]

theorem total_tail_integrable (μ : FiniteLaw Ω) (v : Ω → E → ℝ) :
    Integrable (fun z => ∑ e, positiveTailProbability μ v e z) :=
  integrable_finset_sum univ (fun e _ => positiveTailProbability_integrable μ v e)

theorem integral_total_tail (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (hv : ∀ x e, 0 ≤ v x e) :
    (∫ z, ∑ e, positiveTailProbability μ v e z) = ∑ e, μ.expect (fun x => v x e) := by
  rw [integral_finset_sum univ (fun e _ => positiveTailProbability_integrable μ v e)]
  simp only [integral_positiveTailProbability μ v hv]

theorem integral_total_tail_le (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (hv : ∀ x e, 0 ≤ v x e)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    (∫ z, ∑ e, positiveTailProbability μ v e z) ≤ (Fintype.card E : ℝ) * expectedOptimum μ M v := by
  rw [integral_total_tail μ v hv]
  calc
    _ ≤ ∑ _ : E, expectedOptimum μ M v := sum_le_sum (fun e _ =>
      μ.expect_mono (fun x => (value_le_maximumValue (v x) e).trans (maximumValue_le_optimum M (v x) hnonloop)))
    _ = _ := by simp

theorem integral_variation_bound (f g h : ℝ → ℝ) (hf : Integrable f) (hg : Integrable g)
    (hh : Integrable h) (C : ℝ) (hbound : ∀ z, |f z-g z| ≤ C*h z) :
    |(∫ z, f z) - (∫ z, g z)| ≤ C * ∫ z, h z := by
  rw [← integral_sub hf hg]
  calc
    _ ≤ ∫ z, |f z-g z| := by
      simpa only [Real.norm_eq_abs] using norm_integral_le_integral_norm (fun z => f z-g z)
    _ ≤ ∫ z, C*h z := integral_mono (hf.sub hg).abs (hh.const_mul C) hbound
    _ = _ := integral_const_mul _ _

end MatroidProphetSecretary
