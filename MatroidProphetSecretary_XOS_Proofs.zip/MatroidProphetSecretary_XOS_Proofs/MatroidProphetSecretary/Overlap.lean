import MatroidProphetSecretary.LayerIntegral

/-! The layer overlap Q, its integrability, and the bounds 0 ≤ Q ≤ F. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

def basisLayer (v : E → ℝ) (B : Finset E) (e : E) (z : ℝ) : ℝ :=
  if e ∈ B then positiveLayer (v e) z else 0

def basisMarginal (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (bases : Ω → Finset E)
    (e : E) (z : ℝ) : ℝ := μ.expect (fun w => basisLayer (v w) (bases w) e z)

def overlap (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (bases : Ω → Finset E) : ℝ :=
  ∫ z, ∑ e, (basisMarginal μ v bases e z) ^ 2

theorem basisLayer_bounds (v : E → ℝ) (B : Finset E) (e : E) (z : ℝ) :
    0 ≤ basisLayer v B e z ∧ basisLayer v B e z ≤ 1 := by
  unfold basisLayer positiveLayer
  split_ifs <;> norm_num

theorem basisLayer_integrable (v : E → ℝ) (B : Finset E) (e : E) :
    Integrable (basisLayer v B e) := by
  unfold basisLayer
  by_cases he : e ∈ B
  · simp only [he, if_true]
    exact positiveLayer_integrable (v e)
  · simp only [he, if_false]
    exact integrable_zero _ _ _

theorem basisMarginal_bounds (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (bases : Ω → Finset E)
    (e : E) (z : ℝ) : 0 ≤ basisMarginal μ v bases e z ∧ basisMarginal μ v bases e z ≤ 1 := by
  constructor
  · exact μ.expect_nonneg (fun w => (basisLayer_bounds (v w) (bases w) e z).1)
  · have h := μ.expect_mono (fun w => (basisLayer_bounds (v w) (bases w) e z).2)
    simpa only [FiniteLaw.expect_const] using h

theorem basisMarginal_integrable (μ : FiniteLaw Ω) (v : Ω → E → ℝ)
    (bases : Ω → Finset E) (e : E) : Integrable (basisMarginal μ v bases e) :=
  integrable_finset_sum univ (fun w _ =>
    (basisLayer_integrable (v w) (bases w) e).const_mul (μ.mass w))

theorem basisMarginal_sq_integrable (μ : FiniteLaw Ω) (v : Ω → E → ℝ)
    (bases : Ω → Finset E) (e : E) : Integrable (fun z => (basisMarginal μ v bases e z) ^ 2) := by
  have hi := basisMarginal_integrable μ v bases e
  have hb : ∃ C : ℝ, ∀ z, ‖basisMarginal μ v bases e z‖ ≤ C := by
    refine ⟨1, fun z => ?_⟩
    rw [Real.norm_eq_abs, abs_of_nonneg (basisMarginal_bounds μ v bases e z).1]
    exact (basisMarginal_bounds μ v bases e z).2
  simpa only [pow_two] using hi.bdd_mul hi.aestronglyMeasurable hb

theorem sum_basisMarginal_eq_expected_rank (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (bases : Ω → Finset E)
    (hB : ∀ w, M.IsBase (bases w : Set E)) (hopt : ∀ w, optimum M (v w) = weight (v w) (bases w))
    (z : ℝ) : (∑ e, basisMarginal μ v bases e z) =
      μ.expect (fun w => positiveRankLayer M (v w) z) := by
  unfold basisMarginal FiniteLaw.expect
  rw [sum_comm]
  apply sum_congr rfl
  intro w hw
  rw [← mul_sum]
  congr 1
  dsimp only
  rw [positiveRankLayer_eq_basis_sum (hB w) (hopt w)]
  simp [basisLayer, ← sum_filter]

theorem overlap_nonneg (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (bases : Ω → Finset E) :
    0 ≤ overlap μ v bases :=
  integral_nonneg (fun z => sum_nonneg (fun e _ => sq_nonneg _))

theorem overlap_le_expectedOptimum (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e) (bases : Ω → Finset E)
    (hB : ∀ w, M.IsBase (bases w : Set E)) (hopt : ∀ w, optimum M (v w) = weight (v w) (bases w)) :
    overlap μ v bases ≤ expectedOptimum μ M v := by
  rw [expectedOptimum_eq_integral_expected_rank μ M v hv]
  unfold overlap
  apply integral_mono (integrable_finset_sum univ (fun e _ => basisMarginal_sq_integrable μ v bases e))
    (integrable_finset_sum univ (fun w _ =>
      (positiveRankLayer_integrable M (v w) (hv w)).const_mul (μ.mass w)))
  intro z
  change (∑ e, basisMarginal μ v bases e z ^ 2) ≤
    μ.expect (fun w => positiveRankLayer M (v w) z)
  rw [← sum_basisMarginal_eq_expected_rank μ M v bases hB hopt z]
  apply sum_le_sum
  intro e he
  have hb := basisMarginal_bounds μ v bases e z
  nlinarith

end MatroidProphetSecretary
