import MatroidProphetSecretary.Parameters
import MatroidProphetSecretary.Exponential

noncomputable section

namespace MatroidProphetSecretary

set_option maxHeartbeats 800000

theorem inverse_q_bounds {q : ℝ} (hq : q ∈ interval) :
    499 / 500 < 1 / q ∧ 1 / q < 501 / 500 := by
  have hpos := q_pos hq
  obtain ⟨hl, hu⟩ := interval_bounds hq
  constructor
  · apply (lt_div_iff₀ hpos).mpr
    linarith
  · apply (div_lt_iff₀ hpos).mpr
    linarith

theorem alpha_bounds {q : ℝ} (hq : q ∈ interval) :
    367 / 1000 < alpha q ∧ alpha q < 369 / 1000 := by
  let t := 1 - (1 / q) * (1 - delta)
  have htLo : -(3 / 2000) < t := by
    have h : 1 / q ≤ 512 / 511 :=
      (div_le_iff₀ (q_pos hq)).mpr (by linarith [(interval_bounds hq).1])
    dsimp [t, delta]
    norm_num at *
    linarith
  have htHi : t < 1 / 400 := by
    have h := (inverse_q_bounds hq).1
    dsimp [t, delta]
    linarith
  have hid : alpha q = Real.exp (-1) * Real.exp t := by
    unfold alpha
    rw [← Real.exp_add]
    congr 1
    dsimp [t, alpha]
    ring
  have heLo : 1997 / 2000 < Real.exp t := by
    have hh : (1997 / 2000 : ℝ) < t + 1 := by
      convert add_lt_add_right htLo 1 using 1 <;> norm_num
    exact hh.trans_le (Real.add_one_le_exp t)
  have heHi : Real.exp t < 400 / 399 := by
    have hm := Real.exp_lt_exp.mpr htHi
    have hb := Real.exp_bound_div_one_sub_of_interval
      (by norm_num : (0 : ℝ) ≤ 1 / 400) (by norm_num : (1 / 400 : ℝ) < 1)
    norm_num at hb
    exact hm.trans_le hb
  rw [hid]
  constructor
  · have h := mul_lt_mul Real.exp_neg_one_gt_d9 heLo.le
      (by norm_num : (0 : ℝ) < 1997 / 2000) (Real.exp_pos _).le
    nlinarith
  · have h := mul_lt_mul Real.exp_neg_one_lt_d9 heHi.le
      (Real.exp_pos _) (by norm_num : (0 : ℝ) ≤ 0.3678794412)
    nlinarith

theorem delta_div_q_bounds {q : ℝ} (hq : q ∈ interval) :
    0 < delta / q ∧ delta / q < 1 / 2000 := by
  have hpos := q_pos hq
  have h := (inverse_q_bounds hq).2
  constructor
  · exact div_pos (by norm_num [delta]) hpos
  · dsimp [delta]
    have hid : (1 : ℝ) / 2048 / q = (1 / q) / 2048 := by ring
    rw [hid]
    linarith

theorem omega_positive {q : ℝ} (hq : q ∈ interval) : 183 / 500 < omega q := by
  have ha := (alpha_bounds hq).1
  have hx := (delta_div_q_bounds hq).2
  dsimp [omega]
  linarith

/-- The uniform affine gap (9.6), strengthened by a quadratic term.
The proof uses a certified Taylor remainder on a small interval rather
than the paper's second-derivative argument. -/
theorem affine_gap_quadratic {q : ℝ} (hq : q ∈ interval) :
    Real.exp (-(1 / q)) - theta * q <
      142 / 1000000000 - (9 / 50) * (q - 1) ^ 2 := by
  have hqpos := q_pos hq
  obtain ⟨hqLo, hqHi⟩ := interval_bounds hq
  let t := 1 - 1 / q
  have ht : |t| ≤ 1 / 400 := by
    rw [abs_le]
    constructor
    · dsimp [t]
      have : 1 / q ≤ 401 / 400 := (div_le_iff₀ hqpos).mpr (by linarith)
      linarith
    · dsimp [t]
      have : 399 / 400 ≤ 1 / q := (le_div_iff₀ hqpos).mpr (by linarith)
      linarith
  have hexp := exp_tiny_upper ht
  have hid : Real.exp (-(1 / q)) = Real.exp (-1) * Real.exp t := by
    rw [← Real.exp_add]
    congr 1
    dsimp [t]
    ring
  have hpoly : q - (1 + t + (501 / 1000) * t ^ 2) =
      (q - 1) ^ 2 * (q - 501 / 1000) / q ^ 2 := by
    dsimp [t]
    field_simp
    ring
  have hcoeff : 9 / 50 ≤ Real.exp (-1) * (q - 501 / 1000) / q ^ 2 := by
    apply (le_div_iff₀ (sq_pos_of_pos hqpos)).mpr
    have hu := Real.exp_neg_one_gt_d9
    have hd : 0 ≤ q - 501 / 1000 := by linarith
    have hm := mul_le_mul_of_nonneg_right hu.le hd
    have hqSq : q ^ 2 ≤ (513 / 512) ^ 2 := by nlinarith
    nlinarith
  have hmain : Real.exp (-(1 / q)) ≤
      q * Real.exp (-1) - (9 / 50) * (q - 1) ^ 2 := by
    have hmul := mul_le_mul_of_nonneg_left hexp (Real.exp_pos (-1)).le
    have hgain := mul_le_mul_of_nonneg_right hcoeff (sq_nonneg (q - 1))
    have hid2 : Real.exp (-1) * (q - (1 + t + (501 / 1000) * t ^ 2)) =
        (Real.exp (-1) * (q - 501 / 1000) / q ^ 2) * (q - 1) ^ 2 := by
      rw [hpoly]
      ring
    rw [hid]
    nlinarith
  have hsmall : q * (Real.exp (-1) - theta) < 142 / 1000000000 := by
    have hu := Real.exp_neg_one_lt_d9
    have hm := mul_lt_mul_of_pos_left hu hqpos
    dsimp [theta] at *
    nlinarith
  linarith

theorem affine_gap_uniform {q : ℝ} (hq : q ∈ interval) :
    discount q - (1 - Real.exp (-(1 / q))) < 142 / 1000000000 := by
  have h := affine_gap_quadratic hq
  dsimp [discount]
  nlinarith [sq_nonneg (q - 1)]

end MatroidProphetSecretary
