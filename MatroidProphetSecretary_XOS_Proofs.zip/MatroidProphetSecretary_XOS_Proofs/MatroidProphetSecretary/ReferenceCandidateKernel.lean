import MatroidProphetSecretary.ScreenedLiveKernel
import MatroidProphetSecretary.ReferenceValueLaw
import MatroidProphetSecretary.VirtualStep

/-! Instantiating the screened kernel with the paper's finite reference atoms and replayed matroid live sets. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem finiteIndexTail_difference {k : ℕ} (μ : FiniteLaw (Fin k)) (i : Fin k) :
    finiteIndexTail μ i.val-finiteIndexTail μ (i.val+1) = μ.mass i := by
  unfold finiteIndexTail FiniteLaw.prob
  rw [← FiniteLaw.expect_sub]
  have hpoint (j : Fin k) :
      (if i.val ≤ j.val then (1 : ℝ) else 0)-(if i.val+1 ≤ j.val then 1 else 0) =
        if j = i then 1 else 0 := by
    by_cases hj : j = i
    · subst j; simp
    · have hne : j.val ≠ i.val := fun h => hj (Fin.ext h)
      by_cases hle : i.val ≤ j.val
      · have hnext : i.val+1 ≤ j.val := by omega
        simp [hle,hnext,hj]
      · have hnext : ¬ i.val+1 ≤ j.val := by omega
        simp [hle,hnext,hj]
  simp_rw [hpoint]
  simp [FiniteLaw.expect]

theorem finiteReferenceLaw_atom_domination {k : ℕ} (μ : FiniteLaw (Fin k)) (q : ℝ) (hq : 0 ≤ q)
    (i : Fin k) : (finiteReferenceLaw μ q hq).mass (some i) ≤ q*μ.mass i := by
  have h := (reference_atom_domination q (finiteIndexTail μ i.val) (finiteIndexTail μ (i.val+1)) hq
    (finiteIndexTail_antitone μ (Nat.le_succ _))).2
  rwa [finiteIndexTail_difference] at h

variable {E : Type*} [Fintype E] [DecidableEq E] {k : ℕ}

theorem virtualLive_own_atom_some (M : Matroid E) (base : (E → Option (Fin k)) → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (v : E → Fin k → ℝ)
    (s : VirtualState M) (y : E → Option (Fin k)) (e : E)
    (hy : e ∈ virtualLive M base hbase (fun y e => referenceValue (v e) (y e)) s y) : y e ≠ none := by
  have hv := (mem_filter.mp hy).2
  intro he
  simp only [he,referenceValue] at hv
  exact lt_irrefl _ hv

def finiteReferenceCandidateLaw (laws : E → FiniteLaw (Fin k)) (q : ℝ) (hq : 0 < q)
    (M : Matroid E) (base : (E → Option (Fin k)) → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (v : E → Fin k → ℝ) (s : VirtualState M) (e : E) : FiniteLaw (Option (E → Option (Fin k))) :=
  screenedLiveLaw (laws e) (fun f => finiteReferenceLaw (laws f) q hq.le) e q hq
    (finiteReferenceLaw_atom_domination (laws e) q hq.le)
    (fun y => e ∈ virtualLive M base hbase (fun y e => referenceValue (v e) (y e)) s y)

theorem finite_reference_candidate_kernel (laws : E → FiniteLaw (Fin k)) (q : ℝ) (hq : 0 < q)
    (M : Matroid E) (base : (E → Option (Fin k)) → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (v : E → Fin k → ℝ) (s : VirtualState M) (e : E) (B : (E → Option (Fin k)) → Prop) :
    (finiteReferenceCandidateLaw laws q hq M base hbase v s e).prob (fun x => ∃ y, x = some y ∧ B y) =
      (1/q)*(FiniteLaw.product (fun f => finiteReferenceLaw (laws f) q hq.le)).prob
        (fun y => e ∈ virtualLive M base hbase (fun y e => referenceValue (v e) (y e)) s y ∧ B y) := by
  convert screenedLiveLaw_mark_probability (laws e) (fun f => finiteReferenceLaw (laws f) q hq.le) e q hq
    (finiteReferenceLaw_atom_domination (laws e) q hq.le) _
    (fun y hy => virtualLive_own_atom_some M base hbase v s y e hy) B using 1
  congr 1
  unfold FiniteLaw.prob
  congr 1
  funext y
  split_ifs <;> rfl

theorem finite_reference_candidate_reward (laws : E → FiniteLaw (Fin k)) (q : ℝ) (hq : 0 < q)
    (M : Matroid E) (base : (E → Option (Fin k)) → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (v : E → Fin k → ℝ) (s : VirtualState M) (e : E) :
    (finiteReferenceCandidateLaw laws q hq M base hbase v s e).expect
      (fun x => match x with | none => 0 | some y => referenceValue (v e) (y e)) =
      (1/q)*virtualLiveValue (FiniteLaw.product (fun f => finiteReferenceLaw (laws f) q hq.le))
        M base hbase (fun y e => referenceValue (v e) (y e)) s e := by
  convert screenedLiveLaw_expect_zero (laws e) (fun f => finiteReferenceLaw (laws f) q hq.le) e q hq
    (finiteReferenceLaw_atom_domination (laws e) q hq.le) _
    (fun y hy => virtualLive_own_atom_some M base hbase v s y e hy)
    (fun x => match x with | none => 0 | some y => referenceValue (v e) (y e)) rfl using 1
  congr 1
  unfold virtualLiveValue
  congr 1
  funext y
  split_ifs <;> rfl

end MatroidProphetSecretary
