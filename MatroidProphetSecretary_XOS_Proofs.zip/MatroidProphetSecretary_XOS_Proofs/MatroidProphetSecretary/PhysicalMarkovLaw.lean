import MatroidProphetSecretary.AcceptedTrace

/-! The full physical process has an exact finite Markov law on its stamped accepted history. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem FiniteLaw.map_mass_probability {R W : Type*} [Fintype R] [Fintype W]
    (μ : FiniteLaw R) (f : R → W) (y : W) :
    (μ.map f).mass y = μ.prob (fun raw => f raw = y) := by
  simp [FiniteLaw.map,FiniteLaw.prob,FiniteLaw.expect,mul_ite]

theorem FiniteLaw.timedBatches_congr_range {S W : Type*} [Fintype W]
    (kernel other : ℕ → S → FiniteLaw W) (update : S → W → S) (n offset : ℕ) (s : S)
    (heq : ∀ j, offset ≤ j → j < offset+n → ∀ state, kernel j state = other j state) :
    timedBatches kernel update n offset s = timedBatches other update n offset s := by
  induction n generalizing offset s with
  | zero => rfl
  | succ n ih =>
    simp only [timedBatches]
    rw [heq offset le_rfl (by omega) s]
    congr 1
    funext x
    rw [ih (offset+1) (update s x) (fun j hj hjn state => heq j (by omega) (by omega) state)]

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem same_current_same_past (tapes other : Fin N → Fin L × GridPrivateTape N L V)
    (n i : ℕ) (hin : i ≤ n) (heq : cfg.run tapes n = cfg.run other n) :
    cfg.run tapes i = cfg.run other i := by
  have h := congrArg (recordsBefore i) heq
  simpa only [run,recordsBefore_stampedRun _ _ _ tapes hin,recordsBefore_stampedRun _ _ _ other hin] using h

theorem traceEvent_iff_current (x : ℕ → Option (GridMark N L V)) (n : ℕ) (hn : n ≤ L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (FiniteLaw.traceEvent cfg.trace x n))
    (tapes : Fin N → Fin L × GridPrivateTape N L V) :
    FiniteLaw.traceEvent cfg.trace x n tapes ↔ cfg.run tapes n = FiniteLaw.scanState updateGridHistory [] x n := by
  obtain ⟨witness,hw⟩ := FiniteLaw.exists_of_prob_pos _ _ hp
  have hwpath := (cfg.trace_pathEvent_iff x n hn witness).mp hw
  constructor
  · intro h
    exact ((cfg.trace_pathEvent_iff x n hn tapes).mp h) n le_rfl
  · intro h
    apply (cfg.trace_pathEvent_iff x n hn tapes).mpr
    intro i hi
    have he : cfg.run tapes n = cfg.run witness n := h.trans (hwpath n le_rfl).symm
    exact (cfg.same_current_same_past tapes witness n i hi he).trans (hwpath i hi)

def historyKernel (n : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V)) :
    FiniteLaw (Option (GridMark N L V)) :=
  if _hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history) then
    ((FiniteLaw.product cfg.laws).conditionOrSelf (fun tapes => cfg.run tapes n = history)).map (fun tapes => cfg.trace tapes n)
  else FiniteLaw.pointMass none

theorem trace_law_eq_historyKernel (n : ℕ) (hn : n ≤ L*N) :
    (FiniteLaw.product cfg.laws).map (fun tapes => fun i : Fin n => cfg.trace tapes i.val) =
      FiniteLaw.timedBatches cfg.historyKernel updateGridHistory n 0 [] := by
  apply FiniteLaw.trace_law_eq_timedBatches
  intro j hj x hp
  have hje : j ≤ L*N := hj.le.trans hn
  have he := cfg.traceEvent_iff_current x j hje hp
  have hc := FiniteLaw.conditionOrSelf_congr (FiniteLaw.product cfg.laws)
    (FiniteLaw.traceEvent cfg.trace x j)
    (fun tapes => cfg.run tapes j = FiniteLaw.scanState updateGridHistory [] x j) he
  have hpos : 0 < (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes j = FiniteLaw.scanState updateGridHistory [] x j) := by
    rwa [← FiniteLaw.prob_congr _ he]
  simp only [Nat.zero_add,historyKernel,dif_pos hpos]
  rw [FiniteLaw.map_mass_probability,← hc]

def finiteHistoryKernel (n : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V)) :
    FiniteLaw (Option (GridMark N L V)) :=
  if n < L*N then cfg.historyKernel n history else FiniteLaw.pointMass none

theorem trace_law_eq_finiteHistoryKernel (n : ℕ) (hn : n ≤ L*N) :
    (FiniteLaw.product cfg.laws).map (fun tapes => fun i : Fin n => cfg.trace tapes i.val) =
      FiniteLaw.timedBatches cfg.finiteHistoryKernel updateGridHistory n 0 [] := by
  rw [cfg.trace_law_eq_historyKernel n hn]
  apply FiniteLaw.timedBatches_congr_range
  intro j hj hjn history
  have hbound : j < L*N := (by simpa using hjn : j < n).trans_le hn
  simp [finiteHistoryKernel,hbound]

end PrivateGridConfig
end MatroidProphetSecretary
