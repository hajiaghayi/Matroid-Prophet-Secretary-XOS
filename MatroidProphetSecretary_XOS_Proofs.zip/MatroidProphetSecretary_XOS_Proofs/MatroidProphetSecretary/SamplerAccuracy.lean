import MatroidProphetSecretary.SamplerStatistics
import MatroidProphetSecretary.ScaledConcentration
import MatroidProphetSecretary.AdaptiveBatches

/-! Simultaneous accuracy of a batch of all common-sampler statistics. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def samplerBatchBad (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N : ℕ) (ε : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) : Prop :=
  ∃ s : StatisticIndex E, ε * samplerTarget laws value M hnonloop s +
      samplerStatisticTolerance N ε (finiteValueVolume laws value G) s <
    |FiniteLaw.sampleAverage (samplerStatistic laws value G M s) x - samplerTarget laws value M hnonloop s|

theorem samplerBatch_failure_bound (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (m : ℕ) (hm : 0 < m)
    (ε : ℝ) (hε0 : 0 < ε) (hε1 : ε ≤ 1) :
    (FiniteLaw.product (fun _ : Fin m => finiteValueSampler laws value G hV)).prob
      (samplerBatchBad laws value G M hnonloop N ε) ≤
        2 * ((N:ℝ)+3) * Real.exp (-(m:ℝ)*ε^2/N) := by
  have h := FiniteLaw.simultaneous_scaled_relative_tail (finiteValueSampler laws value G hV)
    (samplerStatistic laws value G M) (samplerStatisticScale N (finiteValueVolume laws value G))
    (samplerStatisticTolerance N ε (finiteValueVolume laws value G))
    (samplerStatisticScale_pos N hN0 _ hV)
    (fun s x => (samplerStatistic_bounds laws value G hV M hnonloop N hN s x).1)
    (fun s x => (samplerStatistic_bounds laws value G hV M hnonloop N hN s x).2)
    m hm ε hε0 hε1
  simp_rw [samplerStatistic_expect laws value hv G hV M hnonloop] at h
  have he (s : StatisticIndex E) : -(m:ℝ)*ε*
      samplerStatisticTolerance N ε (finiteValueVolume laws value G) s /
        samplerStatisticScale N (finiteValueVolume laws value G) s = -(m:ℝ)*ε^2/N := by
    rw [mul_div_assoc, samplerStatistic_tolerance_ratio N hN0 ε _ hV]
    ring
  simp only [he, sum_const, card_univ, StatisticIndex, Fintype.card_sum, Fintype.card_fin, nsmul_eq_mul] at h
  have hlast : ((3 + Fintype.card E : ℕ) : ℝ) * (2 * Real.exp (-(m:ℝ)*ε^2/N)) ≤
      2 * ((N:ℝ)+3) * Real.exp (-(m:ℝ)*ε^2/N) := by
    have hn : (Fintype.card E : ℝ) ≤ N := by exact_mod_cast hN
    have he0 := Real.exp_nonneg (-(m:ℝ)*ε^2/N)
    push_cast
    nlinarith
  convert h.trans hlast using 1
  unfold FiniteLaw.prob
  congr 1
  funext x
  unfold samplerBatchBad
  split_ifs <;> rfl

theorem samplerBatch_accuracy_of_not_bad (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N : ℕ) (ε : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool)))
    (hx : ¬ samplerBatchBad laws value G M hnonloop N ε x) (s : StatisticIndex E) :
    |FiniteLaw.sampleAverage (samplerStatistic laws value G M s) x - samplerTarget laws value M hnonloop s| ≤
      ε * samplerTarget laws value M hnonloop s + samplerStatisticTolerance N ε (finiteValueVolume laws value G) s := by
  exact le_of_not_gt (fun h => hx ⟨s,h⟩)

end MatroidProphetSecretary
