import MatroidProphetSecretary.ScreenedCandidate
import MatroidProphetSecretary.FiniteAbsence
import MatroidProphetSecretary.SeededAdaptiveProcess

/-! Collision loss when independent finite clocks are conditioned to be distinct. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem iid_clock_pair_equal (N L : ℕ) [Nonempty (Fin L)] (i j : Fin N) (hij : i ≠ j) :
    (FiniteLaw.product (fun _ : Fin N => FiniteLaw.uniform (Fin L))).prob (fun x => x i = x j) = 1/(L:ℝ) := by
  let μ := FiniteLaw.uniform (Fin L)
  unfold FiniteLaw.prob
  rw [← FiniteLaw.product_replace_coordinate (fun _ : Fin N => μ) j (fun x => if x i = x j then 1 else 0)]
  simp only [Function.update_same,Function.update_of_ne hij]
  have hc (v : Fin L) : (FiniteLaw.product (fun _ : Fin N => μ)).expect (fun x => if x i = v then 1 else 0) = 1/(L:ℝ) := by
    rw [FiniteLaw.product_expect_single_coordinate (fun _ : Fin N => μ) i (fun x => if x = v then 1 else 0)]
    simp [FiniteLaw.expect,μ,FiniteLaw.uniform]
  simp_rw [hc]
  exact FiniteLaw.expect_const _ _

theorem iid_clock_collision_bound (N L : ℕ) [Nonempty (Fin L)] :
    (FiniteLaw.product (fun _ : Fin N => FiniteLaw.uniform (Fin L))).prob
      (fun x => ¬ Function.Injective x) ≤ (N:ℝ)^2/L := by
  let μ := FiniteLaw.product (fun _ : Fin N => FiniteLaw.uniform (Fin L))
  let bad := fun ij : Fin N × Fin N => fun x : Fin N → Fin L => ij.1 ≠ ij.2 ∧ x ij.1 = x ij.2
  have he (x : Fin N → Fin L) : ¬ Function.Injective x ↔ ∃ ij, bad ij x := by
    constructor
    · intro hn
      by_contra h
      apply hn
      intro i j hij
      by_contra hne
      exact h ⟨(i,j),hne,hij⟩
    · rintro ⟨ij,hne,heq⟩ hinj
      exact hne (hinj heq)
  have hu := FiniteLaw.union_bound μ bad
  have hp (ij : Fin N × Fin N) : μ.prob (bad ij) ≤ 1/(L:ℝ) := by
    by_cases hij : ij.1 = ij.2
    · simp [bad,hij,FiniteLaw.prob]
    · have h := iid_clock_pair_equal N L ij.1 ij.2 hij
      simpa [bad,hij,μ,FiniteLaw.prob] using h.le
  have hs := sum_le_sum (s := (univ : Finset (Fin N × Fin N))) (fun ij _ => hp ij)
  have hr : μ.prob (fun x => ¬ Function.Injective x) = μ.prob (fun x => ∃ ij, bad ij x) := FiniteLaw.prob_congr μ he
  rw [hr]
  apply hu.trans
  convert hs using 1
  simp [Fintype.card_prod,pow_two]
  <;> ring

theorem FiniteLaw.conditioning_expected_loss {Ω : Type*} [Fintype Ω]
    (μ : FiniteLaw Ω) (P : Ω → Prop) (f : Ω → ℝ) (B : ℝ)
    (hf0 : ∀ x, 0 ≤ f x) (hfB : ∀ x, f x ≤ B) :
    μ.expect f-(μ.conditionOrSelf P).expect f ≤ B*μ.prob (fun x => ¬ P x) := by
  have hpoint (x : Ω) : f x-(if P x then f x else 0) ≤ B*(if ¬ P x then 1 else 0) := by
    by_cases hx : P x <;> simp [hx,hfB x]
  have he := μ.expect_mono hpoint
  rw [FiniteLaw.expect_sub,FiniteLaw.expect_const_mul] at he
  have hw := FiniteLaw.conditionOrSelf_weighted_expect μ P f
  rw [← hw] at he
  have hc := (μ.conditionOrSelf P).expect_nonneg hf0
  have hp := μ.prob_le_one P
  have hm := mul_nonneg (sub_nonneg.mpr hp) hc
  change _ ≤ B*μ.prob (fun x => ¬ P x) at he
  nlinarith only [he,hm]

theorem FiniteLaw.conditionOrSelf_irrel {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) (P : Ω → Prop)
    (d₁ d₂ : DecidablePred P) : @FiniteLaw.conditionOrSelf Ω _ μ P d₁ = @FiniteLaw.conditionOrSelf Ω _ μ P d₂ := by
  cases Subsingleton.elim d₁ d₂
  rfl

theorem FiniteLaw.prob_irrel {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) (P : Ω → Prop)
    (d₁ d₂ : DecidablePred P) : @FiniteLaw.prob Ω _ μ P d₁ = @FiniteLaw.prob Ω _ μ P d₂ := by
  cases Subsingleton.elim d₁ d₂
  rfl

theorem distinct_clock_conditioning_loss (N L : ℕ) [Nonempty (Fin L)]
    (f : (Fin N → Fin L) → ℝ) (B : ℝ) (hB : 0 ≤ B) (hf0 : ∀ x, 0 ≤ f x) (hfB : ∀ x, f x ≤ B) :
    let μ := FiniteLaw.product (fun _ : Fin N => FiniteLaw.uniform (Fin L))
    μ.expect f-(μ.conditionOrSelf Function.Injective).expect f ≤ B*((N:ℝ)^2/L) := by
  let μ := FiniteLaw.product (fun _ : Fin N => FiniteLaw.uniform (Fin L))
  let P := fun x : Fin N → Fin L => Function.Injective x
  have hb : B*(@FiniteLaw.prob _ _ μ (fun x => ¬ P x)
      (fun x => @instDecidableNot (P x) (Classical.propDecidable (P x)))) ≤ B*((N:ℝ)^2/L) := by
    convert mul_le_mul_of_nonneg_left (iid_clock_collision_bound N L) hB using 1
    congr 1
    apply FiniteLaw.prob_irrel
  have he := (FiniteLaw.conditioning_expected_loss μ P f B hf0 hfB).trans hb
  convert he using 1
  congr 2
  apply FiniteLaw.conditionOrSelf_irrel

end MatroidProphetSecretary
