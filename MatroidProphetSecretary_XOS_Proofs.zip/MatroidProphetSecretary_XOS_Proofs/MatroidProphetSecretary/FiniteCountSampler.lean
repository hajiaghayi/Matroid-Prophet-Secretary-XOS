import MatroidProphetSecretary.FiniteKernelApproximation
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Fintype.Sigma

/-! Exact realization of integer categorical counts by a bounded uniform seed. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

def countSeedEquiv (counts : Ω → ℕ) (N : ℕ) (htotal : ∑ x, counts x = N) :
    Fin N ≃ (Σ x : Ω, Fin (counts x)) :=
  Fintype.equivOfCardEq (by simpa [Fintype.card_sigma] using htotal.symm)

def countSeedSample (counts : Ω → ℕ) (N : ℕ) (htotal : ∑ x, counts x = N) (seed : Fin N) : Ω :=
  (countSeedEquiv counts N htotal seed).1

def countSampleLaw (counts : Ω → ℕ) (N : ℕ) (hN : 0 < N) (htotal : ∑ x, counts x = N) : FiniteLaw Ω :=
  letI : Nonempty (Fin N) := ⟨⟨0,hN⟩⟩
  (uniform (Fin N)).map (countSeedSample counts N htotal)

theorem countSampleLaw_expect (counts : Ω → ℕ) (N : ℕ) (hN : 0 < N) (htotal : ∑ x, counts x = N)
    (f : Ω → ℝ) :
    (countSampleLaw counts N hN htotal).expect f = ∑ x, (counts x : ℝ)/N*f x := by
  rw [countSampleLaw,map_expect]
  have h := (countSeedEquiv counts N htotal).sum_comp
    (fun y : Σ x : Ω, Fin (counts x) => (1/(N:ℝ))*f y.1)
  simp only [expect,uniform,Fintype.card_fin]
  rw [show (∑ seed : Fin N, (1/(N:ℝ))*f (countSeedSample counts N htotal seed)) =
      ∑ y : Σ x : Ω, Fin (counts x), (1/(N:ℝ))*f y.1 from h]
  rw [Fintype.sum_sigma]
  apply sum_congr rfl
  intro x hx
  simp only [sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul]
  ring

theorem countSampleLaw_mass (counts : Ω → ℕ) (N : ℕ) (hN : 0 < N) (htotal : ∑ x, counts x = N)
    (x : Ω) : (countSampleLaw counts N hN htotal).mass x = (counts x : ℝ)/N := by
  rw [mass_eq_expect_indicator,countSampleLaw_expect]
  simp

theorem fairBits_realize_counts (counts : Ω → ℕ) (K : ℕ) (htotal : ∑ x, counts x = 2^K) :
    ∃ sample : Fin (2^K) → Ω, ∀ x,
      ((uniform (Fin (2^K))).map sample).mass x = (counts x : ℝ)/(2^K:ℕ) := by
  refine ⟨countSeedSample counts (2^K) htotal,?_⟩
  intro x
  exact countSampleLaw_mass counts (2^K) (pow_pos (by omega) _) htotal x

end MatroidProphetSecretary.FiniteLaw
