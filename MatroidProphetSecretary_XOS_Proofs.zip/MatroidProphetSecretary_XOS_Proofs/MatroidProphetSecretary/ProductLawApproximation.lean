import MatroidProphetSecretary.ResidualValueLaw
import MatroidProphetSecretary.FiniteKernelApproximation

/-! Coordinatewise finite-prior approximations control every bounded observable of the product. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

theorem product_expect_approximation {A : Type*} [Fintype A] (n : ℕ)
    (laws other : Fin n → FiniteLaw A) (err B : ℝ) (hB : 0 ≤ B)
    (hstep : ∀ e, massDistance (laws e) (other e) ≤ err)
    (f : (Fin n → A) → ℝ) (hf : ∀ x, |f x| ≤ B) :
    |(product laws).expect f-(product other).expect f| ≤ n*err*B := by
  induction n with
  | zero =>
    have he (x : Fin 0 → A) : x = Fin.elim0 := by funext i; exact Fin.elim0 i
    have hc : f = fun _ => f Fin.elim0 := by funext x; rw [he x]
    rw [hc]
    simp only [expect_const, Nat.cast_zero,zero_mul,sub_self,abs_zero,le_refl]
  | succ n ih =>
    rw [product_expect_fin_succ,product_expect_fin_succ]
    let F := fun a => (product (fun e : Fin n => laws e.succ)).expect (fun x => f (Fin.cons a x))
    let G := fun a => (product (fun e : Fin n => other e.succ)).expect (fun x => f (Fin.cons a x))
    change |(laws 0).expect F-(other 0).expect G| ≤ _
    have hlocal : |(laws 0).expect F-(other 0).expect F| ≤ err*B := by
      have h := expect_difference_massDistance (laws 0) (other 0) F B
        (fun a => expect_abs_bound _ _ B (fun x => hf (Fin.cons a x)))
      exact h.trans (by nlinarith [hstep 0])
    have hfuture : |(other 0).expect F-(other 0).expect G| ≤ n*err*B := by
      apply expect_difference_functions
      intro a
      exact ih (fun e => laws e.succ) (fun e => other e.succ) (fun e => hstep e.succ)
        (fun x => f (Fin.cons a x)) (fun x => hf (Fin.cons a x))
    calc
      _ ≤ |(laws 0).expect F-(other 0).expect F|+|(other 0).expect F-(other 0).expect G| := abs_sub_le _ _ _
      _ ≤ err*B+n*err*B := add_le_add hlocal hfuture
      _ = (↑(n+1):ℝ)*err*B := by push_cast; ring

end MatroidProphetSecretary.FiniteLaw
