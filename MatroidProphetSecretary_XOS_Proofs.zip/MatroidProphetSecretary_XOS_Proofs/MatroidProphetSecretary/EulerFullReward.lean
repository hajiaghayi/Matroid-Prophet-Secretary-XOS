import MatroidProphetSecretary.EulerEarlyStatistics
import MatroidProphetSecretary.EulerLateReward
import MatroidProphetSecretary.AdaptiveTerminalSplit

/-! The full two-phase reward bound for the finite process with physical history-dependent rates. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem euler_full_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1) (hcut : cfg.cut ≤ L) :
    let p := (1/(L:ℝ))*(1/cfg.q)
    let alpha := (1-p)^cfg.cut
    let beta := omega*(1-(1-(1/(L:ℝ))*((1/cfg.q)/omega))^(L-cfg.cut))
    (1-alpha)*virtualTotalLiveValue (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M)+
      beta*((1-p)*alpha*virtualTotalLiveValue (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M)+
        alpha*(1-alpha)*virtualCurrentOverlap (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M)) ≤
    (FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
      cfg.eulerBlockUpdate L (0,[])).expect
      (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x).2) := by
  dsimp only
  let batch := cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le
  let beta := omega*(1-(1-(1/(L:ℝ))*((1/cfg.q)/omega))^(L-cfg.cut))
  let weighted := fun state : BlockState N V =>
    virtualWeightedLiveValue (FiniteLaw.product cfg.reference) M base hbase value
      (fun e => 1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
        ((1/(L:ℝ))*(1/cfg.q)) cfg.cut state.2 e-((1/(L:ℝ))*(1/cfg.q)))
      (recordReplay M base hbase value state.2)
  have hN : (1:ℝ) ≤ N := by exact_mod_cast cfg.labels_pos
  have hnonneg : 0 ≤ (1/(L:ℝ))*((1/cfg.q)/omega) :=
    mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)
  have hstep : (1/(L:ℝ))*((1/cfg.q)/omega) ≤ 1 := by nlinarith
  have hbeta : 0 ≤ beta := mul_nonneg homega.le
    (sub_nonneg.mpr (pow_le_one₀ (sub_nonneg.mpr hstep) (sub_le_self _ hnonneg)))
  have hinit : cfg.blockReachable 0 (0,[]) := by
    constructor
    · simp
    · simpa only [cfg.initial_history_probability] using (zero_lt_one : (0:ℝ) < 1)
  have hfuture :
      (FiniteLaw.adaptiveBatches batch cfg.eulerBlockUpdate cfg.cut (0,[])).expect
        (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x).2+
          beta*weighted (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x)) ≤
      (FiniteLaw.adaptiveBatches batch cfg.eulerBlockUpdate L (0,[])).expect
        (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate L (0,[]) x).2) := by
    have hsplit := FiniteLaw.adaptive_terminal_add batch cfg.eulerBlockUpdate cfg.cut (L-cfg.cut) (0,[])
      (fun state => recordReward value state.2)
    rw [Nat.add_sub_of_le hcut] at hsplit
    rw [hsplit]
    apply FiniteLaw.expect_mono_support
    intro x hx
    let state := FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x
    have hs : cfg.blockReachable cfg.cut state := by
      simpa only [Nat.zero_add] using cfg.euler_trajectory_reachable M base hbase value hlive
        hsmall omega homega homega1 hlower hbudget cfg.cut 0 (by omega) (0,[]) hinit x hx
    have hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (cfg.cut*N) = state.2) := by
      simpa only [hs.1] using hs.2
    have hlate := cfg.euler_late_reward M base hbase value hv hlive hsmall omega homega homega1 hlower hbudget
      (L-cfg.cut) (by omega) state.2 hp
    simpa only [← hs.1,Prod.mk.eta] using hlate
  rw [FiniteLaw.expect_add,FiniteLaw.expect_const_mul] at hfuture
  have hearly := cfg.euler_early_reward M base hbase value hv hsmall omega homega homega1 hlower hbudget.le hcut
  have hweighted := cfg.euler_early_weighted_value M base hbase value hv hsmall omega homega homega1 hlower hbudget.le hcut
  exact (add_le_add hearly (mul_le_mul_of_nonneg_left hweighted hbeta)).trans hfuture

end MatroidProphetSecretary.PrivateGridConfig
