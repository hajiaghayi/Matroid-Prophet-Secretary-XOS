import MatroidProphetSecretary.FiniteProbability
import Mathlib.Logic.Equiv.Prod
import Mathlib.Data.Fintype.Prod
import Mathlib.Data.Fintype.BigOperators

/-! Splitting independent finite coordinates into two arbitrary blocks. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)]

theorem product_mass_split (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (x : (∀ i : {i // p i}, V i) × (∀ i : {i // ¬p i}, V i)) :
    (product laws).mass ((Equiv.piEquivPiSubtypeProd p V).symm x) =
      (product (fun i : {i // p i} => laws i)).mass x.1 *
      (product (fun i : {i // ¬p i} => laws i)).mass x.2 := by
  unfold product
  dsimp
  rw [← Fintype.prod_subtype_mul_prod_subtype p]
  congr 1 <;> apply prod_congr rfl <;> intro i hi <;>
    simp [Equiv.piEquivPiSubtypeProd, i.property]

theorem product_expect_split (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (f : (∀ i, V i) → ℝ) :
    (product laws).expect f =
      (product (fun i : {i // p i} => laws i)).expect (fun x =>
        (product (fun i : {i // ¬p i} => laws i)).expect (fun y =>
          f ((Equiv.piEquivPiSubtypeProd p V).symm (x, y)))) := by
  unfold expect
  rw [← (Equiv.piEquivPiSubtypeProd p V).symm.sum_comp
    (fun x => (product laws).mass x * f x)]
  simp_rw [product_mass_split]
  rw [Fintype.sum_prod_type]
  simp only [mul_sum, mul_assoc]

theorem product_expect_block_mul (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (f : (∀ i : {i // p i}, V i) → ℝ) (g : (∀ i : {i // ¬p i}, V i) → ℝ) :
    (product laws).expect (fun x => f (fun i => x i) * g (fun i => x i)) =
      (product (fun i : {i // p i} => laws i)).expect f *
      (product (fun i : {i // ¬p i} => laws i)).expect g := by
  rw [product_expect_split laws p]
  have hid : ∀ x y,
      f (fun i : {i // p i} => (Equiv.piEquivPiSubtypeProd p V).symm (x, y) i) *
        g (fun i : {i // ¬p i} => (Equiv.piEquivPiSubtypeProd p V).symm (x, y) i) = f x * g y := by
    intro x y
    have hx : (fun i : {i // p i} => (Equiv.piEquivPiSubtypeProd p V).symm (x, y) i) = x := by
      funext i
      simp [Equiv.piEquivPiSubtypeProd, i.property]
    have hy : (fun i : {i // ¬p i} => (Equiv.piEquivPiSubtypeProd p V).symm (x, y) i) = y := by
      funext i
      simp [Equiv.piEquivPiSubtypeProd, i.property]
    rw [hx, hy]
  simp_rw [hid]
  simp_rw [expect_const_mul]
  exact expect_mul_const _ _ _

theorem product_prob_block_and (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (A : (∀ i : {i // p i}, V i) → Prop) (B : (∀ i : {i // ¬p i}, V i) → Prop) :
    (product laws).prob (fun x => A (fun i => x i) ∧ B (fun i => x i)) =
      (product (fun i : {i // p i} => laws i)).prob A *
      (product (fun i : {i // ¬p i} => laws i)).prob B := by
  have hid : ∀ x : ∀ i, V i,
      (if A (fun i => x i) ∧ B (fun i => x i) then (1 : ℝ) else 0) =
        (if A (fun i => x i) then 1 else 0) * (if B (fun i => x i) then 1 else 0) := by
    intro x
    split_ifs <;> simp_all
  unfold prob
  simp_rw [hid]
  exact product_expect_block_mul laws p (fun x => if A x then 1 else 0)
    (fun y => if B y then 1 else 0)

end MatroidProphetSecretary.FiniteLaw
