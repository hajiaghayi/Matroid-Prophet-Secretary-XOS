import MatroidProphetSecretary.ControllerBound

namespace MatroidProphetSecretary

/-- Lemma 22: the concrete witness satisfies all welfare parameter
conditions. This theorem has no mathematical hypotheses. -/
theorem parameter_choice :
    (0 < epsilon ∧ epsilon < delta ∧ delta ≤ 1 / 8 ∧ epsilon ≤ 1 / 10 ∧
      0 < theta ∧ theta < 1 ∧ 0 < rho ∧ rho < 1 ∧ eta > 10 * epsilon ∧
      rho = epsilon ^ 3) ∧
    (∀ q ∈ interval,
      (1 / 2 ≤ discount q ∧ discount q ≤ 3 / 4) ∧
      discount q * (1 + 4 * delta) < 1 ∧
      stationaryRatio q - 20 * epsilon < 1 ∧
      0 < omega q ∧
      discount q < phi q (overlapCutoff q) ∧
      thresholdFactor q * q * (stationaryRatio q + hPlus + 20 * epsilon) + 2 * epsilon <
        surplusLower q) ∧
    (∀ q ∈ interval, 3 * delta ≤ |q - 1| → discount q < phi q 0) ∧
    targetRatio < beta := by
  refine ⟨basic_constants, ?_, ?_, final_gain⟩
  · intro q hq
    exact ⟨discount_basic hq, potential_bound_factor hq, (stationary_cutoff_bounds hq).2,
      lt_trans (by norm_num) (omega_positive hq), stability_parameter_condition hq,
      threshold_parameter_condition hq⟩
  · intro q hq hguard
    exact guard_parameter_condition hq hguard

end MatroidProphetSecretary
