import MatroidProphetSecretary.OptionalLaw
import MatroidProphetSecretary.ReplayMortality
import MatroidProphetSecretary.AdaptiveExpectation
import Mathlib.Data.Fintype.Prod

/-! A finite virtual exchange transition with its explicit marked-event law and credited reward. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

abbrev VirtualState (M : Matroid E) := Σ A : Finset E, ExchangeHistory M A

def virtualLive (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (y : W) : Finset E :=
  s.2.liveSet (base y) (hbase y) (value y)

def virtualUpdate (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) : Option (E × W) → VirtualState M
  | none => s
  | some (e,y) => if he : e ∈ virtualLive M base hbase value s y then
      let old := s.2.replay (base y) (hbase y)
      ⟨insert e s.1,s.2.snoc old.basis old.isBase old.contains e
        (mem_sdiff.mp (mem_filter.mp he).1).1 (mem_sdiff.mp (mem_filter.mp he).1).2⟩
      else s

def virtualStepWeight (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M)
    (dt : ℝ) (rate : E → ℝ) (event : E × W) : ℝ :=
  if event.1 ∈ virtualLive M base hbase value s event.2 then dt*rate event.1*μ.mass event.2 else 0

theorem virtualStepWeight_nonneg (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M)
    (dt : ℝ) (rate : E → ℝ) (hdt : 0 ≤ dt) (hrate : ∀ e, 0 ≤ rate e) (event : E × W) :
    0 ≤ virtualStepWeight μ M base hbase value s dt rate event := by
  unfold virtualStepWeight
  split_ifs
  · exact mul_nonneg (mul_nonneg hdt (hrate _)) (μ.nonneg _)
  · exact le_rfl

theorem virtualStepWeight_total_le (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M)
    (dt : ℝ) (rate : E → ℝ) (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate : ∀ e, rate e ≤ R) :
    (∑ event, virtualStepWeight μ M base hbase value s dt rate event) ≤ dt*R*Fintype.card E := by
  rw [Fintype.sum_prod_type]
  calc
    _ ≤ ∑ _e : E, ∑ y : W, dt*R*μ.mass y := by
      apply sum_le_sum
      intro e he
      apply sum_le_sum
      intro y hy
      unfold virtualStepWeight
      split_ifs
      · exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (hrate e) hdt) (μ.nonneg y)
      · exact mul_nonneg (mul_nonneg hdt hR) (μ.nonneg y)
    _ = dt*R*Fintype.card E := by simp [← mul_sum,μ.total]; ring

def virtualStepLaw (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M)
    (dt : ℝ) (rate : E → ℝ) (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R)
    (hrate0 : ∀ e, 0 ≤ rate e) (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) :
    FiniteLaw (Option (E × W)) :=
  FiniteLaw.optionalLaw (virtualStepWeight μ M base hbase value s dt rate)
    (virtualStepWeight_nonneg μ M base hbase value s dt rate hdt hrate0)
    ((virtualStepWeight_total_le μ M base hbase value s dt rate R hdt hR hrate1).trans hsmall)

def virtualCredit (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) : Option (E × W) → ℝ
  | none => 0
  | some (e,y) => if e ∈ virtualLive M base hbase value s y then value y e else 0

def virtualLiveValue (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M) (e : E) : ℝ :=
  μ.expect (fun y => if e ∈ virtualLive M base hbase value s y then value y e else 0)

theorem virtualStep_expected_credit (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M)
    (dt : ℝ) (rate : E → ℝ) (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R)
    (hrate0 : ∀ e, 0 ≤ rate e) (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) :
    (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
      (virtualCredit M base hbase value s) =
      dt * ∑ e, rate e * virtualLiveValue μ M base hbase value s e := by
  rw [virtualStepLaw,FiniteLaw.optionalLaw_expect_zero _ _ _ _ rfl,Fintype.sum_prod_type]
  simp only [virtualLiveValue,FiniteLaw.expect,mul_sum]
  apply sum_congr rfl
  intro e he
  apply sum_congr rfl
  intro y hy
  simp only [virtualStepWeight,virtualCredit]
  split_ifs <;> ring

end MatroidProphetSecretary
