import MatroidProphetSecretary.ContractionPrices

/-! The full surplus decomposition (Lemma 7) for finite value laws. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

def priceOptimum (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) : ℝ :=
  optimum M (contractionPrice μ M v hnonloop)

def priceGap (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) : ℝ :=
  expectedOptimum μ M v - priceOptimum μ M v hnonloop

def cappedValues (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) (w : Ω) (e : E) : ℝ :=
  min (v w e) (b * contractionPrice μ M v hnonloop e)

def capDeficit (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) : ℝ :=
  b * priceOptimum μ M v hnonloop - expectedOptimum μ M (cappedValues μ M v hnonloop b)

def thresholdSurplus (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (p : E → ℝ) (b : ℝ) : ℝ :=
  ∑ e, μ.expect (fun w => posPart (v w e - b * p e))

def remainingCapSurplus (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) : ℝ :=
  ∑ e, μ.expect (fun w => posPart
    (cappedValues μ M v hnonloop b w e - exclusionThreshold M (v w) e (hnonloop e)))

theorem priceGap_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hv : ∀ w e, 0 ≤ v w e) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    0 ≤ priceGap μ M v hnonloop :=
  sub_nonneg.mpr (optimum_contractionPrice_le_expectedOptimum μ M v hv hnonloop)

theorem capDeficit_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) (hb : 0 ≤ b) :
    0 ≤ capDeficit μ M v hnonloop b := by
  apply sub_nonneg.mpr
  have hpoint : ∀ w, optimum M (cappedValues μ M v hnonloop b w) ≤
      b * priceOptimum μ M v hnonloop := by
    intro w
    calc
      _ ≤ optimum M (fun e => b * contractionPrice μ M v hnonloop e) :=
        optimum_mono M (fun e => min_le_right _ _)
      _ = _ := optimum_smul M _ b hb
  simpa only [FiniteLaw.expect_const] using μ.expect_mono hpoint

theorem thresholdSurplus_antitone (μ : FiniteLaw Ω) (v : Ω → E → ℝ)
    {p p' : E → ℝ} (hpp : ∀ e, p e ≤ p' e) (b : ℝ) (hb : 0 ≤ b) :
    thresholdSurplus μ v p' b ≤ thresholdSurplus μ v p b := by
  apply sum_le_sum
  intro e he
  apply μ.expect_mono
  intro w
  exact max_le_max (sub_le_sub_left (mul_le_mul_of_nonneg_left (hpp e) hb) _) le_rfl

theorem price_surplus_lower (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) :
    (1 - b) * expectedOptimum μ M v + b * priceGap μ M v hnonloop +
      capDeficit μ M v hnonloop b ≤ thresholdSurplus μ v (contractionPrice μ M v hnonloop) b := by
  have h := expected_cap_decomposition μ M v (fun e => b * contractionPrice μ M v hnonloop e)
  unfold priceGap capDeficit cappedValues thresholdSurplus
  linarith

theorem deletion_surplus_split_at_prices (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) :
    deletionSurplus μ M v ≤ thresholdSurplus μ v (contractionPrice μ M v hnonloop) b +
      remainingCapSurplus μ M v hnonloop b := by
  unfold deletionSurplus thresholdSurplus remainingCapSurplus
  rw [← sum_add_distrib]
  apply sum_le_sum
  intro e he
  rw [← μ.expect_add]
  apply μ.expect_mono
  intro w
  rw [(deletion_contraction_identities M (v w) e (hnonloop e)).1]
  exact surplus_split (v w e) (exclusionThreshold M (v w) e (hnonloop e))
    (b * contractionPrice μ M v hnonloop e)

/-- All three inequalities of (3.8), with quantities defined from the instance. -/
theorem matroid_surplus_decomposition (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) (hb : 0 ≤ b) :
    thresholdSurplus μ v (contractionPrice μ M v hnonloop) b ≤
      thresholdSurplus μ v (meanThreshold μ M v hnonloop) b ∧
    (1 - b) * expectedOptimum μ M v + b * priceGap μ M v hnonloop +
      capDeficit μ M v hnonloop b ≤ thresholdSurplus μ v (contractionPrice μ M v hnonloop) b ∧
    deletionSurplus μ M v ≤ thresholdSurplus μ v (contractionPrice μ M v hnonloop) b +
      remainingCapSurplus μ M v hnonloop b :=
  ⟨thresholdSurplus_antitone μ v (meanThreshold_le_contractionPrice μ M v hnonloop) b hb,
    price_surplus_lower μ M v hnonloop b, deletion_surplus_split_at_prices μ M v hnonloop b⟩

end MatroidProphetSecretary
