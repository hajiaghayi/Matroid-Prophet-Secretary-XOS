import MatroidProphetSecretary.BernoulliPathDerivative
import MatroidProphetSecretary.SaturatedTail
import MatroidProphetSecretary.RankInequality

/-! The one-sided derivative inequalities of Lemma 3 at a single value layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def referenceLayerRank (M : Matroid E) (p : E → ℝ) (q : ℝ) : ℝ :=
  bernoulliEval (fun e => scaledTail (p e) q) (rankObservable M)

def referenceLayerRho (M : Matroid E) (p : E → ℝ) (q : ℝ) (e : E) : ℝ :=
  bernoulliEval (fun f => scaledTail (p f) q) (replaceDifference e (rankObservable M))

def referenceLayerD (M : Matroid E) (p : E → ℝ) (q : ℝ) : ℝ :=
  ∑ e, scaledTail (p e) q * referenceLayerRho M p q e

def referenceLayerH (M : Matroid E) (p : E → ℝ) (q : ℝ) : ℝ :=
  ∑ e, (scaledTail (p e) q)^2 * referenceLayerRho M p q e

def referenceLayerRightDerivative (M : Matroid E) (p : E → ℝ) (q : ℝ) : ℝ :=
  ∑ e, scaledTailRightSlope (p e) q * referenceLayerRho M p q e

def referenceLayerLeftDerivative (M : Matroid E) (p : E → ℝ) (q : ℝ) : ℝ :=
  ∑ e, scaledTailLeftSlope (p e) q * referenceLayerRho M p q e

theorem referenceLayerRank_continuous (M : Matroid E) (p : E → ℝ) :
    Continuous (referenceLayerRank M p) :=
  (continuous_bernoulliEval (rankObservable M)).comp
    (continuous_pi (fun e => scaledTail_continuous (p e)))

theorem referenceLayerRank_right_derivative (M : Matroid E) (p : E → ℝ)
    (hp : ∀ e, 0 ≤ p e) (q : ℝ) :
    HasDerivWithinAt (referenceLayerRank M p) (referenceLayerRightDerivative M p q) (Set.Ici q) q :=
  bernoulliEval_hasDerivWithinAt _ _ _ _ _ (fun e => scaledTail_right_derivative (p e) q (hp e))

theorem referenceLayerRank_left_derivative (M : Matroid E) (p : E → ℝ)
    (hp : ∀ e, 0 ≤ p e) (q : ℝ) :
    HasDerivWithinAt (referenceLayerRank M p) (referenceLayerLeftDerivative M p q) (Set.Iic q) q :=
  bernoulliEval_hasDerivWithinAt _ _ _ _ _ (fun e => scaledTail_left_derivative (p e) q (hp e))

theorem referenceLayerRho_nonneg (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q : ℝ) (hq : 0 ≤ q) (e : E) :
    0 ≤ referenceLayerRho M p q e := by
  unfold referenceLayerRho
  rw [bernoulliEval_eq_expect _ (fun f => (scaledTail_bounds (p f) q (hp f) hq).1)
    (fun f => (scaledTail_bounds (p f) q (hp f) hq).2)]
  apply FiniteLaw.expect_nonneg
  intro x
  rw [rank_replaceDifference M hground]
  split_ifs <;> norm_num

/-- The complete derivative sandwich of Lemma 3 at a Bernoulli layer. -/
theorem referenceLayer_derivative_bounds (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q : ℝ) (hq : 0 ≤ q) :
    referenceLayerD M p q - referenceLayerH M p q ≤ q * referenceLayerRightDerivative M p q ∧
      q * referenceLayerRightDerivative M p q ≤ q * referenceLayerLeftDerivative M p q ∧
      q * referenceLayerLeftDerivative M p q ≤ referenceLayerD M p q := by
  have hρ := referenceLayerRho_nonneg M hground p hp q hq
  have hb := fun e => scaledTail_derivative_bounds (p e) q (hp e) hq
  constructor
  · unfold referenceLayerD referenceLayerH referenceLayerRightDerivative
    rw [← sum_sub_distrib, mul_sum]
    apply sum_le_sum
    intro e he
    have h := mul_le_mul_of_nonneg_right (hb e).1 (hρ e)
    nlinarith
  constructor
  · unfold referenceLayerRightDerivative referenceLayerLeftDerivative
    rw [mul_sum, mul_sum]
    apply sum_le_sum
    intro e he
    have h := mul_le_mul_of_nonneg_right (hb e).2.1 (hρ e)
    nlinarith
  · unfold referenceLayerLeftDerivative referenceLayerD
    rw [mul_sum]
    apply sum_le_sum
    intro e he
    have h := mul_le_mul_of_nonneg_right (hb e).2.2 (hρ e)
    nlinarith

end MatroidProphetSecretary
