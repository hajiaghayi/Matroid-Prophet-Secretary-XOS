import MatroidProphetSecretary.BinnedValueLayers
import MatroidProphetSecretary.FiniteIntegrals

/-! The normalizing volume of nonempty layers is the expected largest value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def maximumValue (v : E → ℝ) : ℝ :=
  (insert 0 (univ.image v)).max' ⟨0, mem_insert_self _ _⟩

theorem maximumValue_nonneg (v : E → ℝ) : 0 ≤ maximumValue v :=
  (insert 0 (univ.image v)).le_max' 0 (mem_insert_self _ _)

theorem value_le_maximumValue (v : E → ℝ) (e : E) : v e ≤ maximumValue v :=
  (insert 0 (univ.image v)).le_max' (v e) (mem_insert_of_mem (mem_image.mpr ⟨e, mem_univ _, rfl⟩))

theorem maximumValue_gt_iff (v : E → ℝ) (z : ℝ) (hz : 0 ≤ z) :
    z < maximumValue v ↔ ∃ e, z < v e := by
  constructor
  · intro h
    have hm : maximumValue v ∈ insert 0 (univ.image v) := max'_mem _ _
    rcases mem_insert.mp hm with hm | hm
    · exact False.elim ((not_lt_of_ge hz) (hm ▸ h))
    · obtain ⟨e, he, hv⟩ := mem_image.mp hm
      exact ⟨e, hv ▸ h⟩
  · rintro ⟨e, he⟩
    exact he.trans_le (value_le_maximumValue v e)

theorem maximumValue_le_optimum (M : Matroid E) (v : E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) : maximumValue v ≤ optimum M v := by
  apply max'_le
  intro y hy
  rcases mem_insert.mp hy with rfl | hy
  · exact optimum_nonneg M v
  · obtain ⟨e, he, rfl⟩ := mem_image.mp hy
    have h : weight v {e} ≤ optimum M v := weight_le_optimumOver _ _ v (by simpa using hnonloop e)
    simpa [weight] using h

theorem optimum_le_card_maximumValue (M : Matroid E) (v : E → ℝ) :
    optimum M v ≤ Fintype.card E * maximumValue v := by
  apply optimumOver_le
  intro I hI
  calc
    weight v I ≤ ∑ e ∈ I, maximumValue v := sum_le_sum (fun e he => value_le_maximumValue v e)
    _ = I.card * maximumValue v := by simp
    _ ≤ Fintype.card E * maximumValue v := mul_le_mul_of_nonneg_right
      (by exact_mod_cast card_le_univ I) (maximumValue_nonneg v)

variable {V : E → Type*} [∀ e, Fintype (V e)]

theorem nonempty_activity_expectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (z : ℝ) :
    positiveActivityExpectation laws value (fun _ x => if ∃ e, x e = true then 1 else 0) z =
      (FiniteLaw.product laws).expect (fun x => positiveLayer (maximumValue (coordinateValues value x)) z) := by
  unfold positiveActivityExpectation
  by_cases hz : 0 < z
  · rw [if_pos hz]
    unfold activityLaws
    rw [FiniteLaw.product_map_expect]
    congr 1
    funext x
    simp only [decide_eq_true_eq, positiveLayer, hz, true_and,
      maximumValue_gt_iff _ z hz.le, coordinateValues]
  · simp [hz, positiveLayer]

theorem nonempty_activity_integrable (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) :
    Integrable (positiveActivityExpectation laws value (fun _ x => if ∃ e, x e = true then 1 else 0)) := by
  rw [funext (nonempty_activity_expectation laws value)]
  exact (FiniteLaw.product laws).integrable_expect _ (fun x => positiveLayer_integrable _)

theorem nonemptyLayerVolume_eq_expected_maximum (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) :
    nonemptyLayerVolume (heightBinWidth value G) (heightBinLaws laws value G) =
      (FiniteLaw.product laws).expect (fun x => maximumValue (coordinateValues value x)) := by
  have h := positiveActivityExpectation_bins laws value G
    (fun _ x => if ∃ e, x e = true then 1 else 0) (by intro p; simp)
    (nonempty_activity_integrable laws value)
  change _ = nonemptyLayerVolume (heightBinWidth value G) (heightBinLaws laws value G) at h
  rw [← h]
  simp only [nonempty_activity_expectation laws value]
  rw [FiniteLaw.integral_expect _ _ (fun x => positiveLayer_integrable _)]
  simp only [integral_positiveLayer _ (maximumValue_nonneg _)]

end MatroidProphetSecretary
