import MatroidProphetSecretary.PhysicalSparseGenerator

/-! The sparse physical round credits precisely the value in its matroid exchange kernel. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

def gridMarkCredit (value : (Fin N → Option V) → Fin N → ℝ) : Option (GridMark N L V) → ℝ
  | none => 0
  | some mark => value mark.2.2 mark.1

theorem recordReward_updateGridHistory (value : (Fin N → Option V) → Fin N → ℝ)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (mark : Option (GridMark N L V)) :
    recordReward value (updateGridHistory history mark) = recordReward value history+gridMarkCredit value mark := by
  cases mark <;> simp [updateGridHistory,appendOptional,gridMarkRecord,recordReward,gridMarkCredit,List.map_append,List.sum_append]

namespace PrivateGridConfig

variable (cfg : PrivateGridConfig N L V)

theorem historyKernel_mark_credit (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history)) :
    (cfg.historyKernel n history).expect (gridMarkCredit value) =
      ((1/(L:ℝ))*cfg.historyRate history n)*
        virtualLiveValue (FiniteLaw.product cfg.reference) M base hbase value
          (recordReplay M base hbase value history) (gridLabel N cfg.labels_pos n) := by
  by_cases hseen : gridLabel N cfg.labels_pos n ∈ recordLabels history
  · rw [cfg.historyKernel_seen n hn history hseen,FiniteLaw.pointMass_expect]
    have hvalid := cfg.reachable_history_valid M base hbase value hlive history n hn.le hp
    have hnot (y : Fin N → Option V) :
        gridLabel N cfg.labels_pos n ∉ virtualLive M base hbase value (recordReplay M base hbase value history) y := by
      intro hmem
      exact hvalid.fresh M base hbase value history _ y hmem hseen
    simp [gridMarkCredit,virtualLiveValue,hnot]
  · rw [cfg.historyKernel_expect_zero history n hn hp hseen _ rfl]
    simp only [gridMarkCredit,hlive,virtualLiveValue]

theorem sparsePhysicalRound_expected_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1)
    (hsingle : (1/(L:ℝ))*((1/cfg.q)/omega) < 1)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (clock.val*N) = history)) :
    (cfg.sparsePhysicalRound hsmall omega homega homega1 hlower (clock.val*N) history hbudget).expect
      (fun x => recordReward value (FiniteLaw.stateAfter updateGridHistory N history x)) =
      recordReward value history+
        (cfg.eulerStep M base hbase value hsmall omega homega homega1 hlower hbudget history clock).expect
          (virtualCredit M base hbase value (recordReplay M base hbase value history)) := by
  rw [sparsePhysicalRound,FiniteLaw.sparseRound_terminal_expect_loss cfg.finiteHistoryKernel updateGridHistory
    (fun _ => rfl) ((1/(L:ℝ))*((1/cfg.q)/omega))
    (cfg.finiteHistoryKernel_acceptance_bound hsmall omega homega homega1 hlower) N (clock.val*N) history hbudget
    (recordReward value),eulerStep,virtualStep_expected_credit]
  simp only [recordReward_updateGridHistory,sub_add_cancel_left]
  have hneg (law : FiniteLaw (Option (GridMark N L V))) :
      law.expect (fun mark => -gridMarkCredit value mark) = -(law.expect (gridMarkCredit value)) := by
    simp only [FiniteLaw.expect,mul_neg,Finset.sum_neg_distrib]
  simp_rw [hneg]
  simp only [Finset.sum_neg_distrib,sub_neg_eq_add]
  congr 1
  rw [mul_sum]
  apply sum_congr rfl
  intro e he
  have hn : clock.val*N+e.val < L*N := gridSlot_lt N L clock e
  have hpast := cfg.quiet_interval_reachable history (clock.val*N) e.val hn.le hp hsmall omega homega homega1 hlower hsingle
  simp only [finiteHistoryKernel,if_pos hn]
  rw [cfg.historyKernel_mark_credit M base hbase value hlive history _ hn hpast]
  have hlabel : gridLabel N cfg.labels_pos (clock.val*N+e.val) = e := gridLabel_slot N L cfg.labels_pos clock e
  rw [hlabel]
  unfold eulerRate gridSlot
  ring

end PrivateGridConfig
end MatroidProphetSecretary
