import MatroidProphetSecretary.ReferenceShape
import Mathlib.Analysis.Convex.Slope

/-! A quantitative Lipschitz bound away from zero for the actual reference optimum. -/

noncomputable section

namespace MatroidProphetSecretary

theorem concave_zero_ordered_lipschitz (f : ℝ → ℝ) (hc : ConcaveOn ℝ (Set.Ici 0) f)
    (hm : MonotoneOn f (Set.Ici 0)) (h0 : f 0 = 0) (lo q r : ℝ)
    (hlo : 0 < lo) (hlo1 : lo ≤ 1) (hql : lo ≤ q) (hqr : q ≤ r) :
    |f r-f q| ≤ f 1/lo*(r-q) := by
  have hq : 0 < q := hlo.trans_le hql
  have hr : 0 ≤ r := hq.le.trans hqr
  have hf1 : 0 ≤ f 1 := by
    have h := hm (Set.mem_Ici.mpr le_rfl) (Set.mem_Ici.mpr zero_le_one) zero_le_one
    rwa [h0] at h
  have hscale := (concave_zero_scaling f hc hm h0 q hq.le).2
  have hb : f q/q ≤ f 1/lo := by
    rcases le_total q 1 with hq1 | h1q
    · rw [max_eq_left hq1, one_mul] at hscale
      exact (div_le_div_of_nonneg_right hscale hq.le).trans
        (div_le_div_of_nonneg_left hf1 hlo hql)
    · rw [max_eq_right h1q] at hscale
      calc
        f q/q ≤ f 1 := (div_le_iff₀ hq).mpr (by simpa only [mul_comm] using hscale)
        _ ≤ f 1/lo := (le_div_iff₀ hlo).mpr (mul_le_of_le_one_right hf1 hlo1)
  rcases eq_or_lt_of_le hqr with rfl | hqr
  · simp
  have hs := hc.slope_anti_adjacent (Set.mem_Ici.mpr le_rfl) (Set.mem_Ici.mpr hr) hq hqr
  rw [h0, sub_zero, sub_zero] at hs
  rw [abs_of_nonneg (sub_nonneg.mpr (hm hq.le hr hqr.le))]
  exact (div_le_iff₀ (sub_pos.mpr hqr)).mp (hs.trans hb)

theorem concave_zero_lipschitz (f : ℝ → ℝ) (hc : ConcaveOn ℝ (Set.Ici 0) f)
    (hm : MonotoneOn f (Set.Ici 0)) (h0 : f 0 = 0) (lo q r : ℝ)
    (hlo : 0 < lo) (hlo1 : lo ≤ 1) (hql : lo ≤ q) (hrl : lo ≤ r) :
    |f r-f q| ≤ f 1/lo*|r-q| := by
  rcases le_total q r with hqr | hrq
  · simpa only [abs_of_nonneg (sub_nonneg.mpr hqr)] using
      concave_zero_ordered_lipschitz f hc hm h0 lo q r hlo hlo1 hql hqr
  · have h := concave_zero_ordered_lipschitz f hc hm h0 lo r q hlo hlo1 hrl hrq
    rw [abs_sub_comm] at h
    simpa only [abs_of_nonpos (sub_nonpos.mpr hrq), neg_sub] using h

variable {E : Type*} [Fintype E] [DecidableEq E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem referenceExpectedOptimum_lipschitz (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (lo q r : ℝ) (hlo : 0 < lo) (hlo1 : lo ≤ 1) (hql : lo ≤ q) (hrl : lo ≤ r) :
    |referenceExpectedOptimum laws M value r-referenceExpectedOptimum laws M value q| ≤
      expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)/lo*|r-q| := by
  have h := concave_zero_lipschitz _ (referenceExpectedOptimum_concave laws M hground value hv)
    (referenceExpectedOptimum_monotone laws M hground value hv)
    (referenceExpectedOptimum_zero laws M hground value hv) lo q r hlo hlo1 hql hrl
  rwa [referenceExpectedOptimum_one laws M hground value hv] at h

theorem referenceExpectedOptimum_lower_away_zero (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (lo q : ℝ) (hlo : 0 ≤ lo) (hlo1 : lo ≤ 1) (hql : lo ≤ q) :
    lo*expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) ≤ referenceExpectedOptimum laws M value q := by
  have h := (referenceExpectedOptimum_scaling laws M hground value hv q (hlo.trans hql)).1
  exact (mul_le_mul_of_nonneg_right (le_min hlo1 hql)
    (expectedOptimum_nonneg _ M _)).trans h

end MatroidProphetSecretary
