import MatroidProphetSecretary.GridSurvival
import Mathlib.Algebra.BigOperators.Fin

/-! Exact survival cancellation for one physical arrival on a uniform finite time grid. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem sum_fin_initial_segment (f : ℕ → ℝ) (N n : ℕ) (hn : n ≤ N) :
    (∑ i : Fin N, if i.val < n then f i.val else 0) = ∑ i ∈ range n, f i := by
  rw [Fin.sum_univ_eq_sum_range (fun i => if i < n then f i else 0)]
  rw [← sum_filter]
  congr 1
  ext i
  simp only [mem_filter,mem_range]
  constructor
  · exact And.right
  · intro hi
    exact ⟨hi.trans_le hn,hi⟩

theorem oneArrival_grid_survival {Ω A : Type*} [Fintype Ω]
    (L : ℕ) (hL : 0 < L) (tape : FiniteLaw Ω) (decision : Fin L → Ω → Option A)
    (dose : ℕ → ℝ) (n : ℕ) (hn : n ≤ L)
    (hkernel : ∀ i : Fin L, i.val < n →
      tape.prob (fun w => decision i w ≠ none) = (L:ℝ)*gridSurvival dose i.val*dose i.val) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    ((FiniteLaw.uniform (Fin L)).pair tape).prob
      (FiniteLaw.oneArrivalAbsent (fun t => t.val < n) decision) = gridSurvival dose n := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  rw [FiniteLaw.oneArrival_survival]
  have hL' : (L:ℝ) ≠ 0 := by exact_mod_cast hL.ne'
  have hpoint (i : Fin L) :
      (if i.val < n then (FiniteLaw.uniform (Fin L)).mass i*tape.prob (fun w => decision i w ≠ none) else 0) =
      if i.val < n then gridSurvival dose i.val*dose i.val else 0 := by
    by_cases hi : i.val < n
    · rw [if_pos hi,if_pos hi,hkernel i hi]
      simp only [FiniteLaw.uniform,Fintype.card_fin]
      field_simp
      <;> ring
    · simp only [hi,if_false]
  calc
    _ = 1-∑ i : Fin L, if i.val < n then gridSurvival dose i.val*dose i.val else 0 := by
      congr 1
      apply sum_congr rfl
      intro i hi
      convert hpoint i using 1
      split_ifs
      · congr 1
      · rfl
    _ = _ := by rw [sum_fin_initial_segment (fun i => gridSurvival dose i*dose i) L n hn,gridSurvival_mass]; ring

theorem oneArrival_grid_intensity {Ω A : Type*} [Fintype Ω]
    (L : ℕ) (hL : 0 < L) (tape : FiniteLaw Ω) (decision : Fin L → Ω → Option A)
    (dose : ℕ → ℝ) (hdose : ∀ i, dose i < 1) (t : Fin L) (B : A → Prop) (lam kernel : ℝ)
    (hpast : ∀ i : Fin L, i.val < t.val →
      tape.prob (fun w => decision i w ≠ none) = (L:ℝ)*gridSurvival dose i.val*dose i.val)
    (hnow : FiniteLaw.acceptanceKernel tape decision t B = lam*gridSurvival dose t.val*kernel) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    (((FiniteLaw.uniform (Fin L)).pair tape).conditionOrSelf
      (FiniteLaw.oneArrivalAbsent (fun u => u.val < t.val) decision)).prob
      (fun x => x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ B mark) = (1/(L:ℝ))*lam*kernel := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  have hs := oneArrival_grid_survival L hL tape decision dose t.val t.isLt.le hpast
  have hp : 0 < ((FiniteLaw.uniform (Fin L)).pair tape).prob
      (FiniteLaw.oneArrivalAbsent (fun u => u.val < t.val) decision) := by
    rw [hs]
    exact gridSurvival_pos dose hdose t.val
  have ht := FiniteLaw.oneArrival_conditional_mark (FiniteLaw.uniform (Fin L)) tape
    (fun u => u.val < t.val) decision t (lt_irrefl _) B hp
  rw [hs,hnow] at ht
  convert ht using 1
  · unfold FiniteLaw.prob
    congr 1
    funext x
    split_ifs <;> rfl
  · simp only [FiniteLaw.uniform,Fintype.card_fin]
    have hS := (gridSurvival_pos dose hdose t.val).ne'
    field_simp
    <;> ring

end MatroidProphetSecretary
