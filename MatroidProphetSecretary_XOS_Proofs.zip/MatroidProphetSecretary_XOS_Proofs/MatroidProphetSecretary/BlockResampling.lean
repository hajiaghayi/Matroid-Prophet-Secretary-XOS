import MatroidProphetSecretary.ProductConditioning

/-! Resampling one coordinate block preserves a finite product distribution. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

theorem expect_comm {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]
    (μ : FiniteLaw Ω) (ν : FiniteLaw Ψ) (f : Ω → Ψ → ℝ) :
    μ.expect (fun x => ν.expect (f x)) = ν.expect (fun y => μ.expect (fun x => f x y)) := by
  simp only [expect, mul_sum]
  rw [sum_comm]
  apply sum_congr rfl
  intro y hy
  apply sum_congr rfl
  intro x hx
  ring

theorem expect_finset_sum {Ω ι : Type*} [Fintype Ω] (μ : FiniteLaw Ω)
    (s : Finset ι) (f : ι → Ω → ℝ) :
    μ.expect (fun x => ∑ i ∈ s, f i x) = ∑ i ∈ s, μ.expect (f i) := by
  simp only [expect, mul_sum]
  exact sum_comm

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)]

def resampleBlock (p : ι → Prop) (x y : ∀ i, V i) : ∀ i, V i :=
  fun i => if p i then y i else x i

theorem resampleBlock_split (p : ι → Prop)
    (x₁ y₁ : ∀ i : {i // p i}, V i) (x₂ y₂ : ∀ i : {i // ¬p i}, V i) :
    resampleBlock p ((Equiv.piEquivPiSubtypeProd p V).symm (x₁, x₂))
      ((Equiv.piEquivPiSubtypeProd p V).symm (y₁, y₂)) =
      (Equiv.piEquivPiSubtypeProd p V).symm (y₁, x₂) := by
  funext i
  by_cases hi : p i <;> simp [resampleBlock, Equiv.piEquivPiSubtypeProd, hi]

theorem product_resample_block (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (f : (∀ i, V i) → ℝ) :
    (product laws).expect (fun x => (product laws).expect (fun y => f (resampleBlock p x y))) =
      (product laws).expect f := by
  rw [product_expect_split laws p]
  simp_rw [product_expect_split laws p]
  simp only [resampleBlock_split, expect_const]
  rw [expect_comm]

end MatroidProphetSecretary.FiniteLaw
