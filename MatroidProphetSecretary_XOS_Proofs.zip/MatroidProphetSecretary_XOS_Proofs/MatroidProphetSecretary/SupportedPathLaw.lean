import MatroidProphetSecretary.SupportedKernelTransfer

/-! Equality of supported adaptive kernels determines the entire marked path law. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {S W : Type*} [Fintype W]

theorem adaptive_law_eq_supported (batch other : S → FiniteLaw W) (update : S → W → S)
    (Good : ℕ → S → Prop) (n offset : ℕ) (s : S) (hs : Good offset s)
    (hpreserve : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      ∀ x, (batch state).mass x ≠ 0 → Good (j+1) (update state x))
    (hbatch : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state → batch state = other state) :
    adaptiveBatches batch update n s = adaptiveBatches other update n s := by
  induction n generalizing offset s with
  | zero => rfl
  | succ n ih =>
    apply ext_mass
    funext x
    rw [adaptiveBatches_mass_succ,adaptiveBatches_mass_succ,← hbatch offset le_rfl (by omega) s hs]
    by_cases hx : (batch s).mass (x 0) = 0
    · simp only [hx,zero_mul]
    · rw [ih (offset+1) (update s (x 0)) (hpreserve offset le_rfl (by omega) s hs (x 0) hx)
        (fun j hj hjn state hstate y hy => hpreserve j (by omega) (by omega) state hstate y hy)
        (fun j hj hjn state hstate => hbatch j (by omega) (by omega) state hstate)]

end MatroidProphetSecretary.FiniteLaw
