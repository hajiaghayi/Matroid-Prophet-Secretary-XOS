import MatroidProphetSecretary.FiniteReferenceSelection
import MatroidProphetSecretary.Parameters

/-! Reference selection with the paper's exact numerical constants. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem concrete_search_width_small (N : ℕ) (hN : 0 < N) : epsilon/(4*(N:ℝ)^2) < delta := by
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have he := basic_constants.1
  have hb : (1:ℝ) ≤ 4*(N:ℝ)^2 := by nlinarith
  exact (div_le_self he.le hb).trans_lt basic_constants.2.1

variable {E : Type*} [Fintype E] [LinearOrder E] [Nonempty E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem finite_reference_selection_concrete (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (G : ValueHeightGrid (referenceInstanceValues value))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) {m : ℕ}
    (batches : ℕ → (Fin m → (Fin G.last × (E → Bool))))
    (initial : SearchRecord (Fin m → (Fin G.last × (E → Bool))))
    (hinit : |initial.point-1| < 3*delta)
    (hgood : referenceSearchAccurate (referencePositiveTest laws value G M theta epsilon (m := m))
      (referenceNegativeTest laws value G M theta epsilon (m := m)) batches initial
      (referenceRecordGood laws value G M hnonloop N epsilon) delta (referenceSearchSteps N delta epsilon)) :
    let r := runReferenceSearch (referencePositiveTest laws value G M theta epsilon (m := m))
      (referenceNegativeTest laws value G M theta epsilon (m := m)) batches initial delta (referenceSearchSteps N delta epsilon)
    referenceRecordGood laws value G M hnonloop N epsilon r ∧ r.point ∈ interval ∧
      discount initial.point * referenceExpectedOptimum laws M value initial.point ≤
        discount r.point * referenceExpectedOptimum laws M value r.point ∧
      (|r.point-1| < 3*delta →
        stationaryRatio r.point-20*epsilon ≤ referenceDeletion laws M value r.point / referenceExpectedOptimum laws M value r.point ∧
        referenceDeletion laws M value r.point / referenceExpectedOptimum laws M value r.point ≤
          stationaryRatio r.point + referenceStable laws M value hnonloop r.point / referenceExpectedOptimum laws M value r.point + 20*epsilon) := by
  have hi : initial.point ∈ searchInterval delta := by
    have h := abs_lt.mp hinit
    change 1-4*delta ≤ initial.point ∧ initial.point ≤ 1+4*delta
    have hd : 0 < delta := by norm_num [delta]
    constructor <;> linarith [h.1,h.2]
  have h := finite_reference_selection laws M value hv hnonloop G hF N hN0 hN theta delta epsilon
    (by norm_num [theta]) (by norm_num [theta]) (by norm_num [delta]) (by norm_num [delta])
    (fun q hq => (discount_basic hq).1) (by norm_num [epsilon]) (by norm_num [epsilon])
    (concrete_search_width_small N hN0) batches initial hi hgood
  simpa only [referencePotential,discount,searchInterval,interval,stationaryRatio,sub_sub_cancel] using h

end MatroidProphetSecretary
