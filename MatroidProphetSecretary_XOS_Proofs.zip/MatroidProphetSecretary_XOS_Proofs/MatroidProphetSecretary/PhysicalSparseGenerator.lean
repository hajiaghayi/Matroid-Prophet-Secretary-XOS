import MatroidProphetSecretary.PhysicalReplayKernel
import MatroidProphetSecretary.PhysicalQuietReachability
import MatroidProphetSecretary.SparseRoundExpectation

/-! The sparse physical process has exactly the matroid exchange generator on reachable histories. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem virtualStep_potential_loss {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]
    (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ) (R : ℝ)
    (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e) (hrate1 : ∀ e, rate e ≤ R)
    (hsmall : dt*R*Fintype.card E ≤ 1) (F : VirtualState M → ℝ) :
    (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
      (fun event => F (virtualUpdate M base hbase value s event)) =
      F s-dt*∑ e, rate e*μ.expect (fun y =>
        if e ∈ virtualLive M base hbase value s y then F s-F (virtualUpdate M base hbase value s (some (e,y))) else 0) := by
  rw [virtualStepLaw,FiniteLaw.optionalLaw_expect_loss]
  change F s-∑ event, virtualStepWeight μ M base hbase value s dt rate event*
    (F s-F (virtualUpdate M base hbase value s (some event))) = _
  congr 1
  rw [Fintype.sum_prod_type]
  simp only [FiniteLaw.expect,mul_sum]
  apply sum_congr rfl
  intro e he
  apply sum_congr rfl
  intro y hy
  unfold virtualStepWeight
  split_ifs <;> ring

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def eulerRate (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L) (e : Fin N) : ℝ :=
  cfg.historyRate history (gridSlot clock e)

def eulerStep (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L) :
    FiniteLaw (Option (Fin N × (Fin N → Option V))) :=
  virtualStepLaw (FiniteLaw.product cfg.reference) M base hbase value (recordReplay M base hbase value history)
    (1/(L:ℝ)) (cfg.eulerRate history clock) ((1/cfg.q)/omega)
    (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)
    (fun e => (cfg.historyRate_bounds history (gridSlot clock e) hsmall omega homega homega1 hlower).1)
    (fun e => (cfg.historyRate_bounds history (gridSlot clock e) hsmall omega homega homega1 hlower).2)
    (by simpa only [Fintype.card_fin,mul_comm] using hbudget)

theorem physical_sparse_virtual_expect (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1)
    (hsingle : (1/(L:ℝ))*((1/cfg.q)/omega) < 1)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (clock.val*N) = history))
    (F : VirtualState M → ℝ) :
    (cfg.sparsePhysicalRound hsmall omega homega homega1 hlower (clock.val*N) history hbudget).expect
      (fun x => F (recordReplay M base hbase value (FiniteLaw.stateAfter updateGridHistory N history x))) =
    (cfg.eulerStep M base hbase value hsmall omega homega homega1 hlower hbudget history clock).expect
      (fun event => F (virtualUpdate M base hbase value (recordReplay M base hbase value history) event)) := by
  rw [sparsePhysicalRound,FiniteLaw.sparseRound_terminal_expect_loss cfg.finiteHistoryKernel updateGridHistory
    (fun _ => rfl) ((1/(L:ℝ))*((1/cfg.q)/omega))
    (cfg.finiteHistoryKernel_acceptance_bound hsmall omega homega homega1 hlower) N (clock.val*N) history hbudget
    (fun records => F (recordReplay M base hbase value records)),eulerStep,virtualStep_potential_loss]
  congr 1
  rw [mul_sum]
  apply sum_congr rfl
  intro e he
  have hn : clock.val*N+e.val < L*N := gridSlot_lt N L clock e
  have hpast := cfg.quiet_interval_reachable history (clock.val*N) e.val hn.le hp hsmall omega homega homega1 hlower hsingle
  simp only [finiteHistoryKernel,if_pos hn]
  rw [cfg.historyKernel_replay_loss M base hbase value hlive history _ hn hpast F]
  have hlabel : gridLabel N cfg.labels_pos (clock.val*N+e.val) = e := gridLabel_slot N L cfg.labels_pos clock e
  rw [hlabel]
  unfold eulerRate gridSlot
  ring

end PrivateGridConfig
end MatroidProphetSecretary
