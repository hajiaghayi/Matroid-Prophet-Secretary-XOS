import MatroidProphetSecretary.XOSRandomTape

/-! Theorem 2 of the paper, with actual welfare, explicit XOS clauses,
independent identical finite priors, uniform arrival order, and unrestricted randomization. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open MeasureTheory
open scoped Classical

/-- The finite hard instance is chosen before the policy. The displayed inequality
is exactly the strict competitiveness upper bound from Theorem 2. -/
theorem xos_main_theorem (ξ : ℝ) (hξ : 0 < ξ) :
    ∃ n L : ℕ, ∃ hn : NeZero n, ∃ hL : NeZero L,
      letI : NeZero n := hn
      letI : NeZero L := hL
      2 ≤ n ∧ n ≤ L ∧
      (∀ a : Fin L,
        (∀ c ∈ allowed (n := n) a, ∀ x, coefficient c x = 0 ∨ coefficient c x = 1) ∧
        (∀ S : Finset (Goods n L),
          (∀ c ∈ allowed a, ∑ x ∈ S, coefficient c x ≤ (value a S : ℝ)) ∧
          ∃ c ∈ allowed a, (value a S : ℝ) = ∑ x ∈ S, coefficient c x)) ∧
      0 < expectedProphet n L ∧
      ∀ μ : FiniteLaw (PolicyFamily n L),
        secretaryReward μ < (1 - 1 / Real.exp 1 + ξ) * expectedProphet n L := by
  obtain ⟨n,L,hn2,hnL,hd,hr⟩ := exists_hard_parameters ξ hξ
  haveI hn : NeZero n := ⟨by omega⟩
  haveI hL : NeZero L := ⟨by omega⟩
  refine ⟨n,L,hn,hL,hn2,hnL,?_,expectedProphet_pos hd,?_⟩
  · intro a
    exact ⟨fun c _ x => coefficient_binary c x,(value_is_XOS hnL a).2⟩
  · intro μ
    exact (div_lt_iff₀ (expectedProphet_pos hd)).mp
      ((secretary_ratio_bound hnL hd μ).trans_lt hr)

/-- The same hard instance works for every probability space of independent random tapes. -/
theorem xos_hardness_arbitrary_random_tapes (ξ : ℝ) (hξ : 0 < ξ) :
    ∃ n L : ℕ, ∃ hn : NeZero n, ∃ hL : NeZero L,
      letI : NeZero n := hn
      letI : NeZero L := hL
      2 ≤ n ∧ n ≤ L ∧ 0 < expectedProphet n L ∧
      ∀ (Ω : Type) [MeasurableSpace Ω] (μ : Measure Ω) [IsProbabilityMeasure μ]
        (P : Ω → PolicyFamily n L), Measurable P →
        (∫ ω, familyReward (P ω) ∂μ) < (1 - 1 / Real.exp 1 + ξ) * expectedProphet n L := by
  obtain ⟨n,L,hn2,hnL,hd,hr⟩ := exists_hard_parameters ξ hξ
  haveI hn : NeZero n := ⟨by omega⟩
  haveI hL : NeZero L := ⟨by omega⟩
  refine ⟨n,L,hn,hL,hn2,hnL,expectedProphet_pos hd,?_⟩
  intro Ω _ μ _ P hP
  exact (div_lt_iff₀ (expectedProphet_pos hd)).mp
    ((arbitrary_random_tape_ratio_bound hnL hd μ P hP).trans_lt hr)

end MatroidProphetSecretary.XOS
