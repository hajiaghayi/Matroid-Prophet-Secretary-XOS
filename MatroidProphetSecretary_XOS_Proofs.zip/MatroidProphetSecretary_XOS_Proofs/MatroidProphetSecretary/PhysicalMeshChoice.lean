import MatroidProphetSecretary.DyadicPhysicalMesh
import Mathlib.Tactic.FunProp

/-! Finite physical meshes approach the paper's factor while satisfying all numerical survival conditions. -/

noncomputable section

namespace MatroidProphetSecretary

open Filter
open scoped Topology

theorem limiting_factor_continuous_omega (lam w z : ℝ) (hw : w ≠ 0) :
    ContinuousAt (fun omega => limitingContinuationFactor (1-delta) delta lam omega z) w := by
  unfold limitingContinuationFactor
  fun_prop (disch := assumption)

theorem exists_lower_survival_factor {q z c : ℝ} (hq : q ∈ interval) (hc : c < phi q z) :
    ∃ w : ℝ, 0 < w ∧ w ≤ 1 ∧ w < omega q ∧
      c < limitingContinuationFactor (1-delta) delta (1/q) w z := by
  have hwpos : 0 < omega q := lt_trans (by norm_num) (omega_positive hq)
  have hwone : omega q < 1 := by
    unfold omega
    linarith [(alpha_bounds hq).2,(delta_div_q_bounds hq).1]
  let w := fun n : ℕ => omega q-1/((n:ℝ)+1)
  have hw : Tendsto w atTop (𝓝 (omega q)) := by
    simpa only [sub_zero] using
      (tendsto_const_nhds : Tendsto (fun _ : ℕ => omega q) atTop (𝓝 (omega q))).sub
        tendsto_one_div_add_atTop_nhds_zero_nat
  have hf := (limiting_factor_continuous_omega (1/q) (omega q) z hwpos.ne').tendsto.comp hw
  rw [limiting_factor_eq_phi] at hf
  obtain ⟨n,hn0,hnf⟩ := ((hw.eventually_const_lt hwpos).and (hf.eventually_const_lt hc)).exists
  have hnless : w n < omega q := sub_lt_self _ (one_div_pos.mpr (by positivity))
  exact ⟨w n,hn0,hnless.le.trans hwone.le,hnless,hnf⟩

theorem physical_mesh_admissible_eventually (N : ℕ) (lam w : ℝ)
    (hw : w < Real.exp (-(1-delta)*lam)-delta*lam) :
    ∀ᶠ n : ℕ in atTop, 0 < n ∧ physicalMeshStep lam n < 1 ∧
      (N:ℝ)*((1/(physicalMeshSize n:ℝ))*(lam/w)) < 1 ∧ w ≤ physicalMeshSurvival lam n := by
  have hp := (physicalMesh_step_tendsto lam).eventually_lt_const (zero_lt_one : (0:ℝ) < 1)
  have hb : Tendsto (fun n => (N:ℝ)*physicalMeshStep (lam/w) n) atTop (𝓝 0) := by
    simpa only [mul_zero] using (physicalMesh_step_tendsto (lam/w)).const_mul (N:ℝ)
  have hbudget := hb.eventually_lt_const (zero_lt_one : (0:ℝ) < 1)
  have hs := (physicalMesh_survival_tendsto lam).eventually_const_lt hw
  filter_upwards [eventually_gt_atTop 0,hp,hbudget,hs] with n hn hp hb hs
  exact ⟨hn,hp,hb,hs.le⟩

theorem exists_physical_mesh_factor (N : ℕ) (C : ℝ → ℝ) {q z c : ℝ}
    (hq : q ∈ interval) (hc : c < phi q z) :
    ∃ (w : ℝ) (n : ℕ), 0 < w ∧ w ≤ 1 ∧ 0 < n ∧ N ≤ physicalMeshSize n ∧
      (1/(physicalMeshSize n:ℝ))*(1/q) < 1 ∧
      (N:ℝ)*((1/(physicalMeshSize n:ℝ))*((1/q)/w)) < 1 ∧
      w ≤ (1-(1/(physicalMeshSize n:ℝ))*(1/q))^(physicalMeshCut n)-
        (physicalMeshSize n-physicalMeshCut n:ℕ)*((1/(physicalMeshSize n:ℝ))*(1/q)) ∧
      c < physicalMeshFactor (1/q) w z n-C w/(physicalMeshSize n:ℝ) := by
  obtain ⟨w,hw0,hw1,hw,hfactor⟩ := exists_lower_survival_factor hq hc
  have hw' : w < Real.exp (-(1-delta)*(1/q))-delta*(1/q) := by
    convert hw using 1
    unfold omega alpha
    congr 1 <;> ring
  have hadmissible := physical_mesh_admissible_eventually N (1/q) w hw'
  have hgood := (physicalMesh_factor_with_error_tendsto (1/q) w z (C w)).eventually_const_lt hfactor
  obtain ⟨n,⟨hn,hvalue⟩,hnN⟩ := ((hadmissible.and hgood).and (eventually_ge_atTop N)).exists
  have hNL : N ≤ physicalMeshSize n := by unfold physicalMeshSize; omega
  refine ⟨w,n,hw0,hw1,hn.1,hNL,hn.2.1,hn.2.2.1,?_,hvalue⟩
  rw [← physicalMesh_survival_eq (1/q) n hn.1]
  exact hn.2.2.2

end MatroidProphetSecretary
