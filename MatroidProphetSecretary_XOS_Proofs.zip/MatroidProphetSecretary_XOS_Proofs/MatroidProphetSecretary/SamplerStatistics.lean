import MatroidProphetSecretary.SamplerGuarantees

/-! A finite family containing all statistics used at one queried reference parameter. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

abbrev StatisticIndex (E : Type*) := Fin 3 ⊕ E

def samplerStatistic (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (M : Matroid E) : StatisticIndex E → (Fin G.last × (E → Bool)) → ℝ
  | Sum.inl i, y => finiteValueVolume laws value G *
      (if i = 0 then realRank M (bitSet y.2) else if i = 1 then activeColoopCount M y.2
        else activeUnstableCount M (coordinateTail laws value (G.level y.1.val)) y.2)
  | Sum.inr e, y => finiteValueVolume laws value G * activeOtherClosure M e y.2

def samplerTarget (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) : StatisticIndex E → ℝ
  | Sum.inl i => if i = 0 then expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)
      else if i = 1 then deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)
      else deletionSurplus (FiniteLaw.product laws) M (coordinateValues value) -
        stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop
  | Sum.inr e => meanThreshold (FiniteLaw.product laws) M (coordinateValues value) hnonloop e

def samplerStatisticScale (N : ℕ) (vol : ℝ) : StatisticIndex E → ℝ
  | Sum.inl _ => N * vol
  | Sum.inr _ => vol

def samplerStatisticTolerance (N : ℕ) (ε vol : ℝ) : StatisticIndex E → ℝ
  | Sum.inl _ => ε * vol
  | Sum.inr _ => ε * vol / N

theorem samplerStatistic_expect (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (s : StatisticIndex E) :
    (finiteValueSampler laws value G hV).expect (samplerStatistic laws value G M s) =
      samplerTarget laws value M hnonloop s := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  change (finiteValueSampler laws value G hV).expect (fun y => samplerStatistic laws value G M s y) = _
  cases s with
  | inl i =>
    by_cases hi0 : i = 0
    · simpa only [samplerStatistic, samplerTarget, if_pos hi0] using
        finiteValueSampler_expected_rank laws value hv G hV M hg
    · by_cases hi1 : i = 1
      · simpa only [samplerStatistic, samplerTarget, if_neg hi0, if_pos hi1] using
          finiteValueSampler_expected_coloops laws value hv G hV M hg
      · simpa only [samplerStatistic, samplerTarget, if_neg hi0, if_neg hi1] using
          finiteValueSampler_expected_unstable laws value hv G hV M hnonloop
  | inr e => exact finiteValueSampler_expected_threshold laws value hv G hV M hnonloop e

theorem samplerStatistic_bounds (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N : ℕ) (hN : Fintype.card E ≤ N) (s : StatisticIndex E) (y : Fin G.last × (E → Bool)) :
    0 ≤ samplerStatistic laws value G M s y ∧ samplerStatistic laws value G M s y ≤
      samplerStatisticScale N (finiteValueVolume laws value G) s := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  have hr0 : 0 ≤ realRank M (bitSet y.2) := Nat.cast_nonneg _
  have hrN : realRank M (bitSet y.2) ≤ (N:ℝ) :=
    (activeRank_le_card M hg y.2).trans (by exact_mod_cast hN)
  have hdN := (activeColoopCount_le_rank M hg y.2).trans hrN
  have hc := activeUnstableCount_bounds M (coordinateTail laws value (G.level y.1.val))
    (fun e => (laws e).prob_nonneg _) (fun e => (laws e).prob_le_one _) y.2
  cases s with
  | inl i =>
    simp only [samplerStatistic, samplerStatisticScale]
    have bound (a : ℝ) (ha0 : 0 ≤ a) (haN : a ≤ (N:ℝ)) :
        0 ≤ finiteValueVolume laws value G * a ∧ finiteValueVolume laws value G * a ≤ N * finiteValueVolume laws value G :=
      ⟨mul_nonneg hV.le ha0, by simpa [mul_comm] using mul_le_mul_of_nonneg_left haN hV.le⟩
    split_ifs
    · exact bound _ hr0 hrN
    · exact bound _ (activeColoopCount_nonneg M y.2) hdN
    · exact bound _ hc.1 (hc.2.trans hdN)
  | inr e =>
    exact ⟨mul_nonneg hV.le (activeOtherClosure_bounds M e y.2).1,
      mul_le_of_le_one_right hV.le (activeOtherClosure_bounds M e y.2).2⟩

theorem samplerStatisticScale_pos (N : ℕ) (hN : 0 < N) (vol : ℝ) (hvol : 0 < vol)
    (s : StatisticIndex E) : 0 < samplerStatisticScale N vol s := by
  cases s with
  | inl i => exact mul_pos (Nat.cast_pos.mpr hN) hvol
  | inr e => exact hvol

theorem samplerStatistic_tolerance_ratio (N : ℕ) (hN : 0 < N) (ε vol : ℝ) (hvol : 0 < vol)
    (s : StatisticIndex E) :
    samplerStatisticTolerance N ε vol s / samplerStatisticScale N vol s = ε / N := by
  have hn : (N:ℝ) ≠ 0 := (Nat.cast_pos.mpr hN).ne'
  cases s <;> simp only [samplerStatisticTolerance, samplerStatisticScale] <;> field_simp <;> ring

end MatroidProphetSecretary
