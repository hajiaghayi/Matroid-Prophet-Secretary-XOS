import Mathlib.Data.Matroid.Closure
import Mathlib.Data.Finset.Sort
import Mathlib.Tactic

/-! A one-query-per-label greedy independence scan computes a basis of the scanned restriction. -/

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [DecidableEq E]

def oracleGreedy (oracle : Finset E → Bool) : List E → Finset E → Finset E
  | [], I => I
  | e :: rest, I => oracleGreedy oracle rest (if oracle (insert e I) then insert e I else I)

def oracleGreedyQueries : List E → ℕ
  | [] => 0
  | _ :: rest => 1+oracleGreedyQueries rest

theorem oracleGreedyQueries_eq (xs : List E) : oracleGreedyQueries xs = xs.length := by
  induction xs with
  | nil => rfl
  | cons e xs ih => simp [oracleGreedyQueries,ih,Nat.add_comm]

theorem oracleGreedy_extends (oracle : Finset E → Bool) (xs : List E) (I : Finset E) :
    I ⊆ oracleGreedy oracle xs I := by
  induction xs generalizing I with
  | nil => exact Subset.rfl
  | cons e xs ih =>
    simp only [oracleGreedy]
    split_ifs
    · exact (subset_insert e I).trans (ih _)
    · exact ih I

theorem oracleGreedy_subset (oracle : Finset E → Bool) (xs : List E) (I : Finset E) :
    oracleGreedy oracle xs I ⊆ I ∪ xs.toFinset := by
  induction xs generalizing I with
  | nil => simp [oracleGreedy]
  | cons e xs ih =>
    simp only [oracleGreedy]
    split_ifs
    · have h := ih (insert e I)
      intro x hx
      have hx' := h hx
      simp only [List.toFinset_cons,mem_union,mem_insert] at hx' ⊢
      tauto
    · exact (ih I).trans (by intro x hx; simpa using (show x ∈ I ∪ insert e xs.toFinset from
        (union_subset_union_right (subset_insert e xs.toFinset)) hx))

theorem oracleGreedy_indep (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (xs : List E) (I : Finset E)
    (hI : M.Indep (I : Set E)) : M.Indep (oracleGreedy oracle xs I : Set E) := by
  induction xs generalizing I with
  | nil => exact hI
  | cons e xs ih =>
    simp only [oracleGreedy]
    split_ifs with ht
    · exact ih _ ((horacle _).mp ht)
    · exact ih _ hI

theorem oracleGreedy_spans (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (xs : List E)
    (hground : ∀ e ∈ xs, e ∈ M.E) (I : Finset E) (hI : M.Indep (I : Set E)) :
    ∀ e ∈ xs, e ∈ M.closure (oracleGreedy oracle xs I : Set E) := by
  induction xs generalizing I with
  | nil => simp
  | cons f xs ih =>
    intro e he
    have hg : ∀ x ∈ xs, x ∈ M.E := fun x hx => hground x (by simp [hx])
    by_cases ht : oracle (insert f I) = true
    · simp only [oracleGreedy,ht,if_true]
      rcases List.mem_cons.mp he with rfl | he
      · have hm : e ∈ oracleGreedy oracle xs (insert e I) := oracleGreedy_extends oracle xs _ (mem_insert_self _ _)
        exact M.subset_closure _ (oracleGreedy_indep M oracle horacle xs _ ((horacle _).mp ht)).subset_ground hm
      · exact ih hg _ ((horacle _).mp ht) e he
    · simp only [oracleGreedy,ht,if_false]
      rcases List.mem_cons.mp he with rfl | he
      · have hc : e ∈ M.closure (I : Set E) := by
          by_contra hn
          have hi := hI.insert_indep_iff.mpr (Or.inl ⟨hground e (by simp),hn⟩)
          exact ht ((horacle _).mpr (by simpa only [Finset.coe_insert] using hi))
        exact M.closure_subset_closure (oracleGreedy_extends oracle xs I) hc
      · exact ih hg I hI e he

theorem oracleGreedy_isBasis (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (xs : List E)
    (hground : ∀ e ∈ xs, e ∈ M.E) :
    M.IsBasis (oracleGreedy oracle xs ∅ : Set E) (xs.toFinset : Set E) := by
  apply Matroid.isBasis_iff_indep_subset_closure.mpr
  refine ⟨oracleGreedy_indep M oracle horacle xs ∅ (by simpa using M.empty_indep),?_,?_⟩
  · simpa only [empty_union] using oracleGreedy_subset oracle xs ∅
  · intro e he
    exact oracleGreedy_spans M oracle horacle xs hground ∅ (by simpa using M.empty_indep) e (List.mem_toFinset.mp he)

end MatroidProphetSecretary
