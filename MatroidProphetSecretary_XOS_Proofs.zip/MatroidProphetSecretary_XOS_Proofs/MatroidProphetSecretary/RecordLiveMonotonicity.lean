import MatroidProphetSecretary.RecordReplay
import MatroidProphetSecretary.VirtualExposure

/-! Replay liveness decreases along accepted-record prefixes; within-bin exposure shifts telescope. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem virtualUpdate_live_subset (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (s : VirtualState M) (event : Option (E × W)) (y : W) :
    virtualLive M base hbase value (virtualUpdate M base hbase value s event) y ⊆
      virtualLive M base hbase value s y := by
  cases event with
  | none => exact Subset.rfl
  | some pair =>
    rcases pair with ⟨e,source⟩
    by_cases he : e ∈ virtualLive M base hbase value s source
    · intro f hf
      exact ((virtualUpdate_live_iff M base hbase value s source y e f he).mp hf).1
    · simp only [virtualUpdate,dif_neg he]
      exact Subset.rfl

theorem foldRecords_live_subset (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (s : VirtualState M) (records : StampedHistory E W) (y : W) :
    virtualLive M base hbase value
      (records.foldl (fun state record => virtualUpdate M base hbase value state (some (record.1,record.2.2))) s) y ⊆
      virtualLive M base hbase value s y := by
  induction records generalizing s with
  | nil => exact Subset.rfl
  | cons record rest ih =>
    exact (ih (virtualUpdate M base hbase value s (some (record.1,record.2.2)))).trans
      (virtualUpdate_live_subset M base hbase value s _ y)

theorem recordReplay_prefix_live_subset (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (earlier later : StampedHistory E W) (hp : earlier.IsPrefix later) (y : W) :
    virtualLive M base hbase value (recordReplay M base hbase value later) y ⊆
      virtualLive M base hbase value (recordReplay M base hbase value earlier) y := by
  obtain ⟨tail,rfl⟩ := hp
  unfold recordReplay
  rw [List.foldl_append]
  exact foldRecords_live_subset M base hbase value _ tail y

theorem recordReplay_prefix_mass_antitone (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (earlier later : StampedHistory E W) (hp : earlier.IsPrefix later) (e : E) :
    virtualLiveMass μ M base hbase value (recordReplay M base hbase value later) e ≤
      virtualLiveMass μ M base hbase value (recordReplay M base hbase value earlier) e :=
  FiniteLaw.prob_mono μ (fun y hy => recordReplay_prefix_live_subset M base hbase value earlier later hp y hy)

theorem between_sum_gap (before inside : ℕ → ℝ) (hbetween : ∀ i, before (i+1) ≤ inside i) (n : ℕ) :
    (∑ i ∈ range n, (before i-inside i)) ≤ before 0-before n := by
  induction n with
  | zero => simp
  | succ n ih => rw [sum_range_succ]; linarith [hbetween n]

theorem within_bin_exposure_loss (before inside : ℕ → ℝ)
    (hbetween : ∀ i, before (i+1) ≤ inside i) (hfirst : before 0 ≤ 1)
    (hnonneg : ∀ i, 0 ≤ before i) (p : ℝ) (hp : 0 ≤ p) (n : ℕ) :
    p*(∑ i ∈ range n, before i)-p ≤ p*(∑ i ∈ range n, inside i) := by
  have h := between_sum_gap before inside hbetween n
  rw [sum_sub_distrib] at h
  have hb : (∑ i ∈ range n, before i)-(∑ i ∈ range n, inside i) ≤ 1 := by
    linarith [hnonneg n]
  have hm := mul_le_mul_of_nonneg_left hb hp
  nlinarith only [hm]

end MatroidProphetSecretary
