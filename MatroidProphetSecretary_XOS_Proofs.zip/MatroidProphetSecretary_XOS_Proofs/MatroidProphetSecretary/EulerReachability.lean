import MatroidProphetSecretary.PhysicalEulerProcess
import MatroidProphetSecretary.TransitionSupport
import MatroidProphetSecretary.IndexedAdaptiveDrift
import MatroidProphetSecretary.StampedPrefix

/-! The exchange process inherits physical reachability and preserves reconstructed early history. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem euler_block_reachable (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (j : ℕ) (hj : j < L) (state : BlockState N V) (hs : cfg.blockReachable j state)
    (event : Option (Fin N × (Fin N → Option V)))
    (hevent : (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le state).mass event ≠ 0) :
    cfg.blockReachable (j+1) (cfg.eulerBlockUpdate state event) := by
  apply FiniteLaw.transition_support_transfer
    (cfg.sparseBlockBatch hsmall omega homega homega1 hlower hbudget.le state)
    (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le state)
    (physicalBlockUpdate state) (cfg.eulerBlockUpdate state) (cfg.blockReachable (j+1))
    (cfg.sparse_block_reachable hsmall omega homega homega1 hlower hbudget j hj state hs)
    (cfg.sparse_euler_block_expect M base hbase value hlive hsmall omega homega homega1 hlower hbudget j hj state hs)
    event hevent

theorem euler_trajectory_reachable (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (rounds offset : ℕ) (hhorizon : offset+rounds ≤ L)
    (state : BlockState N V) (hs : cfg.blockReachable offset state)
    (x : Fin rounds → Option (Fin N × (Fin N → Option V)))
    (hx : (FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
      cfg.eulerBlockUpdate rounds state).mass x ≠ 0) :
    cfg.blockReachable (offset+rounds) (FiniteLaw.stateAfter cfg.eulerBlockUpdate rounds state x) := by
  apply FiniteLaw.adaptive_terminal_support _ cfg.eulerBlockUpdate cfg.blockReachable rounds offset state hs _ x hx
  intro j hj hjn s hstate y hy
  exact cfg.euler_block_reachable M base hbase value hlive hsmall omega homega homega1 hlower hbudget j (by omega) s hstate y hy

theorem eulerBlock_recordsBefore (clock : Fin L) (history : StampedHistory (Fin N) (Fin N → Option V))
    (event : Option (Fin N × (Fin N → Option V))) (i : ℕ) (hi : i ≤ clock.val*N) :
    recordsBefore i (cfg.eulerBlockUpdate (clock.val*N,history) event).2 = recordsBefore i history := by
  simp only [eulerBlockUpdate,cfg.gridClock_round clock,eulerHistoryUpdate]
  cases event with
  | none => rfl
  | some event =>
    have hn : ¬ gridSlot clock event.1 < i := by
      unfold gridSlot
      omega
    simp [updateGridHistory,appendOptional,gridMarkRecord,recordsBefore,hn]

end MatroidProphetSecretary.PrivateGridConfig
