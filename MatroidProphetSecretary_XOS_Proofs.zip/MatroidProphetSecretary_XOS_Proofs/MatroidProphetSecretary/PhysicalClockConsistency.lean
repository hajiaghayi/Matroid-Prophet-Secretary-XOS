import MatroidProphetSecretary.PhysicalMarkovLaw

/-! A label already recorded as accepted cannot generate a second physical arrival. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem run_record_schedule (tapes : Fin N → Fin L × GridPrivateTape N L V) (n : ℕ)
    (record : Fin N × (ℕ × (Fin N → Option V))) (hr : record ∈ cfg.run tapes n) :
    gridLabel N cfg.labels_pos record.2.1 = record.1 ∧
      (tapes record.1).1 = gridClock N L cfg.clocks_pos record.2.1 := by
  induction n with
  | zero => simp [run,stampedRun,privateStepRun] at hr
  | succ n ih =>
    change record ∈ markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos)
      (stampDecision cfg.decision) n (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)) at hr
    unfold markedStep stampDecision at hr
    split_ifs at hr with hclock
    · cases hd : cfg.decision n (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)).2 with
      | none => simp only [hd,Option.map_none] at hr; exact ih hr
      | some y =>
        simp only [hd,Option.map_some] at hr
        change record ∈ (cfg.run tapes n) ++ [(gridLabel N cfg.labels_pos n,(n,y))] at hr
        rcases List.mem_append.mp hr with hold | hnew
        · exact ih hold
        · rw [List.mem_singleton.mp hnew]
          exact ⟨rfl,hclock⟩
    · exact ih hr

theorem trace_none_of_seen (tapes : Fin N → Fin L × GridPrivateTape N L V) (n : ℕ) (hn : n < L*N)
    (hseen : gridLabel N cfg.labels_pos n ∈ recordLabels (cfg.run tapes n)) : cfg.trace tapes n = none := by
  obtain ⟨record,hr,he⟩ := List.mem_map.mp (List.mem_toFinset.mp hseen)
  have hs := cfg.run_record_schedule tapes n record hr
  have hi : record.2.1 < n := stampedRun_mem_before (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos)
    cfg.decision tapes n record hr
  have hfresh := grid_schedule_fresh N L cfg.labels_pos cfg.clocks_pos n hn record.2.1 hi (hs.1.trans he)
  have hclock : (tapes (gridLabel N cfg.labels_pos n)).1 ≠ gridClock N L cfg.clocks_pos n := by
    rw [← he,hs.2]
    exact hfresh
  simp [trace,hclock]

theorem historyKernel_seen (n : ℕ) (hn : n < L*N)
    (history : StampedHistory (Fin N) (Fin N → Option V))
    (hseen : gridLabel N cfg.labels_pos n ∈ recordLabels history) :
    cfg.historyKernel n history = FiniteLaw.pointMass none := by
  unfold historyKernel
  split_ifs with hp
  · apply FiniteLaw.ext_expect
    intro f
    rw [FiniteLaw.map_expect,FiniteLaw.pointMass_expect]
    calc
      _ = ((FiniteLaw.product cfg.laws).conditionOrSelf (fun tapes => cfg.run tapes n = history)).expect
          (fun _ => f none) := by
        apply FiniteLaw.expect_congr_support
        intro tapes ht
        have hh := FiniteLaw.conditionOrSelf_support (FiniteLaw.product cfg.laws)
          (fun tapes => cfg.run tapes n = history) hp tapes ht
        rw [cfg.trace_none_of_seen tapes n hn (hh ▸ hseen)]
      _ = _ := FiniteLaw.expect_const _ _
  · rfl

end MatroidProphetSecretary.PrivateGridConfig
