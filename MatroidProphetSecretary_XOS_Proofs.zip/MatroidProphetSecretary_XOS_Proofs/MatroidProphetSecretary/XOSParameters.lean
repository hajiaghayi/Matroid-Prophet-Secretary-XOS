import MatroidProphetSecretary.XOSPartitions
import Mathlib.Analysis.SpecialFunctions.Pow.Deriv

/-! The exact asymptotic constant and selection of a finite hard instance.
The collision union bounds below use n²/L and n³/L; these slightly looser
finite bounds have the same sharp limiting constant as the paper's binomial bounds. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open Filter
open scoped Topology

def coverageRatio (n : ℕ) : ℝ := 1 - (1 - 1 / (n : ℝ)) ^ n

theorem coverageRatio_nonneg (n : ℕ) [NeZero n] : 0 ≤ coverageRatio n := by
  have hn : (1 : ℝ) ≤ n := by exact_mod_cast Nat.one_le_iff_ne_zero.mpr (NeZero.ne n)
  have hb : 0 ≤ 1 - 1 / (n : ℝ) := sub_nonneg.mpr ((div_le_one (by positivity)).mpr hn)
  have hdiv : 0 ≤ 1 / (n : ℝ) := by positivity
  exact sub_nonneg.mpr (pow_le_one₀ hb (by linarith))

theorem coverageRatio_tendsto :
    Tendsto coverageRatio atTop (𝓝 (1 - 1 / Real.exp 1)) := by
  have h := tendsto_one_plus_div_pow_exp (-1 : ℝ)
  change Tendsto (fun n : ℕ => 1 - (1 - 1 / (n : ℝ)) ^ n) _ _
  have hc : Tendsto (fun _ : ℕ => (1 : ℝ)) atTop (𝓝 1) := tendsto_const_nhds
  simpa [coverageRatio, neg_div, sub_eq_add_neg, Real.exp_neg, one_div] using
    hc.sub h

def finiteRatio (n L : ℕ) : ℝ :=
  (coverageRatio n + (n : ℝ)^3 / L) / (1 - (n : ℝ)^2 / L)

theorem finiteRatio_tendsto (n : ℕ) : Tendsto (finiteRatio n) atTop (𝓝 (coverageRatio n)) := by
  have hinv : Tendsto (fun L : ℕ => (L : ℝ)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp tendsto_natCast_atTop_atTop
  have hc : Tendsto (fun _ : ℕ => coverageRatio n) atTop (𝓝 (coverageRatio n)) := tendsto_const_nhds
  have h1 : Tendsto (fun _ : ℕ => (1 : ℝ)) atTop (𝓝 1) := tendsto_const_nhds
  have hnum := hc.add (hinv.const_mul ((n : ℝ)^3))
  have hden := h1.sub (hinv.const_mul ((n : ℝ)^2))
  simpa [finiteRatio,div_eq_mul_inv] using hnum.div hden (by norm_num : (1 : ℝ) - n^2*0 ≠ 0)

/-- Parameters are chosen before the algorithm, so one instance defeats every online policy. -/
theorem exists_hard_parameters (ξ : ℝ) (hξ : 0 < ξ) :
    ∃ n L : ℕ, 2 ≤ n ∧ n ≤ L ∧
      0 < 1 - (n : ℝ)^2 / L ∧ finiteRatio n L < 1 - 1 / Real.exp 1 + ξ := by
  have hnEvent : ∀ᶠ n in atTop, coverageRatio n < 1 - 1 / Real.exp 1 + ξ / 2 :=
    coverageRatio_tendsto.eventually (gt_mem_nhds (by linarith))
  obtain ⟨n,hn,hn2⟩ := (hnEvent.and (eventually_ge_atTop 2)).exists
  have hrEvent : ∀ᶠ L in atTop, finiteRatio n L < 1 - 1 / Real.exp 1 + ξ :=
    (finiteRatio_tendsto n).eventually (gt_mem_nhds (by linarith))
  have hinv : Tendsto (fun L : ℕ => (L : ℝ)⁻¹) atTop (𝓝 0) :=
    tendsto_inv_atTop_zero.comp tendsto_natCast_atTop_atTop
  have hd : Tendsto (fun L : ℕ => 1 - (n : ℝ)^2 / L) atTop (𝓝 1) := by
    have hc : Tendsto (fun _ : ℕ => (1 : ℝ)) atTop (𝓝 1) := tendsto_const_nhds
    simpa [div_eq_mul_inv] using hc.sub (hinv.const_mul ((n : ℝ)^2))
  have hdEvent : ∀ᶠ L : ℕ in atTop, 0 < 1 - (n : ℝ)^2 / L :=
    hd.eventually (lt_mem_nhds (by norm_num))
  obtain ⟨L,hL,hdL,hrL⟩ := ((eventually_ge_atTop n).and (hdEvent.and hrEvent)).exists
  exact ⟨n,L,hn2,hL,hdL,hrL⟩

end MatroidProphetSecretary.XOS
