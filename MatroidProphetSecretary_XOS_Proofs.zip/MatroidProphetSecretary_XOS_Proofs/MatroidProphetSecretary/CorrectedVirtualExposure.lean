import MatroidProphetSecretary.VirtualExposure

/-! The early overlap estimate with an explicit finite-grid correction to every late multiplier. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem corrected_virtual_exposure_value (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (dt lam p : ℝ) (n : ℕ) (s : VirtualState M) (x : Fin n → Option (E × W)) :
    virtualWeightedLiveValue μ M base hbase value
      (fun e => 1+virtualEarlyExposure μ M base hbase value dt lam n s x e-p)
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x) =
    (1-p)*virtualTotalLiveValue μ M base hbase value
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x)+
      virtualExposureValue μ M base hbase value dt lam n s x := by
  simp only [virtualWeightedLiveValue,virtualTotalLiveValue,virtualExposureValue,mul_sum,← sum_add_distrib]
  apply sum_congr rfl
  intro e he
  ring

theorem virtualProcess_corrected_exposure_value (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (dt lam p : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam)
    (hstep : dt*lam ≤ 1) (hsmall : dt*lam*Fintype.card E ≤ 1) (hp : p ≤ 1)
    (n : ℕ) (s : VirtualState M) :
    (1-p)*(1-dt*lam)^n*virtualTotalLiveValue μ M base hbase value s+
      (1-dt*lam)^n*(1-(1-dt*lam)^n)*virtualCurrentOverlap μ M base hbase value s ≤
    (FiniteLaw.adaptiveBatches
      (fun state => virtualStepLaw μ M base hbase value state dt (fun _ => lam) lam hdt hlam
        (fun _ => hlam) (fun _ => le_rfl) hsmall)
      (virtualUpdate M base hbase value) n s).expect
      (fun x => virtualWeightedLiveValue μ M base hbase value
        (fun e => 1+virtualEarlyExposure μ M base hbase value dt lam n s x e-p)
        (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x)) := by
  simp_rw [corrected_virtual_exposure_value]
  rw [FiniteLaw.expect_add,FiniteLaw.expect_const_mul,virtualExposureValue_expect]
  have hW := virtualProcess_total_value_persistence μ M base hbase value hv dt lam hdt hlam hstep
    (fun _ _ => lam) (fun _ _ => hlam) (fun _ _ => le_rfl) hsmall n s
  have hU := virtualProcess_overlap_accumulation μ M base hbase value hv dt lam hdt hlam hstep hsmall n s
  have h := add_le_add (mul_le_mul_of_nonneg_left hW (sub_nonneg.mpr hp)) hU
  convert h using 1
  ring

end MatroidProphetSecretary
