import MatroidProphetSecretary.GreedyOverlapLayer
import Mathlib.Data.Prod.Lex
import Mathlib.Data.Fintype.EquivFin

/-! Finite latent values can always be ordered in the directions required by association. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def valueLinearOrder {Ω : Type*} [Fintype Ω] (v : Ω → ℝ) : LinearOrder Ω :=
  LinearOrder.lift' (fun x => (toLex (v x, Fintype.equivFin Ω x) : ℝ ×ₗ Fin (Fintype.card Ω)))
    (fun _ _ h => (Fintype.equivFin Ω).injective (congrArg (fun x => (ofLex x).2) h))

theorem valueLinearOrder_monotone {Ω : Type*} [Fintype Ω] (v : Ω → ℝ) :
    @Monotone Ω ℝ (valueLinearOrder v).toPreorder inferInstance v := by
  intro x y h
  change toLex (v x, Fintype.equivFin Ω x) ≤ toLex (v y, Fintype.equivFin Ω y) at h
  rcases Prod.Lex.le_iff.mp h with h | h
  · exact h.le
  · exact h.1.le

variable {E : Type*} [Fintype E] [LinearOrder E]
    {V : E → Type*} [∀ e, Fintype (V e)]

theorem independent_latent_value_bound
    (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (e : E) (value : ∀ e, V e → ℝ) :
    nonspanProbability activity M e (fun _ => True) ≤
      (FiniteLaw.product latent).expect (fun x =>
        nonspanProbability activity M e (priorityBefore (fun f => value f (x f)) e)) *
      (FiniteLaw.product latent).expect (fun x =>
        nonspanProbability activity M e (fun f => priorityBefore (fun g => value g (x g)) f e)) := by
  let score := fun f (x : V f) => if f = e then value f x else -value f x
  letI : ∀ f, LinearOrder (V f) := fun f => valueLinearOrder (score f)
  have hown : Monotone (value e) := by
    intro x y hxy
    have h := valueLinearOrder_monotone (score e) hxy
    simpa only [score, if_pos rfl] using h
  have hothers : ∀ f, f ≠ e → Antitone (value f) := by
    intro f hfe x y hxy
    have h := valueLinearOrder_monotone (score f) hxy
    simpa only [score, if_neg hfe, neg_le_neg_iff] using h
  exact independent_latent_priority_bound activity latent M e value hown hothers

end MatroidProphetSecretary
