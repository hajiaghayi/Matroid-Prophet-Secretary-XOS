import MatroidProphetSecretary.PhysicalEulerProcess
import MatroidProphetSecretary.IndexedAdaptiveDrift

/-! The recorded reward telescopes to exactly the credited exchange reward. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem eulerBlock_expected_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (state : BlockState N V) :
    (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget state).expect
      (fun event => recordReward value (cfg.eulerBlockUpdate state event).2) =
    recordReward value state.2+
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget state).expect
        (virtualCredit M base hbase value (recordReplay M base hbase value state.2)) := by
  rw [← FiniteLaw.expect_const
    (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget state)
    (recordReward value state.2),← FiniteLaw.expect_add]
  apply FiniteLaw.expect_congr_support
  intro event hevent
  cases event with
  | none => simp [eulerBlockUpdate,eulerHistoryUpdate,updateGridHistory,appendOptional,virtualCredit]
  | some event =>
    have hl : event.1 ∈ virtualLive M base hbase value (recordReplay M base hbase value state.2) event.2 := by
      by_contra hnot
      apply hevent
      simp [eulerBlockBatch,eulerStep,virtualStepLaw,FiniteLaw.optionalLaw,virtualStepWeight,hnot]
    simp [eulerBlockUpdate,eulerHistoryUpdate,recordReward_updateGridHistory,gridMarkCredit,virtualCredit,hl]

theorem euler_trajectory_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (n : ℕ) (state : BlockState N V) :
    (FiniteLaw.adaptiveBatches (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
      cfg.eulerBlockUpdate n state).expect (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate n state x).2) =
    recordReward value state.2+
      (FiniteLaw.adaptiveBatches (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
        cfg.eulerBlockUpdate n state).expect
        (FiniteLaw.trajectoryReward cfg.eulerBlockUpdate
          (fun s => virtualCredit M base hbase value (recordReplay M base hbase value s.2)) n state) := by
  exact FiniteLaw.adaptive_reward_telescope
    (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget) cfg.eulerBlockUpdate
    (fun s => virtualCredit M base hbase value (recordReplay M base hbase value s.2))
    (fun s => recordReward value s.2)
    (cfg.eulerBlock_expected_reward M base hbase value hsmall omega homega homega1 hlower hbudget) n state

end MatroidProphetSecretary.PrivateGridConfig
