import MatroidProphetSecretary.RecordLiveMonotonicity
import MatroidProphetSecretary.StampedPrefix
import MatroidProphetSecretary.PhysicalSparseGenerator

/-! Replacing within-bin liveness by liveness at the beginning costs at most one grid step. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

def binEarlyExposure (μ : FiniteLaw (Fin N → Option V)) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ) (p : ℝ) (cut : ℕ)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (e : Fin N) : ℝ :=
  p*∑ i ∈ range cut, virtualLiveMass μ M base hbase value
    (recordReplay M base hbase value (recordsBefore (i*N) history)) e

namespace PrivateGridConfig

variable (cfg : PrivateGridConfig N L V)

theorem history_dose_eq (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L) (e : Fin N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (gridSlot clock e) = history))
    (i : ℕ) :
    cfg.dose (historyPath history) (gridSlot clock e) i =
      ((1/(L:ℝ))*(1/cfg.q))*virtualLiveMass (FiniteLaw.product cfg.reference) M base hbase value
        (recordReplay M base hbase value (recordsBefore (i*N+e.val) history)) e := by
  have hfix := cfg.current_history_fixed history (gridSlot clock e) hp
  unfold dose profile gridHistoryProfile gridLiveDose historyPath
  rw [hfix,gridLabel_slot N L cfg.labels_pos clock e]
  congr 1
  apply FiniteLaw.prob_congr
  intro y
  exact hlive _ _ _

theorem physical_bin_exposure_loss (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L) (e : Fin N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (gridSlot clock e) = history))
    (hcut : cfg.cut ≤ clock.val) :
    binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
      ((1/(L:ℝ))*(1/cfg.q)) cfg.cut history e - ((1/(L:ℝ))*(1/cfg.q)) ≤
      accumulatedExposure (cfg.dose (historyPath history) (gridSlot clock e)) cfg.cut := by
  obtain ⟨tapes,ht⟩ := FiniteLaw.exists_of_prob_pos (FiniteLaw.product cfg.laws)
    (fun tapes => cfg.run tapes (gridSlot clock e) = history) (by convert hp using 1; congr 1)
  let before := fun i => virtualLiveMass (FiniteLaw.product cfg.reference) M base hbase value
    (recordReplay M base hbase value (cfg.run tapes (i*N))) e
  let inside := fun i => virtualLiveMass (FiniteLaw.product cfg.reference) M base hbase value
    (recordReplay M base hbase value (cfg.run tapes (i*N+e.val))) e
  have hbetween (i : ℕ) : before (i+1) ≤ inside i := by
    apply recordReplay_prefix_mass_antitone
    apply stampedRun_prefix
    simp only [Nat.add_mul,Nat.one_mul]
    omega
  have hreconstruct (i : ℕ) (hi : i ≤ gridSlot clock e) :
      recordsBefore i history = cfg.run tapes i := by
    rw [← ht]
    exact recordsBefore_stampedRun _ _ _ tapes hi
  have hb (i : ℕ) (hi : i ∈ range cfg.cut) :
      virtualLiveMass (FiniteLaw.product cfg.reference) M base hbase value
        (recordReplay M base hbase value (recordsBefore (i*N) history)) e = before i := by
    rw [hreconstruct _ ((Nat.mul_le_mul_right N ((mem_range.mp hi).le.trans hcut)).trans (Nat.le_add_right _ _))]
  have hd (i : ℕ) (hi : i ∈ range cfg.cut) :
      cfg.dose (historyPath history) (gridSlot clock e) i = ((1/(L:ℝ))*(1/cfg.q))*inside i := by
    rw [cfg.history_dose_eq M base hbase value hlive history clock e hp i,
      hreconstruct _ (Nat.add_le_add_right (Nat.mul_le_mul_right N ((mem_range.mp hi).le.trans hcut)) _)]
  calc
    _ = ((1/(L:ℝ))*(1/cfg.q))*(∑ i ∈ range cfg.cut, before i)-((1/(L:ℝ))*(1/cfg.q)) := by
      unfold binEarlyExposure
      congr 2
      exact sum_congr rfl hb
    _ ≤ ((1/(L:ℝ))*(1/cfg.q))*(∑ i ∈ range cfg.cut, inside i) :=
      within_bin_exposure_loss before inside hbetween ((FiniteLaw.product cfg.reference).prob_le_one _)
        (fun _ => (FiniteLaw.product cfg.reference).prob_nonneg _)
        _ (mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)) cfg.cut
    _ = _ := by
      rw [accumulatedExposure,mul_sum]
      exact sum_congr rfl (fun i hi => (hd i hi).symm)

theorem eulerRate_exposure_lower (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L) (e : Fin N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (gridSlot clock e) = history))
    (hcut : cfg.cut ≤ clock.val)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q))) :
    (1/cfg.q)*(1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
      ((1/(L:ℝ))*(1/cfg.q)) cfg.cut history e - ((1/(L:ℝ))*(1/cfg.q))) ≤
      cfg.eulerRate history clock e := by
  have he := cfg.physical_bin_exposure_loss M base hbase value hlive history clock e hp hcut
  have hc : cfg.cut ≤ (gridClock N L cfg.clocks_pos (gridSlot clock e)).val := by
    rwa [gridClock_slot N L cfg.clocks_pos clock e]
  have hr := (cfg.late_rate_bounds (historyPath history) (gridSlot clock e) hc hsmall omega homega hlower).1
  unfold eulerRate historyRate
  rw [if_neg (not_lt.mpr hc)]
  have hm := mul_le_mul_of_nonneg_left (add_le_add_left he 1) (one_div_nonneg.mpr cfg.q_pos.le)
  calc
    _ ≤ (1/cfg.q)*(1+accumulatedExposure (cfg.dose (historyPath history) (gridSlot clock e)) cfg.cut) := by
      convert hm using 1 <;> ring
    _ ≤ _ := hr

end PrivateGridConfig
end MatroidProphetSecretary
