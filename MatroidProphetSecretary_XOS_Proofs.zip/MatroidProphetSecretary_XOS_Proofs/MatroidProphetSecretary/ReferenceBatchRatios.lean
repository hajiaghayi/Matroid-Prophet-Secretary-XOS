import MatroidProphetSecretary.ReferenceQueryCertificates
import MatroidProphetSecretary.SamplerAccuracy

/-! The signed reference tests use the actual common-sampler batch statistics. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def referenceBatchEstimate (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (q : ℝ) (i : Fin 3) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) : ℝ :=
  FiniteLaw.sampleAverage
    (samplerStatistic (referenceInstanceLaws laws value q) (referenceInstanceValues value) G M (Sum.inl i)) x

def referenceBatchRatio (unstable : Bool) (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (θ q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) : ℝ :=
  referenceBatchEstimate laws value G M q (if unstable then 2 else 1) x /
    referenceBatchEstimate laws value G M q 0 x - θ*q/(1-θ*q)

def referencePositiveTest (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (θ ε q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) : Bool :=
  decide (10*ε < referenceBatchRatio true laws value G M θ q x)

def referenceNegativeTest (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (θ ε q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) : Bool :=
  decide (referenceBatchRatio false laws value G M θ q x < -10*ε)

theorem referenceBatchRatio_accuracy (unstable : Bool) (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (θ q ε : ℝ) (N : ℕ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q) (hε0 : 0 ≤ ε) (hε1 : ε ≤ 1/10)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value)
      G M hnonloop N ε x) :
    0 < referenceBatchEstimate laws value G M q 0 x ∧
      |referenceBatchRatio unstable laws value G M θ q x -
        referenceSearchRatio unstable laws M value hnonloop θ q| ≤ 5*ε := by
  let vol := finiteValueVolume (referenceInstanceLaws laws value q) (referenceInstanceValues value) G
  have hFerr := samplerBatch_accuracy_of_not_bad (referenceInstanceLaws laws value q)
    (referenceInstanceValues value) G M hnonloop N ε x hgood (Sum.inl 0)
  change |referenceBatchEstimate laws value G M q 0 x-referenceExpectedOptimum laws M value q| ≤
    ε*referenceExpectedOptimum laws M value q+ε*vol at hFerr
  have hNerr : |referenceBatchEstimate laws value G M q (if unstable then 2 else 1) x -
      referenceSearchNumerator unstable laws M value hnonloop q| ≤
      ε*referenceSearchNumerator unstable laws M value hnonloop q+ε*vol := by
    have h := samplerBatch_accuracy_of_not_bad (referenceInstanceLaws laws value q)
      (referenceInstanceValues value) G M hnonloop N ε x hgood (Sum.inl (if unstable then 2 else 1))
    cases unstable <;> simpa [referenceBatchEstimate, referenceSearchNumerator,
      referenceDeletion,referenceStable,samplerTarget,samplerStatisticTolerance] using h
  have hN := referenceSearchNumerator_bounds unstable laws M value hnonloop q
  have hV := finiteValueVolume_le_expectedOptimum (referenceInstanceLaws laws value q)
    (referenceInstanceValues value) G M hnonloop
  have hr := ratio_accuracy_five (referenceExpectedOptimum laws M value q)
    (referenceSearchNumerator unstable laws M value hnonloop q) vol
    (referenceBatchEstimate laws value G M q 0 x)
    (referenceBatchEstimate laws value G M q (if unstable then 2 else 1) x)
    ε hF hN.1 hN.2 hV hε0 hε1
    (by simpa only [mul_add] using hFerr) (by simpa only [mul_add] using hNerr)
  exact ⟨hr.1,by simpa only [referenceBatchRatio,referenceSearchRatio,sub_sub_sub_cancel_right] using hr.2⟩

theorem referenceBatch_positive_certificate (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (θ q ε : ℝ) (N : ℕ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q) (hε0 : 0 ≤ ε) (hε1 : ε ≤ 1/10)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value)
      G M hnonloop N ε x) :
    if referencePositiveTest laws value G M θ ε q x then
      0 < referenceSearchRatio true laws M value hnonloop θ q
    else referenceSearchRatio true laws M value hnonloop θ q ≤ 15*ε := by
  have he := (referenceBatchRatio_accuracy true laws value G M hnonloop θ q ε N x hF hε0 hε1 hgood).2
  simp only [referencePositiveTest,decide_eq_true_eq]
  split_ifs with h
  · have hh := (abs_le.mp he).2
    linarith
  · have hh := (abs_le.mp he).1
    have hn := le_of_not_gt h
    linarith

theorem referenceBatch_negative_certificate (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (θ q ε : ℝ) (N : ℕ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q) (hε0 : 0 ≤ ε) (hε1 : ε ≤ 1/10)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value)
      G M hnonloop N ε x) :
    if referenceNegativeTest laws value G M θ ε q x then
      referenceSearchRatio false laws M value hnonloop θ q < 0
    else -15*ε ≤ referenceSearchRatio false laws M value hnonloop θ q := by
  have he := (referenceBatchRatio_accuracy false laws value G M hnonloop θ q ε N x hF hε0 hε1 hgood).2
  simp only [referenceNegativeTest,decide_eq_true_eq]
  split_ifs with h
  · have hh := (abs_le.mp he).1
    linarith
  · have hh := (abs_le.mp he).2
    have hn := le_of_not_gt h
    linarith

end MatroidProphetSecretary
