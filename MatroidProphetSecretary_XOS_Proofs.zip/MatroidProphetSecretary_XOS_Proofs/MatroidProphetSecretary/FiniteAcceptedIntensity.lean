import MatroidProphetSecretary.MarkedHistory
import MatroidProphetSecretary.FiniteSupport

/-! The finite accepted-history intensity is the private arrival kernel divided by survival. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E T Ω A S : Type*} [Fintype E] [DecidableEq E] [Fintype T] [Fintype Ω]

theorem privatePath_coordinate_probability (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n))
    (e : E) (B : Ω → Prop) :
    ((FiniteLaw.product laws).conditionOrSelf (privatePathEvent label step initial path n)).prob
      (fun x => B (x e)) =
    ((laws e).conditionOrSelf (privateCoordinateEvent label step path n e)).prob B := by
  have h := privatePath_conditional_expect laws label step initial path hstart n hp
    (fun x => if B (x e) then 1 else 0)
  rw [FiniteLaw.product_expect_single_coordinate
    (fun f => (laws f).conditionOrSelf (privateCoordinateEvent label step path n f))
    e (fun w => if B w then 1 else 0)] at h
  exact h

def pastMarkedAcceptance (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A) (path : ℕ → List (E × A))
    (n : ℕ) (e : E) (t : T) (w : Ω) : Prop :=
  ∃ i < n, label i = e ∧ t = time i ∧ decision i (path i) w ≠ none

theorem pastMarkedAbsence_iff (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A) (path : ℕ → List (E × A))
    (n : ℕ) (e : E) (x : T × Ω) :
    pastMarkedAbsence label time decision path n e x ↔
      ¬ pastMarkedAcceptance label time decision path n e x.1 x.2 := by
  constructor
  · intro h ⟨i,hi,he,ht,hd⟩
    exact h i hi he ⟨ht,hd⟩
  · intro h i hi he ⟨ht,hd⟩
    exact h ⟨i,hi,he,ht,hd⟩

theorem pastMarkedAbsence_survival (clock : FiniteLaw T) (tape : FiniteLaw Ω)
    (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A) (path : ℕ → List (E × A))
    (n : ℕ) (e : E) :
    (clock.pair tape).prob (pastMarkedAbsence label time decision path n e) =
      1-∑ t, clock.mass t * tape.prob (pastMarkedAcceptance label time decision path n e t) := by
  rw [FiniteLaw.prob_congr _ (pastMarkedAbsence_iff label time decision path n e),FiniteLaw.prob_not]
  congr 1
  unfold FiniteLaw.prob
  rw [FiniteLaw.pair_expect]
  rfl

theorem fresh_mark_implies_absence (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A) (path : ℕ → List (E × A))
    (n : ℕ) (hfresh : ∀ i < n, label i = label n → time i ≠ time n)
    (x : T × Ω) (ht : x.1 = time n) :
    pastMarkedAbsence label time decision path n (label n) x := by
  intro i hi he h
  exact hfresh i hi he (h.1.symm.trans ht)

theorem markedPath_next_intensity (clocks : E → FiniteLaw T) (tapes : E → FiniteLaw Ω)
    (label : ℕ → E) (time : ℕ → T) (decision : ℕ → List (E × A) → Ω → Option A)
    (initial : List (E × A)) (path : ℕ → List (E × A)) (hstart : path 0 = initial) (n : ℕ)
    (hp : 0 < (FiniteLaw.product (fun e => (clocks e).pair (tapes e))).prob
      (privatePathEvent label (markedStep label time decision) initial path n))
    (habsent : ∀ mark, (label n,mark) ∉ path n)
    (hfresh : ∀ i < n, label i = label n → time i ≠ time n) (B : A → Prop) :
    ((FiniteLaw.product (fun e => (clocks e).pair (tapes e))).conditionOrSelf
      (privatePathEvent label (markedStep label time decision) initial path n)).prob
      (fun x => (x (label n)).1 = time n ∧ ∃ mark,
        decision n (privateStepRun label (markedStep label time decision) initial x n) (x (label n)).2 = some mark ∧ B mark) =
      (clocks (label n)).mass (time n) *
        (tapes (label n)).prob (fun w => ∃ mark, decision n (path n) w = some mark ∧ B mark) /
      ((clocks (label n)).pair (tapes (label n))).prob
        (pastMarkedAbsence label time decision path n (label n)) := by
  let laws := fun e => (clocks e).pair (tapes e)
  let P := privatePathEvent label (markedStep label time decision) initial path n
  let C := privateCoordinateEvent label (markedStep label time decision) path n (label n)
  let Q := pastMarkedAbsence label time decision path n (label n)
  let D := fun x : T × Ω => x.1 = time n ∧ ∃ mark, decision n (path n) x.2 = some mark ∧ B mark
  have hC (x : T × Ω) : C x ↔ Q x :=
    absent_coordinate_event_iff laws label time decision initial path n hp (label n) habsent x
  have hD (x : T × Ω) (hx : D x) : C x :=
    (hC x).mpr (fresh_mark_implies_absence label time decision path n hfresh x hx.1)
  calc
    _ = ((FiniteLaw.product laws).conditionOrSelf P).prob (fun x => D (x (label n))) := by
      apply FiniteLaw.prob_congr_support
      intro x hx
      have hpath := FiniteLaw.conditionOrSelf_support (FiniteLaw.product laws) P hp x hx
      dsimp only [D]
      rw [hpath n le_rfl]
    _ = ((laws (label n)).conditionOrSelf C).prob D := by
      convert privatePath_coordinate_probability laws label (markedStep label time decision) initial path hstart n hp (label n) D using 1
      all_goals
        unfold FiniteLaw.prob
        congr 1
        funext x
        split_ifs <;> rfl
    _ = (laws (label n)).prob D / (laws (label n)).prob C := by
      convert FiniteLaw.condition_prob_eq_div (laws (label n)) C D hD
        (privatePath_coordinate_positive laws label (markedStep label time decision) initial path hstart n hp (label n)) using 1
      · unfold FiniteLaw.prob
        congr 1
        funext x
        split_ifs <;> rfl
      · congr 1
        unfold FiniteLaw.prob
        congr 1
        funext x
        split_ifs <;> rfl
    _ = _ := by
      rw [FiniteLaw.prob_congr (laws (label n)) hC]
      congr 1
      convert FiniteLaw.pair_prob_at_time (clocks (label n)) (tapes (label n)) (time n)
        (fun w => ∃ mark, decision n (path n) w = some mark ∧ B mark) using 1
      · unfold FiniteLaw.prob
        congr 1
        funext x
        split_ifs <;> rfl
      · congr 1
        unfold FiniteLaw.prob
        congr 1
        funext x
        split_ifs <;> rfl

end MatroidProphetSecretary
