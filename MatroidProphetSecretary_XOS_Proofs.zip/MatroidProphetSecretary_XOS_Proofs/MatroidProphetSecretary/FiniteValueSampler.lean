import MatroidProphetSecretary.ValueLayerStatistics

/-! The common sampler is unbiased for the actual finite-prior matroid quantities. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def finiteValueVolume (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) : ℝ :=
  nonemptyLayerVolume (heightBinWidth value G) (heightBinLaws laws value G)

def finiteValueSampler (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G) :
    FiniteLaw (Fin G.last × (E → Bool)) :=
  nonemptyLayerSampler (heightBinWidth value G) (heightBinLaws laws value G)
    (heightBinWidth_nonneg value G) hV

theorem finiteValueSampler_statistic_unbiased (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (φ : (E → ℝ) → (E → Bool) → ℝ) (hφ : ∀ p, φ p (fun _ => false) = 0)
    (hf : Integrable (positiveActivityExpectation laws value φ)) :
    (finiteValueSampler laws value G hV).expect (fun y => finiteValueVolume laws value G *
      φ (coordinateTail laws value (G.level y.1.val)) y.2) =
        ∫ z, positiveActivityExpectation laws value φ z := by
  unfold finiteValueSampler finiteValueVolume
  rw [nonemptyLayerSampler_unbiased (heightBinWidth value G) (heightBinLaws laws value G)
    (heightBinWidth_nonneg value G) hV
    (fun j x => φ (coordinateTail laws value (G.level j.val)) x) (by
      intro j x hx
      have heq : x = fun _ => false := by
        funext e
        have hn : x e ≠ true := fun he => hx ⟨e,he⟩
        cases he : x e <;> simp_all
      rw [heq]
      exact hφ _)]
  exact (positiveActivityExpectation_bins laws value G φ hφ hf).symm

theorem finiteValueSampler_expected_rank (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) :
    (finiteValueSampler laws value G hV).expect
      (fun y => finiteValueVolume laws value G * realRank M (bitSet y.2)) =
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  rw [finiteValueSampler_statistic_unbiased laws value G hV
    (fun _ x => realRank M (bitSet x)) (by intro p; simp [bitSet, realRank])
    (rank_activity_integrable laws value hv M hground)]
  simp only [rank_activity_expectation laws value M hground]
  exact (expectedOptimum_eq_integral_expected_rank (FiniteLaw.product laws) M
    (coordinateValues value) (fun x e => hv e (x e))).symm

theorem finiteValueSampler_expected_coloops (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) :
    (finiteValueSampler laws value G hV).expect
      (fun y => finiteValueVolume laws value G * activeColoopCount M y.2) =
        deletionSurplus (FiniteLaw.product laws) M (coordinateValues value) := by
  rw [finiteValueSampler_statistic_unbiased laws value G hV (fun _ => activeColoopCount M)
    (by intro p; simp [activeColoopCount, activeColoopIndicator])
    (coloop_activity_integrable laws value hv M hground)]
  simp only [coloop_activity_expectation laws value M hground]
  exact (deletionSurplus_eq_integral_coloop_count (FiniteLaw.product laws) M
    (coordinateValues value) (fun x e => hv e (x e))).symm

theorem finiteValueSampler_expected_unstable (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    (finiteValueSampler laws value G hV).expect (fun y => finiteValueVolume laws value G *
      activeUnstableCount M (coordinateTail laws value (G.level y.1.val)) y.2) =
        deletionSurplus (FiniteLaw.product laws) M (coordinateValues value) -
          stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  rw [finiteValueSampler_statistic_unbiased laws value G hV (fun p => activeUnstableCount M p)
    (by intro p; simp [activeUnstableCount, activeColoopIndicator])
    (unstable_activity_integrable laws value hv M hg)]
  simp only [unstable_activity_expectation laws value M hg]
  have hD := coloop_activity_integrable laws value hv M hg
  rw [funext (coloop_activity_expectation laws value M hg)] at hD
  rw [integral_sub hD (stableLayerExpectation_integrable (FiniteLaw.product laws) M
    (coordinateValues value) (fun x e => hv e (x e))),
    ← deletionSurplus_eq_integral_coloop_count (FiniteLaw.product laws) M
      (coordinateValues value) (fun x e => hv e (x e)),
    stableSurplus_eq_integral_tail_coloop (FiniteLaw.product laws) M
      (coordinateValues value) (fun x e => hv e (x e)) hnonloop]
  rfl

theorem finiteValueSampler_expected_threshold (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) :
    (finiteValueSampler laws value G hV).expect
      (fun y => finiteValueVolume laws value G * activeOtherClosure M e y.2) =
        meanThreshold (FiniteLaw.product laws) M (coordinateValues value) hnonloop e := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  rw [finiteValueSampler_statistic_unbiased laws value G hV (fun _ => activeOtherClosure M e)
    (by intro p; exact activeOtherClosure_empty M e (hnonloop e) (fun _ => false) (by simp))
    (closure_activity_integrable laws value hv M hg e (hnonloop e))]
  simp only [closure_activity_expectation laws value M hg e]
  exact (meanThreshold_eq_integral (FiniteLaw.product laws) M (coordinateValues value)
    (fun x e => hv e (x e)) hnonloop e).symm

end MatroidProphetSecretary
