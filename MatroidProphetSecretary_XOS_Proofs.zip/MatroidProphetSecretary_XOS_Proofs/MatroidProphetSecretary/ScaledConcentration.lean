import MatroidProphetSecretary.FiniteConcentration

/-! Concentration with a natural observation scale, and simultaneous finite statistics. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

def sampleAverage {m : ℕ} (Z : Ω → ℝ) (x : Fin m → Ω) : ℝ := (∑ i, Z (x i))/(m:ℝ)

theorem iid_scaled_relative_tail (law : FiniteLaw Ω) (Z : Ω → ℝ) (B : ℝ) (hB : 0 < B)
    (hZ0 : ∀ x, 0 ≤ Z x) (hZB : ∀ x, Z x ≤ B)
    (m : ℕ) (hm : 0 < m) (γ β : ℝ) (hγ0 : 0 < γ) (hγ1 : γ ≤ 1) :
    (product (fun _ : Fin m => law)).prob
      (fun x => γ * law.expect Z + β < |sampleAverage Z x - law.expect Z|) ≤
        2 * Real.exp (-(m:ℝ)*γ*β/B) := by
  let W := fun x => Z x / B
  have hW0 : ∀ x, 0 ≤ W x := fun x => div_nonneg (hZ0 x) hB.le
  have hW1 : ∀ x, W x ≤ 1 := fun x => (div_le_one hB).mpr (hZB x)
  have hmean : law.expect W = law.expect Z / B := by
    simp only [W, div_eq_mul_inv, expect_mul_const]
  have hid (x : Fin m → Ω) :
      (∑ i, W (x i))/(m:ℝ) - law.expect W = (sampleAverage Z x - law.expect Z)/B := by
    rw [hmean]
    simp only [W, ← sum_div, sampleAverage]
    ring
  have h := iid_average_relative_tail law W hW0 hW1 m hm γ (β/B) hγ0 hγ1
  have he : -(m:ℝ)*γ*(β/B) = -(m:ℝ)*γ*β/B := by ring
  rw [he] at h
  refine (prob_mono _ (fun x hx => ?_)).trans h
  rw [hid, hmean, abs_div, abs_of_pos hB]
  have hd := (div_lt_div_iff_of_pos_right hB).mpr hx
  convert hd using 1 <;> ring

theorem simultaneous_scaled_relative_tail {I : Type*} [Fintype I]
    (law : FiniteLaw Ω) (Z : I → Ω → ℝ) (B β : I → ℝ) (hB : ∀ i, 0 < B i)
    (hZ0 : ∀ i x, 0 ≤ Z i x) (hZB : ∀ i x, Z i x ≤ B i)
    (m : ℕ) (hm : 0 < m) (γ : ℝ) (hγ0 : 0 < γ) (hγ1 : γ ≤ 1) :
    (product (fun _ : Fin m => law)).prob (fun x => ∃ i,
      γ * law.expect (Z i) + β i < |sampleAverage (Z i) x - law.expect (Z i)|) ≤
        ∑ i, 2 * Real.exp (-(m:ℝ)*γ*β i/B i) := by
  refine ((product (fun _ : Fin m => law)).union_bound
    (fun i x => γ * law.expect (Z i) + β i < |sampleAverage (Z i) x - law.expect (Z i)|)).trans ?_
  exact sum_le_sum (fun i _ => iid_scaled_relative_tail law (Z i) (B i) (hB i)
    (hZ0 i) (hZB i) m hm γ (β i) hγ0 hγ1)

end MatroidProphetSecretary.FiniteLaw
