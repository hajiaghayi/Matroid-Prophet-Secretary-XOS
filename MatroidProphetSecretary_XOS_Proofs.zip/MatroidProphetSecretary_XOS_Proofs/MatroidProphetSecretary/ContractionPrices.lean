import MatroidProphetSecretary.ExchangeConstruction
import MatroidProphetSecretary.Structural

/-! Contraction prices are charged injectively to a realized optimal basis. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

theorem optimum_attained_base (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    ∃ B : Finset E, M.IsBase (B : Set E) ∧ optimum M v = weight v B := by
  classical
  obtain ⟨I, hI, hopt⟩ := optimumOver_attained
    (fun I : Finset E => M.Indep (I : Set E)) (by simpa using M.empty_indep) v
  obtain ⟨C, hC, hIC⟩ := hI.exists_isBase_superset
  let B := C.toFinset
  have hB : M.IsBase (B : Set E) := by simpa [B] using hC
  have hIB : I ⊆ B := by
    intro e he
    exact Set.mem_toFinset.mpr (hIC he)
  refine ⟨B, hB, le_antisymm ?_ (weight_le_optimumOver _ _ v hB.indep)⟩
  change optimumOver _ _ v ≤ weight v B
  rw [hopt]
  exact sum_le_sum_of_subset_of_nonneg hIB (fun e _ _ => hv e)

def optimalBasis (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) : Finset E :=
  (optimum_attained_base M v hv).choose

theorem optimalBasis_isBase (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    M.IsBase (optimalBasis M v hv : Set E) :=
  (optimum_attained_base M v hv).choose_spec.1

theorem optimalBasis_weight (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    weight v (optimalBasis M v hv) = optimum M v :=
  (optimum_attained_base M v hv).choose_spec.2.symm

theorem optimum_smul (M : Matroid E) (v : E → ℝ) (a : ℝ) (ha : 0 ≤ a) :
    optimum M (fun e => a * v e) = a * optimum M v := by
  have hw : ∀ I : Finset E, weight (fun e => a * v e) I = a * weight v I := by
    intro I
    simp only [weight, mul_sum]
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    rw [hw]
    exact mul_le_mul_of_nonneg_left (weight_le_optimumOver _ _ v hI) ha
  · obtain ⟨I, hI, hopt⟩ := optimumOver_attained
      (fun I : Finset E => M.Indep (I : Set E)) (by simpa using M.empty_indep) v
    change a * optimumOver _ _ v ≤ _
    rw [hopt, ← hw]
    exact weight_le_optimumOver _ _ _ hI

def contractionCost (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) : ℝ :=
  optimum M v - contractionValue M v e he

theorem contractionCost_nonneg (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) : 0 ≤ contractionCost M v e he := by
  exact sub_nonneg.mpr ((contraction_le_deletion M v e he).trans (deletion_le_optimum M v e))

theorem contractionCost_le_exchange_weight {M : Matroid E} {v : E → ℝ} {C B : Finset E}
    (φ : ExchangeMap M C B) (hopt : optimum M v = weight v B)
    {e : E} (heC : e ∈ C) (he : M.Indep ({e} : Set E)) :
    contractionCost M v e he ≤ v (φ.map e) := by
  have heErase : e ∉ B.erase (φ.map e) := by
    by_cases heB : e ∈ B
    · rw [φ.fixes e heC heB]
      exact not_mem_erase e B
    · exact fun h => heB (mem_of_mem_erase h)
  have hcon : weight v (B.erase (φ.map e)) ≤ contractionValue M v e he :=
    weight_le_optimumOver _ _ v ⟨heErase, (φ.exchange e heC).indep⟩
  have hsum : weight v B = v (φ.map e) + weight v (B.erase (φ.map e)) := by
    simpa [weight] using (add_sum_erase B v (φ.image_mem e heC)).symm
  unfold contractionCost
  rw [hopt, hsum]
  linarith

/-- The pointwise contraction-price inequality, before taking expectations. -/
theorem sum_contractionCost_le_optimum (M : Matroid E) (v : E → ℝ)
    (hv : ∀ e, 0 ≤ v e) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (I : Finset E) (hI : M.Indep (I : Set E)) :
    (∑ e ∈ I, contractionCost M v e (hnonloop e)) ≤ optimum M v := by
  classical
  obtain ⟨C, hC, hIC⟩ := hI.exists_isBase_superset
  let C' := C.toFinset
  have hC' : M.IsBase (C' : Set E) := by simpa [C'] using hC
  have hIC' : I ⊆ C' := fun _ he => Set.mem_toFinset.mpr (hIC he)
  obtain ⟨B, hB, hopt⟩ := optimum_attained_base M v hv
  let φ := chosenExchangeMap M C' B hC' hB
  calc
    (∑ e ∈ I, contractionCost M v e (hnonloop e)) ≤ ∑ e ∈ I, v (φ.map e) :=
      sum_le_sum (fun e he => contractionCost_le_exchange_weight φ hopt (hIC' he) (hnonloop e))
    _ = ∑ b ∈ I.image φ.map, v b := by
      symm
      exact sum_image (fun e he f hf h => φ.inj e (hIC' he) f (hIC' hf) h)
    _ ≤ weight v B := by
      apply sum_le_sum_of_subset_of_nonneg
      · intro b hb
        obtain ⟨e, he, rfl⟩ := mem_image.mp hb
        exact φ.image_mem e (hIC' he)
      · exact fun e _ _ => hv e
    _ = optimum M v := hopt.symm

def contractionPrice (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) : ℝ :=
  μ.expect (fun w => contractionCost M (v w) e (hnonloop e))

def meanThreshold (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) : ℝ :=
  μ.expect (fun w => exclusionThreshold M (v w) e (hnonloop e))

theorem contractionPrice_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) :
    0 ≤ contractionPrice μ M v hnonloop e :=
  μ.expect_nonneg (fun w => contractionCost_nonneg M (v w) e (hnonloop e))

theorem meanThreshold_le_contractionPrice (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) :
    meanThreshold μ M v hnonloop e ≤ contractionPrice μ M v hnonloop e := by
  apply μ.expect_mono
  intro w
  exact sub_le_sub_right (deletion_le_optimum M (v w) e) _

theorem contractionPrice_eq_meanThreshold_add_surplus (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (e : E) :
    contractionPrice μ M v hnonloop e = meanThreshold μ M v hnonloop e +
      μ.expect (fun w => optimum M (v w) - deletionValue M (v w) e) := by
  unfold contractionPrice meanThreshold contractionCost exclusionThreshold
  rw [← μ.expect_add]
  congr 1
  funext w
  ring

/-- The expected maximum-weight basis of contraction prices is bounded by F. -/
theorem optimum_contractionPrice_le_expectedOptimum (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    optimum M (contractionPrice μ M v hnonloop) ≤ expectedOptimum μ M v := by
  apply optimumOver_le
  intro I hI
  have h := μ.expect_mono (fun w => sum_contractionCost_le_optimum M (v w) (hv w) hnonloop I hI)
  dsimp [FiniteLaw.expect] at h
  simp_rw [mul_sum] at h
  rw [sum_comm] at h
  exact h

end MatroidProphetSecretary
