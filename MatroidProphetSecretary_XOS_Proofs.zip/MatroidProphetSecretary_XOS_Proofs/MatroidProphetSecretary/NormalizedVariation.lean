import MatroidProphetSecretary.Algebra

/-! Quantitative normalization and the stationary-ratio Lipschitz estimate. -/

namespace MatroidProphetSecretary

theorem normalized_ratio_variation (Fr Fq Cr Cq F0 lo L d : ℝ)
    (hF0 : 0 < F0) (hlo : 0 < lo) (hL : 0 ≤ L) (hd : 0 ≤ d)
    (hFr : lo*F0 ≤ Fr) (hFq : lo*F0 ≤ Fq) (hCq0 : 0 ≤ Cq) (hCqF : Cq ≤ Fq)
    (hC : |Cr-Cq| ≤ L*F0*d) (hF : |Fr-Fq| ≤ F0/lo*d) :
    |Cr/Fr-Cq/Fq| ≤ (L/lo+1/lo^2)*d := by
  have hr : 0 < Fr := (mul_pos hlo hF0).trans_le hFr
  have hq : 0 < Fq := (mul_pos hlo hF0).trans_le hFq
  have hc0 : 0 ≤ Cq/Fq := div_nonneg hCq0 hq.le
  have hc1 : Cq/Fq ≤ 1 := (div_le_one hq).mpr hCqF
  have hid : Cr/Fr-Cq/Fq = (Cr-Cq + (Cq/Fq)*(Fq-Fr))/Fr := by field_simp; ring
  have hb : |Cr-Cq + (Cq/Fq)*(Fq-Fr)| ≤ L*F0*d + F0/lo*d := by
    calc
      _ ≤ |Cr-Cq| + |(Cq/Fq)*(Fq-Fr)| := abs_add _ _
      _ = |Cr-Cq| + (Cq/Fq)*|Fq-Fr| := by rw [abs_mul, abs_of_nonneg hc0]
      _ ≤ L*F0*d + 1*(F0/lo*d) := add_le_add hC
        (mul_le_mul hc1 (by simpa only [abs_sub_comm] using hF) (abs_nonneg _) zero_le_one)
      _ = _ := by ring
  rw [hid, abs_div, abs_of_pos hr]
  calc
    _ ≤ (L*F0*d + F0/lo*d)/Fr := div_le_div_of_nonneg_right hb hr.le
    _ ≤ (L*F0*d + F0/lo*d)/(lo*F0) :=
      div_le_div_of_nonneg_left (by positivity) (mul_pos hlo hF0) hFr
    _ = _ := by field_simp; ring

theorem stationary_ratio_variation (θ a q r : ℝ) (hθ : 0 ≤ θ) (ha : 0 < a)
    (hq : a ≤ 1-θ*q) (hr : a ≤ 1-θ*r) :
    |θ*r/(1-θ*r)-θ*q/(1-θ*q)| ≤ θ/a^2*|r-q| := by
  have hq0 : 0 < 1-θ*q := ha.trans_le hq
  have hr0 : 0 < 1-θ*r := ha.trans_le hr
  have hid : θ*r/(1-θ*r)-θ*q/(1-θ*q) = θ*(r-q)/((1-θ*r)*(1-θ*q)) := by field_simp; ring
  rw [hid, abs_div, abs_mul, abs_of_nonneg hθ, abs_of_pos (mul_pos hr0 hq0)]
  have hden : a^2 ≤ (1-θ*r)*(1-θ*q) := by
    have h := mul_le_mul hr hq ha.le hr0.le
    nlinarith
  calc
    _ ≤ (θ*|r-q|)/a^2 := div_le_div_of_nonneg_left (mul_nonneg hθ (abs_nonneg _)) (sq_pos_of_pos ha) hden
    _ = _ := by ring

theorem normalized_stationary_difference_bound (L lo θ a n : ℝ)
    (hL : L ≤ 3*n^2) (hlo : 1/2 ≤ lo) (ha : 1/2 ≤ a)
    (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) (hn : 1 ≤ n) (hL0 : 0 ≤ L) :
    L/lo + 1/lo^2 + θ/a^2 ≤ 14*n^2 := by
  have hlo0 : 0 < lo := by linarith
  have ha0 : 0 < a := by linarith
  have h1 : L/lo ≤ 2*L := (div_le_iff₀ hlo0).mpr (by nlinarith)
  have h2 : (1:ℝ)/lo^2 ≤ 4 := (div_le_iff₀ (sq_pos_of_pos hlo0)).mpr (by nlinarith)
  have h3 : θ/a^2 ≤ 4*θ := (div_le_iff₀ (sq_pos_of_pos ha0)).mpr (by
    have hs : 1 ≤ 4*a^2 := by nlinarith
    nlinarith [mul_le_mul_of_nonneg_left hs hθ0])
  nlinarith

end MatroidProphetSecretary
