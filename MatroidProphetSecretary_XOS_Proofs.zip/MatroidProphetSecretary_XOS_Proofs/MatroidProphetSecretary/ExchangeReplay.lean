import MatroidProphetSecretary.ContractionPrices

/-! Feasible accepted histories and deterministic replay on reference bases. -/

noncomputable section

namespace MatroidProphetSecretary

variable {E : Type*} [DecidableEq E]

/-- Every acceptance carries a feasible source basis containing the previous acceptances. -/
inductive ExchangeHistory (M : Matroid E) : Finset E → Type _
  | nil : ExchangeHistory M ∅
  | snoc {A : Finset E} (history : ExchangeHistory M A)
      (C : Finset E) (source_base : M.IsBase (C : Set E)) (contains : A ⊆ C)
      (e : E) (source_mem : e ∈ C) (fresh : e ∉ A) : ExchangeHistory M (insert e A)

structure ReplayResult (M : Matroid E) (A : Finset E) where
  basis : Finset E
  isBase : M.IsBase (basis : Set E)
  contains : A ⊆ basis

namespace ExchangeHistory

def replay {M : Matroid E} {A : Finset E} (h : ExchangeHistory M A)
    (B : Finset E) (hB : M.IsBase (B : Set E)) : ReplayResult M A :=
  match h with
  | .nil => ⟨B, hB, Finset.empty_subset B⟩
  | .snoc history C hC hAC e heC heA =>
    let old := history.replay B hB
    let φ := chosenExchangeMap M C old.basis hC old.isBase
    ⟨insert e (old.basis.erase (φ.map e)), φ.exchange e heC,
      exchange_preserves_accepted φ hAC old.contains heC heA⟩

theorem replay_acceptances_independent {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (B : Finset E) (hB : M.IsBase (B : Set E)) :
    M.Indep (A : Set E) :=
  (h.replay B hB).isBase.indep.subset (h.replay B hB).contains

/-- An unaccepted label in a replayed basis must have been in its initial basis. -/
theorem replay_unaccepted_subset_initial {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (B : Finset E) (hB : M.IsBase (B : Set E)) :
    (h.replay B hB).basis \ A ⊆ B := by
  induction h with
  | nil => simp [replay]
  | @snoc A history C hC hAC e heC heA ih =>
    intro f hf
    obtain ⟨hfB, hfA⟩ := Finset.mem_sdiff.mp hf
    change f ∈ insert e _ at hfB
    rcases Finset.mem_insert.mp hfB with rfl | hfB
    · exact (hfA (Finset.mem_insert_self _ _)).elim
    · apply ih
      exact Finset.mem_sdiff.mpr ⟨Finset.mem_of_mem_erase hfB,
        fun hf => hfA (Finset.mem_insert_of_mem hf)⟩

def liveSet {M : Matroid E} {A : Finset E} (h : ExchangeHistory M A)
    (B : Finset E) (hB : M.IsBase (B : Set E)) (v : E → ℝ) : Finset E :=
  ((h.replay B hB).basis \ A).filter (fun e => 0 < v e)

theorem liveSet_subset_initial {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (B : Finset E) (hB : M.IsBase (B : Set E)) (v : E → ℝ) :
    h.liveSet B hB v ⊆ B :=
  (Finset.filter_subset _ _).trans (h.replay_unaccepted_subset_initial B hB)

theorem liveSet_disjoint_accepted {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (B : Finset E) (hB : M.IsBase (B : Set E)) (v : E → ℝ) :
    Disjoint (h.liveSet B hB v) A := by
  apply Finset.disjoint_left.mpr
  intro e heL heA
  exact (Finset.mem_sdiff.mp (Finset.mem_filter.mp heL).1).2 heA

/-- A replay step can only remove live labels; it cannot create new ones. -/
theorem liveSet_snoc_subset {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (C : Finset E) (hC : M.IsBase (C : Set E))
    (hAC : A ⊆ C) (e : E) (heC : e ∈ C) (heA : e ∉ A)
    (B : Finset E) (hB : M.IsBase (B : Set E)) (v : E → ℝ) :
    (h.snoc C hC hAC e heC heA).liveSet B hB v ⊆ h.liveSet B hB v := by
  intro f hf
  obtain ⟨hf, hfv⟩ := Finset.mem_filter.mp hf
  obtain ⟨hfB, hfA⟩ := Finset.mem_sdiff.mp hf
  change f ∈ insert e _ at hfB
  rcases Finset.mem_insert.mp hfB with rfl | hfB
  · exact (hfA (Finset.mem_insert_self _ _)).elim
  · exact Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨Finset.mem_of_mem_erase hfB,
      fun hf => hfA (Finset.mem_insert_of_mem hf)⟩, hfv⟩

variable [Fintype E]

theorem live_weight_le_initial {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (B : Finset E) (hB : M.IsBase (B : Set E))
    (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    weight v (h.liveSet B hB v) ≤ weight v B :=
  Finset.sum_le_sum_of_subset_of_nonneg (h.liveSet_subset_initial B hB v) (fun e _ _ => hv e)

theorem live_weight_le_optimum {M : Matroid E} {A : Finset E}
    (h : ExchangeHistory M A) (B : Finset E) (hB : M.IsBase (B : Set E))
    (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    weight v (h.liveSet B hB v) ≤ optimum M v :=
  (h.live_weight_le_initial B hB v hv).trans (weight_le_optimumOver _ _ v hB.indep)

end ExchangeHistory

end MatroidProphetSecretary
