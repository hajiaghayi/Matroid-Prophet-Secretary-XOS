import MatroidProphetSecretary.EarlyPrivateIntensity
import MatroidProphetSecretary.TwoPhaseGridSurvival

/-! Both phases use the same private value and the same law of auxiliary tapes. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V]

def phasePrivateDecision (cut : ℕ) (live : ℕ → (E → Option V) → Prop) {L : ℕ} (c : Fin L) :
    (V × (Fin L → (Fin L → Bool × (E → Option V)) × Option (E → Option V))) → Option (E → Option V) :=
  if c.val < cut then earlyPrivateDecision live c
  else referencePrivateDecision (live c.val) (fun _ => True) c

theorem phase_private_mark_kernel (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) (cut : ℕ)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none)
    (c : Fin L) (B : (E → Option V) → Prop) :
    (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1).prob
      (fun tape => ∃ y, phasePrivateDecision cut live c tape = some y ∧ B y) =
      (1/q)*(if c.val < cut then gridSurvival (gridLiveDose (FiniteLaw.product references) p live) c.val else 1)*
        (FiniteLaw.product references).prob (fun y => live c.val y ∧ B y) := by
  by_cases hc : c.val < cut
  · simp only [phasePrivateDecision,hc,if_true]
    exact early_private_mark_kernel prior references e q hq hdom L p hp0 hp1 live hpositive c B
  · simp only [phasePrivateDecision,hc,if_false,mul_one]
    have h := reference_private_tape_kernel prior references e q hq hdom
      (gridProbeLaw (FiniteLaw.product references) L p hp0 hp1) c
      (live c.val) (hpositive c.val) (fun _ => True) B
    simpa only [FiniteLaw.prob,if_true,FiniteLaw.expect_const,mul_one] using h

theorem phase_private_accept_probability (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) (cut : ℕ)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none) (c : Fin L) :
    (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1).prob
      (fun tape => phasePrivateDecision cut live c tape ≠ none) =
      (1/q)*(if c.val < cut then gridSurvival (gridLiveDose (FiniteLaw.product references) p live) c.val else 1)*
        (FiniteLaw.product references).prob (live c.val) := by
  have h := phase_private_mark_kernel prior references e q hq hdom L p hp0 hp1 cut live hpositive c (fun _ => True)
  have heq := FiniteLaw.prob_congr (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1)
    (A := fun tape => phasePrivateDecision cut live c tape ≠ none)
    (B := fun tape => ∃ y, phasePrivateDecision cut live c tape = some y ∧ True)
    (fun tape => by cases hd : phasePrivateDecision cut live c tape <;> simp [hd])
  rw [heq]
  simpa only [FiniteLaw.prob,and_true] using h

theorem phase_private_grid_mass (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (hL : 0 < L) (hp1 : (1/(L:ℝ))*(1/q) ≤ 1) (cut : ℕ)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none) (c : Fin L) :
    (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1).prob
      (fun tape => phasePrivateDecision cut live c tape ≠ none) =
      (L:ℝ)*phaseArrivalMass (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) cut c.val := by
  rw [phase_private_accept_probability prior references e q hq hdom L _ _ hp1 cut live hpositive c]
  unfold phaseArrivalMass gridLiveDose
  have hL' : (L:ℝ) ≠ 0 := by exact_mod_cast hL.ne'
  split_ifs <;> field_simp <;> ring

theorem phase_private_survival (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (hL : 0 < L) (hp1 : (1/(L:ℝ))*(1/q) ≤ 1) (cut : ℕ)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none)
    (n : ℕ) (hn : n ≤ L) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    ((FiniteLaw.uniform (Fin L)).pair
      (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1)).prob
      (FiniteLaw.oneArrivalAbsent (fun t => t.val < n) (phasePrivateDecision cut live)) =
      phaseSurvival (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) cut n := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  apply oneArrival_phase_survival L hL _ _ _ cut n hn
  intro i hi
  convert phase_private_grid_mass prior references e q hq hdom L hL hp1 cut live hpositive i using 1
  unfold FiniteLaw.prob
  congr 1
  funext x
  split_ifs <;> rfl

theorem phase_private_conditional_intensity (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (hL : 0 < L) (hp1 : (1/(L:ℝ))*(1/q) ≤ 1) (cut : ℕ)
    (live : ℕ → (E → Option V) → Prop) (hpositive : ∀ i y, live i y → y e ≠ none)
    (t : Fin L) (B : (E → Option V) → Prop)
    (hS : 0 < phaseSurvival (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) cut t.val) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    (((FiniteLaw.uniform (Fin L)).pair
      (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1)).conditionOrSelf
      (FiniteLaw.oneArrivalAbsent (fun u => u.val < t.val) (phasePrivateDecision cut live))).prob
      (fun x => x.1 = t ∧ ∃ y, phasePrivateDecision cut live t x.2 = some y ∧ B y) =
      (1/(L:ℝ))*(1/q)*
        (if t.val < cut then gridSurvival (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) t.val else 1)*
        (FiniteLaw.product references).prob (fun y => live t.val y ∧ B y) /
        phaseSurvival (gridLiveDose (FiniteLaw.product references) ((1/(L:ℝ))*(1/q)) live) cut t.val := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  have hs := phase_private_survival prior references e q hq hdom L hL hp1 cut live hpositive t.val t.isLt.le
  have hp : 0 < ((FiniteLaw.uniform (Fin L)).pair
      (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1)).prob
      (FiniteLaw.oneArrivalAbsent (fun u => u.val < t.val) (phasePrivateDecision cut live)) := by
    rw [hs]
    exact hS
  have ht := FiniteLaw.oneArrival_conditional_mark (FiniteLaw.uniform (Fin L))
    (earlyPrivateTapeLaw prior references e q hq hdom L ((1/(L:ℝ))*(1/q)) (by positivity) hp1)
    (fun u => u.val < t.val) (phasePrivateDecision cut live) t (lt_irrefl _) B hp
  rw [hs] at ht
  have hk := phase_private_mark_kernel prior references e q hq hdom L _ (by positivity) hp1 cut live hpositive t B
  change FiniteLaw.acceptanceKernel _ (phasePrivateDecision cut live) t B = _ at hk
  rw [hk] at ht
  convert ht using 1
  · unfold FiniteLaw.prob
    congr 1
    funext x
    split_ifs <;> rfl
  · simp only [FiniteLaw.uniform,Fintype.card_fin]
    ring

end MatroidProphetSecretary
