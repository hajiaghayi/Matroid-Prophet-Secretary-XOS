import MatroidProphetSecretary.ReferenceSurplusVariation
import MatroidProphetSecretary.ReferenceOptimumVariation
import MatroidProphetSecretary.NormalizedVariation

/-! The normalized reference statistics have the Lipschitz constant used in Lemma 17. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def referenceSearchNumerator (unstable : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) : ℝ :=
  if unstable then referenceDeletion laws M value q - referenceStable laws M value hnonloop q
  else referenceDeletion laws M value q

def referenceSearchRatio (unstable : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ q : ℝ) : ℝ :=
  referenceSearchNumerator unstable laws M value hnonloop q / referenceExpectedOptimum laws M value q -
    θ*q/(1-θ*q)

theorem referenceSearchNumerator_bounds (unstable : Bool) (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) :
    0 ≤ referenceSearchNumerator unstable laws M value hnonloop q ∧
      referenceSearchNumerator unstable laws M value hnonloop q ≤ referenceExpectedOptimum laws M value q := by
  have h := basic_surplus_bounds (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value)) hnonloop
  have hD := deletionSurplus_nonneg (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value))
  cases unstable <;> simp only [referenceSearchNumerator, Bool.false_eq_true, if_false, if_true]
  · exact ⟨hD, h.2.2⟩
  · change 0 ≤ _ - _ ∧ _ - _ ≤ _
    exact ⟨sub_nonneg.mpr h.2.1, (sub_le_self _ h.1).trans h.2.2⟩

theorem referenceSearchNumerator_variation (unstable : Bool) (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q r : ℝ) (hq : 0 ≤ q) (hr : 0 ≤ r) :
    |referenceSearchNumerator unstable laws M value hnonloop r -
      referenceSearchNumerator unstable laws M value hnonloop q| ≤
      (3*(Fintype.card E : ℝ)^2)*expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)*|r-q| := by
  cases unstable <;> simp only [referenceSearchNumerator, Bool.false_eq_true, if_false, if_true]
  · have h := referenceDeletion_lipschitz laws M value hv hnonloop q r hq hr
    have hF := expectedOptimum_nonneg (FiniteLaw.product laws) M (coordinateValues value)
    have hh : 0 ≤ (Fintype.card E : ℝ)^2 * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) * |r-q| := by positivity
    nlinarith
  · exact referenceUnstable_lipschitz laws M value hv hnonloop q r hq hr

theorem referenceSearchRatio_lipschitz [Nonempty E] (unstable : Bool)
    (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (lo a θ q r : ℝ) (hlo : 1/2 ≤ lo) (hlo1 : lo ≤ 1) (ha : 1/2 ≤ a)
    (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) (hql : lo ≤ q) (hrl : lo ≤ r)
    (haq : a ≤ 1-θ*q) (har : a ≤ 1-θ*r) :
    |referenceSearchRatio unstable laws M value hnonloop θ r -
      referenceSearchRatio unstable laws M value hnonloop θ q| ≤ 14*(Fintype.card E : ℝ)^2*|r-q| := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  have hlo0 : 0 < lo := by linarith
  have ha0 : 0 < a := by linarith
  have hq : 0 ≤ q := hlo0.le.trans hql
  have hr : 0 ≤ r := hlo0.le.trans hrl
  have hN := referenceSearchNumerator_bounds unstable laws M value hnonloop q
  have hratio := normalized_ratio_variation
    (referenceExpectedOptimum laws M value r) (referenceExpectedOptimum laws M value q)
    (referenceSearchNumerator unstable laws M value hnonloop r)
    (referenceSearchNumerator unstable laws M value hnonloop q)
    (expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)) lo
    (3*(Fintype.card E : ℝ)^2) |r-q| hF hlo0 (by positivity) (abs_nonneg _)
    (referenceExpectedOptimum_lower_away_zero laws M hg value hv lo r hlo0.le hlo1 hrl)
    (referenceExpectedOptimum_lower_away_zero laws M hg value hv lo q hlo0.le hlo1 hql) hN.1 hN.2
    (referenceSearchNumerator_variation unstable laws M value hv hnonloop q r hq hr)
    (referenceExpectedOptimum_lipschitz laws M hg value hv lo q r hlo0 hlo1 hql hrl)
  have hstat := stationary_ratio_variation θ a q r hθ0 ha0 haq har
  have hcoef := normalized_stationary_difference_bound (3*(Fintype.card E : ℝ)^2) lo θ a
    (Fintype.card E) le_rfl hlo ha hθ0 hθ1 (by exact_mod_cast Fintype.card_pos) (by positivity)
  have hcoef' := mul_le_mul_of_nonneg_right hcoef (abs_nonneg (r-q))
  unfold referenceSearchRatio
  have h := abs_sub_le
    (referenceSearchNumerator unstable laws M value hnonloop r / referenceExpectedOptimum laws M value r - θ*r/(1-θ*r))
    (referenceSearchNumerator unstable laws M value hnonloop q / referenceExpectedOptimum laws M value q - θ*r/(1-θ*r))
    (referenceSearchNumerator unstable laws M value hnonloop q / referenceExpectedOptimum laws M value q - θ*q/(1-θ*q))
  simp only [sub_sub_sub_cancel_right] at h
  have heq : ∀ b c d : ℝ, (b-c)-(b-d) = -(c-d) := by intros; ring
  rw [heq, abs_neg] at h
  nlinarith only [h, hratio, hstat, hcoef']

end MatroidProphetSecretary
