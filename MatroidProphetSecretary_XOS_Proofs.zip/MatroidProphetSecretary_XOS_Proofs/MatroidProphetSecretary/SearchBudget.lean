import MatroidProphetSecretary.BisectionGeometry
import MatroidProphetSecretary.BatchBudget

/-! The exact logarithmic midpoint-query budget and its terminal-width guarantee. -/

noncomputable section

namespace MatroidProphetSecretary

def referenceSearchSteps (N : ℕ) (δ ε : ℝ) : ℕ :=
  ⌈Real.logb 2 (max 1 (32*δ*(N:ℝ)^2/ε))⌉₊

def referenceSearchBudget (N : ℕ) (δ ε : ℝ) : ℕ := 1+referenceSearchSteps N δ ε

theorem referenceSearchBudget_pos (N : ℕ) (δ ε : ℝ) : 0 < referenceSearchBudget N δ ε := by
  unfold referenceSearchBudget
  omega

theorem referenceSearchSteps_power (N : ℕ) (δ ε : ℝ) :
    32*δ*(N:ℝ)^2/ε ≤ (2:ℝ)^referenceSearchSteps N δ ε := by
  have hA : 0 < max 1 (32*δ*(N:ℝ)^2/ε) := lt_of_lt_of_le zero_lt_one (le_max_left _ _)
  have h := (Real.logb_le_iff_le_rpow (by norm_num : (1:ℝ)<2) hA).mp
    (Nat.le_ceil (Real.logb 2 (max 1 (32*δ*(N:ℝ)^2/ε))))
  rw [Real.rpow_natCast] at h
  exact (le_max_right _ _).trans h

theorem referenceSearchSteps_width (answers : ℕ → Bool) (b : SearchBracket)
    (N : ℕ) (hN : 0 < N) (δ ε : ℝ) (hε : 0 < ε) (hb : b.upper-b.lower ≤ 8*δ) :
    (bisectionRun answers (referenceSearchSteps N δ ε) b).upper -
      (bisectionRun answers (referenceSearchSteps N δ ε) b).lower ≤ ε/(4*(N:ℝ)^2) := by
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN
  have hp := (div_le_iff₀ hε).mp (referenceSearchSteps_power N δ ε)
  apply bisectionRun_width_bound
  have hmul := mul_le_mul_of_nonneg_right hb (show 0 ≤ 4*(N:ℝ)^2 by positivity)
  have hbudget : b.upper-b.lower ≤ (ε*2^referenceSearchSteps N δ ε)/(4*(N:ℝ)^2) := by
    apply (le_div_iff₀ (show 0 < 4*(N:ℝ)^2 by positivity)).mpr
    nlinarith only [hmul,hp]
  convert hbudget using 1 <;> ring

theorem referenceSearchSteps_continuity_loss (answers : ℕ → Bool) (b : SearchBracket)
    (N : ℕ) (hN : 0 < N) (δ ε : ℝ) (hε : 0 < ε) (hb : b.upper-b.lower ≤ 8*δ) :
    16*(N:ℝ)^2*((bisectionRun answers (referenceSearchSteps N δ ε) b).upper -
      (bisectionRun answers (referenceSearchSteps N δ ε) b).lower) ≤ 4*ε := by
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN
  have h := mul_le_mul_of_nonneg_left (referenceSearchSteps_width answers b N hN δ ε hε hb)
    (show 0 ≤ 16*(N:ℝ)^2 by positivity)
  convert h using 1 <;> field_simp <;> ring

end MatroidProphetSecretary
