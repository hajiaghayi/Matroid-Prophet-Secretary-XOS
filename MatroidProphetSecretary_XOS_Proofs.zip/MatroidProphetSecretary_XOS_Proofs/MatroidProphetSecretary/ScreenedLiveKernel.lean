import MatroidProphetSecretary.ScreenedCandidate
import MatroidProphetSecretary.GridSurvival

/-! The full finite candidate kernel after liveness filtering and independent attenuation. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {V E : Type*} [Fintype V] [Fintype E] [DecidableEq E]

def liveCandidate (live : (E → Option V) → Prop) : Option (E → Option V) → Option (E → Option V)
  | none => none
  | some y => if live y then some y else none

def screenedLiveLaw (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (live : (E → Option V) → Prop) : FiniteLaw (Option (E → Option V)) :=
  (screenedCandidateLaw prior references e q hq hdom).map (liveCandidate live)

theorem screenedLiveLaw_expect_zero (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (live : (E → Option V) → Prop) (hpositive : ∀ y, live y → y e ≠ none)
    (f : Option (E → Option V) → ℝ) (hf : f none = 0) :
    (screenedLiveLaw prior references e q hq hdom live).expect f =
      (1/q)*(FiniteLaw.product references).expect (fun y => if live y then f (some y) else 0) := by
  rw [screenedLiveLaw,FiniteLaw.map_expect]
  have hpoint (x : Option (E → Option V)) : f (liveCandidate live x) =
      match x with | none => 0 | some y => if live y then f (some y) else 0 := by
    cases x with
    | none => exact hf
    | some y => by_cases hy : live y <;> simp [liveCandidate,hy,hf]
  simp_rw [hpoint]
  apply screenedCandidateLaw_expect prior references e q hq hdom
  intro y hy
  have hl : ¬ live y := fun hl => hpositive y hl hy
  simp [hl]

theorem screenedLiveLaw_mark_probability (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (live : (E → Option V) → Prop) (hpositive : ∀ y, live y → y e ≠ none)
    (B : (E → Option V) → Prop) :
    (screenedLiveLaw prior references e q hq hdom live).prob (fun x => ∃ y, x = some y ∧ B y) =
      (1/q)*(FiniteLaw.product references).prob (fun y => live y ∧ B y) := by
  have h := screenedLiveLaw_expect_zero prior references e q hq hdom live hpositive
    (fun x => if ∃ y, x = some y ∧ B y then 1 else 0) (by simp)
  convert h using 1
  unfold FiniteLaw.prob
  congr 2
  funext y
  by_cases hl : live y <;> by_cases hb : B y <;> simp [hl,hb]

def attenuateOption {W P : Type*} (pass : P → Prop) (x : P × Option W) : Option W :=
  if pass x.1 then x.2 else none

theorem attenuateOption_mark_probability {W P : Type*} [Fintype W] [Fintype P]
    (probe : FiniteLaw P) (candidate : FiniteLaw (Option W)) (pass : P → Prop) (B : W → Prop) :
    (probe.pair candidate).prob (fun x => ∃ y, attenuateOption pass x = some y ∧ B y) =
      probe.prob pass * candidate.prob (fun x => ∃ y, x = some y ∧ B y) := by
  unfold FiniteLaw.prob
  rw [FiniteLaw.pair_expect]
  have hpoint (p : P) (x : Option W) :
      (if ∃ y, attenuateOption pass (p,x) = some y ∧ B y then (1 : ℝ) else 0) =
      (if pass p then 1 else 0) * (if ∃ y, x = some y ∧ B y then 1 else 0) := by
    by_cases hp : pass p <;> simp [attenuateOption,hp]
  simp_rw [hpoint,FiniteLaw.expect_const_mul]
  exact FiniteLaw.expect_mul_const _ _ _

theorem screened_probed_kernel {I P : Type*} [Fintype I] [DecidableEq I] [Fintype P]
    (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (live : (E → Option V) → Prop) (hpositive : ∀ y, live y → y e ≠ none)
    (probeLaws : I → FiniteLaw P) (p : I → ℝ) (hp0 : ∀ i, 0 ≤ p i) (hp1 : ∀ i, p i ≤ 1)
    (A : I → P → Prop) (B : (E → Option V) → Prop) :
    ((FiniteLaw.product (fun i => finiteProbeLaw (probeLaws i) (p i) (hp0 i) (hp1 i))).pair
      (screenedLiveLaw prior references e q hq hdom live)).prob
      (fun x => ∃ y, attenuateOption (fun probes => ∀ i, finiteProbePass (A i) (probes i)) x = some y ∧ B y) =
      (1/q)*(∏ i, (1-p i*(probeLaws i).prob (A i)))*
        (FiniteLaw.product references).prob (fun y => live y ∧ B y) := by
  rw [attenuateOption_mark_probability]
  have hpr : (FiniteLaw.product (fun i => finiteProbeLaw (probeLaws i) (p i) (hp0 i) (hp1 i))).prob
      (fun probes => ∀ i, finiteProbePass (A i) (probes i)) =
      ∏ i, (1-p i*(probeLaws i).prob (A i)) := by
    convert independent_finite_probes probeLaws p hp0 hp1 A using 1
  have hk := screenedLiveLaw_mark_probability prior references e q hq hdom live hpositive B
  convert congrArg₂ (fun a b : ℝ => a*b) hpr hk using 1
  · congr 1 <;> (unfold FiniteLaw.prob; congr 1; funext x; split_ifs <;> rfl)
  · ring

end MatroidProphetSecretary
