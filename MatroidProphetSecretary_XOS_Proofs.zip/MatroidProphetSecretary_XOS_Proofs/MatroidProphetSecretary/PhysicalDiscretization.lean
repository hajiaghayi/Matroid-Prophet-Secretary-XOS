import MatroidProphetSecretary.PhysicalBlockComparison
import MatroidProphetSecretary.BlockKernelSemigroup

/-! A full finite physical run and its sparse exchange discretization differ by an explicit O(1/L) term. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem physical_terminal_expect (n : ℕ) (hn : n ≤ L*N)
    (f : StampedHistory (Fin N) (Fin N → Option V) → ℝ) :
    (FiniteLaw.timedBatches cfg.finiteHistoryKernel updateGridHistory n 0 []).expect
      (fun x => f (FiniteLaw.stateAfter updateGridHistory n [] x)) =
    (FiniteLaw.product cfg.laws).expect (fun tapes => f (cfg.run tapes n)) := by
  have h := congrArg (fun law => law.expect (fun x => f (FiniteLaw.stateAfter updateGridHistory n [] x)))
    (cfg.trace_law_eq_finiteHistoryKernel n hn)
  dsimp only at h
  rw [FiniteLaw.map_expect] at h
  rw [← h]
  congr 1
  funext tapes
  rw [FiniteLaw.stateAfter_stream updateGridHistory n [] (cfg.trace tapes),cfg.trace_scan tapes n hn]

theorem physical_blocks_terminal
    (f : StampedHistory (Fin N) (Fin N → Option V) → ℝ) :
    (FiniteLaw.adaptiveBatches cfg.physicalBlockBatch physicalBlockUpdate L (0,[])).expect
      (fun x => f (FiniteLaw.stateAfter physicalBlockUpdate L (0,[]) x).2) =
      (FiniteLaw.product cfg.laws).expect (fun tapes => f (cfg.run tapes (L*N))) := by
  change (FiniteLaw.adaptiveBatches (FiniteLaw.blockBatch cfg.finiteHistoryKernel updateGridHistory N)
    (FiniteLaw.blockUpdate updateGridHistory N) L (0,[])).expect
    (fun x => f (FiniteLaw.stateAfter (FiniteLaw.blockUpdate updateGridHistory N) L (0,[]) x).2) = _
  rw [FiniteLaw.block_terminal_eq cfg.finiteHistoryKernel updateGridHistory N L 0 [] f]
  exact cfg.physical_terminal_expect (L*N) le_rfl f

theorem physical_discretization_error
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1)
    (B : ℝ) (hB : 0 ≤ B) (f : StampedHistory (Fin N) (Fin N → Option V) → ℝ)
    (hf : ∀ history, |f history| ≤ B) :
    |(FiniteLaw.product cfg.laws).expect (fun tapes => f (cfg.run tapes (L*N))) -
      (FiniteLaw.adaptiveBatches (cfg.sparseBlockBatch hsmall omega homega homega1 hlower hbudget)
        physicalBlockUpdate L (0,[])).expect
        (fun x => f (FiniteLaw.stateAfter physicalBlockUpdate L (0,[]) x).2)| ≤
      2*(N:ℝ)^2*((1/cfg.q)/omega)^2*B/L := by
  have h := cfg.physical_blocks_approximation hsmall omega homega homega1 hlower hbudget L (0,[]) B hB
    (fun x => f (FiniteLaw.stateAfter physicalBlockUpdate L (0,[]) x).2) (fun x => hf _)
  rw [cfg.physical_blocks_terminal f,physical_blocks_error_full_grid ((1/cfg.q)/omega) B cfg.clocks_pos] at h
  exact h

end MatroidProphetSecretary.PrivateGridConfig
