import MatroidProphetSecretary.RecordReplay

/-! Feasible exchange records have a reward bound independent of the number of clock bins. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem recordReward_nonneg (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (history : StampedHistory E W) : 0 ≤ recordReward value history := by
  induction history with
  | nil => simp [recordReward]
  | cons record history ih =>
    change 0 ≤ value record.2.2 record.1+recordReward value history
    exact add_nonneg (hv _ _) ih

theorem ValidExchangeRecords.reward_le_labels (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (bound : E → ℝ) (hbound : ∀ y e, value y e ≤ bound e)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history) :
    recordReward value history ≤ ∑ e ∈ recordLabels history, bound e := by
  induction h with
  | nil => simp [recordReward,recordLabels]
  | @snoc history valid e t y hl ih =>
    have hf := valid.fresh M base hbase value history e y hl
    have hs : recordLabels (history++[(e,(t,y))]) = insert e (recordLabels history) := by
      simp [recordLabels,Finset.insert_eq,Finset.union_comm]
    rw [hs,Finset.sum_insert hf]
    simp only [recordReward,List.map_append,List.map_singleton,List.sum_append,List.sum_cons,List.sum_nil,add_zero]
    change recordReward value history+value y e ≤ _
    linarith [hbound y e]

theorem ValidExchangeRecords.reward_le_budget (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (bound : E → ℝ) (hb0 : ∀ e, 0 ≤ bound e) (hbound : ∀ y e, value y e ≤ bound e)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history) :
    recordReward value history ≤ ∑ e, bound e := by
  apply (h.reward_le_labels M base hbase value bound hbound history).trans
  exact sum_le_sum_of_subset_of_nonneg (subset_univ _) (fun e _ _ => hb0 e)

def finiteValueBudget (value : W → E → ℝ) : ℝ := ∑ e, ∑ y, value y e

theorem finiteValueBudget_nonneg (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e) :
    0 ≤ finiteValueBudget value := sum_nonneg (fun e _ => sum_nonneg (fun y _ => hv y e))

theorem ValidExchangeRecords.reward_bounds (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history) :
    0 ≤ recordReward value history ∧ recordReward value history ≤ finiteValueBudget value := by
  constructor
  · exact recordReward_nonneg value hv history
  · apply h.reward_le_budget M base hbase value (fun e => ∑ y, value y e)
      (fun e => sum_nonneg (fun y _ => hv y e)) _ history
    intro y e
    exact single_le_sum (fun z _ => hv z e) (mem_univ y)

def boundedRecordReward (value : W → E → ℝ) (history : StampedHistory E W) : ℝ :=
  min (finiteValueBudget value) (max 0 (recordReward value history))

theorem boundedRecordReward_abs (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (history : StampedHistory E W) : |boundedRecordReward value history| ≤ finiteValueBudget value := by
  have h0 : 0 ≤ boundedRecordReward value history :=
    le_min (finiteValueBudget_nonneg value hv) (le_max_left _ _)
  rw [abs_of_nonneg h0]
  exact min_le_left _ _

theorem ValidExchangeRecords.bounded_reward_eq (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (history : StampedHistory E W) (h : ValidExchangeRecords M base hbase value history) :
    boundedRecordReward value history = recordReward value history := by
  have hb := h.reward_bounds M base hbase value hv history
  exact (congrArg (min (finiteValueBudget value)) (max_eq_right hb.1)).trans (min_eq_right hb.2)

end MatroidProphetSecretary
