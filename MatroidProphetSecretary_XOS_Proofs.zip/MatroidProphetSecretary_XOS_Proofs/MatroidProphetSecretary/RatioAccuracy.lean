import MatroidProphetSecretary.Algebra

/-! Ratio estimates used by the potential-preserving reference search. -/

namespace MatroidProphetSecretary

theorem ratio_accuracy (F D V Fhat Dhat ε : ℝ) (hF : 0 < F) (hD0 : 0 ≤ D)
    (hDF : D ≤ F) (hVF : V ≤ F) (hε0 : 0 ≤ ε) (hε1 : ε < 1/2)
    (hFerr : |Fhat-F| ≤ ε*(F+V)) (hDerr : |Dhat-D| ≤ ε*(D+V)) :
    0 < Fhat ∧ |Dhat/Fhat-D/F| ≤ 4*ε/(1-2*ε) := by
  have hc : 0 < 1-2*ε := by linarith
  have heF : |Fhat-F| ≤ 2*ε*F := hFerr.trans (by nlinarith)
  have heD : |Dhat-D| ≤ 2*ε*F := hDerr.trans (by nlinarith)
  have hFhlow : (1-2*ε)*F ≤ Fhat := by have h := (abs_le.mp heF).1; nlinarith
  have hFh : 0 < Fhat := (mul_pos hc hF).trans_le hFhlow
  refine ⟨hFh, ?_⟩
  have hr0 : 0 ≤ D/F := div_nonneg hD0 hF.le
  have hr1 : D/F ≤ 1 := (div_le_one hF).mpr hDF
  have hn : |Dhat-D + (D/F)*(F-Fhat)| ≤ 4*ε*F := by
    calc
      _ ≤ |Dhat-D| + |(D/F)*(F-Fhat)| := abs_add _ _
      _ = |Dhat-D| + (D/F)*|F-Fhat| := by rw [abs_mul, abs_of_nonneg hr0]
      _ ≤ 2*ε*F + 1*(2*ε*F) := add_le_add heD
        (mul_le_mul hr1 (by simpa [abs_sub_comm] using heF) (abs_nonneg _) zero_le_one)
      _ = _ := by ring
  have hid : Dhat/Fhat-D/F = (Dhat-D + (D/F)*(F-Fhat))/Fhat := by field_simp; ring
  rw [hid, abs_div, abs_of_pos hFh]
  calc
    _ ≤ (4*ε*F)/Fhat := div_le_div_of_nonneg_right hn hFh.le
    _ ≤ (4*ε*F)/((1-2*ε)*F) := div_le_div_of_nonneg_left (by positivity) (mul_pos hc hF) hFhlow
    _ = 4*ε/(1-2*ε) := by field_simp; ring

theorem ratio_accuracy_five (F D V Fhat Dhat ε : ℝ) (hF : 0 < F) (hD0 : 0 ≤ D)
    (hDF : D ≤ F) (hVF : V ≤ F) (hε0 : 0 ≤ ε) (hε1 : ε ≤ 1/10)
    (hFerr : |Fhat-F| ≤ ε*(F+V)) (hDerr : |Dhat-D| ≤ ε*(D+V)) :
    0 < Fhat ∧ |Dhat/Fhat-D/F| ≤ 5*ε := by
  have h := ratio_accuracy F D V Fhat Dhat ε hF hD0 hDF hVF hε0 (by linarith) hFerr hDerr
  refine ⟨h.1, h.2.trans ?_⟩
  apply (div_le_iff₀ (show 0 < 1-2*ε by linarith)).mpr
  nlinarith [mul_nonneg hε0 (sub_nonneg.mpr hε1)]

theorem positive_ratio_certificate (estimated actual stationary ε : ℝ)
    (herr : |estimated-actual| ≤ 5*ε) (hpositive : stationary+10*ε < estimated) :
    stationary+5*ε < actual := by
  have h := (abs_le.mp herr).2
  linarith

theorem negative_ratio_certificate (estimated actual stationary ε : ℝ)
    (herr : |estimated-actual| ≤ 5*ε) (hnegative : estimated < stationary-10*ε) :
    actual < stationary-5*ε := by
  have h := (abs_le.mp herr).1
  linarith

theorem failed_positive_ratio_certificate (estimated actual stationary ε : ℝ)
    (herr : |estimated-actual| ≤ 5*ε) (hfailed : ¬ stationary+10*ε < estimated) :
    actual ≤ stationary+15*ε := by
  have h := (abs_le.mp herr).1
  have hf := le_of_not_gt hfailed
  linarith

theorem failed_negative_ratio_certificate (estimated actual stationary ε : ℝ)
    (herr : |estimated-actual| ≤ 5*ε) (hfailed : ¬ estimated < stationary-10*ε) :
    stationary-15*ε ≤ actual := by
  have h := (abs_le.mp herr).2
  have hf := le_of_not_gt hfailed
  linarith

end MatroidProphetSecretary
