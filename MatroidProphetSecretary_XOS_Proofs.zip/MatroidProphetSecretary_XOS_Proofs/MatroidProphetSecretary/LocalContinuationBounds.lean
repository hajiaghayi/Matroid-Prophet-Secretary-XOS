import MatroidProphetSecretary.StrongOverlap
import MatroidProphetSecretary.ControllerBound

/-! The guard and large-stability branches of the local potential argument. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem phi_monotone {q : ℝ} (hq : q ∈ interval) : Monotone (phi q) := by
  have ha := alpha_bounds hq
  have hw : 0 < omega q := by linarith [omega_positive hq]
  have hex : 0 ≤ 1-Real.exp (-(delta/q)/omega q) := by
    apply sub_nonneg.mpr
    apply Real.exp_le_one_iff.mpr
    have hd : 0 ≤ delta/q := div_nonneg (by norm_num [delta]) (q_pos hq).le
    exact div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hd) hw.le
  intro x y hxy
  unfold phi
  apply add_le_add_left
  apply mul_le_mul_of_nonneg_left
  · exact add_le_add_left (mul_le_mul_of_nonneg_left hxy (by linarith [ha.2])) _
  · exact mul_nonneg (mul_nonneg (by linarith [ha.1]) hw.le) hex

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem finite_stable_overlap_cutoff (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) {q : ℝ} (hq : q ∈ interval)
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (hD : stationaryRatio q-20*epsilon ≤
      deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (hH : hMinus ≤ stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)) :
    overlapCutoff q ≤
      overlap (FiniteLaw.product laws) (coordinateValues value) (fun y => canonicalBasis M (coordinateValues value y))/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  let F := expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)
  let D := deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)
  let H := stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop
  let Q := overlap (FiniteLaw.product laws) (coordinateValues value) (fun y => canonicalBasis M (coordinateValues value y))
  change stationaryRatio q-20*epsilon ≤ D/F at hD
  change hMinus ≤ H/F at hH
  have hm : 0 < hMinus := by norm_num [hMinus,eta,epsilon]
  have hHpos : 0 < H := (div_pos_iff.mp (hm.trans_le hH)).elim (fun h => h.1)
    (fun h => False.elim ((not_lt_of_ge hF.le) h.2))
  have hDF : D ≤ F := deletionSurplus_le_expectedOptimum _ _ _
  have hden : 0 < F-D+H := by linarith only [hDF,hHpos]
  have hden' : 0 < 1-D/F+H/F := by
    have he : 1-D/F+H/F = (F-D+H)/F := by field_simp
    rw [he]
    exact div_pos hden hF
  have hc : 0 < 1-stationaryRatio q+20*epsilon := by linarith [(stationary_cutoff_bounds hq).2]
  have hnorm := normalized_overlap F D H Q hF hden (finite_strong_overlap laws M value hv hnonloop).1
  change overlapCutoff q ≤ Q/F
  calc
    _ ≤ (H/F)^2/(1-stationaryRatio q+20*epsilon+H/F) :=
      square_div_add_mono (1-stationaryRatio q+20*epsilon) hMinus (H/F) hc hm.le hH
    _ ≤ (H/F)^2/(1-D/F+H/F) :=
      div_le_div_of_nonneg_left (sq_nonneg _) hden' (by linarith only [hD])
    _ ≤ Q/F := hnorm

theorem finite_large_stability_continuation_factor (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) {q : ℝ} (hq : q ∈ interval)
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (hD : stationaryRatio q-20*epsilon ≤
      deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (hH : hMinus ≤ stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)) :
    discount q < phi q
      (overlap (FiniteLaw.product laws) (coordinateValues value) (fun y => canonicalBasis M (coordinateValues value y))/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)) :=
  (stability_parameter_condition hq).trans_le
    (phi_monotone hq (finite_stable_overlap_cutoff laws M value hv hnonloop hq hF hD hH))

theorem finite_guard_continuation_factor (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (base : (∀ e, V e) → Finset E) {q : ℝ} (hq : q ∈ interval)
    (hguard : 3*delta ≤ |q-1|) :
    discount q < phi q (overlap (FiniteLaw.product laws) (coordinateValues value) base/
      expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)) :=
  (guard_parameter_condition hq hguard).trans_le (phi_monotone hq
    (div_nonneg (overlap_nonneg _ _ _) (expectedOptimum_nonneg _ _ _)))

end MatroidProphetSecretary
