import MatroidProphetSecretary.ReferenceStabilityTest
import MatroidProphetSecretary.ThresholdEstimates
import MatroidProphetSecretary.ThresholdEpochProgress

/-! The actual saved batch provides all thresholds and their total error budget. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E] [Nonempty E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def referenceMeanEstimate (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) (e : E) : ℝ :=
  FiniteLaw.sampleAverage (samplerStatistic (referenceInstanceLaws laws value q) (referenceInstanceValues value) G M (Sum.inr e)) x

def referenceSavedThreshold (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (q : ℝ) (N : ℕ) {m : ℕ} (x : Fin m → (Fin G.last × (E → Bool))) (e : E) : ℝ :=
  discount q*upperMeanEstimate (referenceMeanEstimate laws value G M q x e) epsilon
    (finiteValueVolume (referenceInstanceLaws laws value q) (referenceInstanceValues value) G) N

theorem referenceSavedThreshold_bounds (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e v, 0 ≤ value e v) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) {q : ℝ} (hq : q ∈ interval)
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) {m : ℕ}
    (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value) G M hnonloop N epsilon x) :
    (∀ e, discount q*meanThreshold (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) hnonloop e ≤ referenceSavedThreshold laws value G M q N x e) ∧
      (∑ e, posPart (referenceSavedThreshold laws value G M q N x e-thresholdFactor q*
        meanThreshold (FiniteLaw.product (referenceInstanceLaws laws value q)) M
          (coordinateValues (referenceInstanceValues value)) hnonloop e)) < 2*epsilon*referenceExpectedOptimum laws M value q := by
  have hacc (e : E) := samplerBatch_accuracy_of_not_bad (referenceInstanceLaws laws value q)
    (referenceInstanceValues value) G M hnonloop N epsilon x hgood (Sum.inr e)
  simp only [samplerTarget,samplerStatisticTolerance] at hacc
  have ha := discount_pos hq
  have heps : epsilon < 1 := by norm_num [epsilon]
  constructor
  · intro e
    exact (threshold_estimate_bounds _ _ (discount q) epsilon _ _ ha.le heps (hacc e)).1
  · have hvol := finiteValueVolume_pos (referenceInstanceLaws laws value q) (referenceInstanceValues value)
      G M hF
    have hvolF := finiteValueVolume_le_expectedOptimum (referenceInstanceLaws laws value q)
      (referenceInstanceValues value) G M hnonloop
    have halt : discount q < 1-epsilon := by
      have h := (discount_bounds hq).2
      norm_num [epsilon] at *
      linarith
    exact threshold_estimate_total_excess (referenceMeanEstimate laws value G M q x) _ (discount q) epsilon _ _ N hN0 hN
      ha.le halt (by norm_num [epsilon]) heps hvol hvolF hacc

theorem referenceSavedThreshold_nonneg (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e v, 0 ≤ value e v) (G : ValueHeightGrid (referenceInstanceValues value))
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) {q : ℝ} (hq : q ∈ interval)
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) {m : ℕ}
    (x : Fin m → (Fin G.last × (E → Bool)))
    (hF : 0 < referenceExpectedOptimum laws M value q)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws laws value q) (referenceInstanceValues value) G M hnonloop N epsilon x)
    (e : E) : 0 ≤ referenceSavedThreshold laws value G M q N x e :=
  (mul_nonneg (discount_pos hq).le (meanThreshold_nonneg _ _ _ hnonloop e)).trans
    ((referenceSavedThreshold_bounds laws value hv G M hnonloop hq N hN0 hN x hF hgood).1 e)

end MatroidProphetSecretary
