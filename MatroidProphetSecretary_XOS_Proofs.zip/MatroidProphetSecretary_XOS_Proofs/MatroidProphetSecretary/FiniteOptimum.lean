import Mathlib.Data.Matroid.Basic
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-!
Actual finite-matroid optimization. `deletionValue` and `contractionValue`
are defined by their independent-set constraints for a nonloop element.
The optimization identity is proved by splitting a maximizing independent set.
-/

noncomputable section

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [Fintype E] [DecidableEq E]

def weight (v : E → ℝ) (I : Finset E) : ℝ := ∑ e ∈ I, v e

def feasibleFamily (P : Finset E → Prop) : Finset (Finset E) := by
  classical
  exact univ.filter P

theorem mem_feasibleFamily (P : Finset E → Prop) (I : Finset E) :
    I ∈ feasibleFamily P ↔ P I := by
  classical
  simp [feasibleFamily]

theorem feasible_nonempty (P : Finset E → Prop) (h : P ∅) :
    (feasibleFamily P).Nonempty :=
  ⟨∅, (mem_feasibleFamily P ∅).mpr h⟩

def optimumOver (P : Finset E → Prop) (h : P ∅) (v : E → ℝ) : ℝ :=
  (feasibleFamily P).sup' (feasible_nonempty P h) (weight v)

theorem weight_le_optimumOver (P : Finset E → Prop) (h : P ∅)
    (v : E → ℝ) {I : Finset E} (hI : P I) : weight v I ≤ optimumOver P h v := by
  exact le_sup' (weight v) ((mem_feasibleFamily P I).mpr hI)

theorem optimumOver_le (P : Finset E → Prop) (h : P ∅) (v : E → ℝ) (b : ℝ)
    (hb : ∀ I, P I → weight v I ≤ b) : optimumOver P h v ≤ b := by
  exact sup'_le _ _ (fun I hI => hb I ((mem_feasibleFamily P I).mp hI))

theorem optimumOver_attained (P : Finset E → Prop) (h : P ∅) (v : E → ℝ) :
    ∃ I, P I ∧ optimumOver P h v = weight v I := by
  obtain ⟨I, hI, heq⟩ := exists_mem_eq_sup' (feasible_nonempty P h) (weight v)
  exact ⟨I, (mem_feasibleFamily P I).mp hI, heq⟩

theorem optimumOver_nonneg (P : Finset E → Prop) (h : P ∅) (v : E → ℝ) :
    0 ≤ optimumOver P h v := by
  simpa [weight] using weight_le_optimumOver P h v h

def optimum (M : Matroid E) (v : E → ℝ) : ℝ :=
  optimumOver (fun I => M.Indep (I : Set E)) (by simpa using M.empty_indep) v

def deletionValue (M : Matroid E) (v : E → ℝ) (e : E) : ℝ :=
  optimumOver (fun I => e ∉ I ∧ M.Indep (I : Set E))
    (by simp [M.empty_indep]) v

def contractionValue (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) : ℝ :=
  optimumOver (fun I => e ∉ I ∧ M.Indep ((insert e I : Finset E) : Set E))
    (by simpa using And.intro (not_mem_empty e) he) v

theorem contraction_le_deletion (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) :
    contractionValue M v e he ≤ deletionValue M v e := by
  apply optimumOver_le
  intro I hI
  apply weight_le_optimumOver
  refine ⟨hI.1, hI.2.subset ?_⟩
  intro f hf
  exact mem_insert_of_mem hf

/-- The optimization split underlying equation (3.1). -/
theorem optimum_deletion_contraction (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) :
    optimum M v = max (deletionValue M v e) (v e + contractionValue M v e he) := by
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    by_cases hei : e ∈ I
    · have hErase : e ∉ I.erase e ∧
          M.Indep ((insert e (I.erase e) : Finset E) : Set E) := by
        simpa [Finset.insert_erase hei] using And.intro (not_mem_erase e I) hI
      have hbound : weight v (I.erase e) ≤ contractionValue M v e he :=
        weight_le_optimumOver _ _ v hErase
      have hsum : weight v I = v e + weight v (I.erase e) := by
        simpa [weight] using (Finset.add_sum_erase I v hei).symm
      rw [hsum]
      exact (add_le_add_left hbound (v e)).trans (le_max_right _ _)
    · exact (weight_le_optimumOver _ _ v ⟨hei, hI⟩).trans (le_max_left _ _)
  · apply max_le
    · apply optimumOver_le
      intro I hI
      exact weight_le_optimumOver _ _ v hI.2
    · obtain ⟨I, hI, hbest⟩ := optimumOver_attained
        (fun I => e ∉ I ∧ M.Indep ((insert e I : Finset E) : Set E))
        (by simpa using And.intro (not_mem_empty e) he) v
      change v e + optimumOver _ _ v ≤ optimum M v
      rw [hbest]
      have hs : v e + weight v I = weight v (insert e I) := by
        simp [weight, sum_insert, hI.1]
      rw [hs]
      exact weight_le_optimumOver _ _ v hI.2

theorem optimum_nonneg (M : Matroid E) (v : E → ℝ) : 0 ≤ optimum M v :=
  optimumOver_nonneg _ _ _

theorem deletion_le_optimum (M : Matroid E) (v : E → ℝ) (e : E) :
    deletionValue M v e ≤ optimum M v := by
  apply optimumOver_le
  intro I hI
  exact weight_le_optimumOver _ _ _ hI.2

theorem deletion_surplus_nonneg (M : Matroid E) (v : E → ℝ) (e : E) :
    0 ≤ optimum M v - deletionValue M v e :=
  sub_nonneg.mpr (deletion_le_optimum M v e)

/-- The deletion-surplus upper bound in (3.3), pointwise before expectation. -/
theorem total_deletion_surplus_le_optimum (M : Matroid E) (v : E → ℝ) :
    (∑ e, (optimum M v - deletionValue M v e)) ≤ optimum M v := by
  obtain ⟨I, hI, hopt⟩ := optimumOver_attained
    (fun I : Finset E => M.Indep (I : Set E)) (by simpa using M.empty_indep) v
  change optimum M v = weight v I at hopt
  have hp : ∀ e, optimum M v - deletionValue M v e ≤ if e ∈ I then v e else 0 := by
    intro e
    by_cases hei : e ∈ I
    · have herase : e ∉ I.erase e ∧ M.Indep ((I.erase e : Finset E) : Set E) :=
        ⟨not_mem_erase e I, hI.subset (by
          intro f hf
          exact mem_of_mem_erase hf)⟩
      have hdel : weight v (I.erase e) ≤ deletionValue M v e :=
        weight_le_optimumOver _ _ _ herase
      have hs : weight v I = v e + weight v (I.erase e) := by
        simpa [weight] using (Finset.add_sum_erase I v hei).symm
      rw [if_pos hei]
      linarith
    · have hdel : weight v I ≤ deletionValue M v e :=
        weight_le_optimumOver _ _ _ ⟨hei, hI⟩
      rw [if_neg hei]
      linarith
  have hsum := sum_le_sum (fun e (_ : e ∈ (univ : Finset E)) => hp e)
  have hindicator : (∑ e, if e ∈ I then v e else 0) = weight v I := by
    classical
    simp [weight, ← sum_filter]
  rw [hindicator, ← hopt] at hsum
  exact hsum

theorem optimum_mono (M : Matroid E) {v w : E → ℝ} (h : ∀ e, v e ≤ w e) :
    optimum M v ≤ optimum M w := by
  apply optimumOver_le
  intro I hI
  exact (sum_le_sum (fun e _ => h e)).trans (weight_le_optimumOver _ _ w hI)

/-- The total nonnegative weight bounds every independent-set optimum. -/
theorem optimum_le_total (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    optimum M v ≤ ∑ e, v e := by
  apply optimumOver_le
  intro I hI
  apply sum_le_sum_of_subset_of_nonneg (subset_univ I)
  intro e he hnot
  exact hv e

/-- Evaluating capped weights on an optimal independent set (Lemma 7). -/
theorem optimum_cap_decomposition (M : Matroid E) (v cap : E → ℝ) :
    optimum M v ≤ optimum M (fun e => min (v e) (cap e)) +
      ∑ e, max (v e - cap e) 0 := by
  apply optimumOver_le
  intro I hI
  have hsum : weight v I = weight (fun e => min (v e) (cap e)) I +
      ∑ e ∈ I, max (v e - cap e) 0 := by
    simp only [weight]
    rw [← sum_add_distrib]
    apply sum_congr rfl
    intro e he
    rcases le_total (v e) (cap e) with h | h
    · rw [min_eq_left h, max_eq_right (sub_nonpos.mpr h), add_zero]
    · rw [min_eq_right h, max_eq_left (sub_nonneg.mpr h)]
      ring
  rw [hsum]
  apply add_le_add (weight_le_optimumOver _ _ _ hI)
  apply sum_le_sum_of_subset_of_nonneg (subset_univ I)
  intro e he hnot
  exact le_max_right _ _

end MatroidProphetSecretary
