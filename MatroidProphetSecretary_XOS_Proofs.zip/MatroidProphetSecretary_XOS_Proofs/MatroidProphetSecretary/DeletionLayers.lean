import MatroidProphetSecretary.ContractionLayers

/-! Deletion surplus is the integral of active-coloop counts. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem realRank_deletion_marginal (M : Matroid E) (S : Set E) (hS : S ⊆ M.E) (e : E) :
    realRank M S - realRank M (S \ {e}) =
      if e ∈ S ∧ e ∉ M.closure (S \ {e}) then 1 else 0 := by
  by_cases he : e ∈ S
  · have h := realRank_insert M (S \ {e}) (Set.diff_subset.trans hS) e (hS he)
    rw [Set.insert_diff_singleton, Set.insert_eq_of_mem he] at h
    by_cases hc : e ∈ M.closure (S \ {e})
    · simp only [hc, if_true, he, not_true_eq_false, and_false, if_false] at h ⊢
      linarith
    · simp only [hc, if_false, he, not_false_eq_true, and_self, if_true] at h ⊢
      linarith
  · rw [Set.diff_singleton_eq_self he]
    simp [he]

theorem deletionValue_eq_delete_optimum (M : Matroid E) (v : E → ℝ) (e : E) :
    deletionValue M v e = optimum (M ＼ {e}) v := by
  have hiff : ∀ I : Finset E, (e ∉ I ∧ M.Indep (I : Set E)) ↔
      (M ＼ {e}).Indep (I : Set E) := by
    intro I
    simp [Matroid.delete_indep_iff, Set.disjoint_singleton_right, and_comm]
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    exact weight_le_optimumOver _ _ v ((hiff I).mp hI)
  · apply optimumOver_le
    intro I hI
    exact weight_le_optimumOver _ _ v ((hiff I).mpr hI)

theorem valueLayer_delete_singleton (M : Matroid E) (v : E → ℝ) (z : ℝ) (e : E) :
    valueLayer (M ＼ {e}) v z = valueLayer M v z \ {e} := by
  ext x
  simp only [valueLayer, Set.mem_setOf_eq, Matroid.delete_ground, Set.mem_diff, Set.mem_singleton_iff]
  tauto

theorem delete_layer_realRank (M : Matroid E) (v : E → ℝ) (z : ℝ) (e : E) :
    realRank (M ＼ {e}) (valueLayer (M ＼ {e}) v z) = realRank M (valueLayer M v z \ {e}) := by
  unfold realRank
  have hsub : valueLayer M v z \ {e} ⊆ M.E \ {e} := fun _ hx => ⟨hx.1.1, hx.2⟩
  rw [valueLayer_delete_singleton, Matroid.delete_eq_restrict, M.restrict_eRk_eq hsub]

def coloopLayer (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) : ℝ :=
  if 0 < z ∧ e ∈ valueLayer M v z ∧ e ∉ M.closure (valueLayer M v z \ {e}) then 1 else 0

theorem coloopLayer_eq_rank_difference (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) :
    coloopLayer M v e z = positiveRankLayer M v z - positiveRankLayer (M ＼ {e}) v z := by
  by_cases hz : 0 < z
  · simp only [coloopLayer, positiveRankLayer, hz, if_true, true_and]
    change _ = realRank M (valueLayer M v z) - realRank (M ＼ {e}) (valueLayer (M ＼ {e}) v z)
    rw [delete_layer_realRank, realRank_deletion_marginal M _ (fun _ h => h.1)]
  · simp [coloopLayer, positiveRankLayer, hz]

theorem coloopLayer_integrable (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) (e : E) :
    Integrable (coloopLayer M v e) := by
  rw [funext (coloopLayer_eq_rank_difference M v e)]
  exact (positiveRankLayer_integrable M v hv).sub (positiveRankLayer_integrable (M ＼ {e}) v hv)

theorem deletion_surplus_eq_integral_coloop (M : Matroid E) (v : E → ℝ)
    (hv : ∀ e, 0 ≤ v e) (e : E) :
    optimum M v - deletionValue M v e = ∫ z, coloopLayer M v e z := by
  rw [deletionValue_eq_delete_optimum, optimum_eq_integral_rank M v hv,
    optimum_eq_integral_rank (M ＼ {e}) v hv]
  rw [← integral_sub (positiveRankLayer_integrable M v hv)
    (positiveRankLayer_integrable (M ＼ {e}) v hv)]
  congr 1
  funext z
  exact (coloopLayer_eq_rank_difference M v e z).symm

variable {Ω : Type*} [Fintype Ω]

theorem deletionSurplus_eq_integral_coloop_count (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e) :
    deletionSurplus μ M v = ∫ z, ∑ e, μ.expect (fun w => coloopLayer M (v w) e z) := by
  have hInt : ∀ e, Integrable (fun z => μ.expect (fun w => coloopLayer M (v w) e z)) := by
    intro e
    exact integrable_finset_sum univ (fun w _ =>
      (coloopLayer_integrable M (v w) (hv w) e).const_mul (μ.mass w))
  rw [integral_finset_sum univ (fun e _ => hInt e)]
  unfold deletionSurplus
  apply sum_congr rfl
  intro e he
  unfold FiniteLaw.expect
  rw [integral_finset_sum univ (fun w _ =>
    (coloopLayer_integrable M (v w) (hv w) e).const_mul (μ.mass w))]
  simp only [integral_const_mul]
  apply sum_congr rfl
  intro w hw
  rw [deletion_surplus_eq_integral_coloop M (v w) (hv w) e]

end MatroidProphetSecretary
