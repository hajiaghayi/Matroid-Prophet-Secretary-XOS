import MatroidProphetSecretary.SeededAdaptiveProcess
import Mathlib.Data.Finset.Sort
import Mathlib.Data.Fintype.CardEmbedding
import Mathlib.Data.Fintype.Perm

/-! Distinct finite arrival clocks are a sorted schedule and an independent permutation. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

abbrev ClockSchedule (N L : ℕ) := {s : Finset (Fin L) // s.card = N}

def clockImage {N L : ℕ} (clock : Fin N ↪ Fin L) : Finset (Fin L) := univ.map clock

theorem clockImage_card {N L : ℕ} (clock : Fin N ↪ Fin L) : (clockImage clock).card = N := by
  simp [clockImage]

def clockRangeEquiv {N L : ℕ} (clock : Fin N ↪ Fin L) : Fin N ≃ clockImage clock :=
  Equiv.ofBijective (fun i => ⟨clock i,by simp [clockImage]⟩)
    ⟨fun i j h => clock.injective (congrArg Subtype.val h),by
      rintro ⟨y,hy⟩
      obtain ⟨i,hi,hiy⟩ := mem_map.mp hy
      exact ⟨i,Subtype.ext hiy⟩⟩

def clockRank {N L : ℕ} (clock : Fin N ↪ Fin L) : Equiv.Perm (Fin N) :=
  (clockRangeEquiv clock).trans ((clockImage clock).orderIsoOfFin (clockImage_card clock)).toEquiv.symm

def decodeClocks {N L : ℕ} (data : ClockSchedule N L × Equiv.Perm (Fin N)) : Fin N ↪ Fin L :=
  data.2.toEmbedding.trans (data.1.val.orderEmbOfFin data.1.property).toEmbedding

theorem clockImage_decode {N L : ℕ} (data : ClockSchedule N L × Equiv.Perm (Fin N)) :
    clockImage (decodeClocks data) = data.1.val := by
  unfold clockImage decodeClocks
  rw [← map_map]
  have hp : univ.map data.2.toEmbedding = univ := by
    ext i
    simp
  rw [hp]
  exact map_orderEmbOfFin_univ _ _

theorem decode_clockImage_rank {N L : ℕ} (clock : Fin N ↪ Fin L) :
    decodeClocks (⟨clockImage clock,clockImage_card clock⟩,clockRank clock) = clock := by
  apply Function.Embedding.ext
  intro i
  change ↑((clockImage clock).orderIsoOfFin (clockImage_card clock)
    (((clockImage clock).orderIsoOfFin (clockImage_card clock)).symm (clockRangeEquiv clock i))) = clock i
  simp only [OrderIso.apply_symm_apply]
  rfl

theorem decodeClocks_injective (N L : ℕ) : Function.Injective (decodeClocks (N := N) (L := L)) := by
  rintro ⟨s,p⟩ ⟨t,q⟩ heq
  have hsets : s = t := by
    apply Subtype.ext
    have h := congrArg clockImage heq
    simpa only [clockImage_decode] using h
  subst t
  have hp : p = q := by
    apply Equiv.ext
    intro i
    apply (s.val.orderEmbOfFin s.property).injective
    exact congrArg (fun clock : Fin N ↪ Fin L => clock i) heq
  subst q
  rfl

theorem decodeClocks_surjective (N L : ℕ) : Function.Surjective (decodeClocks (N := N) (L := L)) := by
  intro clock
  exact ⟨(⟨clockImage clock,clockImage_card clock⟩,clockRank clock),decode_clockImage_rank clock⟩

def clockEncodingEquiv (N L : ℕ) : (Fin N ↪ Fin L) ≃ (ClockSchedule N L × Equiv.Perm (Fin N)) :=
  (Equiv.ofBijective decodeClocks ⟨decodeClocks_injective N L,decodeClocks_surjective N L⟩).symm

theorem decoded_clocks_follow_permutation {N L : ℕ} (schedule : ClockSchedule N L)
    (rank : Equiv.Perm (Fin N)) (i : Fin N) :
    decodeClocks (schedule,rank) (rank.symm i) = schedule.val.orderEmbOfFin schedule.property i := by
  simp [decodeClocks]

theorem decoded_arrivals_increasing {N L : ℕ} (schedule : ClockSchedule N L) (rank : Equiv.Perm (Fin N)) :
    StrictMono (fun i => decodeClocks (schedule,rank) (rank.symm i)) := by
  simpa only [decoded_clocks_follow_permutation] using (schedule.val.orderEmbOfFin schedule.property).strictMono

theorem FiniteLaw.uniform_pair {X Y : Type*} [Fintype X] [Fintype Y] [Nonempty X] [Nonempty Y] :
    FiniteLaw.uniform (X × Y) = (FiniteLaw.uniform X).pair (FiniteLaw.uniform Y) := by
  apply FiniteLaw.ext_mass
  funext x
  simp [FiniteLaw.uniform,FiniteLaw.pair,Fintype.card_prod,div_mul_div_comm]
  <;> ring

theorem uniform_distinct_clocks_factor (N L : ℕ) [Nonempty (Fin N ↪ Fin L)]
    [Nonempty (ClockSchedule N L)] (f : ClockSchedule N L → Equiv.Perm (Fin N) → ℝ) :
    (FiniteLaw.uniform (Fin N ↪ Fin L)).expect (fun clock => f (clockEncodingEquiv N L clock).1 (clockEncodingEquiv N L clock).2) =
      (FiniteLaw.uniform (ClockSchedule N L)).expect (fun schedule =>
        (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (f schedule)) := by
  rw [FiniteLaw.uniform_expect_equiv (clockEncodingEquiv N L) (fun data => f data.1 data.2),
    FiniteLaw.uniform_pair,FiniteLaw.pair_expect]

end MatroidProphetSecretary
