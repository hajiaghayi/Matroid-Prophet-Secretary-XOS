import MatroidProphetSecretary.FiniteConditioning
import MatroidProphetSecretary.ProductMoments

/-! Conditioning a finite product on separate per-label constraints preserves its product form. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem product_condition_weighted_mass (laws : ∀ e, FiniteLaw (V e)) (P : ∀ e, V e → Prop)
    (x : ∀ e, V e) :
    (product laws).prob (fun y => ∀ e, P e (y e)) *
      (product (fun e => (laws e).conditionOrSelf (P e))).mass x =
        if ∀ e, P e (x e) then (product laws).mass x else 0 := by
  have hp : (product laws).prob (fun y => ∀ e, P e (y e)) = ∏ e, (laws e).prob (P e) := by
    convert product_prob_coordinates laws P using 1
  rw [hp]
  change (∏ e, (laws e).prob (P e)) * (∏ e, ((laws e).conditionOrSelf (P e)).mass (x e)) = _
  rw [← prod_mul_distrib]
  simp_rw [conditionOrSelf_weighted_mass]
  by_cases hx : ∀ e, P e (x e)
  · simp [hx,product]
  · rw [if_neg hx]
    obtain ⟨e,he⟩ := not_forall.mp hx
    exact prod_eq_zero (mem_univ e) (by simp [he])

theorem product_condition_weighted_expect (laws : ∀ e, FiniteLaw (V e)) (P : ∀ e, V e → Prop)
    (f : (∀ e, V e) → ℝ) :
    (product laws).prob (fun y => ∀ e, P e (y e)) *
      (product (fun e => (laws e).conditionOrSelf (P e))).expect f =
        (product laws).expect (fun x => if ∀ e, P e (x e) then f x else 0) := by
  unfold expect
  rw [mul_sum]
  apply sum_congr rfl
  intro x hx
  rw [← mul_assoc,product_condition_weighted_mass]
  by_cases hA : ∀ e, P e (x e) <;> simp [hA]

theorem product_condition_expect (laws : ∀ e, FiniteLaw (V e)) (P : ∀ e, V e → Prop)
    (hp : 0 < (product laws).prob (fun x => ∀ e, P e (x e))) (f : (∀ e, V e) → ℝ) :
    ((product laws).conditionOrSelf (fun x => ∀ e, P e (x e))).expect f =
      (product (fun e => (laws e).conditionOrSelf (P e))).expect f := by
  apply (mul_left_cancel₀ hp.ne')
  rw [conditionOrSelf_weighted_expect,product_condition_weighted_expect]

end MatroidProphetSecretary.FiniteLaw
