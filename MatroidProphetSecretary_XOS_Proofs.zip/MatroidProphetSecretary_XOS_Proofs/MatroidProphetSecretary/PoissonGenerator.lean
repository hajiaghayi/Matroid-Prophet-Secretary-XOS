import MatroidProphetSecretary.FiniteProbability
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Logic.Equiv.Prod
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.Calculus.Deriv.Mul

/-! Finite Poisson-rounded expectations and their pure-birth generator. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def assembleBit (e : E) (b : Bool) (rest : {f // f ≠ e} → Bool) : E → Bool :=
  (Equiv.funSplitAt e Bool).symm (b, rest)

theorem assembleBit_self (e : E) (b : Bool) (rest : {f // f ≠ e} → Bool) :
    assembleBit e b rest e = b := by
  simp [assembleBit, Equiv.funSplitAt, Equiv.piSplitAt]

theorem assembleBit_other (e : E) (b : Bool) (rest : {f // f ≠ e} → Bool)
    (f : E) (hfe : f ≠ e) : assembleBit e b rest f = rest ⟨f, hfe⟩ := by
  simp [assembleBit, Equiv.funSplitAt, Equiv.piSplitAt, hfe]

theorem assembleBit_update (e : E) (b c : Bool) (rest : {f // f ≠ e} → Bool) :
    Function.update (assembleBit e b rest) e c = assembleBit e c rest := by
  funext f
  by_cases hfe : f = e
  · subst f
    rw [Function.update_self, assembleBit_self]
  · rw [Function.update_of_ne hfe, assembleBit_other e b rest f hfe,
      assembleBit_other e c rest f hfe]

theorem sum_split_bit (e : E) (f : (E → Bool) → ℝ) :
    (∑ x, f x) = ∑ rest : {f // f ≠ e} → Bool,
      (f (assembleBit e true rest) + f (assembleBit e false rest)) := by
  rw [← (Equiv.funSplitAt e Bool).symm.sum_comp f, Fintype.sum_prod_type_right]
  simp only [Fintype.sum_bool]
  rfl

def poissonWeight (a : ℝ) (b : Bool) : ℝ := if b = true then 1 - Real.exp (-a) else Real.exp (-a)

def poissonMass (a : E → ℝ) (x : E → Bool) : ℝ := ∏ e, poissonWeight (a e) (x e)

def poissonExcept (a : E → ℝ) (e : E) (x : E → Bool) : ℝ :=
  ∏ f ∈ univ.erase e, poissonWeight (a f) (x f)

def poissonEval (a : E → ℝ) (f : (E → Bool) → ℝ) : ℝ := ∑ x, poissonMass a x * f x

def insertDifference (e : E) (f : (E → Bool) → ℝ) (x : E → Bool) : ℝ :=
  f (Function.update x e true) - f x

theorem poissonMass_factor (a : E → ℝ) (e : E) (x : E → Bool) :
    poissonMass a x = poissonWeight (a e) (x e) * poissonExcept a e x :=
  (mul_prod_erase univ (fun f => poissonWeight (a f) (x f)) (mem_univ e)).symm

theorem poissonExcept_assembleBit (a : E → ℝ) (e : E) (b c : Bool)
    (rest : {f // f ≠ e} → Bool) :
    poissonExcept a e (assembleBit e b rest) = poissonExcept a e (assembleBit e c rest) := by
  apply prod_congr rfl
  intro f hf
  have hfe := (mem_erase.mp hf).1
  rw [assembleBit_other e b rest f hfe, assembleBit_other e c rest f hfe]

theorem poisson_generator_column (a : E → ℝ) (e : E) (f : (E → Bool) → ℝ) :
    (∑ x, poissonExcept a e x * (if x e = true then Real.exp (-a e) else -Real.exp (-a e)) * f x) =
      poissonEval a (insertDifference e f) := by
  unfold poissonEval
  rw [sum_split_bit e, sum_split_bit e]
  apply sum_congr rfl
  intro rest hrest
  simp only [assembleBit_self, if_true, Bool.false_eq_true, if_false, insertDifference,
    assembleBit_update, sub_self, mul_zero, add_zero, zero_add]
  rw [poissonMass_factor a e (assembleBit e false rest), assembleBit_self]
  simp only [poissonWeight, Bool.false_eq_true, if_false]
  rw [poissonExcept_assembleBit a e true false rest]
  ring

theorem poissonWeight_hasDerivAt (a b t : ℝ) (s : Bool) :
    HasDerivAt (fun u => poissonWeight (a + u * b) s)
      ((if s = true then Real.exp (-(a + t * b)) else -Real.exp (-(a + t * b))) * b) t := by
  have hlin := (hasDerivAt_const t a).add ((hasDerivAt_id t).mul_const b)
  have hexp := hlin.neg.exp
  cases s
  · convert hexp using 1 <;> simp [poissonWeight] <;> ring
  · convert hexp.const_sub 1 using 1 <;> simp [poissonWeight] <;> ring

theorem poissonEval_hasDerivAt (a b : E → ℝ) (f : (E → Bool) → ℝ) (t : ℝ) :
    HasDerivAt (fun u => poissonEval (fun e => a e + u * b e) f)
      (∑ e, b e * poissonEval (fun i => a i + t * b i) (insertDifference e f)) t := by
  have hworld : ∀ x : E → Bool,
      HasDerivAt (fun u => poissonMass (fun e => a e + u * b e) x * f x)
        ((∑ e, poissonExcept (fun i => a i + t * b i) e x *
          ((if x e = true then Real.exp (-(a e + t * b e)) else -Real.exp (-(a e + t * b e))) * b e)) * f x) t := by
    intro x
    simpa only [poissonMass, poissonExcept, smul_eq_mul] using
      (HasDerivAt.finset_prod (u := univ) (fun e _ => poissonWeight_hasDerivAt (a e) (b e) t (x e))).mul_const (f x)
  have hsum := HasDerivAt.sum (u := univ) (fun x _ => hworld x)
  have hvalue :
      (∑ x, (∑ e, poissonExcept (fun i => a i + t * b i) e x *
          ((if x e = true then Real.exp (-(a e + t * b e)) else -Real.exp (-(a e + t * b e))) * b e)) * f x) =
      ∑ e, b e * poissonEval (fun i => a i + t * b i) (insertDifference e f) := by
    simp_rw [sum_mul]
    rw [sum_comm]
    apply sum_congr rfl
    intro e he
    rw [← poisson_generator_column, mul_sum]
    apply sum_congr rfl
    intro x hx
    ring
  rw [hvalue] at hsum
  exact hsum

end MatroidProphetSecretary
