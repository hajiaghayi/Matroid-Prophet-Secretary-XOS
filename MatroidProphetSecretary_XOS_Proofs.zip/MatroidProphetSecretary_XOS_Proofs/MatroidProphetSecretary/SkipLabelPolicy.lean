import MatroidProphetSecretary.FirstArrivalReward
import MatroidProphetSecretary.FixedLabelOrder

/-! Deleting a known loop is implemented by ignoring that label in the observed history. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def lowerLabel {n : ℕ} (e x : Fin (n+1)) : Option (Fin n) :=
  if h : x ≠ e then some (remainingIndex e x h) else none

def skipLabelPolicy {n : ℕ} (e : Fin (n+1)) (child : OnlinePolicy n 0) : OnlinePolicy (n+1) 0 :=
  fun _ history x v => if h : x ≠ e then
    child 0 (history.filterMap (lowerObservation e)) (remainingIndex e x h) v else false

theorem acceptedSet_cons_observation {N : ℕ} (x : Observation N) (history : List (Observation N)) :
    acceptedSet (x :: history) = if x.accepted then insert x.label (acceptedSet history) else acceptedSet history := by
  cases h : x.accepted <;> simp [acceptedSet,List.filter_cons,h]

theorem acceptedSet_lower_history {n : ℕ} (e : Fin (n+1)) (history : List (Observation (n+1))) :
    (acceptedSet (history.filterMap (lowerObservation e))).image (remainingLabel e) = (acceptedSet history).erase e := by
  induction history with
  | nil => simp [acceptedSet]
  | cons x xs ih =>
    by_cases hx : x.label ≠ e
    · cases hb : x.accepted <;>
        simp [List.filterMap_cons,lowerObservation,hx,acceptedSet_cons_observation,hb,ih,remainingLabel_index,
          Finset.erase_insert_of_ne hx]
    · have he := not_ne_iff.mp hx
      cases hb : x.accepted <;>
        simp [List.filterMap_cons,lowerObservation,hx,acceptedSet_cons_observation,hb,ih,he]

theorem run_skipLabel_lower {n : ℕ} (e : Fin (n+1)) (child : OnlinePolicy n 0) (seed : Fin (2^0))
    (values : Fin (n+1) → ℝ) (order : List (Fin (n+1))) (history : List (Observation (n+1))) :
    (runPolicy (skipLabelPolicy e child) seed values order history).filterMap (lowerObservation e) =
      runPolicy child 0 (fun i => values (remainingLabel e i)) (order.filterMap (lowerLabel e))
        (history.filterMap (lowerObservation e)) := by
  induction order generalizing history with
  | nil => rfl
  | cons x xs ih =>
    by_cases hx : x ≠ e
    · simp only [runPolicy,skipLabelPolicy,dif_pos hx,List.filterMap_cons,lowerLabel]
      rw [ih]
      simp only [List.filterMap_append,List.filterMap_cons,List.filterMap_nil,lowerObservation,dif_pos hx,
        remainingLabel_index]
    · simp only [runPolicy,skipLabelPolicy,dif_neg hx,List.filterMap_cons,lowerLabel]
      rw [ih]
      simp only [List.filterMap_append,List.filterMap_cons,List.filterMap_nil,lowerObservation,dif_neg hx,List.append_nil]

theorem run_skipLabel_not_accepted {n : ℕ} (e : Fin (n+1)) (child : OnlinePolicy n 0) (seed : Fin (2^0))
    (values : Fin (n+1) → ℝ) (order : List (Fin (n+1))) (history : List (Observation (n+1)))
    (hh : e ∉ acceptedSet history) : e ∉ acceptedSet (runPolicy (skipLabelPolicy e child) seed values order history) := by
  induction order generalizing history with
  | nil => exact hh
  | cons x xs ih =>
    apply ih
    rw [acceptedSet_append_observation]
    by_cases hx : x ≠ e
    · simp only [skipLabelPolicy,dif_pos hx]
      split_ifs <;> simp [hh,hx.symm]
    · simp only [skipLabelPolicy,dif_neg hx,Bool.false_eq_true,if_false]
      exact hh

theorem lowerLabel_remaining {n : ℕ} (e : Fin (n+1)) (i : Fin n) :
    lowerLabel e (remainingLabel e i) = some i := by
  rw [lowerLabel,dif_pos (remainingLabel_ne e i),remainingIndex_label]

theorem lowerLabel_filter {n : ℕ} (e : Fin (n+1)) (order : List (Fin (n+1))) :
    order.filterMap (lowerLabel e) = (order.filter (fun x => decide (x ≠ e))).filterMap (lowerLabel e) := by
  induction order with
  | nil => rfl
  | cons x xs ih =>
    by_cases hx : x ≠ e <;> simp [List.filter_cons,List.filterMap_cons,lowerLabel,hx,ih]

theorem lowerLabel_insertArrivalOrder {n : ℕ} (e pos : Fin (n+1)) (rest : Equiv.Perm (Fin n)) :
    ((List.finRange (n+1)).map (insertArrivalOrder e pos rest)).filterMap (lowerLabel e) =
      (List.finRange n).map rest := by
  rw [lowerLabel_filter,insertArrivalOrder_filter]
  have h (xs : List (Fin n)) : (xs.map (remainingLabel e)).filterMap (lowerLabel e) = xs := by
    induction xs with
    | nil => rfl
    | cons x xs ih => simp only [List.map_cons,List.filterMap_cons,lowerLabel_remaining,ih]
  exact h _

theorem completed_skipLabel_accepted {n : ℕ} (e pos : Fin (n+1)) (child : OnlinePolicy n 0)
    (seed : Fin (2^0)) (values : Fin (n+1) → ℝ) (rest : Equiv.Perm (Fin n)) :
    acceptedSet (completedHistory (skipLabelPolicy e child) seed values (insertArrivalOrder e pos rest)) =
      (acceptedSet (completedHistory child 0 (fun i => values (remainingLabel e i)) rest)).image (remainingLabel e) := by
  have h := acceptedSet_lower_history e (completedHistory (skipLabelPolicy e child) seed values (insertArrivalOrder e pos rest))
  have hnot := run_skipLabel_not_accepted e child seed values
    ((List.finRange (n+1)).map (insertArrivalOrder e pos rest)) [] (by simp [acceptedSet])
  change e ∉ acceptedSet (completedHistory (skipLabelPolicy e child) seed values (insertArrivalOrder e pos rest)) at hnot
  rw [Finset.erase_eq_of_not_mem hnot] at h
  rw [completedHistory,run_skipLabel_lower,lowerLabel_insertArrivalOrder] at h
  exact h.symm

theorem skipLabelPolicy_feasible {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1))
    (child : OnlinePolicy n 0) (hc : PolicyFeasible (remainingDelete M e) child) :
    PolicyFeasible M (skipLabelPolicy e child) := by
  intro seed values order
  obtain ⟨⟨pos,rest⟩,rfl⟩ := (insertArrivalEquiv e).surjective order
  change M.Indep (acceptedSet (completedHistory (skipLabelPolicy e child) seed values (insertArrivalOrder e pos rest)) : Set (Fin (n+1)))
  rw [completed_skipLabel_accepted]
  exact remainingDelete_feasible M e _ (hc 0 _ rest)

theorem expected_skipLabelPolicy {n k : ℕ} (prior : RationalPriors (n+1) k) (e : Fin (n+1))
    (child : OnlinePolicy n 0) :
    expectedPolicyReward prior (skipLabelPolicy e child) = expectedPolicyReward (prior.remaining e) child := by
  rw [expectedPolicyReward_zero_bits]
  simp_rw [uniform_fixed_label_decomposition e,completed_skipLabel_accepted,weight_remaining_image,
    FiniteLaw.expect_const]
  rw [first_arrival_value_decomposition prior.law e]
  simp only [realization_join_remaining,FiniteLaw.expect_const]
  rw [expectedPolicyReward_zero_bits]
  rfl

end MatroidProphetSecretary
