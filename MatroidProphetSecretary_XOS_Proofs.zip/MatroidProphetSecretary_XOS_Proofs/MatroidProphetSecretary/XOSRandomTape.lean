import MatroidProphetSecretary.XOSArrivalOrder
import MatroidProphetSecretary.FiniteMeasureLaw

/-! Arbitrary independent random tapes reduce to a law on a finite policy space.
No finite-bit or rational-probability restriction is imposed by the hardness proof. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open MeasureTheory
open scoped Classical

instance policyFamilyMeasurableSpace (n L : ℕ) : MeasurableSpace (PolicyFamily n L) := ⊤
instance policyFamilyMeasurableSingleton (n L : ℕ) :
    MeasurableSingletonClass (PolicyFamily n L) := ⟨fun _ => trivial⟩

def familyReward {n L : ℕ} [NeZero L] (p : PolicyFamily n L) : ℝ :=
  (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect (fun σ => expectedReward (p σ).val)

theorem secretaryReward_as_expect {n L : ℕ} [NeZero L]
    (μ : FiniteLaw (PolicyFamily n L)) : secretaryReward μ = μ.expect familyReward := by
  rw [secretaryReward_eq]
  exact FiniteLaw.expect_comm _ _ _

/-- Push an arbitrary measurable independent tape through its deterministic policy table. -/
theorem random_tape_reduction {Ω : Type*} [MeasurableSpace Ω] {n L : ℕ} [NeZero L]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (P : Ω → PolicyFamily n L) (hP : Measurable P) :
    (∫ ω, familyReward (P ω) ∂μ) = secretaryReward (finiteRandomVariableLaw μ P hP) := by
  rw [secretaryReward_as_expect]
  letI : IsProbabilityMeasure (μ.map P) := isProbabilityMeasure_map hP.aemeasurable
  change _ = (FiniteLaw.ofMeasure (μ.map P)).expect familyReward
  rw [FiniteLaw.ofMeasure_expect]
  exact (integral_map hP.aemeasurable (measurable_of_countable familyReward).aestronglyMeasurable).symm

theorem arbitrary_random_tape_ratio_bound {Ω : Type*} [MeasurableSpace Ω]
    {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L) (hd : 0 < 1 - (n : ℝ)^2 / L)
    (μ : Measure Ω) [IsProbabilityMeasure μ] (P : Ω → PolicyFamily n L) (hP : Measurable P) :
    (∫ ω, familyReward (P ω) ∂μ) / expectedProphet n L ≤ finiteRatio n L := by
  rw [random_tape_reduction μ P hP]
  exact secretary_ratio_bound hnL hd _

end MatroidProphetSecretary.XOS
