import MatroidProphetSecretary.PoissonGenerator
import MatroidProphetSecretary.PoissonRankStructure
import Mathlib.Analysis.Convex.Deriv

/-! Concavity of the Poisson extension of matroid rank, proved from its generator. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def bitSet (x : E → Bool) : Set E := {e | x e = true}

theorem bitSet_update (x : E → Bool) (e : E) :
    bitSet (Function.update x e true) = insert e (bitSet x) := by
  ext f
  by_cases h : f = e
  · subst f
    simp [bitSet]
  · simp [bitSet, Function.update_of_ne h, h]

def rankObservable (M : Matroid E) (x : E → Bool) : ℝ := realRank M (bitSet x)

theorem rankObservable_second_difference (M : Matroid E) (e f : E) (x : E → Bool) :
    insertDifference f (insertDifference e (rankObservable M)) x =
      -rankBlock M (bitSet x) e f := by
  simp only [insertDifference, rankObservable, bitSet_update, rankBlock]
  ring

theorem poissonWeight_nonneg {a : ℝ} (ha : 0 ≤ a) (b : Bool) :
    0 ≤ poissonWeight a b := by
  have hexp : Real.exp (-a) ≤ 1 := Real.exp_le_one_iff.mpr (neg_nonpos.mpr ha)
  cases b <;> simp only [poissonWeight, Bool.false_eq_true, if_false, if_true]
  · exact (Real.exp_pos _).le
  · linarith

theorem poissonEval_nonneg (a : E → ℝ) (ha : ∀ e, 0 ≤ a e)
    (f : (E → Bool) → ℝ) (hf : ∀ x, 0 ≤ f x) : 0 ≤ poissonEval a f := by
  apply sum_nonneg
  intro x hx
  exact mul_nonneg (prod_nonneg (fun e _ => poissonWeight_nonneg (ha e) (x e))) (hf x)

def poissonSlope (M : Matroid E) (a b : E → ℝ) (t : ℝ) : ℝ :=
  ∑ e, b e * poissonEval (fun i => a i + t * b i) (insertDifference e (rankObservable M))

def poissonCurvature (M : Matroid E) (a b : E → ℝ) (t : ℝ) : ℝ :=
  -poissonEval (fun i => a i + t * b i)
    (fun x => ∑ e, ∑ f, b e * b f * rankBlock M (bitSet x) e f)

theorem poissonSlope_hasDerivAt (M : Matroid E) (a b : E → ℝ) (t : ℝ) :
    HasDerivAt (poissonSlope M a b) (poissonCurvature M a b t) t := by
  have h := HasDerivAt.sum (u := Finset.univ) (fun e _ =>
    (poissonEval_hasDerivAt a b (insertDifference e (rankObservable M)) t).const_mul (b e))
  have heq :
      (∑ e, b e * ∑ f, b f * poissonEval (fun i => a i + t * b i)
        (insertDifference f (insertDifference e (rankObservable M)))) =
      poissonCurvature M a b t := by
    simp only [poissonCurvature, poissonEval]
    simp_rw [mul_sum]
    conv_lhs => arg 2; ext e; rw [sum_comm]
    rw [sum_comm]
    simp only [← sum_neg_distrib]
    apply sum_congr rfl
    intro x hx
    apply sum_congr rfl
    intro e he
    apply sum_congr rfl
    intro f hf
    rw [rankObservable_second_difference]
    ring
  rw [heq] at h
  exact h

theorem poissonCurvature_nonpos (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (a b : E → ℝ) (t : ℝ) (ht : ∀ e, 0 ≤ a e + t * b e) :
    poissonCurvature M a b t ≤ 0 := by
  apply neg_nonpos.mpr
  apply poissonEval_nonneg _ ht
  intro x
  exact rankBlock_quadratic_nonneg M (bitSet x) (fun e _ => hground e) hground b

theorem poissonRank_concave_segment (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (a c : E → ℝ) (ha : ∀ e, 0 ≤ a e) (hc : ∀ e, 0 ≤ c e) :
    ConcaveOn ℝ (Icc (0 : ℝ) 1)
      (fun t => poissonEval (fun e => a e + t * (c e - a e)) (rankObservable M)) := by
  let b := fun e => c e - a e
  apply concaveOn_of_hasDerivWithinAt2_nonpos (convex_Icc 0 1)
    (f' := poissonSlope M a b) (f'' := poissonCurvature M a b)
  · intro t ht
    exact (poissonEval_hasDerivAt a b (rankObservable M) t).continuousAt.continuousWithinAt
  · intro t ht
    exact (poissonEval_hasDerivAt a b (rankObservable M) t).hasDerivWithinAt
  · intro t ht
    exact (poissonSlope_hasDerivAt M a b t).hasDerivWithinAt
  · intro t ht
    have hti : t ∈ Icc (0 : ℝ) 1 := interior_subset ht
    apply poissonCurvature_nonpos M hground a b t
    intro e
    have h1 := mul_nonneg (sub_nonneg.mpr hti.2) (ha e)
    have h2 := mul_nonneg hti.1 (hc e)
    dsimp [b]
    nlinarith

theorem poissonRank_tangent (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (a c : E → ℝ) (ha : ∀ e, 0 ≤ a e) (hc : ∀ e, 0 ≤ c e) :
    poissonEval c (rankObservable M) ≤ poissonEval a (rankObservable M) +
      ∑ e, (c e - a e) * poissonEval a (insertDifference e (rankObservable M)) := by
  have hconc := poissonRank_concave_segment M hground a c ha hc
  have hder := poissonEval_hasDerivAt a (fun e => c e - a e) (rankObservable M) 0
  have h := hconc.neg.le_slope_of_hasDerivAt
    (show (0 : ℝ) ∈ Set.Icc 0 1 by constructor <;> norm_num)
    (show (1 : ℝ) ∈ Set.Icc 0 1 by constructor <;> norm_num)
    (by norm_num) hder.neg
  simp only [slope_def_field, sub_zero, div_one, zero_mul, add_zero, one_mul,
    add_sub_cancel, Pi.neg_apply] at h
  linarith

end MatroidProphetSecretary
