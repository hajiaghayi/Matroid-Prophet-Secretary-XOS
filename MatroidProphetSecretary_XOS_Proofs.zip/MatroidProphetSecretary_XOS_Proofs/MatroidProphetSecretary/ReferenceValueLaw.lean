import MatroidProphetSecretary.FiniteTailLaw
import MatroidProphetSecretary.FinitePushforward
import MatroidProphetSecretary.LatentValueOrder
import Mathlib.Data.Fintype.Sort

/-! Finite reference values have exactly the saturated upper tails in (3.4). -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem upper_set_fin_cutoff {n : ℕ} (A : Fin n → Prop)
    (hA : ∀ i j, i ≤ j → A i → A j) : ∃ k ≤ n, ∀ i : Fin n, A i ↔ k ≤ i.val := by
  by_cases hex : ∃ i, A i
  · let S := univ.filter A
    have hS : S.Nonempty := by
      obtain ⟨i, hi⟩ := hex
      exact ⟨i, mem_filter.mpr ⟨mem_univ _, hi⟩⟩
    let i₀ := S.min' hS
    have hi₀ : A i₀ := (mem_filter.mp (min'_mem S hS)).2
    refine ⟨i₀.val, i₀.isLt.le, fun i => ⟨?_, ?_⟩⟩
    · intro hi
      exact min'_le S i (mem_filter.mpr ⟨mem_univ _, hi⟩)
    · intro hi
      exact hA i₀ i hi hi₀
  · refine ⟨n, le_rfl, fun i => ?_⟩
    have hn : ¬ A i := fun hi => hex ⟨i, hi⟩
    simp [hn, not_le_of_gt i.isLt]

def referenceValue {n : ℕ} (v : Fin n → ℝ) : Option (Fin n) → ℝ
  | none => 0
  | some i => v i

theorem finiteReferenceLaw_value_tail {n : ℕ} (μ : FiniteLaw (Fin n)) (v : Fin n → ℝ)
    (hv : Monotone v) (q : ℝ) (hq : 0 ≤ q) (z : ℝ) (hz : 0 ≤ z) :
    (finiteReferenceLaw μ q hq).prob (fun x => z < referenceValue v x) =
      min 1 (q * μ.prob (fun i => z < v i)) := by
  obtain ⟨k, hk, hcut⟩ := upper_set_fin_cutoff (fun i => z < v i)
    (fun i j hij hi => hi.trans_le (hv hij))
  have hprior : μ.prob (fun i => z < v i) = finiteIndexTail μ k :=
    FiniteLaw.prob_congr μ hcut
  rw [hprior]
  change _ = scaledIndexTail μ q k
  rw [← finiteReferenceLaw_index_tail μ q hq k hk]
  apply FiniteLaw.prob_congr
  intro x
  cases x with
  | none => simp [referenceValue, not_lt_of_ge hz]
  | some i => simpa [referenceValue] using hcut i

theorem referenceValue_nonneg {n : ℕ} (v : Fin n → ℝ) (hv : ∀ i, 0 ≤ v i)
    (x : Option (Fin n)) : 0 ≤ referenceValue v x := by
  cases x with
  | none => exact le_rfl
  | some i => exact hv i

variable {Ω : Type*} [Fintype Ω]

def valueSortedEquiv (v : Ω → ℝ) : Fin (Fintype.card Ω) ≃ Ω :=
  letI := valueLinearOrder v
  (monoEquivOfFin Ω rfl).toEquiv

theorem valueSortedEquiv_monotone (v : Ω → ℝ) : Monotone (fun i => v (valueSortedEquiv v i)) := by
  letI := valueLinearOrder v
  intro i j hij
  exact valueLinearOrder_monotone v ((monoEquivOfFin Ω rfl).monotone hij)

def sortedValueLaw (μ : FiniteLaw Ω) (v : Ω → ℝ) : FiniteLaw (Fin (Fintype.card Ω)) :=
  μ.map (valueSortedEquiv v).symm

theorem sortedValueLaw_prob (μ : FiniteLaw Ω) (v : Ω → ℝ) (z : ℝ) :
    (sortedValueLaw μ v).prob (fun i => z < v (valueSortedEquiv v i)) = μ.prob (fun x => z < v x) := by
  rw [sortedValueLaw, FiniteLaw.map_prob]
  apply FiniteLaw.prob_congr
  intro x
  simp only [Equiv.apply_symm_apply]

def referencePrior (μ : FiniteLaw Ω) (v : Ω → ℝ) (q : ℝ) (hq : 0 ≤ q) :
    FiniteLaw (Option (Fin (Fintype.card Ω))) := finiteReferenceLaw (sortedValueLaw μ v) q hq

def referencePriorValue (v : Ω → ℝ) : Option (Fin (Fintype.card Ω)) → ℝ :=
  referenceValue (fun i => v (valueSortedEquiv v i))

theorem referencePrior_tail (μ : FiniteLaw Ω) (v : Ω → ℝ) (q : ℝ) (hq : 0 ≤ q)
    (z : ℝ) (hz : 0 ≤ z) :
    (referencePrior μ v q hq).prob (fun x => z < referencePriorValue v x) =
      min 1 (q * μ.prob (fun x => z < v x)) := by
  rw [referencePrior, referencePriorValue, finiteReferenceLaw_value_tail _ _ (valueSortedEquiv_monotone v)
    q hq z hz, sortedValueLaw_prob]

theorem referencePriorValue_nonneg (v : Ω → ℝ) (hv : ∀ x, 0 ≤ v x)
    (x : Option (Fin (Fintype.card Ω))) : 0 ≤ referencePriorValue v x :=
  referenceValue_nonneg _ (fun i => hv (valueSortedEquiv v i)) x

end MatroidProphetSecretary
