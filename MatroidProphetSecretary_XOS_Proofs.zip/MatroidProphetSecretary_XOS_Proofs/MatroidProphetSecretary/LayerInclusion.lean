import MatroidProphetSecretary.GreedyOverlapLayer

/-! Active greedy inclusion factors as activity times a nonspanning probability. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def activityProbability (laws : E → FiniteLaw Bool) (e : E) : ℝ :=
  (FiniteLaw.product laws).prob (fun x => x e = true)

def selectedProbability (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E) (p : E → Prop) : ℝ :=
  (FiniteLaw.product laws).prob (fun x => x e = true ∧ nonspanEvent M e p x)

theorem nonspanEvent_ignores_own (M : Matroid E) (e : E) (p : E → Prop) (x y : E → Bool)
    (hxy : ∀ f, f ≠ e → x f = y f) : nonspanEvent M e p x ↔ nonspanEvent M e p y := by
  have hid : activeBlock M e p x = activeBlock M e p y := by
    ext f
    by_cases hfe : f = e
    · simp [activeBlock, hfe]
    · simp [activeBlock, hfe, hxy f hfe]
  unfold nonspanEvent
  rw [hid]

theorem selectedProbability_eq_factor (laws : E → FiniteLaw Bool) (M : Matroid E)
    (e : E) (p : E → Prop) :
    selectedProbability laws M e p = activityProbability laws e * nonspanProbability laws M e p := by
  unfold selectedProbability activityProbability nonspanProbability
  apply FiniteLaw.product_prob_and_of_disjoint laws (fun f => f = e)
  · intro x y hxy
    rw [hxy e rfl]
  · exact nonspanEvent_ignores_own M e p

theorem selectedProbability_le_activity (laws : E → FiniteLaw Bool) (M : Matroid E)
    (e : E) (p : E → Prop) : selectedProbability laws M e p ≤ activityProbability laws e :=
  FiniteLaw.prob_mono _ (fun _ h => h.1)

theorem coloop_probability_le_selected (laws : E → FiniteLaw Bool) (M : Matroid E)
    (e : E) (p : E → Prop) :
    activityProbability laws e * nonspanProbability laws M e (fun _ => True) ≤
      selectedProbability laws M e p := by
  rw [selectedProbability_eq_factor]
  exact mul_le_mul_of_nonneg_left (nonspanProbability_antitone laws M e (fun _ _ => trivial))
    ((FiniteLaw.product laws).prob_nonneg _)

def maskedValue (v : E → ℝ) (x : E → Bool) (e : E) : ℝ := if x e = true then v e else 0

theorem masked_higher_layer (M : Matroid E) (v : E → ℝ) (x : E → Bool)
    (e : E) (hve : 0 < v e) (hxe : x e = true) :
    {f | f ∈ M.E ∧ priorityBefore (maskedValue v x) e f} =
      activeBlock M e (priorityBefore v e) x := by
  ext f
  by_cases hfe : f = e
  · subst f
    simp [priorityBefore_irrefl, activeBlock]
  · cases hxf : x f
    · simp [priorityBefore, maskedValue, hxe, hxf, activeBlock, hfe,
        not_lt_of_ge hve.le, ne_of_gt hve]
    · simp [priorityBefore, maskedValue, hxe, hxf, activeBlock, hfe] <;> tauto

theorem selectedProbability_eq_canonical_inclusion (laws : E → FiniteLaw Bool) (M : Matroid E)
    (v : E → ℝ) (e : E) (he : e ∈ M.E) (hve : 0 < v e) :
    selectedProbability laws M e (priorityBefore v e) =
      (FiniteLaw.product laws).prob (fun x => x e = true ∧ e ∈ canonicalBasis M (maskedValue v x)) := by
  have hid : (fun x => x e = true ∧ nonspanEvent M e (priorityBefore v e) x) =
      (fun x => x e = true ∧ e ∈ canonicalBasis M (maskedValue v x)) := by
    funext x
    apply propext
    by_cases hxe : x e = true
    · rw [canonicalBasis_mem_iff M _ e he, masked_higher_layer M v x e hve hxe]
      rfl
    · simp [hxe]
  unfold selectedProbability
  exact FiniteLaw.prob_congr _ (fun x => Iff.of_eq (congrFun hid x))

end MatroidProphetSecretary
