import MatroidProphetSecretary.DeletionLayers

/-! Exclusion thresholds ignore the element's own value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem weight_update_of_not_mem (v : E → ℝ) (e : E) (u : ℝ) (I : Finset E) (he : e ∉ I) :
    weight (Function.update v e u) I = weight v I := by
  apply sum_congr rfl
  intro f hf
  have hfe : f ≠ e := by rintro rfl; exact he hf
  exact Function.update_of_ne hfe u v

theorem deletionValue_update (M : Matroid E) (v : E → ℝ) (e : E) (u : ℝ) :
    deletionValue M (Function.update v e u) e = deletionValue M v e := by
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    rw [weight_update_of_not_mem v e u I hI.1]
    exact weight_le_optimumOver _ _ v hI
  · apply optimumOver_le
    intro I hI
    rw [← weight_update_of_not_mem v e u I hI.1]
    exact weight_le_optimumOver _ _ _ hI

theorem contractionValue_update (M : Matroid E) (v : E → ℝ) (e : E) (u : ℝ)
    (he : M.Indep ({e} : Set E)) :
    contractionValue M (Function.update v e u) e he = contractionValue M v e he := by
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    rw [weight_update_of_not_mem v e u I hI.1]
    exact weight_le_optimumOver _ _ v hI
  · apply optimumOver_le
    intro I hI
    rw [← weight_update_of_not_mem v e u I hI.1]
    exact weight_le_optimumOver _ _ _ hI

theorem exclusionThreshold_update (M : Matroid E) (v : E → ℝ) (e : E) (u : ℝ)
    (he : M.Indep ({e} : Set E)) :
    exclusionThreshold M (Function.update v e u) e he = exclusionThreshold M v e he := by
  unfold exclusionThreshold
  rw [deletionValue_update, contractionValue_update]

theorem valueLayer_update_diff (M : Matroid E) (v : E → ℝ) (e : E) (u z : ℝ) :
    valueLayer M (Function.update v e u) z \ {e} = valueLayer M v z \ {e} := by
  ext f
  by_cases hfe : f = e
  · simp [hfe]
  · simp [valueLayer, Function.update_of_ne hfe, hfe]

theorem coloopLayer_update_min (M : Matroid E) (v : E → ℝ) (e : E) (u z : ℝ) :
    coloopLayer M (Function.update v e (min (v e) u)) e z =
      coloopLayer M v e z * positiveLayer u z := by
  unfold coloopLayer
  rw [valueLayer_update_diff]
  simp only [valueLayer, Set.mem_setOf_eq, Function.update_self, lt_min_iff, positiveLayer]
  split_ifs <;> norm_num <;> tauto

end MatroidProphetSecretary
