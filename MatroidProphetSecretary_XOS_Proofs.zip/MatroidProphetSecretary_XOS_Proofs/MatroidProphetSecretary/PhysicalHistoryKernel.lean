import MatroidProphetSecretary.PhysicalClockConsistency
import MatroidProphetSecretary.PhysicalGridRates

/-! An accepted-history transition kernel equals the explicit one-label private conditional law. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def historyPath (history : StampedHistory (Fin N) (Fin N → Option V)) (i : ℕ) := recordsBefore i history

theorem current_history_fixed (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history)) :
    recordsBefore n history = history := by
  obtain ⟨tapes,ht⟩ := FiniteLaw.exists_of_prob_pos (FiniteLaw.product cfg.laws)
    (fun tapes => cfg.run tapes n = history) (by
      convert hp using 1
      congr 1)
  rw [← ht]
  exact recordsBefore_stampedRun_self _ _ _ tapes n

theorem current_path_iff (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (tapes : Fin N → Fin L × GridPrivateTape N L V) :
    cfg.pathEvent (historyPath history) n tapes ↔ cfg.run tapes n = history := by
  constructor
  · intro h
    exact (h n le_rfl).trans (cfg.current_history_fixed history n hp)
  · intro h i hi
    have he := congrArg (recordsBefore i) h
    simpa only [run,recordsBefore_stampedRun _ _ _ tapes hi] using he

def privateMark (n : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V))
    (data : Fin L × GridPrivateTape N L V) : Option (GridMark N L V) :=
  if data.1 = gridClock N L cfg.clocks_pos n then
    (cfg.decision n history data.2).map
      (fun y => (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y)))
  else none

theorem historyKernel_absent_law (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (habsent : gridLabel N cfg.labels_pos n ∉ recordLabels history) :
    cfg.historyKernel n history =
      ((cfg.laws (gridLabel N cfg.labels_pos n)).conditionOrSelf
        (FiniteLaw.oneArrivalAbsent (fun c => c.val < (gridClock N L cfg.clocks_pos n).val)
          (phasePrivateDecision cfg.cut (gridHistoryProfile cfg.live history (gridLabel N cfg.labels_pos n))))).map
        (cfg.privateMark n history) := by
  let path := historyPath history
  have hfix : path n = history := cfg.current_history_fixed history n hp
  have hpath : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n) := by
    rwa [FiniteLaw.prob_congr _ (cfg.current_path_iff history n hp)]
  have hab : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ path n := by
    intro mark hm
    apply habsent
    rw [hfix] at hm
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨_,hm,rfl⟩)
  have hc := cfg.coordinate_condition path n hn hpath hab
  simp only [profile,hfix] at hc
  have hcond := FiniteLaw.conditionOrSelf_congr (FiniteLaw.product cfg.laws)
    (fun tapes => cfg.run tapes n = history) (cfg.pathEvent path n)
    (fun tapes => (cfg.current_path_iff history n hp tapes).symm)
  unfold historyKernel
  rw [dif_pos hp,hcond]
  apply FiniteLaw.ext_expect
  intro f
  rw [FiniteLaw.map_expect,FiniteLaw.map_expect]
  calc
    _ = ((FiniteLaw.product cfg.laws).conditionOrSelf (cfg.pathEvent path n)).expect
        (fun tapes => f (cfg.privateMark n history (tapes (gridLabel N cfg.labels_pos n)))) := by
      apply FiniteLaw.expect_congr_support
      intro tapes ht
      have hpt := FiniteLaw.conditionOrSelf_support (FiniteLaw.product cfg.laws) (cfg.pathEvent path n) hpath tapes ht
      have hh : cfg.run tapes n = history := (hpt n le_rfl).trans hfix
      simp only [trace,privateMark,hh]
    _ = _ := by
      have he := congrArg (fun law => law.expect (fun data => f (cfg.privateMark n history data))) hc
      dsimp only at he
      rw [FiniteLaw.map_expect] at he
      exact he

end MatroidProphetSecretary.PrivateGridConfig
