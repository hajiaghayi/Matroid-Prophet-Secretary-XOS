import MatroidProphetSecretary.FiniteProbability
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Constructions.Pi
import Mathlib.Probability.Independence.Basic

/-! Finite independent random variables have exactly the finite product laws used by the policy theorem. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory ProbabilityTheory
open scoped Classical

def FiniteLaw.ofMeasure {A : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]
    (μ : Measure A) [IsProbabilityMeasure μ] : FiniteLaw A where
  mass a := μ.real {a}
  nonneg a := measureReal_nonneg
  total := by simpa using sum_measureReal_singleton (μ := μ) (Finset.univ : Finset A)

theorem FiniteLaw.ofMeasure_expect {A : Type*} [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]
    (μ : Measure A) [IsProbabilityMeasure μ] (f : A → ℝ) :
    (FiniteLaw.ofMeasure μ).expect f = ∫ a, f a ∂μ := by
  rw [integral_fintype f Integrable.of_finite]
  rfl

theorem integral_pi_finiteLaw {I : Type*} [Fintype I] [DecidableEq I]
    {A : I → Type*} [∀ i, Fintype (A i)] [∀ i, MeasurableSpace (A i)] [∀ i, MeasurableSingletonClass (A i)]
    (μ : ∀ i, Measure (A i)) [∀ i, IsProbabilityMeasure (μ i)] (f : (∀ i, A i) → ℝ) :
    (∫ x, f x ∂Measure.pi μ) = (FiniteLaw.product (fun i => FiniteLaw.ofMeasure (μ i))).expect f := by
  rw [integral_fintype f Integrable.of_finite]
  apply Finset.sum_congr rfl
  intro x hx
  have hs : ({x} : Set (∀ i, A i)) = Set.pi Set.univ (fun i => {x i}) := by
    ext y
    simp only [Set.mem_singleton_iff,Set.mem_pi,Set.mem_univ,forall_true_left]
    exact funext_iff
  have hm : (Measure.pi μ).real {x} = ∏ i, (μ i).real {x i} := by
    simp only [measureReal_def,hs,Measure.pi_pi,ENNReal.toReal_prod]
  simp only [hm,smul_eq_mul,FiniteLaw.product,FiniteLaw.ofMeasure]

def finiteRandomVariableLaw {Ω A : Type*} [MeasurableSpace Ω] [MeasurableSpace A]
    [Fintype A] [MeasurableSingletonClass A] (μ : Measure Ω) [IsProbabilityMeasure μ]
    (X : Ω → A) (hX : Measurable X) : FiniteLaw A :=
  letI : IsProbabilityMeasure (μ.map X) := MeasureTheory.isProbabilityMeasure_map hX.aemeasurable
  FiniteLaw.ofMeasure (μ.map X)

theorem independent_finite_integral {Ω I : Type*} [MeasurableSpace Ω] [Fintype I] [DecidableEq I]
    {A : I → Type*} [∀ i, Fintype (A i)] [∀ i, MeasurableSpace (A i)] [∀ i, MeasurableSingletonClass (A i)]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : ∀ i, Ω → A i) (hX : ∀ i, Measurable (X i))
    (hind : iIndepFun X μ) (f : (∀ i, A i) → ℝ) :
    (∫ ω, f (fun i => X i ω) ∂μ) =
      (FiniteLaw.product (fun i => finiteRandomVariableLaw μ (X i) (hX i))).expect f := by
  letI (i : I) : IsProbabilityMeasure (μ.map (X i)) := isProbabilityMeasure_map (hX i).aemeasurable
  have hmap := (iIndepFun_iff_map_fun_eq_pi_map (fun i => (hX i).aemeasurable)).mp hind
  rw [← integral_map (measurable_pi_lambda _ hX).aemeasurable
    (measurable_of_countable f).aestronglyMeasurable,hmap,integral_pi_finiteLaw]
  rfl

end MatroidProphetSecretary
