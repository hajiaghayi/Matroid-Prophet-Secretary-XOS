import MatroidProphetSecretary.CategoricalInverseCDF
import MatroidProphetSecretary.UniformGridDraw

/-! Executable exact-rational comparisons implement the bounded categorical primitive. -/

namespace MatroidProphetSecretary

def rationalInverseCDF : List ℚ → ℚ → ℕ
  | [], _ => 0
  | b::bs, u => if u < b then 0 else 1+rationalInverseCDF bs u

def rationalCumulativeBoundaries : ℚ → List ℚ → List ℚ
  | _, [] => []
  | a,p::ps => (a+p)::rationalCumulativeBoundaries (a+p) ps

def rationalCategoricalDraw {k G : ℕ} (p : Fin k → ℚ) (j : Fin G) : ℕ :=
  rationalInverseCDF (rationalCumulativeBoundaries 0 (List.ofFn p)).dropLast ((j.val:ℚ)/G)

def fairBitCategorical {k : ℕ} (p : Fin k → ℚ) (bits : ℕ) (seed : Fin (2^bits)) : ℕ :=
  rationalCategoricalDraw p seed

noncomputable section

open MeasureTheory
open scoped Classical

theorem rationalInverseCDF_cast (bs : List ℚ) (u : ℚ) :
    rationalInverseCDF bs u = inverseCDF (bs.map (fun b : ℚ => (b:ℝ))) u := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp [rationalInverseCDF,inverseCDF,ih]

theorem rationalCumulativeBoundaries_cast (a : ℚ) (ps : List ℚ) :
    (rationalCumulativeBoundaries a ps).map (fun b : ℚ => (b:ℝ)) =
      cumulativeBoundaries a (ps.map (fun p : ℚ => (p:ℝ))) := by
  induction ps generalizing a with
  | nil => rfl
  | cons p ps ih => simp [rationalCumulativeBoundaries,cumulativeBoundaries,ih]

def rationalCategoryLaw {k : ℕ} (p : Fin k → ℚ) (hp : ∀ i, 0 ≤ p i) (ht : ∑ i, p i = 1) :
    FiniteLaw (Fin k) where
  mass i := p i
  nonneg i := by exact_mod_cast hp i
  total := by exact_mod_cast ht

theorem rationalCategoricalDraw_eq {k G : ℕ} (p : Fin k → ℚ)
    (hp : ∀ i, 0 ≤ p i) (ht : ∑ i, p i = 1) (j : Fin G) :
    rationalCategoricalDraw p j = categoricalDraw (rationalCategoryLaw p hp ht) ((j.val:ℝ)/G) := by
  rw [rationalCategoricalDraw,rationalInverseCDF_cast]
  simp only [List.map_dropLast,rationalCumulativeBoundaries_cast,Rat.cast_zero,Rat.cast_div,Rat.cast_natCast,List.map_ofFn]
  rfl

theorem rationalCategorical_shared_uniform {k G : ℕ} (p : Fin k → ℚ)
    (hp : ∀ i, 0 ≤ p i) (ht : ∑ i, p i = 1) (hG : 0 < G) (u : ℝ)
    (hu : u ∈ Set.Ico (0:ℝ) 1) :
    rationalCategoricalDraw p (uniformGridIndex G hG u) =
      categoricalDraw (rationalCategoryLaw p hp ht) (uniformGridDown G u) := by
  rw [rationalCategoricalDraw_eq p hp ht,uniformGridIndex_down G hG u hu]

theorem bounded_bit_categorical_coupling {k : ℕ} (p : Fin k → ℚ)
    (hp : ∀ i, 0 ≤ p i) (ht : ∑ i, p i = 1) (bits : ℕ) :
    let G := 2^bits
    let hG : 0 < G := pow_pos (by omega) bits
    let μ := rationalCategoryLaw p hp ht
    finiteRandomVariableLaw unitUniform (uniformGridIndex G hG) (uniformGridIndex_measurable G hG) =
      @FiniteLaw.uniform (Fin G) _ ⟨⟨0,hG⟩⟩ ∧
    (∀ i : Fin k, unitUniform {u | categoricalDraw μ u = i.val} = ENNReal.ofReal (p i)) ∧
    unitUniform {u | fairBitCategorical p bits (uniformGridIndex G hG u) ≠ categoricalDraw μ u} ≤
      ENNReal.ofReal ((k-1:ℕ)/(G:ℝ)) ∧
    (∀ u ∈ Set.Ico (0:ℝ) 1,
      fairBitCategorical p bits (uniformGridIndex G hG u) ≤ categoricalDraw μ u) := by
  dsimp only
  let G := 2^bits
  have hG : 0 < G := pow_pos (by omega) bits
  let μ := rationalCategoryLaw p hp ht
  refine ⟨uniformGridIndex_finiteLaw G hG,?_,?_,?_⟩
  · intro i
    exact categoricalDraw_mass μ i
  · have h := (categorical_grid_coupling μ G hG).1
    change unitUniform _ ≤ _ at h
    apply le_trans ?_ h
    rw [unitUniform,Measure.restrict_apply' measurableSet_Ico,Measure.restrict_apply' measurableSet_Ico]
    apply measure_mono
    intro u hu
    refine ⟨?_,hu.2⟩
    have hbad := hu.1
    change rationalCategoricalDraw p (uniformGridIndex G hG u) ≠ categoricalDraw μ u at hbad
    rw [rationalCategorical_shared_uniform p hp ht hG u hu.2] at hbad
    exact hbad
  · intro u hu
    change rationalCategoricalDraw p (uniformGridIndex G hG u) ≤ categoricalDraw μ u
    rw [rationalCategorical_shared_uniform p hp ht hG u hu]
    exact (categorical_grid_coupling μ G hG).2 u hu.1

end

end MatroidProphetSecretary
