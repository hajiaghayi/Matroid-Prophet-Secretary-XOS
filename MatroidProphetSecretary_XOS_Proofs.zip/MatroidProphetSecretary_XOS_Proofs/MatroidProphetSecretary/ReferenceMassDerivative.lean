import MatroidProphetSecretary.ReferenceInstance

/-! One-sided differentiability of every atom of the constructed reference law. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set Filter
open scoped Classical Topology

def referenceSide (left : Bool) (q : ℝ) : Set ℝ := if left = true then Iic q else Ici q

def referenceTailSlope (left : Bool) (p q : ℝ) : ℝ :=
  if left = true then scaledTailLeftSlope p q else scaledTailRightSlope p q

theorem clipped_scaledTail_derivative (left : Bool) (p q : ℝ) (hp : 0 ≤ p) (hq : 0 < q) :
    HasDerivWithinAt (fun t => scaledTail p (max 0 t)) (referenceTailSlope left p q) (referenceSide left q) q := by
  have hd : HasDerivWithinAt (scaledTail p) (referenceTailSlope left p q) (referenceSide left q) q := by
    cases left
    · exact scaledTail_right_derivative p q hp
    · exact scaledTail_left_derivative p q hp
  apply hd.congr_of_eventuallyEq
  · have hpos : ∀ᶠ t in 𝓝 q, 0 < t := isOpen_Ioi.mem_nhds hq
    filter_upwards [hpos.filter_mono nhdsWithin_le_nhds] with t ht
    rw [max_eq_right ht.le]
  · rw [max_eq_right hq.le]

def referenceAtomSlope {n : ℕ} (left : Bool) (μ : FiniteLaw (Fin n)) (q : ℝ) : Option (Fin n) → ℝ
  | none => -referenceTailSlope left (finiteIndexTail μ 0) q
  | some i => referenceTailSlope left (finiteIndexTail μ i.val) q -
      referenceTailSlope left (finiteIndexTail μ (i.val+1)) q

theorem finiteReferenceLaw_mass_derivative {n : ℕ} (left : Bool) (μ : FiniteLaw (Fin n))
    (q : ℝ) (hq : 0 < q) (x : Option (Fin n)) :
    HasDerivWithinAt (fun t => (finiteReferenceLaw μ (max 0 t) (le_max_left _ _)).mass x)
      (referenceAtomSlope left μ q x) (referenceSide left q) q := by
  cases x with
  | none =>
    exact (clipped_scaledTail_derivative left (finiteIndexTail μ 0) q (μ.prob_nonneg _) hq).const_sub 1
  | some i =>
    exact (clipped_scaledTail_derivative left (finiteIndexTail μ i.val) q (μ.prob_nonneg _) hq).sub
      (clipped_scaledTail_derivative left (finiteIndexTail μ (i.val+1)) q (μ.prob_nonneg _) hq)

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

def referenceWorldSlope (left : Bool) (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (q : ℝ) (x : ∀ e, ReferenceAtom V e) : ℝ :=
  ∑ e, (∏ f ∈ univ.erase e, (referenceInstanceLaws laws value q f).mass (x f)) *
    referenceAtomSlope left (sortedValueLaw (laws e) (value e)) q (x e)

theorem referenceWorld_mass_derivative (left : Bool) (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 < q) (x : ∀ e, ReferenceAtom V e) :
    HasDerivWithinAt (fun t => (FiniteLaw.product (referenceInstanceLaws laws value t)).mass x)
      (referenceWorldSlope left laws value q x) (referenceSide left q) q := by
  simpa only [FiniteLaw.product, referenceWorldSlope, smul_eq_mul] using
    HasDerivWithinAt.finset_prod (u := univ) (fun e _ =>
      finiteReferenceLaw_mass_derivative left (sortedValueLaw (laws e) (value e)) q hq (x e))

theorem referenceWorld_expect_derivative (left : Bool) (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 < q) (f : (∀ e, ReferenceAtom V e) → ℝ) :
    HasDerivWithinAt (fun t => (FiniteLaw.product (referenceInstanceLaws laws value t)).expect f)
      (∑ x, referenceWorldSlope left laws value q x * f x) (referenceSide left q) q :=
  HasDerivWithinAt.sum (u := univ) (fun x _ =>
    (referenceWorld_mass_derivative left laws value q hq x).mul_const (f x))

end MatroidProphetSecretary
