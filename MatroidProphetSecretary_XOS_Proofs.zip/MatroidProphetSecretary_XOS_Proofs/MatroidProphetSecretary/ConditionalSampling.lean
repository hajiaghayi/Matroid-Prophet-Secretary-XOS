import MatroidProphetSecretary.FiniteConditioning
import MatroidProphetSecretary.FinitePairs
import MatroidProphetSecretary.PoissonLaw

/-! A value above a cutoff is an independent activity bit and a conditional latent value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem bernoulliLaw_expect (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) (f : Bool → ℝ) :
    (bernoulliLaw p hp0 hp1).expect f = p * f true + (1 - p) * f false := by
  simp [FiniteLaw.expect, bernoulliLaw, Fintype.sum_bool]

def activeOption {Ω : Type*} (b : Bool) (x : Ω) : Option Ω := if b = true then some x else none

namespace FiniteLaw

variable {Ω : Type*} [Fintype Ω]

theorem expect_event_split (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A]
    (f : Ω → ℝ) (c : ℝ) :
    μ.expect (fun x => if A x then f x else c) =
      μ.expect (fun x => if A x then f x else 0) + (1 - μ.prob A) * c := by
  have hpoint (x : Ω) : (if A x then f x else c) =
      (if A x then f x else 0) + (1 - (if A x then (1 : ℝ) else 0)) * c := by
    split_ifs <;> ring
  simp_rw [hpoint]
  rw [expect_add, expect_mul_const, expect_sub, expect_const]
  rfl

theorem conditional_sampling_expect (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A]
    (f : Option Ω → ℝ) :
    (bernoulliLaw (μ.prob A) (μ.prob_nonneg A) (μ.prob_le_one A)).expect
        (fun b => (μ.conditionOrSelf A).expect (fun x => f (activeOption b x))) =
      μ.expect (fun x => f (if A x then some x else none)) := by
  rw [bernoulliLaw_expect]
  simp only [activeOption, if_true, Bool.false_eq_true, if_false, expect_const]
  rw [conditionOrSelf_weighted_expect]
  symm
  simpa only [apply_ite] using μ.expect_event_split A (fun x => f (some x)) (f none)

theorem conditional_sampling_law (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A] :
    (((bernoulliLaw (μ.prob A) (μ.prob_nonneg A) (μ.prob_le_one A)).pair
      (μ.conditionOrSelf A)).map (fun x => activeOption x.1 x.2)) =
        μ.map (fun x => if A x then some x else none) := by
  apply ext_expect
  intro f
  rw [map_expect, map_expect, pair_expect]
  exact conditional_sampling_expect μ A f

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)]

theorem product_conditional_sampling (laws : ∀ i, FiniteLaw (V i))
    (A : ∀ i, V i → Prop) [∀ i, DecidablePred (A i)] (f : (∀ i, Option (V i)) → ℝ) :
    (product (fun i => bernoulliLaw ((laws i).prob (A i))
      ((laws i).prob_nonneg (A i)) ((laws i).prob_le_one (A i)))).expect
      (fun b => (product (fun i => (laws i).conditionOrSelf (A i))).expect
        (fun x => f (fun i => activeOption (b i) (x i)))) =
      (product laws).expect (fun x => f (fun i => if A i (x i) then some (x i) else none)) := by
  let bits := fun i => bernoulliLaw ((laws i).prob (A i))
    ((laws i).prob_nonneg (A i)) ((laws i).prob_le_one (A i))
  let latent := fun i => (laws i).conditionOrSelf (A i)
  calc
    _ = (product (fun i => (bits i).pair (latent i))).expect
        (fun x => f (fun i => activeOption (x i).1 (x i).2)) :=
      (product_pair_expect bits latent _).symm
    _ = (product (fun i => ((bits i).pair (latent i)).map
        (fun x => activeOption x.1 x.2))).expect f :=
      (product_map_expect (fun i => (bits i).pair (latent i))
        (fun _ x => activeOption x.1 x.2) f).symm
    _ = (product (fun i => (laws i).map (fun x => if A i x then some x else none))).expect f := by
      congr 2
      funext i
      exact conditional_sampling_law (laws i) (A i)
    _ = _ := product_map_expect laws _ f

end FiniteLaw

end MatroidProphetSecretary
