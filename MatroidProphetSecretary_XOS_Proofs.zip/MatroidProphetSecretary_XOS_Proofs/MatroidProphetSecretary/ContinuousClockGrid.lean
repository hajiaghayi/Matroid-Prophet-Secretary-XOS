import MatroidProphetSecretary.ClockGridRounding
import MatroidProphetSecretary.ClockCollisions
import MatroidProphetSecretary.CategoricalExpectation

/-! Independent continuous clocks round to exactly independent uniform grid clocks. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

theorem uniformGrid_product_expect (N G : ℕ) (hG : 0 < G) (f : (Fin N → Fin G) → ℝ) :
    (∫ x : Fin N → ℝ, f (fun i => uniformGridIndex G hG (x i)) ∂Measure.pi (fun _ => unitUniform)) =
      (FiniteLaw.product (fun _ : Fin N => @FiniteLaw.uniform (Fin G) _ ⟨⟨0,hG⟩⟩)).expect f := by
  let ν := unitUniform.map (uniformGridIndex G hG)
  letI : IsProbabilityMeasure ν := isProbabilityMeasure_map (uniformGridIndex_measurable G hG).aemeasurable
  have hp := measurePreserving_pi (fun _ : Fin N => unitUniform) (fun _ : Fin N => ν)
    (f := fun _ => uniformGridIndex G hG) (fun _ => ⟨uniformGridIndex_measurable G hG,rfl⟩)
  rw [← integral_map hp.measurable.aemeasurable (measurable_of_countable f).aestronglyMeasurable,
    hp.map_eq,integral_pi_finiteLaw]
  have hν : FiniteLaw.ofMeasure ν = @FiniteLaw.uniform (Fin G) _ ⟨⟨0,hG⟩⟩ := uniformGridIndex_finiteLaw G hG
  simp only [hν]

theorem continuous_grid_collision_bound (N G : ℕ) (hG : 0 < G) :
    (Measure.pi (fun _ : Fin N => unitUniform)).real
      {x | ¬ Function.Injective (fun i => uniformGridIndex G hG (x i))} ≤ (N:ℝ)^2/G := by
  letI : Nonempty (Fin G) := ⟨⟨0,hG⟩⟩
  let X := fun x : Fin N → ℝ => fun i => uniformGridIndex G hG (x i)
  have hX : Measurable X := measurable_pi_lambda _ (fun i =>
    (uniformGridIndex_measurable G hG).comp (measurable_pi_apply i))
  have hm : MeasurableSet {x : Fin N → ℝ | ¬ Function.Injective (X x)} :=
    (Set.to_countable {x : Fin N → Fin G | ¬ Function.Injective x}).measurableSet.preimage hX
  have hi := uniformGrid_product_expect N G hG (fun x => if ¬ Function.Injective x then (1:ℝ) else 0)
  have he : (∫ x : Fin N → ℝ, if ¬ Function.Injective (X x) then (1:ℝ) else 0
      ∂Measure.pi (fun _ => unitUniform)) =
      (Measure.pi (fun _ : Fin N => unitUniform)).real {x | ¬ Function.Injective (X x)} := by
    simpa only [Set.indicator,Set.mem_setOf_eq,Pi.one_apply] using
      (integral_indicator_one (μ := Measure.pi (fun _ : Fin N => unitUniform)) hm)
  change (∫ x, if ¬ Function.Injective (X x) then (1:ℝ) else 0 ∂Measure.pi (fun _ => unitUniform)) = _ at hi
  rw [he] at hi
  rw [hi]
  exact iid_clock_collision_bound N G

theorem rounded_clock_order_on_distinct (N G : ℕ) (hG : 0 < G) (x : Fin N → ℝ)
    (hx : ∀ i, x i ∈ Set.Ico (0:ℝ) 1)
    (hd : Function.Injective (fun i => uniformGridIndex G hG (x i))) (i j : Fin N) :
    uniformGridUp G (x i) < uniformGridUp G (x j) ↔ x i < x j := by
  by_cases hij : i = j
  · subst j; simp
  apply uniformGridUp_order_iff
  intro he
  have hidx : uniformGridIndex G hG (x i) = uniformGridIndex G hG (x j) := by
    rw [uniformGridUp_index G hG _ (hx i),uniformGridUp_index G hG _ (hx j)] at he
    have hG' : (G:ℝ) ≠ 0 := by exact_mod_cast ne_of_gt hG
    have hv := (div_left_inj' hG').mp he
    apply Fin.ext
    exact_mod_cast (add_right_cancel hv :
      ((uniformGridIndex G hG (x i)).val:ℝ) = (uniformGridIndex G hG (x j)).val)
  exact hij (hd hidx)

end MatroidProphetSecretary
