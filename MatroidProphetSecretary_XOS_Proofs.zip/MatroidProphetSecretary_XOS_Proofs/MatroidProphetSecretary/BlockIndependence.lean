import MatroidProphetSecretary.ProductConditioning

/-! Independence of functions of disjoint coordinate blocks. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

theorem nonempty_of_law {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) : Nonempty Ω := by
  by_contra h
  haveI : IsEmpty Ω := not_nonempty_iff.mp h
  have ht := μ.total
  simpa using ht

theorem prob_mono {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) {A B : Ω → Prop}
    [DecidablePred A] [DecidablePred B]
    (hAB : ∀ w, A w → B w) : μ.prob A ≤ μ.prob B := by
  apply μ.expect_mono
  intro w
  by_cases hA : A w
  · simp [hA, hAB w hA]
  · simp only [hA, if_false]
    split_ifs <;> norm_num

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)]

theorem product_expect_mul_of_disjoint (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (f g : (∀ i, V i) → ℝ)
    (hf : ∀ x y, (∀ i, p i → x i = y i) → f x = f y)
    (hg : ∀ x y, (∀ i, ¬p i → x i = y i) → g x = g y) :
    (product laws).expect (fun x => f x * g x) = (product laws).expect f * (product laws).expect g := by
  let x0 : ∀ i, V i := fun i => Classical.choice (nonempty_of_law (laws i))
  let F := fun x : ∀ i : {i // p i}, V i =>
    f ((Equiv.piEquivPiSubtypeProd p V).symm (x, fun i => x0 i))
  let G := fun y : ∀ i : {i // ¬p i}, V i =>
    g ((Equiv.piEquivPiSubtypeProd p V).symm ((fun i => x0 i), y))
  have hfp : ∀ x y, f ((Equiv.piEquivPiSubtypeProd p V).symm (x, y)) = F x := by
    intro x y
    apply hf
    intro i hi
    simp [Equiv.piEquivPiSubtypeProd, hi]
  have hgp : ∀ x y, g ((Equiv.piEquivPiSubtypeProd p V).symm (x, y)) = G y := by
    intro x y
    apply hg
    intro i hi
    simp [Equiv.piEquivPiSubtypeProd, hi]
  have hfval := product_expect_split laws p f
  simp_rw [hfp, expect_const] at hfval
  have hgval := product_expect_split laws p g
  simp_rw [hgp, expect_const] at hgval
  have hfg := product_expect_split laws p (fun x => f x * g x)
  simp_rw [hfp, hgp, expect_const_mul, expect_mul_const] at hfg
  rw [hfval, hgval]
  exact hfg

theorem product_prob_and_of_disjoint (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (A B : (∀ i, V i) → Prop)
    [DecidablePred A] [DecidablePred B]
    (hA : ∀ x y, (∀ i, p i → x i = y i) → (A x ↔ A y))
    (hB : ∀ x y, (∀ i, ¬p i → x i = y i) → (B x ↔ B y)) :
    (product laws).prob (fun x => A x ∧ B x) = (product laws).prob A * (product laws).prob B := by
  have hi : ∀ x, (if A x ∧ B x then (1 : ℝ) else 0) =
      (if A x then 1 else 0) * (if B x then 1 else 0) := by
    intro x
    split_ifs <;> simp_all
  unfold prob
  simp_rw [hi]
  apply product_expect_mul_of_disjoint laws p
  · intro x y hxy
    simp only [hA x y hxy]
  · intro x y hxy
    simp only [hB x y hxy]

theorem prob_congr {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) {A B : Ω → Prop}
    [DecidablePred A] [DecidablePred B] (h : ∀ w, A w ↔ B w) : μ.prob A = μ.prob B := by
  unfold prob
  congr 1
  funext w
  by_cases hA : A w
  · simp [hA, (h w).mp hA]
  · have hB : ¬B w := fun hB => hA ((h w).mpr hB)
    simp [hA, hB]

end MatroidProphetSecretary.FiniteLaw
