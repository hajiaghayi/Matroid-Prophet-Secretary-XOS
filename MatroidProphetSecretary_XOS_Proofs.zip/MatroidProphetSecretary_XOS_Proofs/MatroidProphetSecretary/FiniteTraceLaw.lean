import MatroidProphetSecretary.TimedBatches
import MatroidProphetSecretary.AcceptedCoordinateLaw

/-! Conditional transition probabilities determine the complete finite trajectory law. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {R W S : Type*} [Fintype R] [Fintype W]

def traceEvent (trace : R → ℕ → W) (x : ℕ → W) (n : ℕ) (raw : R) : Prop :=
  ∀ i < n, trace raw i = x i

def scanState (update : S → W → S) (s : S) (x : ℕ → W) : ℕ → S
  | 0 => s
  | n+1 => update (scanState update s x n) (x n)

theorem scanState_shift (update : S → W → S) (s : S) (x : ℕ → W) (n : ℕ) :
    scanState update (update s (x 0)) (fun i => x (i+1)) n = scanState update s x (n+1) := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [scanState,ih]

theorem traceEvent_succ (trace : R → ℕ → W) (x : ℕ → W) (n : ℕ) (raw : R) :
    traceEvent trace x (n+1) raw ↔ traceEvent trace x n raw ∧ trace raw n = x n := by
  constructor
  · intro h
    exact ⟨fun i hi => h i (by omega),h n (by omega)⟩
  · rintro ⟨h,hn⟩ i hi
    rcases Nat.eq_or_lt_of_le (Nat.le_of_lt_succ hi) with rfl | hi
    · exact hn
    · exact h i hi

theorem traceEvent_step_probability (μ : FiniteLaw R) (trace : R → ℕ → W) (x : ℕ → W) (n : ℕ) :
    μ.prob (traceEvent trace x (n+1)) = μ.prob (traceEvent trace x n)*
      (μ.conditionOrSelf (traceEvent trace x n)).prob (fun raw => trace raw n = x n) := by
  symm
  change μ.prob (traceEvent trace x n)*
    (μ.conditionOrSelf (traceEvent trace x n)).expect (fun raw => if trace raw n = x n then 1 else 0) = _
  rw [conditionOrSelf_weighted_expect]
  unfold prob
  congr 1
  funext raw
  simp only [traceEvent_succ]
  split_ifs <;> simp_all

theorem traceEvent_probability_product (μ : FiniteLaw R) (trace : R → ℕ → W)
    (kernel : ℕ → S → FiniteLaw W) (update : S → W → S) (s : S) (offset n : ℕ)
    (htransition : ∀ j < n, ∀ x : ℕ → W, 0 < μ.prob (traceEvent trace x j) →
      (μ.conditionOrSelf (traceEvent trace x j)).prob (fun raw => trace raw j = x j) =
        (kernel (offset+j) (scanState update s x j)).mass (x j)) (x : ℕ → W) :
    μ.prob (traceEvent trace x n) =
      ∏ j ∈ range n, (kernel (offset+j) (scanState update s x j)).mass (x j) := by
  induction n with
  | zero => simp [traceEvent,prob]
  | succ n ih =>
    have hprev := ih (fun j hj => htransition j (by omega))
    rw [traceEvent_step_probability,prod_range_succ]
    by_cases hp : 0 < μ.prob (traceEvent trace x n)
    · rw [htransition n (Nat.lt_succ_self n) x hp,hprev]
    · have hz : μ.prob (traceEvent trace x n) = 0 :=
        le_antisymm (le_of_not_gt hp) (μ.prob_nonneg _)
      rw [← hprev,hz,zero_mul,zero_mul]

theorem timedBatches_mass_stream (kernel : ℕ → S → FiniteLaw W) (update : S → W → S)
    (n offset : ℕ) (s : S) (x : ℕ → W) :
    (timedBatches kernel update n offset s).mass (fun i => x i.val) =
      ∏ j ∈ range n, (kernel (offset+j) (scanState update s x j)).mass (x j) := by
  induction n generalizing offset s x with
  | zero =>
    have he : (fun i : Fin 0 => x i.val) = Fin.elim0 := funext (fun i => Fin.elim0 i)
    simp [timedBatches,pointMass,he]
  | succ n ih =>
    rw [timedBatches_mass_succ]
    change (kernel offset s).mass (x 0)*
      (timedBatches kernel update n (offset+1) (update s (x 0))).mass (fun i => x (i.val+1)) = _
    rw [ih (offset+1) (update s (x 0)) (fun j => x (j+1)),prod_range_succ',mul_comm]
    congr 1
    apply prod_congr rfl
    intro j hj
    rw [scanState_shift]
    congr 2
    omega

theorem trace_map_mass (μ : FiniteLaw R) (trace : R → ℕ → W) (n : ℕ) (x : ℕ → W) :
    (μ.map (fun raw => fun i : Fin n => trace raw i.val)).mass (fun i => x i.val) =
      μ.prob (traceEvent trace x n) := by
  have he (raw : R) : (fun i : Fin n => trace raw i.val) = (fun i => x i.val) ↔ traceEvent trace x n raw := by
    constructor
    · intro h i hi
      exact congrFun h ⟨i,hi⟩
    · intro h
      funext i
      exact h i.val i.isLt
  simp only [map,prob,expect]
  apply sum_congr rfl
  intro raw hr
  rw [he]
  split_ifs <;> simp

theorem trace_law_eq_timedBatches [Nonempty W] (μ : FiniteLaw R) (trace : R → ℕ → W)
    (kernel : ℕ → S → FiniteLaw W) (update : S → W → S) (s : S) (offset n : ℕ)
    (htransition : ∀ j < n, ∀ x : ℕ → W, 0 < μ.prob (traceEvent trace x j) →
      (μ.conditionOrSelf (traceEvent trace x j)).prob (fun raw => trace raw j = x j) =
        (kernel (offset+j) (scanState update s x j)).mass (x j)) :
    μ.map (fun raw => fun i : Fin n => trace raw i.val) = timedBatches kernel update n offset s := by
  apply ext_mass
  funext x
  let stream := fun j => if hj : j < n then x ⟨j,hj⟩ else Classical.choice (inferInstance : Nonempty W)
  have hx : (fun i : Fin n => stream i.val) = x := by funext i; simp [stream,i.isLt]
  rw [← hx,trace_map_mass,timedBatches_mass_stream]
  exact traceEvent_probability_product μ trace kernel update s offset n htransition stream

end MatroidProphetSecretary.FiniteLaw
