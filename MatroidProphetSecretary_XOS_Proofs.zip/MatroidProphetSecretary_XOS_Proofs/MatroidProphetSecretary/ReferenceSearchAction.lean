import MatroidProphetSecretary.SelectedReferenceAction
import MatroidProphetSecretary.ConcreteReferenceSelection

/-! The actual reference search followed by its chosen action pays the inherited potential. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

def ReferenceActionPays {N k B : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N)))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    (potential q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (Fin N → Bool))) : Prop :=
  if 3*delta ≤ |q-1| ∨ eta < referenceStabilityEstimate prior.law (fun e v => (prior.value e v : ℝ)) G M q x then
    ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧ potential ≤ expectedPolicyReward prior policy
  else potential ≤ referenceThresholdEpochReward (B := B) hN prior M hnonloop G q x

theorem ReferenceActionPays.mono {N k B : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N)))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    {P Q q : ℝ} {m : ℕ} (x : Fin m → (Fin G.last × (Fin N → Bool)))
    (hPQ : P ≤ Q) (h : ReferenceActionPays (B := B) hN prior M hnonloop G Q q x) :
    ReferenceActionPays (B := B) hN prior M hnonloop G P q x := by
  unfold ReferenceActionPays at h ⊢
  split_ifs at h ⊢ with hg
  · obtain ⟨K,policy,hfeasible,hreward⟩ := h
    exact ⟨K,policy,hfeasible,hPQ.trans hreward⟩
  · exact hPQ.trans h

theorem reference_search_action_pays {N k B : ℕ} (hN : 0 < N) (hB : 0 < B) (hNB : N ≤ B)
    (prior : RationalPriors N k) (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N)))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    (hF : 0 < expectedProphet M prior) {m : ℕ}
    (batches : ℕ → (Fin m → (Fin G.last × (Fin N → Bool))))
    (initial : SearchRecord (Fin m → (Fin G.last × (Fin N → Bool))))
    (hinit : |initial.point-1| < 3*delta)
    (hgood : referenceSearchAccurate
      (referencePositiveTest prior.law (fun e v => (prior.value e v : ℝ)) G M theta epsilon (m := m))
      (referenceNegativeTest prior.law (fun e v => (prior.value e v : ℝ)) G M theta epsilon (m := m)) batches initial
      (referenceRecordGood prior.law (fun e v => (prior.value e v : ℝ)) G M hnonloop B epsilon)
      delta (referenceSearchSteps B delta epsilon)) :
    let r := runReferenceSearch
      (referencePositiveTest prior.law (fun e v => (prior.value e v : ℝ)) G M theta epsilon (m := m))
      (referenceNegativeTest prior.law (fun e v => (prior.value e v : ℝ)) G M theta epsilon (m := m)) batches initial
      delta (referenceSearchSteps B delta epsilon)
    ReferenceActionPays (B := B) hN prior M hnonloop G
      (discount initial.point*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) initial.point)
      r.point r.batch := by
  letI : Nonempty (Fin N) := ⟨⟨0,hN⟩⟩
  let observed := fun e v => (prior.value e v : ℝ)
  let r := runReferenceSearch (referencePositiveTest prior.law observed G M theta epsilon (m := m))
    (referenceNegativeTest prior.law observed G M theta epsilon (m := m)) batches initial
    delta (referenceSearchSteps B delta epsilon)
  have hobs (e : Fin N) (v : Fin k) : 0 ≤ observed e v := by
    change (0:ℝ) ≤ (prior.value e v:ℝ)
    exact_mod_cast prior.value_nonneg e v
  have hs := finite_reference_selection_concrete prior.law M observed hobs hnonloop G
  rw [fin_order_decidableEq] at hs
  have hF' : 0 < expectedOptimum (FiniteLaw.product prior.law) M (coordinateValues observed) := hF
  have hs := hs hF' B hB (by simpa only [Fintype.card_fin] using hNB) batches initial hinit hgood
  change referenceRecordGood prior.law observed G M hnonloop B epsilon r ∧ r.point ∈ interval ∧
    discount initial.point*referenceExpectedOptimum prior.law M observed initial.point ≤
      discount r.point*referenceExpectedOptimum prior.law M observed r.point ∧
    (|r.point-1| < 3*delta →
      stationaryRatio r.point-20*epsilon ≤ referenceDeletion prior.law M observed r.point/referenceExpectedOptimum prior.law M observed r.point ∧
      referenceDeletion prior.law M observed r.point/referenceExpectedOptimum prior.law M observed r.point ≤
        stationaryRatio r.point+referenceStable prior.law M observed hnonloop r.point/referenceExpectedOptimum prior.law M observed r.point+20*epsilon) at hs
  have hFq : 0 < referenceExpectedOptimum prior.law M observed r.point :=
    (mul_pos (by norm_num : (0:ℝ) < 1/2) hF').trans_le
      (referenceExpectedOptimum_lower_away_zero prior.law M
        (fun e => (hnonloop e).subset_ground (Set.mem_singleton e)) observed hobs (1/2) r.point
        (by norm_num) (by norm_num) (by linarith [(interval_bounds hs.2.1).1]))
  have hsaved := hs.1
  unfold referenceRecordGood at hsaved
  have hpay := selected_reference_action_pays hN hB hNB prior M hnonloop G hs.2.1 r.batch hFq hsaved hs.2.2.2
  exact ReferenceActionPays.mono hN prior M hnonloop G r.batch hs.2.2.1 hpay

end MatroidProphetSecretary
