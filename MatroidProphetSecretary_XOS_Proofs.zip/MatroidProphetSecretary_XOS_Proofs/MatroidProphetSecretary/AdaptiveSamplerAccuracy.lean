import MatroidProphetSecretary.SamplerAccuracy
import MatroidProphetSecretary.BatchBudget

/-! Lemma 16 for finite priors, with actual adaptively requested common-sampler batches. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)] {S : Type*}

def samplerQueryBatch (laws : S → ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (hV : ∀ s, 0 < finiteValueVolume (laws s) value G)
    (m : ℕ) (s : S) : FiniteLaw (Fin m → (Fin G.last × (E → Bool))) :=
  FiniteLaw.product (fun _ : Fin m => finiteValueSampler (laws s) value G (hV s))

theorem samplerQueryBatch_budget (laws : S → ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (G : ValueHeightGrid value)
    (hV : ∀ s, 0 < finiteValueVolume (laws s) value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N K : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (hK : 0 < K)
    (ε ρ : ℝ) (hε0 : 0 < ε) (hε1 : ε ≤ 1) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1) (s : S) :
    (samplerQueryBatch laws value G hV (commonBatchSize N K ε ρ) s).prob
      (samplerBatchBad (laws s) value G M hnonloop N ε) ≤ ρ/((N:ℝ)*K) := by
  have hm := commonBatchSize_pos N K hN0 ε ρ hε0
    (confidenceArgument_gt_one N K hN0 hK ρ hρ0 hρ1)
  exact (samplerBatch_failure_bound (laws s) value hv G (hV s) M hnonloop N hN0 hN
    (commonBatchSize N K ε ρ) hm ε hε0 hε1).trans
      (commonBatchSize_failure_budget N K hN0 hK ε ρ hε0 hρ0 hρ1)

theorem finite_adaptive_sampler_accuracy (laws : S → ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) (G : ValueHeightGrid value)
    (hV : ∀ s, 0 < finiteValueVolume (laws s) value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N K : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (hK : 0 < K)
    (ε ρ : ℝ) (hε0 : 0 < ε) (hε1 : ε ≤ 1) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1)
    (update : S → (Fin (commonBatchSize N K ε ρ) → (Fin G.last × (E → Bool))) → S) (start : S) :
    (FiniteLaw.adaptiveBatches (samplerQueryBatch laws value G hV (commonBatchSize N K ε ρ)) update K start).prob
      (FiniteLaw.trajectoryBad update (fun s => samplerBatchBad (laws s) value G M hnonloop N ε) K start) ≤ ρ/N := by
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN0
  have hk : 0 < (K:ℝ) := Nat.cast_pos.mpr hK
  have h := FiniteLaw.adaptiveBatches_failure_bound
    (samplerQueryBatch laws value G hV (commonBatchSize N K ε ρ)) update
    (fun s => samplerBatchBad (laws s) value G M hnonloop N ε) (ρ/((N:ℝ)*K))
    (by positivity) (samplerQueryBatch_budget laws value hv G hV M hnonloop N K hN0 hN hK ε ρ hε0 hε1 hρ0 hρ1) K start
  convert h using 1 <;> field_simp <;> ring

theorem finite_selected_sampler_accuracy (laws : S → ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) (G : ValueHeightGrid value)
    (hV : ∀ s, 0 < finiteValueVolume (laws s) value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (N K : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (hK : 0 < K)
    (ε ρ : ℝ) (hε0 : 0 < ε) (hε1 : ε ≤ 1) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1)
    (update : S → (Fin (commonBatchSize N K ε ρ) → (Fin G.last × (E → Bool))) → S) (start : S)
    (select : (Fin K → Fin (commonBatchSize N K ε ρ) → (Fin G.last × (E → Bool))) → Fin K) :
    (FiniteLaw.adaptiveBatches (samplerQueryBatch laws value G hV (commonBatchSize N K ε ρ)) update K start).prob
      (fun x => samplerBatchBad (laws (FiniteLaw.stateBefore update K start x (select x)))
        value G M hnonloop N ε (x (select x))) ≤ ρ/N := by
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN0
  have hk : 0 < (K:ℝ) := Nat.cast_pos.mpr hK
  have h := FiniteLaw.adaptiveBatches_selected_bound
    (samplerQueryBatch laws value G hV (commonBatchSize N K ε ρ)) update
    (fun s => samplerBatchBad (laws s) value G M hnonloop N ε) (ρ/((N:ℝ)*K))
    (by positivity) (samplerQueryBatch_budget laws value hv G hV M hnonloop N K hN0 hN hK ε ρ hε0 hε1 hρ0 hρ1)
    K start select
  convert h using 1 <;> field_simp <;> ring

end MatroidProphetSecretary
