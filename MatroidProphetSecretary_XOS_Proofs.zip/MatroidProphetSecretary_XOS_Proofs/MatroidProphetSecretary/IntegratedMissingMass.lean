import MatroidProphetSecretary.CapMissingLayers
import MatroidProphetSecretary.FiniteIntegrals
import MatroidProphetSecretary.BlockResampling

/-! Integrating the deterministic cap rank deficit. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

theorem cap_missing_integral_bound (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (c : E → ℝ) (hv : ∀ w e, 0 ≤ v w e) (hc : ∀ e, 0 ≤ c e)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (B : Finset E)
    (hB : M.IsBase (B : Set E)) (hopt : optimum M c = weight c B) :
    (∫ z, μ.expect (fun w => capMissingLayer M (v w) c B z)) ≤
      optimum M c - expectedOptimum μ M (fun w e => min (v w e) (c e)) +
        μ.expect (fun w => optimum M (v w) - ∑ e ∈ B, contractionCost M (v w) e (hnonloop e)) := by
  have hmin (w : Ω) (e : E) : 0 ≤ min (v w e) (c e) := le_min (hv w e) (hc e)
  have hright (w : Ω) : Integrable (fun z =>
      positiveRankLayer M c z - positiveRankLayer M (fun e => min (v w e) (c e)) z +
        realizedLayerGap M (v w) B z) :=
    ((positiveRankLayer_integrable M c hc).sub
      (positiveRankLayer_integrable M _ (hmin w))).add
        (realizedLayerGap_integrable M (v w) (hv w) B hnonloop)
  have h := integral_mono
    (μ.integrable_expect _ (fun w => capMissingLayer_integrable M (v w) c (hv w) B hnonloop))
    (μ.integrable_expect _ hright)
    (fun z => μ.expect_mono (fun w => capMissingLayer_le_deficits M (v w) c B hB hopt z))
  rw [μ.integral_expect _ hright] at h
  have hi (w : Ω) :
      (∫ z, positiveRankLayer M c z - positiveRankLayer M (fun e => min (v w e) (c e)) z +
        realizedLayerGap M (v w) B z) =
      optimum M c - optimum M (fun e => min (v w e) (c e)) +
        (optimum M (v w) - ∑ e ∈ B, contractionCost M (v w) e (hnonloop e)) := by
    have hsub : Integrable (fun z => positiveRankLayer M c z -
        positiveRankLayer M (fun e => min (v w e) (c e)) z) :=
      (positiveRankLayer_integrable M c hc).sub (positiveRankLayer_integrable M _ (hmin w))
    rw [integral_add hsub
      (realizedLayerGap_integrable M (v w) (hv w) B hnonloop),
      integral_sub (positiveRankLayer_integrable M c hc) (positiveRankLayer_integrable M _ (hmin w)),
      ← optimum_eq_integral_rank M c hc, ← optimum_eq_integral_rank M _ (hmin w),
      ← realized_gap_eq_integral M (v w) (hv w) B hnonloop]
  simp_rw [hi, FiniteLaw.expect_add, FiniteLaw.expect_sub, FiniteLaw.expect_const] at h
  simpa only [expectedOptimum, FiniteLaw.expect_sub] using h

/-- The integrated missing-mass estimate in the proof of Lemma 9. -/
theorem price_missing_mass_bound (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hv : ∀ w e, 0 ≤ v w e) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (B : Finset E) (hB : M.IsBase (B : Set E))
    (hopt : priceOptimum μ M v hnonloop = weight (contractionPrice μ M v hnonloop) B)
    (b : ℝ) (hb : 0 ≤ b) :
    (∫ z, μ.expect (fun w => capMissingLayer M (v w)
      (fun e => b * contractionPrice μ M v hnonloop e) B z)) ≤
      priceGap μ M v hnonloop + capDeficit μ M v hnonloop b := by
  let c := fun e => b * contractionPrice μ M v hnonloop e
  have hc : ∀ e, 0 ≤ c e := fun e => mul_nonneg hb (contractionPrice_nonneg μ M v hnonloop e)
  have hoptc : optimum M c = weight c B := by
    rw [optimum_smul M _ b hb]
    change b * priceOptimum μ M v hnonloop = _
    rw [hopt]
    simp [weight, c, mul_sum]
  have h := cap_missing_integral_bound μ M v c hv hc hnonloop B hB hoptc
  have hcost : μ.expect (fun w => ∑ e ∈ B, contractionCost M (v w) e (hnonloop e)) =
      priceOptimum μ M v hnonloop := by
    rw [FiniteLaw.expect_finset_sum, hopt]
    rfl
  rw [FiniteLaw.expect_sub, hcost, optimum_smul M _ b hb] at h
  change _ ≤ b * priceOptimum μ M v hnonloop -
    expectedOptimum μ M (cappedValues μ M v hnonloop b) +
    (expectedOptimum μ M v - priceOptimum μ M v hnonloop) at h
  unfold priceGap capDeficit
  linarith

end MatroidProphetSecretary
