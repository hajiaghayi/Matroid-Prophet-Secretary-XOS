import MatroidProphetSecretary.CategoricalExpectation
import MatroidProphetSecretary.PoissonIntegerTable

/-! A fixed-length fair-bit Poisson count sampler, bounded on every run and in expectation. -/

namespace MatroidProphetSecretary

open Finset

def rationalPoissonProbability (T : ℕ) (n : Fin (T+1)) : ℚ :=
  (poissonIntegerWeight T n : ℚ)/(∑ j : Fin (T+1), poissonIntegerWeight T j : ℕ)

def boundedPoissonCount (T bits : ℕ) (seed : Fin (2^bits)) : ℕ :=
  fairBitCategorical (rationalPoissonProbability T) bits seed

noncomputable section

theorem rationalPoissonProbability_nonneg (T : ℕ) (n : Fin (T+1)) :
    0 ≤ rationalPoissonProbability T n := by unfold rationalPoissonProbability; positivity

theorem rationalPoissonProbability_total (T : ℕ) : ∑ n, rationalPoissonProbability T n = 1 := by
  simp only [rationalPoissonProbability,← sum_div,← Nat.cast_sum]
  exact div_self (by exact_mod_cast ne_of_gt (poissonIntegerTable_total_pos T))

theorem rationalPoissonProbability_law (T : ℕ) :
    rationalCategoryLaw (rationalPoissonProbability T) (rationalPoissonProbability_nonneg T)
      (rationalPoissonProbability_total T) = truncatedPoissonTwo T := by
  apply FiniteLaw.ext_mass
  funext n
  change (rationalPoissonProbability T n : ℝ) = _
  simp only [rationalPoissonProbability,Rat.cast_div,Rat.cast_natCast]
  exact poissonIntegerTable_distribution T n

theorem boundedPoissonCount_le (T bits : ℕ) (seed : Fin (2^bits)) : boundedPoissonCount T bits seed ≤ T := by
  obtain ⟨i,hi,_⟩ := rationalCategoricalDraw_supported (rationalPoissonProbability T)
    (rationalPoissonProbability_nonneg T) (rationalPoissonProbability_total T) seed
  change rationalCategoricalDraw (rationalPoissonProbability T) seed ≤ T
  rw [hi]
  exact Nat.le_of_lt_succ i.isLt

theorem boundedPoissonCount_eq (T bits : ℕ) (seed : Fin (2^bits)) :
    boundedPoissonCount T bits seed = categoricalDraw (truncatedPoissonTwo T) ((seed.val:ℝ)/(2^bits:ℕ)) := by
  change rationalCategoricalDraw (rationalPoissonProbability T) seed = _
  rw [rationalCategoricalDraw_eq _ (rationalPoissonProbability_nonneg T) (rationalPoissonProbability_total T),
    rationalPoissonProbability_law]

theorem boundedPoissonCount_mean_le_two (T bits : ℕ) :
    (FiniteLaw.uniform (Fin (2^bits))).expect (fun seed => (boundedPoissonCount T bits seed : ℝ)) ≤ 2 := by
  have h := categorical_grid_expect_le (truncatedPoissonTwo T) (Nat.zero_lt_succ T)
    (pow_pos (by omega : 0 < 2) bits) (fun n : Fin (T+1) => (n.val:ℝ))
    (fun i j hij => by change (i.val:ℝ) ≤ j.val; exact_mod_cast hij)
  apply le_trans ?_ (h.trans (truncatedPoissonTwo_mean_le_two T))
  apply FiniteLaw.expect_mono
  intro seed
  rw [boundedPoissonCount_eq]
  rfl

end

end MatroidProphetSecretary
