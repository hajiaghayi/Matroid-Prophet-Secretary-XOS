import MatroidProphetSecretary.ReferenceMassDerivative

/-! Differentiation of reference welfare commutes with the height integral by finite summation. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory Set Filter
open scoped Classical Topology

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

def referenceOptimumSlope (left : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) : ℝ :=
  ∑ x, referenceWorldSlope left laws value q x *
    optimum M (coordinateValues (referenceInstanceValues value) x)

def referenceLayerSlope (left : Bool) (M : Matroid E) (p : E → ℝ) (q : ℝ) : ℝ :=
  if left = true then referenceLayerLeftDerivative M p q else referenceLayerRightDerivative M p q

theorem referenceExpectedOptimum_derivative (left : Bool) (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 < q) :
    HasDerivWithinAt (referenceExpectedOptimum laws M value) (referenceOptimumSlope left laws M value q)
      (referenceSide left q) q := referenceWorld_expect_derivative left laws value q hq _

theorem referenceWorld_layer_slope (left : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 < q) (z : ℝ) :
    (∑ x, referenceWorldSlope left laws value q x *
      positiveRankLayer M (coordinateValues (referenceInstanceValues value) x) z) =
      if 0 < z then referenceLayerSlope left M (coordinateTail laws value z) q else 0 := by
  by_cases hz : 0 < z
  · rw [if_pos hz]
    have hd := referenceWorld_expect_derivative left laws value q hq
      (fun x => positiveRankLayer M (coordinateValues (referenceInstanceValues value) x) z)
    have hcongr : HasDerivWithinAt (referenceLayerRank M (coordinateTail laws value z))
        (∑ x, referenceWorldSlope left laws value q x *
          positiveRankLayer M (coordinateValues (referenceInstanceValues value) x) z)
        (referenceSide left q) q := by
      apply hd.congr_of_eventuallyEq
      · have hpos : ∀ᶠ t in 𝓝 q, 0 < t := isOpen_Ioi.mem_nhds hq
        filter_upwards [hpos.filter_mono nhdsWithin_le_nhds] with t ht
        simpa only [hz, if_true] using
          (referenceInstance_expected_layer laws M hground value t ht.le z).symm
      · simpa only [hz, if_true] using
          (referenceInstance_expected_layer laws M hground value q hq.le z).symm
    have href : HasDerivWithinAt (referenceLayerRank M (coordinateTail laws value z))
        (referenceLayerSlope left M (coordinateTail laws value z) q) (referenceSide left q) q := by
      cases left
      · exact referenceLayerRank_right_derivative M _ (fun e => (laws e).prob_nonneg _) q
      · exact referenceLayerRank_left_derivative M _ (fun e => (laws e).prob_nonneg _) q
    have hu : UniqueDiffWithinAt ℝ (referenceSide left q) q := by
      cases left
      · exact uniqueDiffOn_Ici q q left_mem_Ici
      · exact uniqueDiffOn_Iic q q right_mem_Iic
    exact hu.eq_deriv _ hcongr href
  · simp [positiveRankLayer, hz]

theorem referenceLayerSlope_integrable (left : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 < q) :
    Integrable (fun z => if 0 < z then referenceLayerSlope left M (coordinateTail laws value z) q else 0) := by
  have h := integrable_finset_sum univ (fun x _ =>
    (positiveRankLayer_integrable M (coordinateValues (referenceInstanceValues value) x)
      (fun e => referencePriorValue_nonneg (value e) (hv e) (x e))).const_mul
        (referenceWorldSlope left laws value q x))
  simpa only [referenceWorld_layer_slope left laws M hground value q hq] using h

theorem referenceOptimumSlope_integral (left : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 < q) :
    referenceOptimumSlope left laws M value q =
      ∫ z, if 0 < z then referenceLayerSlope left M (coordinateTail laws value z) q else 0 := by
  simp_rw [← referenceWorld_layer_slope left laws M hground value q hq]
  rw [integral_finset_sum univ (fun x _ =>
    (positiveRankLayer_integrable M (coordinateValues (referenceInstanceValues value) x)
      (fun e => referencePriorValue_nonneg (value e) (hv e) (x e))).const_mul
        (referenceWorldSlope left laws value q x))]
  simp only [integral_const_mul]
  unfold referenceOptimumSlope
  apply sum_congr rfl
  intro x hx
  rw [optimum_eq_integral_rank M (coordinateValues (referenceInstanceValues value) x)
    (fun e => referencePriorValue_nonneg (value e) (hv e) (x e))]

end MatroidProphetSecretary
