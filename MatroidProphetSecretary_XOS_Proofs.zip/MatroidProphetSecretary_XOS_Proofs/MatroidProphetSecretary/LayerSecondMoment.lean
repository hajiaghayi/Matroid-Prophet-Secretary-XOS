import MatroidProphetSecretary.Overlap
import MatroidProphetSecretary.FiniteIntegrals
import MatroidProphetSecretary.BlockResampling

/-! Layer second-moment estimates used in the overlap accumulation argument. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

theorem FiniteLaw.expect_sq_ge {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) (f : Ω → ℝ) :
    (μ.expect f)^2 ≤ μ.expect (fun x => (f x)^2) := by
  have h := μ.expect_nonneg (fun x => sq_nonneg (f x-μ.expect f))
  have heq (x : Ω) : (f x-μ.expect f)^2 = (f x)^2 - (2*μ.expect f)*f x + (μ.expect f)^2 := by ring
  simp_rw [heq] at h
  rw [FiniteLaw.expect_add,FiniteLaw.expect_sub,FiniteLaw.expect_const_mul,FiniteLaw.expect_const] at h
  nlinarith only [h]

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem basisMarginal_le_membership_probability (μ : FiniteLaw W) (value : W → E → ℝ)
    (sets : W → Finset E) (e : E) (z : ℝ) :
    basisMarginal μ value sets e z ≤ μ.prob (fun y => e ∈ sets y) := by
  apply μ.expect_mono
  intro y
  unfold basisLayer positiveLayer
  split_ifs <;> norm_num

theorem integral_basisMarginal (μ : FiniteLaw W) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (sets : W → Finset E) (e : E) :
    (∫ z, basisMarginal μ value sets e z) = μ.expect (fun y => if e ∈ sets y then value y e else 0) := by
  unfold basisMarginal
  rw [FiniteLaw.integral_expect μ _ (fun y => basisLayer_integrable (value y) (sets y) e)]
  congr 1
  funext y
  unfold basisLayer
  by_cases he : e ∈ sets y
  · simp only [he,if_true,integral_positiveLayer _ (hv y e)]
  · simp [he]

theorem live_value_mass_ge_layer_square (μ : FiniteLaw W) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (sets : W → Finset E) (e : E) :
    (∫ z, (basisMarginal μ value sets e z)^2) ≤
      μ.prob (fun y => e ∈ sets y) * μ.expect (fun y => if e ∈ sets y then value y e else 0) := by
  rw [← integral_basisMarginal μ value hv sets e,← integral_const_mul]
  apply integral_mono (basisMarginal_sq_integrable μ value sets e)
    ((basisMarginal_integrable μ value sets e).const_mul _)
  intro z
  have h := mul_le_mul_of_nonneg_right (basisMarginal_le_membership_probability μ value sets e z)
    (basisMarginal_bounds μ value sets e z).1
  simpa only [pow_two] using h

theorem expected_layer_square_persistence {H : Type*} [Fintype H]
    (history : FiniteLaw H) (μ : FiniteLaw W) (value : W → E → ℝ)
    (initial : W → Finset E) (current : H → W → Finset E) (c : ℝ) (hc : 0 ≤ c)
    (hpersist : ∀ e z, c*basisMarginal μ value initial e z ≤ history.expect (fun h => basisMarginal μ value (current h) e z))
    (e : E) (z : ℝ) :
    c^2*(basisMarginal μ value initial e z)^2 ≤
      history.expect (fun h => (basisMarginal μ value (current h) e z)^2) := by
  have hi := (basisMarginal_bounds μ value initial e z).1
  have hE := history.expect_nonneg (fun h => (basisMarginal_bounds μ value (current h) e z).1)
  have h := hpersist e z
  have hj := history.expect_sq_ge (fun h => basisMarginal μ value (current h) e z)
  nlinarith [mul_nonneg (sub_nonneg.mpr h) (add_nonneg hE (mul_nonneg hc hi))]

theorem expected_overlap_persistence {H : Type*} [Fintype H]
    (history : FiniteLaw H) (μ : FiniteLaw W) (value : W → E → ℝ)
    (initial : W → Finset E) (current : H → W → Finset E) (c : ℝ) (hc : 0 ≤ c)
    (hpersist : ∀ e z, c*basisMarginal μ value initial e z ≤ history.expect (fun h => basisMarginal μ value (current h) e z)) :
    c^2*overlap μ value initial ≤ history.expect (fun h => overlap μ value (current h)) := by
  have hint (h : H) : Integrable (fun z => ∑ e, (basisMarginal μ value (current h) e z)^2) :=
    integrable_finset_sum univ (fun e _ => basisMarginal_sq_integrable μ value (current h) e)
  unfold overlap
  rw [← FiniteLaw.integral_expect history _ hint,← integral_const_mul]
  apply integral_mono
    ((integrable_finset_sum univ (fun e _ => basisMarginal_sq_integrable μ value initial e)).const_mul _)
    (history.integrable_expect _ hint)
  intro z
  dsimp only
  rw [mul_sum,FiniteLaw.expect_finset_sum]
  exact sum_le_sum (fun e _ => expected_layer_square_persistence history μ value initial current c hc hpersist e z)

end MatroidProphetSecretary
