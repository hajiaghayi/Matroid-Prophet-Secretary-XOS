import MatroidProphetSecretary.PhysicalGridIntensity
import MatroidProphetSecretary.PrivateValueConsistency
import MatroidProphetSecretary.RecordReplay

/-! The physical private-clock run produces feasible exchange records with actual arriving values. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def run (tapes : Fin N → Fin L × GridPrivateTape N L V) : ℕ → StampedHistory (Fin N) (Fin N → Option V) :=
  stampedRun (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) cfg.decision tapes

theorem run_valid (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (tapes : Fin N → Fin L × GridPrivateTape N L V) (n : ℕ) (hn : n ≤ L*N) :
    ValidExchangeRecords M base hbase value (cfg.run tapes n) := by
  induction n with
  | zero => exact ValidExchangeRecords.nil
  | succ n ih =>
    have hvalid := ih (by omega)
    have hbound : n < L*N := by omega
    change ValidExchangeRecords M base hbase value
      (markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision) n
        (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)))
    unfold markedStep stampDecision
    split_ifs
    · cases hd : cfg.decision n (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)).2 with
      | none => simpa using hvalid
      | some y =>
        apply ValidExchangeRecords.snoc hvalid _ n y
        have hy := (phasePrivateDecision_some cfg.cut
          (gridHistoryProfile cfg.live (cfg.run tapes n) (gridLabel N cfg.labels_pos n))
          (gridClock N L cfg.clocks_pos n) (tapes (gridLabel N cfg.labels_pos n)).2 y hd).2
        unfold gridHistoryProfile at hy
        have hslot := gridSlot_clock_label N L cfg.labels_pos cfg.clocks_pos n hbound
        unfold gridSlot at hslot
        rw [hslot] at hy
        simp only [run,recordsBefore_stampedRun_self] at hy
        exact (hlive _ _ _).mp hy
    · exact hvalid

theorem run_feasible (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (tapes : Fin N → Fin L × GridPrivateTape N L V) (n : ℕ) (hn : n ≤ L*N) :
    M.Indep (recordLabels (cfg.run tapes n) : Set (Fin N)) :=
  (cfg.run_valid M base hbase value hlive tapes n hn).feasible (FiniteLaw.product cfg.reference) M base hbase value _

theorem run_own_values (tapes : Fin N → Fin L × GridPrivateTape N L V)
    (ht : (FiniteLaw.product cfg.laws).mass tapes ≠ 0) (n : ℕ)
    (record : Fin N × (ℕ × (Fin N → Option V))) (hr : record ∈ cfg.run tapes n) :
    record.2.2 record.1 = some (tapes record.1).2.1 := by
  induction n with
  | zero => simp [run,stampedRun,privateStepRun] at hr
  | succ n ih =>
    change record ∈ markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos)
      (stampDecision cfg.decision) n (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)) at hr
    unfold markedStep stampDecision at hr
    split_ifs at hr
    · cases hd : cfg.decision n (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)).2 with
      | none => simp only [hd,Option.map_none] at hr; exact ih hr
      | some y =>
        simp only [hd,Option.map_some] at hr
        change record ∈ (cfg.run tapes n) ++ [(gridLabel N cfg.labels_pos n,(n,y))] at hr
        rcases List.mem_append.mp hr with hold | hnew
        · exact ih hold
        · have he := List.mem_singleton.mp hnew
          rw [he]
          have hlabel := FiniteLaw.product_support cfg.laws tapes ht (gridLabel N cfg.labels_pos n)
          have htape : (cfg.tapes (gridLabel N cfg.labels_pos n)).mass (tapes (gridLabel N cfg.labels_pos n)).2 ≠ 0 :=
            (mul_ne_zero_iff.mp hlabel).2
          exact phasePrivateDecision_own_value (cfg.prior _) cfg.reference _ cfg.q cfg.q_pos (cfg.domination _)
            L _ _ cfg.step_le cfg.cut
            (gridHistoryProfile cfg.live (cfg.run tapes n) (gridLabel N cfg.labels_pos n))
            (gridClock N L cfg.clocks_pos n) _ htape y hd
    · exact ih hr

theorem run_reward_is_actual (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (observed : Fin N → V → ℝ)
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hvalue : ∀ y e v, y e = some v → value y e = observed e v)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (tapes : Fin N → Fin L × GridPrivateTape N L V)
    (ht : (FiniteLaw.product cfg.laws).mass tapes ≠ 0) (n : ℕ) (hn : n ≤ L*N) :
    recordReward value (cfg.run tapes n) =
      weight (fun e => observed e (tapes e).2.1) (recordLabels (cfg.run tapes n)) := by
  apply (cfg.run_valid M base hbase value hlive tapes n hn).reward_eq_weight M base hbase value _
  intro record hr
  exact hvalue _ _ _ (cfg.run_own_values tapes ht n record hr)

end MatroidProphetSecretary.PrivateGridConfig
