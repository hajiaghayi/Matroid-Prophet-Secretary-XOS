import MatroidProphetSecretary.FiniteProbability
import Mathlib.Combinatorics.SetFamily.FourFunctions

/-! Association of independent finite coordinates, including opposite monotonicities. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)] [∀ i, LinearOrder (V i)]

theorem product_mass_modular (laws : ∀ i, FiniteLaw (V i)) (x y : ∀ i, V i) :
    (product laws).mass x * (product laws).mass y =
      (product laws).mass (x ⊓ y) * (product laws).mass (x ⊔ y) := by
  unfold product
  dsimp
  rw [← prod_mul_distrib, ← prod_mul_distrib]
  apply prod_congr rfl
  intro i hi
  change (laws i).mass (x i) * (laws i).mass (y i) =
    (laws i).mass (min (x i) (y i)) * (laws i).mass (max (x i) (y i))
  rcases le_total (x i) (y i) with h | h
  · rw [min_eq_left h, max_eq_right h]
  · rw [min_eq_right h, max_eq_left h, mul_comm]

theorem product_association (laws : ∀ i, FiniteLaw (V i))
    (f g : (∀ i, V i) → ℝ) (hf0 : ∀ x, 0 ≤ f x) (hg0 : ∀ x, 0 ≤ g x)
    (hf : Monotone f) (hg : Monotone g) :
    (product laws).expect f * (product laws).expect g ≤
      (product laws).expect (fun x => f x * g x) := by
  have h := fkg f g (product laws).mass (product laws).nonneg hf0 hg0 hf hg
    (fun x y => (product_mass_modular laws x y).le)
  simpa only [(product laws).total, one_mul] using h

/-- The reversed association inequality used for forward and reverse priorities. -/
theorem product_reversed_association (laws : ∀ i, FiniteLaw (V i))
    (f g : (∀ i, V i) → ℝ) (hf0 : ∀ x, 0 ≤ f x) (hg1 : ∀ x, g x ≤ 1)
    (hf : Monotone f) (hg : Antitone g) :
    (product laws).expect (fun x => f x * g x) ≤
      (product laws).expect f * (product laws).expect g := by
  have hmono : Monotone (fun x => 1 - g x) := fun x y h => sub_le_sub_left (hg h) 1
  have h := product_association laws f (fun x => 1 - g x) hf0
    (fun x => sub_nonneg.mpr (hg1 x)) hf hmono
  rw [(product laws).expect_sub, (product laws).expect_const] at h
  have hid : (product laws).expect (fun x => f x * (1 - g x)) =
      (product laws).expect f - (product laws).expect (fun x => f x * g x) := by
    simp_rw [mul_sub, mul_one]
    exact (product laws).expect_sub _ _
  rw [hid] at h
  nlinarith

end MatroidProphetSecretary.FiniteLaw
