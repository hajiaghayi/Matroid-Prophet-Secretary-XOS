import MatroidProphetSecretary.UniformConditioning
import MatroidProphetSecretary.ClockCollisions

/-! The iid clock law, conditioned on no collisions, equals a sorted schedule with uniform arrival order. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def injectiveClockEquiv (N L : ℕ) : {x : Fin N → Fin L // Function.Injective x} ≃ (Fin N ↪ Fin L) where
  toFun x := ⟨x.val,x.property⟩
  invFun x := ⟨x,x.injective⟩
  left_inv x := by rfl
  right_inv x := by rfl

def lowerClockEmbedding (N L : ℕ) (hNL : N ≤ L) : Fin N ↪ Fin L where
  toFun i := ⟨i.val,i.isLt.trans_le hNL⟩
  inj' i j hij := Fin.ext (show i.val = j.val from congrArg (fun x : Fin L => x.val) hij)

theorem decode_clockEncoding {N L : ℕ} (clock : Fin N ↪ Fin L) :
    decodeClocks (clockEncodingEquiv N L clock) = clock :=
  (clockEncodingEquiv N L).symm_apply_apply clock

def inversePermutationEquiv (N : ℕ) : Equiv.Perm (Fin N) ≃ Equiv.Perm (Fin N) where
  toFun p := p.symm
  invFun p := p.symm
  left_inv _ := rfl
  right_inv _ := rfl

theorem uniform_permutation_inverse (N : ℕ) (f : Equiv.Perm (Fin N) → ℝ) :
    (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun p => f p.symm) =
      (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect f :=
  FiniteLaw.uniform_expect_equiv (inversePermutationEquiv N) f

theorem distinct_clocks_sorted_expect (N L : ℕ) (hNL : N ≤ L) (hL : 0 < L)
    (f : (Fin N → Fin L) → ℝ) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    letI : Nonempty (ClockSchedule N L) :=
      ⟨⟨clockImage (lowerClockEmbedding N L hNL),clockImage_card _⟩⟩
    ((FiniteLaw.product (fun _ : Fin N => FiniteLaw.uniform (Fin L))).conditionOrSelf Function.Injective).expect f =
      (FiniteLaw.uniform (ClockSchedule N L)).expect (fun schedule =>
        (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order => f (decodeClocks (schedule,order.symm)))) := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  letI (x : Fin N → Fin L) : Decidable (Function.Injective x) := Classical.propDecidable _
  letI : Nonempty (Fin N ↪ Fin L) := ⟨lowerClockEmbedding N L hNL⟩
  letI : Nonempty {x : Fin N → Fin L // Function.Injective x} :=
    ⟨⟨lowerClockEmbedding N L hNL,(lowerClockEmbedding N L hNL).injective⟩⟩
  letI : Nonempty (ClockSchedule N L) :=
    ⟨⟨clockImage (lowerClockEmbedding N L hNL),clockImage_card _⟩⟩
  rw [FiniteLaw.product_uniform_eq]
  have hc : ((FiniteLaw.uniform (Fin N → Fin L)).conditionOrSelf Function.Injective).expect f =
      (FiniteLaw.uniform {x : Fin N → Fin L // Function.Injective x}).expect (fun x => f x.val) := by
    exact FiniteLaw.uniform_condition_expect (fun x : Fin N → Fin L => Function.Injective x) f
  trans (FiniteLaw.uniform {x : Fin N → Fin L // Function.Injective x}).expect (fun x => f x.val)
  · convert hc using 1
    congr 1
    apply FiniteLaw.conditionOrSelf_irrel
  have hi := FiniteLaw.uniform_expect_equiv (injectiveClockEquiv N L) (fun clock => f clock)
  simp only [injectiveClockEquiv, Equiv.coe_fn_mk] at hi
  trans (FiniteLaw.uniform (Fin N ↪ Fin L)).expect (fun clock => f clock)
  · convert hi using 1
  have hs := uniform_distinct_clocks_factor N L (fun schedule rank => f (decodeClocks (schedule,rank)))
  simp only [Prod.mk.eta, decode_clockEncoding] at hs
  rw [hs]
  congr 1
  funext schedule
  exact (uniform_permutation_inverse N (fun rank => f (decodeClocks (schedule,rank)))).symm

end MatroidProphetSecretary
