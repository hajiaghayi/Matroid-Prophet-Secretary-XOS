import Mathlib.Data.List.Basic
import Mathlib.Tactic

/-! A deterministic first-success oracle scan, with its exact number of tests. -/

namespace MatroidProphetSecretary

variable {α : Type*}

def firstSuccess (test : α → Bool) : List α → Option α
  | [] => none
  | a :: l => if test a = true then some a else firstSuccess test l

def scanTests (test : α → Bool) : List α → ℕ
  | [] => 0
  | a :: l => if test a = true then 1 else 1 + scanTests test l

theorem scanTests_le_length (test : α → Bool) (l : List α) : scanTests test l ≤ l.length := by
  induction l with
  | nil => simp [scanTests]
  | cons a l ih =>
    simp only [scanTests, List.length_cons]
    split_ifs <;> omega

theorem firstSuccess_spec (test : α → Bool) (l : List α) (a : α)
    (h : firstSuccess test l = some a) : a ∈ l ∧ test a = true := by
  induction l with
  | nil => simp [firstSuccess] at h
  | cons b l ih =>
    by_cases hb : test b = true
    · simp only [firstSuccess, if_pos hb, Option.some.injEq] at h
      subst a
      exact ⟨List.mem_cons_self, hb⟩
    · simp only [firstSuccess, if_neg hb] at h
      obtain ⟨ha, hta⟩ := ih h
      exact ⟨List.mem_cons_of_mem _ ha, hta⟩

theorem firstSuccess_exists (test : α → Bool) (l : List α)
    (h : ∃ a ∈ l, test a = true) : ∃ a, firstSuccess test l = some a := by
  induction l with
  | nil => simpa using h
  | cons b l ih =>
    by_cases hb : test b = true
    · exact ⟨b, by simp [firstSuccess, hb]⟩
    · obtain ⟨a, ha, hta⟩ := h
      have hal : a ∈ l := (List.mem_cons.mp ha).resolve_left (fun hab => hb (hab ▸ hta))
      obtain ⟨c, hc⟩ := ih ⟨a, hal, hta⟩
      exact ⟨c, by simpa [firstSuccess, hb] using hc⟩

theorem firstSuccess_first (test : α → Bool) (l : List α) (a : α)
    (h : firstSuccess test l = some a) :
    ∃ pre post, l = pre ++ a :: post ∧ (∀ b ∈ pre, test b = false) ∧ scanTests test l = pre.length + 1 := by
  induction l with
  | nil => simp [firstSuccess] at h
  | cons b l ih =>
    by_cases hb : test b = true
    · simp only [firstSuccess, if_pos hb, Option.some.injEq] at h
      subst a
      exact ⟨[], l, rfl, by simp, by simp [scanTests, hb]⟩
    · simp only [firstSuccess, if_neg hb] at h
      obtain ⟨pre, post, hl, hp, hc⟩ := ih h
      refine ⟨b :: pre, post, by simp [hl], ?_, ?_⟩
      · intro c hcmem
        rcases List.mem_cons.mp hcmem with rfl | hcp
        · cases ht : test c <;> simp_all
        · exact hp c hcp
      · simp only [scanTests, if_neg hb, hc, List.length_cons]
        omega

end MatroidProphetSecretary
