import MatroidProphetSecretary.ReferenceLayerConcavity

/-! Scaling bounds for saturated reference rank layers. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem bernoulliEval_zero (f : (E → Bool) → ℝ) :
    bernoulliEval (fun _ => 0) f = f (fun _ => false) := by
  unfold bernoulliEval
  rw [sum_eq_single (fun _ => false)]
  · simp
  · intro x hx hne
    have hex : ∃ e, x e = true := by
      by_contra hn
      apply hne
      funext e
      cases he : x e
      · rfl
      · exact (hn ⟨e, he⟩).elim
    obtain ⟨e, he⟩ := hex
    have hp : (∏ i, if x i = true then (0 : ℝ) else 1 - 0) = 0 :=
      prod_eq_zero (mem_univ e) (by simp [he])
    rw [hp, zero_mul]
  · simp

theorem referenceLayerRank_zero (M : Matroid E) (p : E → ℝ) : referenceLayerRank M p 0 = 0 := by
  simp only [referenceLayerRank, scaledTail, zero_mul, min_eq_right zero_le_one, bernoulliEval_zero]
  have heq : bitSet (fun _ : E => false) = ∅ := by ext e; simp [bitSet]
  simp [rankObservable, heq, realRank]

theorem concave_zero_scaling (f : ℝ → ℝ) (hconc : ConcaveOn ℝ (Set.Ici 0) f)
    (hmono : MonotoneOn f (Set.Ici 0)) (hzero : f 0 = 0) (q : ℝ) (hq : 0 ≤ q) :
    min 1 q * f 1 ≤ f q ∧ f q ≤ max 1 q * f 1 := by
  by_cases hq1 : q ≤ 1
  · rw [min_eq_right hq1, max_eq_left hq1, one_mul]
    have h := hconc.2 (show (1 : ℝ) ∈ Set.Ici 0 from Set.mem_Ici.mpr zero_le_one)
      (show (0 : ℝ) ∈ Set.Ici 0 from Set.mem_Ici.mpr le_rfl) hq (sub_nonneg.mpr hq1)
      (show q + (1 - q) = 1 by ring)
    simp only [smul_eq_mul, hzero, mul_zero, add_zero, mul_one] at h
    exact ⟨h, hmono hq (Set.mem_Ici.mpr zero_le_one) hq1⟩
  · have hq1' : 1 ≤ q := (lt_of_not_ge hq1).le
    have hqpos : 0 < q := lt_of_lt_of_le zero_lt_one hq1'
    rw [min_eq_left hq1', max_eq_right hq1', one_mul]
    have hi : 1 / q ≤ (1 : ℝ) := (div_le_iff₀ hqpos).mpr (by simpa using hq1')
    have h := hconc.2 hq (show (0 : ℝ) ∈ Set.Ici 0 from Set.mem_Ici.mpr le_rfl)
      (show 0 ≤ 1 / q from div_nonneg zero_le_one hq) (sub_nonneg.mpr hi)
      (show 1 / q + (1 - 1 / q) = 1 by ring)
    simp only [smul_eq_mul, hzero, mul_zero, add_zero, one_div_mul_cancel hqpos.ne'] at h
    constructor
    · exact hmono (Set.mem_Ici.mpr zero_le_one) hq hq1'
    · have hm := mul_le_mul_of_nonneg_left h hq
      field_simp at hm
      nlinarith

theorem referenceLayerRank_scaling (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (q : ℝ) (hq : 0 ≤ q) :
    min 1 q * referenceLayerRank M p 1 ≤ referenceLayerRank M p q ∧
      referenceLayerRank M p q ≤ max 1 q * referenceLayerRank M p 1 :=
  concave_zero_scaling _ (referenceLayerRank_concave M hground p hp)
    (referenceLayerRank_monotone M hground p hp) (referenceLayerRank_zero M p) q hq

end MatroidProphetSecretary
