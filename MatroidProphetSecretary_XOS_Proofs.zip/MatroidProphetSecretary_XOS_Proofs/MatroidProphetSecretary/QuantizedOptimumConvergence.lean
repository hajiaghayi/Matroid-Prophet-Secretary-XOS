import MatroidProphetSecretary.RationalValueQuantization
import MatroidProphetSecretary.OptimumContinuity
import Mathlib.MeasureTheory.Integral.DominatedConvergence

/-! Truncation and rational downward rounding preserve the expected optimum in the limit. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory Filter
open scoped Topology

theorem quantized_optimum_tendsto {N : ℕ} (M : Matroid (Fin N)) (x : Fin N → ℝ)
    (hx : ∀ e, 0 ≤ x e) :
    Tendsto (fun n => optimum M (fun e => rationalRound n (x e))) atTop (𝓝 (optimum M x)) := by
  apply (continuous_optimum M).continuousAt.tendsto.comp
  exact tendsto_pi_nhds.mpr (fun e => rationalRound_tendsto (x e) (hx e))

theorem measurable_quantized_optimum {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ) (hX : ∀ e, Measurable (X e)) (n : ℕ) :
    Measurable (fun ω => optimum M (fun e => rationalRound n (X e ω))) :=
  (measurable_optimum M).comp (measurable_pi_lambda _ (fun e => (measurable_rationalRound n).comp (hX e)))

theorem expected_quantized_optimum_tendsto {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hx : ∀ ω e, 0 ≤ X e ω)
    (hint : Integrable (fun ω => optimum M (fun e => X e ω)) μ) :
    Tendsto (fun n => ∫ ω, optimum M (fun e => rationalRound n (X e ω)) ∂μ) atTop
      (𝓝 (∫ ω, optimum M (fun e => X e ω) ∂μ)) := by
  apply tendsto_integral_of_dominated_convergence (fun ω => optimum M (fun e => X e ω))
    (fun n => (measurable_quantized_optimum M X hX n).aestronglyMeasurable) hint
  · intro n
    exact Filter.Eventually.of_forall (fun ω => by
      rw [Real.norm_eq_abs,abs_of_nonneg (optimum_nonneg M _)]
      exact optimum_mono M (fun e => (rationalRound_bounds n (X e ω) (hx ω e)).2))
  · exact Filter.Eventually.of_forall (fun ω => quantized_optimum_tendsto M (fun e => X e ω) (hx ω))

theorem exists_expected_quantized_optimum_close {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hx : ∀ ω e, 0 ≤ X e ω)
    (hint : Integrable (fun ω => optimum M (fun e => X e ω)) μ)
    (err : ℝ) (herr : 0 < err) :
    ∃ n, (∫ ω, optimum M (fun e => X e ω) ∂μ)-err <
      ∫ ω, optimum M (fun e => rationalRound n (X e ω)) ∂μ := by
  have h := (expected_quantized_optimum_tendsto μ M X hX hx hint).eventually
    (lt_mem_nhds (sub_lt_self _ herr))
  exact h.exists

end MatroidProphetSecretary
