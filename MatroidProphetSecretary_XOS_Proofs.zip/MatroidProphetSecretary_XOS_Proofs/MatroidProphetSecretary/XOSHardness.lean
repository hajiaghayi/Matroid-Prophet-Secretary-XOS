import MatroidProphetSecretary.XOSOnlineBound

/-! The information-theoretic XOS hardness theorem. Randomized policies are
arbitrary real probability distributions on the finite space of legal online rules.
There is no limit on computation, oracle queries, or independent prior simulations. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open scoped Classical

def randomizedReward {n L : ℕ} [NeZero L] (μ : FiniteLaw (OnlineRule n L)) : ℝ :=
  μ.expect (fun rule => expectedReward rule.val)

theorem randomizedReward_upper {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L)
    (μ : FiniteLaw (OnlineRule n L)) :
    randomizedReward μ ≤ (Fintype.card (Goods n L) : ℝ) *
      (coverageRatio n + (n : ℝ)^3 / L) := by
  have h := μ.expect_mono (fun rule => expectedReward_upper hnL rule.val rule.property)
  simpa [randomizedReward] using h

theorem expectedProphet_pos {n L : ℕ} [NeZero n] [NeZero L]
    (hd : 0 < 1 - (n : ℝ)^2 / L) : 0 < expectedProphet n L := by
  have hm : (0 : ℝ) < Fintype.card (Goods n L) := by exact_mod_cast Fintype.card_pos
  exact (mul_pos hm hd).trans_le expectedProphet_lower

theorem randomized_ratio_bound {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L)
    (hd : 0 < 1 - (n : ℝ)^2 / L) (μ : FiniteLaw (OnlineRule n L)) :
    randomizedReward μ / expectedProphet n L ≤ finiteRatio n L := by
  have hnum : 0 ≤ coverageRatio n + (n : ℝ)^3 / L :=
    add_nonneg (coverageRatio_nonneg n) (by positivity)
  have hr : 0 ≤ finiteRatio n L := div_nonneg hnum hd.le
  have h1 := randomizedReward_upper hnL μ
  have h2 := mul_le_mul_of_nonneg_left (expectedProphet_lower (n := n) (L := L)) hr
  have heq : finiteRatio n L * ((Fintype.card (Goods n L) : ℝ) * (1 - (n : ℝ)^2 / L)) =
      (Fintype.card (Goods n L) : ℝ) * (coverageRatio n + (n : ℝ)^3 / L) := by
    dsimp [finiteRatio]
    rw [mul_comm _ ((Fintype.card (Goods n L) : ℝ) * _), mul_assoc,
      mul_div_cancel₀ _ hd.ne']
  rw [heq] at h2
  exact (div_le_iff₀ (expectedProphet_pos hd)).mpr (h1.trans h2)

/-- Section 10 / Theorem 2: a single finite identical-prior XOS instance has
expected online/prophet ratio strictly below `1 - 1/e + ξ` for every online rule. -/
theorem xos_hardness (ξ : ℝ) (hξ : 0 < ξ) :
    ∃ n L : ℕ, ∃ hn : NeZero n, ∃ hL : NeZero L,
      letI : NeZero n := hn
      letI : NeZero L := hL
      2 ≤ n ∧ n ≤ L ∧
      (∀ a : Fin L,
        (∀ c ∈ allowed (n := n) a, ∀ x, coefficient c x = 0 ∨ coefficient c x = 1) ∧
        (∀ S : Finset (Goods n L),
          (∀ c ∈ allowed a, ∑ x ∈ S, coefficient c x ≤ (value a S : ℝ)) ∧
          ∃ c ∈ allowed a, (value a S : ℝ) = ∑ x ∈ S, coefficient c x)) ∧
      0 < expectedProphet n L ∧
      ∀ μ : FiniteLaw (OnlineRule n L),
        randomizedReward μ / expectedProphet n L < 1 - 1 / Real.exp 1 + ξ := by
  obtain ⟨n,L,hn2,hnL,hd,hr⟩ := exists_hard_parameters ξ hξ
  haveI hn : NeZero n := ⟨by omega⟩
  haveI hL : NeZero L := ⟨by omega⟩
  refine ⟨n,L,hn,hL,hn2,hnL,?_,expectedProphet_pos hd,?_⟩
  · intro a
    exact ⟨fun c _ x => coefficient_binary c x,(value_is_XOS hnL a).2⟩
  · intro μ
    exact (randomized_ratio_bound hnL hd μ).trans_lt hr

end MatroidProphetSecretary.XOS
