import MatroidProphetSecretary.PhysicalHistoryKernel

/-! Mark probabilities of the physical Markov kernel have the explicit exchange-rate formula. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def historyRate (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) : ℝ :=
  if (gridClock N L cfg.clocks_pos n).val < cfg.cut then 1/cfg.q
  else (1/cfg.q)/cfg.survival (historyPath history) n

theorem privateMark_some_iff (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (data : Fin L × GridPrivateTape N L V) (B : GridMark N L V → Prop) :
    (∃ mark, cfg.privateMark n history data = some mark ∧ B mark) ↔
      data.1 = gridClock N L cfg.clocks_pos n ∧ ∃ y, cfg.decision n history data.2 = some y ∧
        B (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y)) := by
  by_cases hc : data.1 = gridClock N L cfg.clocks_pos n
  · cases hd : cfg.decision n history data.2 <;> simp [privateMark,hc,hd]
  · simp [privateMark,hc]

theorem historyKernel_mark_as_path_probability (history : StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (B : GridMark N L V → Prop) :
    (cfg.historyKernel n history).prob (fun outcome => ∃ mark, outcome = some mark ∧ B mark) =
    ((FiniteLaw.product cfg.laws).conditionOrSelf (cfg.pathEvent (historyPath history) n)).prob
      (fun tapes => (tapes (gridLabel N cfg.labels_pos n)).1 = gridClock N L cfg.clocks_pos n ∧
        ∃ y, cfg.decision n (historyPath history n) (tapes (gridLabel N cfg.labels_pos n)).2 = some y ∧
          B (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y))) := by
  have hcond := FiniteLaw.conditionOrSelf_congr (FiniteLaw.product cfg.laws)
    (fun tapes => cfg.run tapes n = history) (cfg.pathEvent (historyPath history) n)
    (fun tapes => (cfg.current_path_iff history n hp tapes).symm)
  have hpath : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent (historyPath history) n) := by
    rwa [FiniteLaw.prob_congr _ (cfg.current_path_iff history n hp)]
  unfold historyKernel
  rw [dif_pos hp,FiniteLaw.map_prob,hcond]
  apply FiniteLaw.prob_congr_support
  intro tapes ht
  have hh := FiniteLaw.conditionOrSelf_support (FiniteLaw.product cfg.laws)
    (cfg.pathEvent (historyPath history) n) hpath tapes ht
  have he : cfg.trace tapes n = cfg.privateMark n (historyPath history n) (tapes (gridLabel N cfg.labels_pos n)) := by
    simp only [trace,privateMark,show cfg.run tapes n = historyPath history n from hh n le_rfl]
  rw [he]
  exact cfg.privateMark_some_iff _ n _ B

theorem historyKernel_mark_probability (history : StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (habsent : gridLabel N cfg.labels_pos n ∉ recordLabels history) (B : GridMark N L V → Prop) :
    (cfg.historyKernel n history).prob (fun outcome => ∃ mark, outcome = some mark ∧ B mark) =
      (1/(L:ℝ))*cfg.historyRate history n*(FiniteLaw.product cfg.reference).prob
        (fun y => cfg.live history (gridLabel N cfg.labels_pos n) y ∧
          B (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y))) := by
  have hfix : historyPath history n = history := cfg.current_history_fixed history n hp
  have hpath : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent (historyPath history) n) := by
    rwa [FiniteLaw.prob_congr _ (cfg.current_path_iff history n hp)]
  have hab : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ historyPath history n := by
    intro mark hm
    apply habsent
    rw [hfix] at hm
    exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨_,hm,rfl⟩)
  rw [cfg.historyKernel_mark_as_path_probability history n hp B]
  by_cases he : (gridClock N L cfg.clocks_pos n).val < cfg.cut
  · rw [cfg.accepted_path_early_intensity (historyPath history) n hn hpath hab he
      (fun y => B (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y)))]
    simp only [historyRate,he,if_true,hfix]
  · rw [cfg.accepted_path_late_intensity (historyPath history) n hn hpath hab (le_of_not_gt he)
      (fun y => B (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y)))]
    simp only [historyRate,he,if_false,hfix]

theorem historyRate_bounds (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q))) :
    0 ≤ cfg.historyRate history n ∧ cfg.historyRate history n ≤ (1/cfg.q)/omega := by
  unfold historyRate
  split_ifs with he
  · constructor
    · exact one_div_nonneg.mpr cfg.q_pos.le
    · exact (le_div_iff₀ homega).mpr (mul_le_of_le_one_right (one_div_nonneg.mpr cfg.q_pos.le) homega1)
  · have hlate := cfg.late_rate_bounds (historyPath history) n (le_of_not_gt he) hsmall omega homega hlower
    have hsurv : 0 < cfg.survival (historyPath history) n :=
      homega.trans_le (hlower.trans (cfg.late_survival_lower (historyPath history) n (le_of_not_gt he)))
    exact ⟨div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) hsurv.le,hlate.2⟩

end MatroidProphetSecretary.PrivateGridConfig
