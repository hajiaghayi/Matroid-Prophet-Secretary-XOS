import MatroidProphetSecretary.ReferenceShape
import MatroidProphetSecretary.ResidualReferencePotential
import MatroidProphetSecretary.ZeroBenchmarkPolicy

/-! Reference scaling and deletion of loops do not require a full ambient ground set. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical Matroid

theorem optimum_eq_of_indep_iff {E : Type*} [Fintype E] [DecidableEq E] (M L : Matroid E)
    (h : ∀ I : Finset E, M.Indep (I : Set E) ↔ L.Indep (I : Set E)) (v : E → ℝ) :
    optimum M v = optimum L v := by
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    exact weight_le_optimumOver _ _ _ ((h I).mp hI)
  · apply optimumOver_le
    intro I hI
    exact weight_le_optimumOver _ _ _ ((h I).mpr hI)

theorem optimum_full_ground {E : Type*} [Fintype E] [DecidableEq E] (M : Matroid E) (v : E → ℝ) :
    optimum (M ↾ Set.univ) v = optimum M v := by
  apply optimum_eq_of_indep_iff
  intro I
  simp only [Matroid.restrict_indep_iff,Set.subset_univ,and_true]

theorem referenceExpectedOptimum_full_ground {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)] (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (q : ℝ) :
    referenceExpectedOptimum laws (M ↾ Set.univ) value q = referenceExpectedOptimum laws M value q := by
  unfold referenceExpectedOptimum expectedOptimum
  simp only [optimum_full_ground]

theorem referenceExpectedOptimum_scaling_general {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)] (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) (q : ℝ) (hq : 0 ≤ q) :
    min 1 q * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) ≤ referenceExpectedOptimum laws M value q ∧
      referenceExpectedOptimum laws M value q ≤ max 1 q * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  have h := referenceExpectedOptimum_scaling laws (M ↾ Set.univ) (fun _ => Set.mem_univ _) value hv q hq
  simp only [referenceExpectedOptimum_full_ground,expectedOptimum,optimum_full_ground] at h
  exact h

theorem referenceExpectedOptimum_one_general {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)] (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) :
    referenceExpectedOptimum laws M value 1 = expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  have h := referenceExpectedOptimum_one laws (M ↾ Set.univ) (fun _ => Set.mem_univ _) value hv
  simpa only [referenceExpectedOptimum_full_ground,expectedOptimum,optimum_full_ground] using h

theorem deletionValue_eq_optimum_of_not_indep_singleton {E : Type*} [Fintype E] [DecidableEq E]
    (M : Matroid E) (e : E) (he : ¬ M.Indep ({e} : Set E)) (v : E → ℝ) :
    deletionValue M v e = optimum M v := by
  apply le_antisymm (deletion_le_optimum M v e)
  apply optimumOver_le
  intro I hI
  apply weight_le_optimumOver
  refine ⟨?_,hI⟩
  intro hi
  exact he (hI.subset (Set.singleton_subset_iff.mpr hi))

theorem reference_remaining_delete_loop {n k : ℕ} (prior : RationalPriors (n+1) k)
    (M : Matroid (Fin (n+1))) (e : Fin (n+1)) (he : ¬ M.Indep ({e} : Set (Fin (n+1)))) (q : ℝ) :
    referenceExpectedOptimum (prior.remaining e).law (remainingDelete M e)
      (fun i v => ((prior.remaining e).value i v : ℝ)) q =
        referenceExpectedOptimum prior.law M (fun i v => (prior.value i v : ℝ)) q := by
  rw [reference_remaining_delete]
  simp only [deletionValue_eq_optimum_of_not_indep_singleton M e he]
  rfl

theorem zero_benchmark_reference_policy {N k : ℕ} (prior : RationalPriors N k) (M : Matroid (Fin N))
    (hzero : expectedProphet M prior = 0) (q : ℝ) (hq : 0 ≤ q) :
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ expectedPolicyReward prior policy := by
  have hs := referenceExpectedOptimum_scaling_general prior.law M (fun e v => (prior.value e v : ℝ))
    (fun e v => by change (0:ℝ) ≤ (prior.value e v:ℝ); exact_mod_cast prior.value_nonneg e v) q hq
  change min 1 q*expectedProphet M prior ≤ _ ∧ _ ≤ max 1 q*expectedProphet M prior at hs
  rw [hzero,mul_zero,mul_zero] at hs
  have hz := le_antisymm hs.2 hs.1
  exact ⟨rejectAllPolicy N,rejectAll_feasible M,by rw [hz,mul_zero,rejectAll_expected_reward]⟩

end MatroidProphetSecretary
