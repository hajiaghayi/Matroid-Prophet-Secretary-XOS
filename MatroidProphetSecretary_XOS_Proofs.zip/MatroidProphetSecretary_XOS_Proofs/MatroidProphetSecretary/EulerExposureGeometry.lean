import MatroidProphetSecretary.EulerReachability
import MatroidProphetSecretary.BinExposureFreezing
import MatroidProphetSecretary.LiftedVirtualProcess

/-! The reconstructed bin exposure is exactly the accumulated exposure of the exchange trajectory. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem recordsBefore_self_mono {E W : Type*} (history : StampedHistory E W) (i j : ℕ) (hij : i ≤ j)
    (hi : recordsBefore i history = history) : recordsBefore j history = history := by
  apply List.filter_eq_self.mpr
  intro record hr
  have ht : record.2.1 < i := by simpa using List.filter_eq_self.mp hi record hr
  simpa using ht.trans_le hij

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem eulerBlock_history_bounded (clock : Fin L) (history : StampedHistory (Fin N) (Fin N → Option V))
    (hh : recordsBefore (clock.val*N) history = history) (event : Option (Fin N × (Fin N → Option V))) :
    recordsBefore ((clock.val+1)*N) (cfg.eulerBlockUpdate (clock.val*N,history) event).2 =
      (cfg.eulerBlockUpdate (clock.val*N,history) event).2 := by
  have hhist := recordsBefore_self_mono history (clock.val*N) ((clock.val+1)*N)
    (Nat.mul_le_mul_right N (Nat.le_succ _)) hh
  simp only [eulerBlockUpdate,cfg.gridClock_round clock,eulerHistoryUpdate]
  cases event with
  | none => exact hhist
  | some event =>
    have ht : gridSlot clock event.1 < (clock.val+1)*N := by
      unfold gridSlot
      rw [Nat.add_mul,Nat.one_mul]
      omega
    change recordsBefore ((clock.val+1)*N) (history++[(event.1,(gridSlot clock event.1,event.2))]) = _
    simpa only [recordsBefore,List.filter_append,List.filter_cons,ht,decide_true,Bool.true_eq,if_true,List.filter_nil] using
      congrArg (fun records => records++[(event.1,(gridSlot clock event.1,event.2))]) hhist

theorem binEarlyExposure_step (μ : FiniteLaw (Fin N → Option V)) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ) (p : ℝ) (clock : Fin L)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (hh : recordsBefore (clock.val*N) history = history)
    (event : Option (Fin N × (Fin N → Option V))) (e : Fin N) :
    binEarlyExposure μ M base hbase value p (clock.val+1) (cfg.eulerBlockUpdate (clock.val*N,history) event).2 e =
      binEarlyExposure μ M base hbase value p clock.val history e+
        p*virtualLiveMass μ M base hbase value (recordReplay M base hbase value history) e := by
  unfold binEarlyExposure
  rw [sum_range_succ,mul_add]
  apply congrArg₂ (· + ·)
  · apply congrArg (fun t : ℝ => p*t)
    apply sum_congr rfl
    intro i hi
    rw [cfg.eulerBlock_recordsBefore clock history event (i*N) (Nat.mul_le_mul_right N (mem_range.mp hi).le)]
  · rw [cfg.eulerBlock_recordsBefore clock history event (clock.val*N) le_rfl,hh]

theorem euler_trajectory_exposure (μ : FiniteLaw (Fin N → Option V)) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ) (p : ℝ) (n offset : ℕ) (hhorizon : offset+n ≤ L)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (hh : recordsBefore (offset*N) history = history)
    (x : Fin n → Option (Fin N × (Fin N → Option V))) (e : Fin N) :
    binEarlyExposure μ M base hbase value p (offset+n)
      (FiniteLaw.stateAfter cfg.eulerBlockUpdate n (offset*N,history) x).2 e =
      binEarlyExposure μ M base hbase value p offset history e+
        p*FiniteLaw.trajectoryReward cfg.eulerBlockUpdate
          (fun s _ => virtualLiveMass μ M base hbase value (recordReplay M base hbase value s.2) e)
          n (offset*N,history) x := by
  induction n generalizing offset history with
  | zero => simp [FiniteLaw.stateAfter,FiniteLaw.trajectoryReward]
  | succ n ih =>
    have ho : offset < L := by omega
    let next := cfg.eulerBlockUpdate (offset*N,history) (x 0)
    have hnext : next = ((offset+1)*N,next.2) := by
      apply Prod.ext
      · change offset*N+N = (offset+1)*N
        ring
      · rfl
    have hbounded : recordsBefore ((offset+1)*N) next.2 = next.2 :=
      cfg.eulerBlock_history_bounded ⟨offset,ho⟩ history hh (x 0)
    have ht := ih (offset+1) (by omega) next.2 hbounded (fun i => x i.succ)
    have he : offset+1+n = offset+(n+1) := by omega
    rw [he] at ht
    have hstep := cfg.binEarlyExposure_step μ M base hbase value p ⟨offset,ho⟩ history hh (x 0) e
    change binEarlyExposure μ M base hbase value p (offset+1) next.2 e = _ at hstep
    simp only [FiniteLaw.stateAfter,FiniteLaw.trajectoryReward]
    change binEarlyExposure μ M base hbase value p (offset+(n+1))
      (FiniteLaw.stateAfter cfg.eulerBlockUpdate n next (fun i => x i.succ)).2 e =
      binEarlyExposure μ M base hbase value p offset history e+
        p*(virtualLiveMass μ M base hbase value (recordReplay M base hbase value history) e+
          FiniteLaw.trajectoryReward cfg.eulerBlockUpdate
            (fun s _ => virtualLiveMass μ M base hbase value (recordReplay M base hbase value s.2) e)
            n next (fun i => x i.succ))
    rw [hnext,ht,← hnext,hstep]
    ring

theorem initial_euler_exposure (μ : FiniteLaw (Fin N → Option V)) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ) (dt lam : ℝ) (n : ℕ) (hn : n ≤ L)
    (x : Fin n → Option (Fin N × (Fin N → Option V))) (e : Fin N) :
    binEarlyExposure μ M base hbase value (dt*lam) n
      (FiniteLaw.stateAfter cfg.eulerBlockUpdate n (0,[]) x).2 e =
      virtualEarlyExposure μ M base hbase value dt lam n (initialVirtualState M) x e := by
  have h := cfg.euler_trajectory_exposure μ M base hbase value (dt*lam) n 0 (by simpa using hn) [] rfl x e
  simp only [Nat.zero_add,Nat.zero_mul,binEarlyExposure,sum_range_zero,mul_zero,zero_add] at h
  rw [FiniteLaw.trajectoryReward_projection (fun s : BlockState N V => recordReplay M base hbase value s.2)
    cfg.eulerBlockUpdate (virtualUpdate M base hbase value) (cfg.eulerBlockUpdate_replay M base hbase value)
    (fun s _ => virtualLiveMass μ M base hbase value s e) n (0,[]) x] at h
  exact h

end PrivateGridConfig
end MatroidProphetSecretary
