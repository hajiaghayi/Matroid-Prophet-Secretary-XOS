import MatroidProphetSecretary.FiniteReferenceSampling

/-! The proved sampling bound supplies an accurate reference-search execution. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E] [Nonempty E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem exists_accurate_reference_search (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (G : ValueHeightGrid (referenceInstanceValues value))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (q : ℝ) (hq : q ∈ interval) :
    ∃ (m : ℕ) (initial : Fin m → (Fin G.last × (E → Bool)))
      (batches : ℕ → (Fin m → (Fin G.last × (E → Bool)))),
      referenceSearchAccurate (fun q x => referencePositiveTest laws value G M theta epsilon q x)
        (fun q x => referenceNegativeTest laws value G M theta epsilon q x) batches ⟨q,initial⟩
        (referenceRecordGood laws value G M hnonloop N epsilon) delta (referenceSearchSteps N delta epsilon) := by
  let n := referenceSearchSteps N delta epsilon
  let m := commonBatchSize N (n+1) epsilon (1/2)
  let positive : ℝ → (Fin m → (Fin G.last × (E → Bool))) → Bool :=
    fun q x => referencePositiveTest laws value G M theta epsilon q x
  let negative : ℝ → (Fin m → (Fin G.last × (E → Bool))) → Bool :=
    fun q x => referenceNegativeTest laws value G M theta epsilon q x
  let batch := referenceQuerySampler laws value G (reference_volume_positive laws M value hv hnonloop G hF) m
  let μ := referenceSearchTapeLaw positive negative batch delta q n
  let good := fun tape : Fin (n+1) → (Fin m → (Fin G.last × (E → Bool))) =>
    referenceSearchAccurate positive negative (fun i => finiteTapeStream tape (i+1)) ⟨q,tape 0⟩
      (referenceRecordGood laws value G M hnonloop N epsilon) delta n
  have h := finite_reference_search_failure laws M value hv hnonloop G hF N hN0 hN
    (1/2) (by norm_num) (by norm_num) q hq
  change μ.prob (fun tape => ¬ good tape) ≤ (1/2)/(N:ℝ) at h
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN0
  have hsmall : (1/2)/(N:ℝ) < 1 := (div_lt_one (by linarith)).mpr (by linarith)
  have hprob : 0 < μ.prob good := by
    have hnprob := FiniteLaw.prob_not μ good
    have hh : μ.prob (fun tape => ¬ good tape) = 1-μ.prob good := by
      convert hnprob using 1
    linarith
  obtain ⟨tape,ht⟩ := FiniteLaw.exists_of_prob_pos μ good hprob
  exact ⟨m,tape 0,(fun i => finiteTapeStream tape (i+1)),ht⟩

end MatroidProphetSecretary
