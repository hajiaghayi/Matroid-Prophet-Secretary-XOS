import Mathlib.Data.Complex.ExponentialBounds
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.Ring

/-! Exact rational constants from (9.1). Bounds below are proved over `ℝ`. -/

noncomputable section

namespace MatroidProphetSecretary

def delta : ℝ := 1 / 2048
def theta : ℝ := 3678793 / 10000000
def epsilon : ℝ := 1 / 10000
def eta : ℝ := 1 / 32
def rho : ℝ := 1 / 1000000000000
def epsilonZero : ℝ := 1 / 10000000
def discount (q : ℝ) : ℝ := 1 - theta * q
def interval : Set ℝ := Set.Icc (1 - 4 * delta) (1 + 4 * delta)
def stationaryRatio (q : ℝ) : ℝ := (1 - discount q) / discount q
def hMinus : ℝ := eta - 10 * epsilon
def hPlus : ℝ := eta + 10 * epsilon
def thresholdFactor (q : ℝ) : ℝ := discount q * (1 + epsilon) / (1 - epsilon)
def overlapCutoff (q : ℝ) : ℝ :=
  hMinus ^ 2 / (1 - stationaryRatio q + 20 * epsilon + hMinus)
def surplusLower (q : ℝ) : ℝ :=
  1 - thresholdFactor q + thresholdFactor q / (thresholdFactor q + 3) *
    (stationaryRatio q - 20 * epsilon - (1 - thresholdFactor q) - hPlus -
      thresholdFactor q * Real.exp (-3))
def alpha (q : ℝ) : ℝ := Real.exp (-(1 / q) * (1 - delta))
def omega (q : ℝ) : ℝ := alpha q - delta / q
def phi (q z : ℝ) : ℝ :=
  1 - alpha q + alpha q * omega q * (1 - Real.exp (-(delta / q) / omega q)) *
    (1 + (1 - alpha q) * z)
def beta : ℝ := 1 - theta - 2 * rho
def targetRatio : ℝ := 1 - 1 / Real.exp 1 + epsilonZero

theorem interval_bounds {q : ℝ} (hq : q ∈ interval) :
    511 / 512 ≤ q ∧ q ≤ 513 / 512 := by
  norm_num [interval, delta, Set.mem_Icc] at hq ⊢
  exact hq

theorem basic_constants :
    0 < epsilon ∧ epsilon < delta ∧ delta ≤ 1 / 8 ∧ epsilon ≤ 1 / 10 ∧
    0 < theta ∧ theta < 1 ∧ 0 < rho ∧ rho < 1 ∧ eta > 10 * epsilon ∧
    rho = epsilon ^ 3 := by
  norm_num [epsilon, delta, theta, rho, eta]

theorem discount_bounds {q : ℝ} (hq : q ∈ interval) :
    63 / 100 < discount q ∧ discount q < 633 / 1000 := by
  obtain ⟨hl, hu⟩ := interval_bounds hq
  dsimp [discount, theta]
  constructor <;> linarith

theorem discount_basic {q : ℝ} (hq : q ∈ interval) :
    1 / 2 ≤ discount q ∧ discount q ≤ 3 / 4 := by
  obtain ⟨hl, hu⟩ := discount_bounds hq
  constructor <;> linarith

theorem discount_pos {q : ℝ} (hq : q ∈ interval) : 0 < discount q :=
  lt_trans (by norm_num) (discount_bounds hq).1

theorem q_pos {q : ℝ} (hq : q ∈ interval) : 0 < q :=
  lt_of_lt_of_le (by norm_num) (interval_bounds hq).1

theorem discount_times_q {q : ℝ} (hq : q ∈ interval) :
    discount q * q < 16 / 25 := by
  have h := mul_lt_mul (discount_bounds hq).2 (interval_bounds hq).2
    (q_pos hq) (by norm_num : (0 : ℝ) ≤ 633 / 1000)
  norm_num at h
  linarith

theorem potential_bound_factor {q : ℝ} (hq : q ∈ interval) :
    discount q * (1 + 4 * delta) < 1 := by
  have h := mul_lt_mul_of_pos_right (discount_bounds hq).2
    (by norm_num [delta] : 0 < 1 + 4 * delta)
  norm_num [delta] at h ⊢
  linarith

theorem stationary_bounds {q : ℝ} (hq : q ∈ interval) :
    367 / 633 < stationaryRatio q ∧ stationaryRatio q < 37 / 63 := by
  have ha := discount_pos hq
  obtain ⟨hl, hu⟩ := discount_bounds hq
  dsimp [stationaryRatio]
  constructor
  · apply (lt_div_iff₀ ha).mpr
    linarith
  · apply (div_lt_iff₀ ha).mpr
    linarith

theorem stationary_residual {q : ℝ} (hq : q ∈ interval) :
    213 / 1000 < stationaryRatio q - (1 - discount q) := by
  have ha := discount_pos hq
  have hqlo := (interval_bounds hq).1
  have hb : discount q < 15821 / 25000 := by
    dsimp [discount, theta]
    linarith
  dsimp [stationaryRatio]
  rw [lt_sub_iff_add_lt, lt_div_iff₀ ha]
  nlinarith [sq_nonneg (discount q - 15821 / 25000)]

theorem stability_values : hMinus = 121 / 4000 ∧ hPlus = 129 / 4000 := by
  norm_num [hMinus, hPlus, eta, epsilon]

theorem threshold_factor_bounds {q : ℝ} (hq : q ∈ interval) :
    0 ≤ thresholdFactor q - discount q ∧
    thresholdFactor q - discount q < 2 * epsilon ∧
    63 / 100 < thresholdFactor q ∧ thresholdFactor q < 16 / 25 := by
  obtain ⟨hl, hu⟩ := discount_bounds hq
  dsimp [thresholdFactor, epsilon]
  norm_num
  constructor
  · linarith
  constructor
  · linarith
  constructor <;> linarith

theorem exp_neg_three_lt : Real.exp (-3) < 1 / 20 := by
  have he : (163 : ℝ) / 60 < Real.exp 1 := by
    linarith [Real.exp_one_gt_d9]
  have hc : (20 : ℝ) < (Real.exp 1) ^ 3 := by nlinarith [sq_nonneg (Real.exp 1 - 163 / 60)]
  have hid : Real.exp (3 : ℝ) = (Real.exp 1) ^ 3 := by
    simpa using Real.exp_nat_mul (1 : ℝ) 3
  rw [Real.exp_neg, inv_lt_comm₀ (Real.exp_pos _) (by norm_num)]
  norm_num
  rwa [hid]

/-- The final strict gain uses a checked exponential-series bound from mathlib. -/
theorem final_gain : targetRatio < beta := by
  have h := Real.exp_neg_one_gt_d9
  rw [Real.exp_neg, ← one_div] at h
  dsimp [targetRatio, beta, theta, rho, epsilonZero]
  linarith

theorem beta_positive : 0 < beta := by norm_num [beta, theta, rho]
theorem beta_lt_one : beta < 1 := by norm_num [beta, theta, rho]

theorem stationary_cutoff_bounds {q : ℝ} (hq : q ∈ interval) :
    57 / 100 < stationaryRatio q - 20 * epsilon ∧
    stationaryRatio q - 20 * epsilon < 1 := by
  obtain ⟨hl, hu⟩ := stationary_bounds hq
  norm_num [epsilon]
  constructor <;> linarith

theorem overlap_cutoff_positive {q : ℝ} (hq : q ∈ interval) :
    0 < 1 - stationaryRatio q + 20 * epsilon + hMinus := by
  have h := (stationary_cutoff_bounds hq).2
  have hm : 0 < hMinus := by norm_num [hMinus, eta, epsilon]
  linarith

theorem overlap_cutoff_bound {q : ℝ} (hq : q ∈ interval) :
    9 / 4600 ≤ overlapCutoff q := by
  have hd := (stationary_cutoff_bounds hq).1
  unfold overlapCutoff
  apply (le_div_iff₀ (overlap_cutoff_positive hq)).mpr
  norm_num [hMinus, eta, epsilon] at *
  linarith

theorem surplus_lower_bound {q : ℝ} (hq : q ∈ interval) :
    1 - thresholdFactor q + 1 / 40 < surplusLower q := by
  obtain ⟨hba, hbGap, hbLo, hbHi⟩ := threshold_factor_bounds hq
  have hd := stationary_residual hq
  have hb : 0 < thresholdFactor q := by linarith
  have hfrac : 63 / 363 < thresholdFactor q / (thresholdFactor q + 3) := by
    apply (lt_div_iff₀ (by linarith : 0 < thresholdFactor q + 3)).mpr
    linarith
  have hcap : thresholdFactor q * Real.exp (-3) < (16 / 25) * (1 / 20) :=
    mul_lt_mul hbHi exp_neg_three_lt.le (Real.exp_pos _) (by norm_num)
  have hterm : 73 / 500 < stationaryRatio q - 20 * epsilon -
      (1 - thresholdFactor q) - hPlus - thresholdFactor q * Real.exp (-3) := by
    norm_num [hPlus, eta, epsilon] at *
    linarith
  have hprod := mul_lt_mul hfrac hterm.le (by norm_num : (0 : ℝ) < 73 / 500)
    (by positivity : 0 ≤ thresholdFactor q / (thresholdFactor q + 3))
  unfold surplusLower
  nlinarith

theorem discount_shift {q : ℝ} (hq : q ∈ interval) :
    q * (1 - discount q) - (1 - discount q) < 1 / 1000 := by
  obtain ⟨hl, hu⟩ := interval_bounds hq
  have ha := discount_bounds hq
  have hpos : 0 ≤ 1 - discount q := by linarith [ha.2]
  have h1 := mul_le_mul_of_nonneg_right (show q - 1 ≤ 1 / 512 by linarith) hpos
  nlinarith [ha.1]

theorem threshold_required_bound {q : ℝ} (hq : q ∈ interval) :
    thresholdFactor q * q * (stationaryRatio q + hPlus + 20 * epsilon) + 2 * epsilon <
      1 - thresholdFactor q + 1 / 40 := by
  obtain ⟨hba, hbGap, hbLo, hbHi⟩ := threshold_factor_bounds hq
  obtain ⟨hdLo, hdHi⟩ := stationary_bounds hq
  have haq := discount_times_q hq
  have hshift := discount_shift hq
  have hq0 := q_pos hq
  have hqHi : q < 501 / 500 := by linarith [(interval_bounds hq).2]
  have ha0 := discount_pos hq
  have hsum0 : 0 ≤ stationaryRatio q + hPlus + 20 * epsilon := by
    norm_num [hPlus, eta, epsilon] at *
    linarith
  have hsum1 : stationaryRatio q + hPlus + 20 * epsilon < 1 := by
    norm_num [hPlus, eta, epsilon] at *
    linarith
  have hh : hPlus + 20 * epsilon < 7 / 200 := by
    norm_num [hPlus, eta, epsilon]
  have hh0 : 0 < hPlus + 20 * epsilon := by
    norm_num [hPlus, eta, epsilon]
  have h1 : discount q * q * (hPlus + 20 * epsilon) < (16 / 25) * (7 / 200) :=
    mul_lt_mul haq hh.le hh0 (by norm_num)
  have h2 : (thresholdFactor q - discount q) * q < 2 * epsilon * (501 / 500) := by
    apply lt_of_lt_of_le (mul_lt_mul_of_pos_right hbGap hq0)
    exact mul_le_mul_of_nonneg_left hqHi.le (by norm_num [epsilon])
  have h3 : (thresholdFactor q - discount q) * q *
      (stationaryRatio q + hPlus + 20 * epsilon) ≤
      (thresholdFactor q - discount q) * q := by
    exact mul_le_of_le_one_right (mul_nonneg hba hq0.le) hsum1.le
  have hid : discount q * q * stationaryRatio q = q * (1 - discount q) := by
    unfold stationaryRatio
    field_simp
    ring
  have heq : thresholdFactor q * q * (stationaryRatio q + hPlus + 20 * epsilon) =
      discount q * q * stationaryRatio q + discount q * q * (hPlus + 20 * epsilon) +
      (thresholdFactor q - discount q) * q * (stationaryRatio q + hPlus + 20 * epsilon) := by ring
  rw [heq, hid]
  norm_num [epsilon] at *
  linarith

/-- Condition (7.4), fully instantiated for the rational witness. -/
theorem threshold_parameter_condition {q : ℝ} (hq : q ∈ interval) :
    thresholdFactor q * q * (stationaryRatio q + hPlus + 20 * epsilon) + 2 * epsilon <
      surplusLower q :=
  (threshold_required_bound hq).trans (surplus_lower_bound hq)

theorem final_gain_times {F : ℝ} (hF : 0 ≤ F) : targetRatio * F ≤ beta * F :=
  mul_le_mul_of_nonneg_right final_gain.le hF

end MatroidProphetSecretary
