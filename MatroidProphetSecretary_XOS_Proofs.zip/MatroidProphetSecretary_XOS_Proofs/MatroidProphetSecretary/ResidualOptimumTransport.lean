import MatroidProphetSecretary.MinorOptimumIdentities
import MatroidProphetSecretary.UniformArrivalDecomposition
import Mathlib.Data.Matroid.Map

/-! Removing the first arrival transports the child matroid to one fewer label. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

theorem optimum_comap_embedding {A E : Type*} [Fintype A] [DecidableEq A] [Fintype E] [DecidableEq E]
    (M : Matroid E) (f : A → E) (hf : Function.Injective f) (hcover : M.E ⊆ Set.range f) (v : E → ℝ) :
    optimum (M.comap f) (fun i => v (f i)) = optimum M v := by
  have hw (I : Finset A) : weight v (I.image f) = weight (fun i => v (f i)) I := by
    unfold weight
    rw [sum_image]
    exact fun i _ j _ h => hf h
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    rw [← hw]
    apply weight_le_optimumOver
    simpa only [Finset.coe_image] using (Matroid.comap_indep_iff.mp hI).1
  · obtain ⟨J,hJ,hopt⟩ := optimumOver_attained (fun J : Finset E => M.Indep (J : Set E)) (by simpa using M.empty_indep) v
    let I : Finset A := univ.filter (fun i => f i ∈ J)
    have himage : I.image f = J := by
      ext e
      constructor
      · intro he
        obtain ⟨i,hi,rfl⟩ := mem_image.mp he
        exact (mem_filter.mp hi).2
      · intro he
        obtain ⟨i,hi⟩ := hcover (hJ.subset_ground he)
        exact mem_image.mpr ⟨i,mem_filter.mpr ⟨mem_univ _,by rwa [hi]⟩,hi⟩
    have hI : (M.comap f).Indep (I : Set A) := by
      rw [Matroid.comap_indep_iff]
      exact ⟨by simpa only [← Finset.coe_image,himage] using hJ,hf.injOn⟩
    change optimumOver _ _ v ≤ _
    rw [hopt,← himage,hw]
    exact weight_le_optimumOver _ _ _ hI

theorem remainingLabel_surjective_away {n : ℕ} (e x : Fin (n+1)) (hx : x ≠ e) :
    ∃ i : Fin n, remainingLabel e i = x := by
  have hz : Equiv.swap 0 e x ≠ 0 := by
    intro h
    have h' := congrArg (Equiv.swap 0 e) h
    exact hx (by simpa only [Equiv.swap_apply_self,Equiv.swap_apply_left] using h')
  refine ⟨(Equiv.swap 0 e x).pred hz,?_⟩
  unfold remainingLabel
  rw [Fin.succ_pred,Equiv.swap_apply_self]

def remainingDelete {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1)) : Matroid (Fin n) :=
  (M ＼ {e}).comap (remainingLabel e)

def remainingContract {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1)) : Matroid (Fin n) :=
  (M ／ {e}).comap (remainingLabel e)

theorem remainingDelete_optimum {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1))
    (v : Fin (n+1) → ℝ) :
    optimum (remainingDelete M e) (fun i => v (remainingLabel e i)) = deletionValue M v e := by
  rw [remainingDelete,optimum_comap_embedding _ _ (remainingLabel_injective e),optimum_delete_singleton]
  intro x hx
  exact remainingLabel_surjective_away e x (by simpa using hx.2)

theorem remainingContract_optimum {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1))
    (he : M.Indep ({e} : Set (Fin (n+1)))) (v : Fin (n+1) → ℝ) :
    optimum (remainingContract M e) (fun i => v (remainingLabel e i)) = contractionValue M v e he := by
  rw [remainingContract,optimum_comap_embedding _ _ (remainingLabel_injective e),optimum_contract_singleton M v e he]
  intro x hx
  exact remainingLabel_surjective_away e x (by simpa using hx.2)

end MatroidProphetSecretary
