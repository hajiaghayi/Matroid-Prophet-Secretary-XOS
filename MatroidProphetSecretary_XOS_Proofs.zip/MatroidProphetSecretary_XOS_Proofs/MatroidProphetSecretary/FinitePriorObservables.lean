import MatroidProphetSecretary.DeterministicPolicy
import MatroidProphetSecretary.RationalPriorApproximation
import MatroidProphetSecretary.ZeroBenchmarkPolicy
import MatroidProphetSecretary.ValueActivity

/-! Offline and online observables for arbitrary finite probability vectors on a fixed value support. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def inputValueBudget {N k : ℕ} (value : Fin N → Fin k → ℝ) : ℝ := ∑ e, ∑ v, value e v

theorem inputValueBudget_nonneg {N k : ℕ} (value : Fin N → Fin k → ℝ) (hv : ∀ e v, 0 ≤ value e v) :
    0 ≤ inputValueBudget value := sum_nonneg (fun e _ => sum_nonneg (fun v _ => hv e v))

theorem finite_value_weight_bounds {N k : ℕ} (value : Fin N → Fin k → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (x : Fin N → Fin k) (I : Finset (Fin N)) :
    0 ≤ weight (coordinateValues value x) I ∧ weight (coordinateValues value x) I ≤ inputValueBudget value := by
  constructor
  · exact sum_nonneg (fun e _ => hv e (x e))
  · calc
      _ ≤ ∑ e : Fin N, value e (x e) :=
        sum_le_sum_of_subset_of_nonneg (subset_univ _) (fun e _ _ => hv e (x e))
      _ ≤ inputValueBudget value := by
        apply sum_le_sum
        intro e he
        exact single_le_sum (fun v _ => hv e v) (mem_univ (x e))

theorem finite_value_optimum_abs_bound {N k : ℕ} (value : Fin N → Fin k → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (M : Matroid (Fin N)) (x : Fin N → Fin k) :
    |optimum M (coordinateValues value x)| ≤ inputValueBudget value := by
  rw [abs_of_nonneg (optimum_nonneg M _)]
  apply optimumOver_le
  intro I hI
  exact (finite_value_weight_bounds value hv x I).2

def finitePolicyObservable {N k : ℕ} (value : Fin N → Fin k → ℝ) (policy : OnlinePolicy N 0)
    (x : Fin N → Fin k) : ℝ :=
  (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
    weight (coordinateValues value x) (acceptedSet (completedHistory policy 0 (coordinateValues value x) order)))

def finitePriorReward {N k : ℕ} (laws : Fin N → FiniteLaw (Fin k)) (value : Fin N → Fin k → ℝ)
    (policy : OnlinePolicy N 0) : ℝ := (FiniteLaw.product laws).expect (finitePolicyObservable value policy)

theorem finitePolicyObservable_abs_bound {N k : ℕ} (value : Fin N → Fin k → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (policy : OnlinePolicy N 0) (x : Fin N → Fin k) :
    |finitePolicyObservable value policy x| ≤ inputValueBudget value := by
  apply FiniteLaw.expect_abs_bound
  intro order
  rw [abs_of_nonneg (finite_value_weight_bounds value hv x _).1]
  exact (finite_value_weight_bounds value hv x _).2

theorem finitePriorReward_of_rational {N k : ℕ} (prior : RationalPriors N k) (policy : OnlinePolicy N 0) :
    finitePriorReward prior.law (fun e v => (prior.value e v : ℝ)) policy = expectedPolicyReward prior policy :=
  (expectedPolicyReward_zero_bits prior policy).symm

theorem finitePriorReward_reject {N k : ℕ} (laws : Fin N → FiniteLaw (Fin k)) (value : Fin N → Fin k → ℝ) :
    finitePriorReward laws value (rejectAllPolicy N) = 0 := by
  unfold finitePriorReward finitePolicyObservable
  simp only [rejectAll_completed_accepted,weight,sum_empty,FiniteLaw.expect_const]

theorem finite_prior_observable_approximation {N k : ℕ} (laws other : Fin N → FiniteLaw (Fin k))
    (value : Fin N → Fin k → ℝ) (hv : ∀ e v, 0 ≤ value e v) (M : Matroid (Fin N))
    (policy : OnlinePolicy N 0) (err : ℝ)
    (herr : ∀ e, FiniteLaw.massDistance (laws e) (other e) ≤ err) :
    |expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)-
        expectedOptimum (FiniteLaw.product other) M (coordinateValues value)| ≤ N*err*inputValueBudget value ∧
      |finitePriorReward laws value policy-finitePriorReward other value policy| ≤ N*err*inputValueBudget value := by
  constructor
  · exact FiniteLaw.product_expect_approximation N laws other err (inputValueBudget value)
      (inputValueBudget_nonneg value hv) herr _ (finite_value_optimum_abs_bound value hv M)
  · exact FiniteLaw.product_expect_approximation N laws other err (inputValueBudget value)
      (inputValueBudget_nonneg value hv) herr _ (finitePolicyObservable_abs_bound value hv policy)

end MatroidProphetSecretary

