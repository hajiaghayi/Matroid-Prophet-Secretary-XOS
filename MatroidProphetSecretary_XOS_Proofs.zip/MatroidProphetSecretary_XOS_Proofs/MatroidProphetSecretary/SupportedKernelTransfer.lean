import MatroidProphetSecretary.BlockKernelSemigroup
import MatroidProphetSecretary.SupportedAdaptiveDrift

/-! Equal transition expectations on reachable states determine equal finite terminal laws. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {S A B : Type*} [Fintype A] [Fintype B]

theorem timedBatches_constant (batch : S → FiniteLaw A) (update : S → A → S)
    (n offset : ℕ) (s : S) :
    timedBatches (fun _ => batch) update n offset s = adaptiveBatches batch update n s := by
  induction n generalizing offset s with
  | zero => rfl
  | succ n ih => simp only [timedBatches,adaptiveBatches,ih]

theorem timed_terminal_transfer (kernel : ℕ → S → FiniteLaw A) (other : ℕ → S → FiniteLaw B)
    (update : S → A → S) (otherUpdate : S → B → S) (Good : ℕ → S → Prop)
    (n offset : ℕ) (s : S) (hs : Good offset s)
    (hpreserve : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      ∀ x, (kernel j state).mass x ≠ 0 → Good (j+1) (update state x))
    (hstep : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state → ∀ F : S → ℝ,
      (kernel j state).expect (fun x => F (update state x)) =
        (other j state).expect (fun x => F (otherUpdate state x))) (F : S → ℝ) :
    (timedBatches kernel update n offset s).expect (fun x => F (stateAfter update n s x)) =
      (timedBatches other otherUpdate n offset s).expect (fun x => F (stateAfter otherUpdate n s x)) := by
  induction n generalizing offset s with
  | zero => simp [timedBatches,stateAfter]
  | succ n ih =>
    rw [timed_terminal_succ kernel update n offset s F,timed_terminal_succ other otherUpdate n offset s F]
    calc
      _ = (kernel offset s).expect (fun x =>
          (timedBatches other otherUpdate n (offset+1) (update s x)).expect
            (fun y => F (stateAfter otherUpdate n (update s x) y))) := by
        apply expect_congr_support
        intro x hx
        apply ih (offset+1) (update s x)
          (hpreserve offset le_rfl (by omega) s hs x hx)
        · intro j hj hjn state hstate y hy
          exact hpreserve j (by omega) (by omega) state hstate y hy
        · intro j hj hjn state hstate f
          exact hstep j (by omega) (by omega) state hstate f
      _ = _ := hstep offset le_rfl (by omega) s hs
        (fun state => (timedBatches other otherUpdate n (offset+1) state).expect
          (fun y => F (stateAfter otherUpdate n state y)))

theorem adaptive_terminal_transfer (kernel : S → FiniteLaw A) (other : S → FiniteLaw B)
    (update : S → A → S) (otherUpdate : S → B → S) (Good : ℕ → S → Prop)
    (n offset : ℕ) (s : S) (hs : Good offset s)
    (hpreserve : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state →
      ∀ x, (kernel state).mass x ≠ 0 → Good (j+1) (update state x))
    (hstep : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state → ∀ F : S → ℝ,
      (kernel state).expect (fun x => F (update state x)) =
        (other state).expect (fun x => F (otherUpdate state x))) (F : S → ℝ) :
    (adaptiveBatches kernel update n s).expect (fun x => F (stateAfter update n s x)) =
      (adaptiveBatches other otherUpdate n s).expect (fun x => F (stateAfter otherUpdate n s x)) := by
  have h := timed_terminal_transfer (fun _ => kernel) (fun _ => other) update otherUpdate Good
    n offset s hs hpreserve hstep F
  simpa only [timedBatches_constant] using h

end MatroidProphetSecretary.FiniteLaw
