import MatroidProphetSecretary.ReferenceSearchAlgorithm
import MatroidProphetSecretary.ReferenceBatchRatios

/-! Lemma 17 for the actual finite independent reference priors and common-sampler batches. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E] [Nonempty E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def referenceRecordGood (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid (referenceInstanceValues value)) (M : Matroid E)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (N : ℕ) (ε : ℝ) {m : ℕ}
    (r : SearchRecord (Fin m → (Fin G.last × (E → Bool)))) : Prop :=
  ¬ samplerBatchBad (referenceInstanceLaws laws value r.point) (referenceInstanceValues value)
    G M hnonloop N ε r.batch

theorem finite_reference_search_bounds (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (G : ValueHeightGrid (referenceInstanceValues value))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (N : ℕ) (hN : Fintype.card E ≤ N) (θ δ ε : ℝ)
    (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) (hδ0 : 0 ≤ δ) (hδ1 : δ ≤ 1/8)
    (ha : ∀ q ∈ searchInterval δ, 1/2 ≤ 1-θ*q) (hε0 : 0 ≤ ε) (hε1 : ε ≤ 1/10) (m : ℕ) :
    SearchAnalyticBounds
      (referencePositiveTest laws value G M θ ε (m := m))
      (referenceNegativeTest laws value G M θ ε (m := m))
      (referenceRecordGood laws value G M hnonloop N ε)
      (referenceSearchRatio true laws M value hnonloop θ)
      (referenceSearchRatio false laws M value hnonloop θ)
      (referencePotential laws M value θ) ε δ (16*(N:ℝ)^2) := by
  have hlo : (1:ℝ)/2 ≤ 1-4*δ := by linarith
  have hlo0 : (0:ℝ) < 1-4*δ := by linarith
  have hlo1 : (1:ℝ)-4*δ ≤ 1 := by linarith
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  have hqpos (q : ℝ) (hq : q ∈ searchInterval δ) : 0 < q := hlo0.trans_le hq.1
  have hFq (q : ℝ) (hq : q ∈ searchInterval δ) : 0 < referenceExpectedOptimum laws M value q :=
    (mul_pos hlo0 hF).trans_le
      (referenceExpectedOptimum_lower_away_zero laws M hg value hv (1-4*δ) q hlo0.le hlo1 hq.1)
  have hapos (q : ℝ) (hq : q ∈ searchInterval δ) : 0 < 1-θ*q := lt_of_lt_of_le (by norm_num) (ha q hq)
  have hLip (unstable : Bool) (x : ℝ) (hx : x ∈ searchInterval δ) (y : ℝ) (hy : y ∈ searchInterval δ) :
      |referenceSearchRatio unstable laws M value hnonloop θ x -
        referenceSearchRatio unstable laws M value hnonloop θ y| ≤ 16*(N:ℝ)^2*|x-y| := by
    have h := referenceSearchRatio_lipschitz unstable laws M value hv hnonloop hF
      (1-4*δ) (1/2) θ y x hlo hlo1 le_rfl hθ0 hθ1 hy.1 hx.1 (ha y hy) (ha x hx)
    have hn : (Fintype.card E : ℝ) ≤ N := by exact_mod_cast hN
    have hc : 14*(Fintype.card E : ℝ)^2 ≤ 16*(N:ℝ)^2 := by
      nlinarith [show (0:ℝ) ≤ Fintype.card E from Nat.cast_nonneg _,show (0:ℝ) ≤ N from Nat.cast_nonneg _]
    exact h.trans (mul_le_mul_of_nonneg_right hc (abs_nonneg _))
  refine ⟨?_,?_,?_,hLip true,hLip false,?_,?_⟩
  · intro q hq
    have hs := (basic_surplus_bounds (FiniteLaw.product (referenceInstanceLaws laws value q)) M
      (coordinateValues (referenceInstanceValues value)) hnonloop).1
    unfold referenceSearchRatio referenceSearchNumerator
    simp only [if_true,Bool.false_eq_true,if_false]
    apply sub_le_sub_right
    exact div_le_div_of_nonneg_right (sub_le_self _ hs) (hFq q hq).le
  · intro q hq x hx
    exact referenceBatch_positive_certificate laws value G M hnonloop θ q ε N x
      (hFq q hq) hε0 hε1 hx
  · intro q hq x hx
    exact referenceBatch_negative_certificate laws value G M hnonloop θ q ε N x
      (hFq q hq) hε0 hε1 hx
  · intro x hx q hq hxq hpos
    rcases eq_or_lt_of_le hxq with rfl | hlt
    · exact le_rfl
    · exact (reference_positive_query_potential laws M value hv hnonloop θ hθ0
        (searchInterval δ) (convex_Icc _ _) (fun r hr => (hqpos r hr).le)
        hapos x q hx hq (hqpos q hq) hlt (hFq q hq) hpos).le
  · intro q hq x hx hqx hneg
    rcases eq_or_lt_of_le hqx with rfl | hlt
    · exact le_rfl
    · exact (reference_negative_query_potential laws M value hv hnonloop θ hθ0
        (searchInterval δ) (convex_Icc _ _) (fun r hr => (hqpos r hr).le)
        hapos q x hq hx (hqpos q hq) hlt (hFq q hq) hneg).le

theorem finite_reference_selection (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (G : ValueHeightGrid (referenceInstanceValues value))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (N : ℕ) (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (θ δ ε : ℝ)
    (hθ0 : 0 ≤ θ) (hθ1 : θ ≤ 1) (hδ0 : 0 ≤ δ) (hδ1 : δ ≤ 1/8)
    (ha : ∀ q ∈ searchInterval δ, 1/2 ≤ 1-θ*q) (hε0 : 0 < ε) (hε1 : ε ≤ 1/10)
    (hsmall : ε/(4*(N:ℝ)^2) < δ) {m : ℕ}
    (batches : ℕ → (Fin m → (Fin G.last × (E → Bool))))
    (initial : SearchRecord (Fin m → (Fin G.last × (E → Bool))))
    (hinit : initial.point ∈ searchInterval δ)
    (hgood : referenceSearchAccurate (referencePositiveTest laws value G M θ ε (m := m))
      (referenceNegativeTest laws value G M θ ε (m := m)) batches initial
      (referenceRecordGood laws value G M hnonloop N ε) δ (referenceSearchSteps N δ ε)) :
    let r := runReferenceSearch (referencePositiveTest laws value G M θ ε (m := m))
      (referenceNegativeTest laws value G M θ ε (m := m)) batches initial δ (referenceSearchSteps N δ ε)
    referenceRecordGood laws value G M hnonloop N ε r ∧ r.point ∈ searchInterval δ ∧
      referencePotential laws M value θ initial.point ≤ referencePotential laws M value θ r.point ∧
      (|r.point-1| < 3*δ →
        θ*r.point/(1-θ*r.point)-20*ε ≤ referenceDeletion laws M value r.point / referenceExpectedOptimum laws M value r.point ∧
        referenceDeletion laws M value r.point / referenceExpectedOptimum laws M value r.point ≤
          θ*r.point/(1-θ*r.point) + referenceStable laws M value hnonloop r.point / referenceExpectedOptimum laws M value r.point + 20*ε) := by
  have hb := finite_reference_search_bounds laws M value hv hnonloop G hF N hN θ δ ε
    hθ0 hθ1 hδ0 hδ1 ha hε0.le hε1 m
  have hr := runReferenceSearch_correct (referencePositiveTest laws value G M θ ε (m := m))
    (referenceNegativeTest laws value G M θ ε (m := m)) batches initial
    (referenceRecordGood laws value G M hnonloop N ε)
    (referenceSearchRatio true laws M value hnonloop θ)
    (referenceSearchRatio false laws M value hnonloop θ)
    (referencePotential laws M value θ) N hN0 ε δ hε0 hsmall hinit hb hgood
  refine ⟨hr.1,hr.2.1,hr.2.2.1,?_⟩
  intro interior
  have hs := hr.2.2.2 interior
  simp only [referenceSearchRatio,referenceSearchNumerator,if_true,Bool.false_eq_true,if_false,sub_div] at hs
  constructor <;> linarith [hs.1,hs.2]

end MatroidProphetSecretary
