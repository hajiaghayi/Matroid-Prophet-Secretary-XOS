import MatroidProphetSecretary.FinitePushforward
import MatroidProphetSecretary.RankInequality

/-! A finite monotone coupling of two product Bernoulli laws. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def coupledBitLaw (p q : ℝ) (hp : 0 ≤ p) (hpq : p ≤ q) (hq : q ≤ 1) : FiniteLaw (Bool × Bool) where
  mass x := if x.1 = true then (if x.2 = true then p else 0)
    else (if x.2 = true then q - p else 1 - q)
  nonneg x := by
    rcases x with ⟨a,b⟩
    cases a <;> cases b <;> simp only [Bool.false_eq_true, if_false, if_true]
    · linarith
    · linarith
    · exact le_rfl
    · exact hp
  total := by
    simp [Fintype.sum_prod_type, Fintype.sum_bool]

theorem coupledBitLaw_fst (p q : ℝ) (hp : 0 ≤ p) (hpq : p ≤ q) (hq : q ≤ 1) :
    (coupledBitLaw p q hp hpq hq).map Prod.fst = bernoulliLaw p hp (hpq.trans hq) := by
  apply FiniteLaw.ext_mass
  funext b
  cases b <;> simp [FiniteLaw.map, coupledBitLaw, bernoulliLaw, Fintype.sum_prod_type, Fintype.sum_bool] <;> ring

theorem coupledBitLaw_snd (p q : ℝ) (hp : 0 ≤ p) (hpq : p ≤ q) (hq : q ≤ 1) :
    (coupledBitLaw p q hp hpq hq).map Prod.snd = bernoulliLaw q (hp.trans hpq) hq := by
  apply FiniteLaw.ext_mass
  funext b
  cases b <;> simp [FiniteLaw.map, coupledBitLaw, bernoulliLaw, Fintype.sum_prod_type, Fintype.sum_bool] <;> ring

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem bernoulliEval_mono_parameters (p q : E → ℝ)
    (hp : ∀ e, 0 ≤ p e) (hpq : ∀ e, p e ≤ q e) (hq : ∀ e, q e ≤ 1)
    (f : (E → Bool) → ℝ) (hf : Monotone f) : bernoulliEval p f ≤ bernoulliEval q f := by
  let laws := fun e => coupledBitLaw (p e) (q e) (hp e) (hpq e) (hq e)
  let μ := FiniteLaw.product laws
  have hfpoint (x : E → Bool × Bool) :
      μ.mass x * f (fun e => (x e).1) ≤ μ.mass x * f (fun e => (x e).2) := by
    by_cases hz : μ.mass x = 0
    · simp [hz]
    · apply mul_le_mul_of_nonneg_left _ (μ.nonneg x)
      apply hf
      intro e
      by_contra hbad
      have hi : (laws e).mass (x e) = 0 := by
        cases h1 : (x e).1 <;> cases h2 : (x e).2 <;>
          simp_all [laws, coupledBitLaw]
      apply hz
      exact prod_eq_zero (mem_univ e) hi
  have hineq : μ.expect (fun x => f (fun e => (x e).1)) ≤
      μ.expect (fun x => f (fun e => (x e).2)) := sum_le_sum (fun x _ => hfpoint x)
  have hfst := FiniteLaw.product_map_expect laws (fun _ => Prod.fst) f
  have hsnd := FiniteLaw.product_map_expect laws (fun _ => Prod.snd) f
  simp only [laws, coupledBitLaw_fst] at hfst
  simp only [laws, coupledBitLaw_snd] at hsnd
  rw [bernoulliEval_eq_expect p hp (fun e => (hpq e).trans (hq e)),
    bernoulliEval_eq_expect q (fun e => (hp e).trans (hpq e)) hq]
  exact hfst.trans_le (hineq.trans_eq hsnd.symm)

theorem bernoulliEval_antitone_parameters (p q : E → ℝ)
    (hp : ∀ e, 0 ≤ p e) (hpq : ∀ e, p e ≤ q e) (hq : ∀ e, q e ≤ 1)
    (f : (E → Bool) → ℝ) (hf : Antitone f) : bernoulliEval q f ≤ bernoulliEval p f := by
  have h := bernoulliEval_mono_parameters p q hp hpq hq (fun x => -f x) (by
    intro x y hxy
    exact neg_le_neg (hf hxy))
  have hneg (a : E → ℝ) : bernoulliEval a (fun x => -f x) = -bernoulliEval a f := by
    simp [bernoulliEval, mul_neg, sum_neg_distrib]
  rw [hneg, hneg] at h
  linarith

end MatroidProphetSecretary
