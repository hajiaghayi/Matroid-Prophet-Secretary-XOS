import MatroidProphetSecretary.PrivateTransitions
import MatroidProphetSecretary.FiniteAbsence
import Mathlib.Data.List.Infix

/-! Accepted-record paths for independent private clocks and arbitrary private tapes. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E T Ω A : Type*}

def markedStep (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A)
    (i : ℕ) (history : List (E × A)) (tape : T × Ω) : List (E × A) :=
  if tape.1 = time i then
    match decision i history tape.2 with
    | none => history
    | some mark => history ++ [(label i,mark)]
  else history

theorem markedStep_sublist (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A)
    (i : ℕ) (history : List (E × A)) (tape : T × Ω) :
    history.Sublist (markedStep label time decision i history tape) := by
  unfold markedStep
  split_ifs
  · cases decision i history tape.2
    · exact List.Sublist.refl _
    · exact (List.prefix_append _ _).sublist
  · exact List.Sublist.refl _

theorem markedRun_sublist (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A) (initial : List (E × A))
    (tapes : E → T × Ω) {i n : ℕ} (hin : i ≤ n) :
    (privateStepRun label (markedStep label time decision) initial tapes i).Sublist
      (privateStepRun label (markedStep label time decision) initial tapes n) := by
  induction n with
  | zero =>
    have hi : i = 0 := by omega
    subst i
    exact List.Sublist.refl _
  | succ n ih =>
    rcases Nat.eq_or_lt_of_le hin with hi | hi
    · subst i; exact List.Sublist.refl _
    · exact (ih (by omega)).trans (markedStep_sublist label time decision n _ _)

theorem FiniteLaw.exists_of_prob_pos {V : Type*} [Fintype V] (μ : FiniteLaw V)
    (P : V → Prop) (hp : 0 < μ.prob P) : ∃ x, P x := by
  by_contra h
  have hn : ∀ x, ¬ P x := by simpa using h
  have hz : μ.prob P = 0 := by simp [FiniteLaw.prob,FiniteLaw.expect,hn]
  linarith

theorem markedStep_eq_self_iff (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A)
    (i : ℕ) (history : List (E × A)) (tape : T × Ω) :
    markedStep label time decision i history tape = history ↔
      ¬ (tape.1 = time i ∧ decision i history tape.2 ≠ none) := by
  by_cases ht : tape.1 = time i
  · cases hd : decision i history tape.2 with
    | none => simp [markedStep,ht,hd]
    | some mark =>
      have hne : history ++ [(label i,mark)] ≠ history := by
        intro heq
        have hlen := congrArg List.length heq
        simp at hlen
      simp [markedStep,ht,hd,hne]
  · simp [markedStep,ht]

theorem markedStep_eq_self_of_absent (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A)
    (i : ℕ) (history : List (E × A)) (tape : T × Ω)
    (habsent : ∀ mark, (label i,mark) ∉ markedStep label time decision i history tape) :
    markedStep label time decision i history tape = history := by
  by_cases ht : tape.1 = time i
  · cases hd : decision i history tape.2 with
    | none => simp [markedStep,ht,hd]
    | some mark => exact False.elim (habsent mark (by simp [markedStep,ht,hd]))
  · simp [markedStep,ht]

variable [Fintype E] [DecidableEq E] [Fintype T] [Fintype Ω]

theorem markedPath_unchanged_at_absent (laws : E → FiniteLaw (T × Ω))
    (label : ℕ → E) (time : ℕ → T) (decision : ℕ → List (E × A) → Ω → Option A)
    (initial : List (E × A)) (path : ℕ → List (E × A)) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent label (markedStep label time decision) initial path n))
    (e : E) (habsent : ∀ mark, (e,mark) ∉ path n) {i : ℕ} (hi : i < n) (hei : label i = e) :
    path (i+1) = path i := by
  obtain ⟨tapes,hpath⟩ := FiniteLaw.exists_of_prob_pos _ _ hp
  have hsub : (path (i+1)).Sublist (path n) := by
    rw [← hpath (i+1) (by omega),← hpath n le_rfl]
    exact markedRun_sublist label time decision initial tapes (by omega)
  have hnext : markedStep label time decision i (path i) (tapes (label i)) = path (i+1) := by
    rw [← hpath i hi.le,← hpath (i+1) (by omega)]
    rfl
  rw [← hnext]
  apply markedStep_eq_self_of_absent
  intro mark hm
  apply habsent mark
  rw [hnext] at hm
  simpa only [hei] using hsub.subset hm

def pastMarkedAbsence (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A) (path : ℕ → List (E × A))
    (n : ℕ) (e : E) (tape : T × Ω) : Prop :=
  ∀ i < n, label i = e → ¬ (tape.1 = time i ∧ decision i (path i) tape.2 ≠ none)

theorem absent_coordinate_event_iff (laws : E → FiniteLaw (T × Ω))
    (label : ℕ → E) (time : ℕ → T) (decision : ℕ → List (E × A) → Ω → Option A)
    (initial : List (E × A)) (path : ℕ → List (E × A)) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent label (markedStep label time decision) initial path n))
    (e : E) (habsent : ∀ mark, (e,mark) ∉ path n) (tape : T × Ω) :
    privateCoordinateEvent label (markedStep label time decision) path n e tape ↔
      pastMarkedAbsence label time decision path n e tape := by
  unfold privateCoordinateEvent pastMarkedAbsence
  apply forall_congr'
  intro i
  apply forall_congr'
  intro hi
  apply forall_congr'
  intro hei
  rw [markedPath_unchanged_at_absent laws label time decision initial path n hp e habsent hi hei]
  exact markedStep_eq_self_iff label time decision i (path i) tape

end MatroidProphetSecretary
