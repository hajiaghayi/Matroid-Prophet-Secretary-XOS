import MatroidProphetSecretary.TimedBatches
import MatroidProphetSecretary.FiniteMassShortfall
import MatroidProphetSecretary.OptionalLaw

/-! One-event Euler rounds and their trace representation. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {W S : Type*} [Fintype W]

theorem mass_le_one {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω) (x : Ω) : μ.mass x ≤ 1 := by
  have h := single_le_sum (s := univ) (f := μ.mass) (fun y _ => μ.nonneg y) (mem_univ x)
  rwa [μ.total] at h

theorem option_mark_mass (μ : FiniteLaw (Option W)) : (∑ w, μ.mass (some w)) = 1-μ.mass none := by
  have h := μ.total
  rw [Fintype.sum_option] at h
  linarith

theorem timed_none_mass_union (kernel : ℕ → S → FiniteLaw (Option W)) (update : S → Option W → S)
    (hnone : ∀ s, update s none = s) (n offset : ℕ) (s : S) :
    1-(∑ i : Fin n, (1-(kernel (offset+i.val) s).mass none)) ≤
      (timedBatches kernel update n offset s).mass (fun _ => none) := by
  induction n generalizing offset s with
  | zero =>
    have he : (fun _ : Fin 0 => (none : Option W)) = Fin.elim0 := funext (fun i => Fin.elim0 i)
    simp [timedBatches,pointMass,he]
  | succ n ih =>
    rw [timedBatches_mass_succ,hnone,Fin.sum_univ_succ]
    simp only [Fin.val_zero,Nat.add_zero,Fin.val_succ]
    have htail := ih (offset+1) s
    have he (i : Fin n) : offset+1+i.val = offset+(i.val+1) := by omega
    simp_rw [he] at htail
    have hm := mul_le_mul_of_nonneg_left htail ((kernel offset s).nonneg none)
    have hsum : 0 ≤ ∑ i : Fin n, (1-(kernel (offset+(i.val+1)) s).mass none) :=
      sum_nonneg (fun i _ => sub_nonneg.mpr (mass_le_one _ _))
    have hextra := mul_nonneg hsum (sub_nonneg.mpr (mass_le_one (kernel offset s) none))
    nlinarith only [hm,hextra]

def sparseTrace {n : ℕ} : Option (Fin n × W) → (Fin n → Option W)
  | none => fun _ => none
  | some (i,w) => oneMarkTrace i w

theorem sparseTrace_injective (n : ℕ) : Function.Injective (sparseTrace (W := W) (n := n)) := by
  intro a b hab
  cases a with
  | none =>
    cases b with
    | none => rfl
    | some iw =>
      have h := congrFun hab iw.1
      simp [sparseTrace,oneMarkTrace] at h
  | some iw =>
    cases b with
    | none =>
      have h := congrFun hab iw.1
      simp [sparseTrace,oneMarkTrace] at h
    | some jw =>
      have hij : iw.1 = jw.1 := by
        by_contra hn
        have h := congrFun hab iw.1
        simp [sparseTrace,oneMarkTrace,hn] at h
      have hw : iw.2 = jw.2 := by
        have h := congrFun hab iw.1
        simpa [sparseTrace,oneMarkTrace,hij] using h
      congr 1
      exact Prod.ext hij hw

def sparseRoundWeight (kernel : ℕ → S → FiniteLaw (Option W)) (n offset : ℕ) (s : S) (iw : Fin n × W) : ℝ :=
  (kernel (offset+iw.1.val) s).mass (some iw.2)

theorem sparseRoundWeight_total (kernel : ℕ → S → FiniteLaw (Option W)) (n offset : ℕ) (s : S) :
    (∑ iw, sparseRoundWeight kernel n offset s iw) = ∑ i : Fin n, (1-(kernel (offset+i.val) s).mass none) := by
  rw [Fintype.sum_prod_type]
  simp only [sparseRoundWeight,option_mark_mass]

theorem sparseRoundWeight_bound (kernel : ℕ → S → FiniteLaw (Option W)) (h : ℝ)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h) (n offset : ℕ) (s : S) :
    (∑ iw, sparseRoundWeight kernel n offset s iw) ≤ (n:ℝ)*h := by
  rw [sparseRoundWeight_total]
  have hb := sum_le_sum (s := (univ : Finset (Fin n))) (fun i _ => hsmall (offset+i.val) s)
  simpa using hb

def sparseRoundLaw (kernel : ℕ → S → FiniteLaw (Option W)) (h : ℝ)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h) (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) :=
  optionalLaw (sparseRoundWeight kernel n offset s)
    (fun iw => (kernel _ s).nonneg _)
    ((sparseRoundWeight_bound kernel h hsmall n offset s).trans hbudget)

def sparseRoundTraceLaw (kernel : ℕ → S → FiniteLaw (Option W)) (h : ℝ)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h) (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) :=
  (sparseRoundLaw kernel h hsmall n offset s hbudget).map sparseTrace

theorem sparseRound_event_probability (kernel : ℕ → S → FiniteLaw (Option W)) (h : ℝ)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h) (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) :
    (sparseRoundTraceLaw kernel h hsmall n offset s hbudget).prob (fun x => x ≠ fun _ => none) =
      ∑ iw, sparseRoundWeight kernel n offset s iw := by
  rw [sparseRoundTraceLaw,map_prob]
  have he (x : Option (Fin n × W)) : sparseTrace x ≠ (fun _ => none) ↔ x ≠ none := by
    have heq : sparseTrace x = sparseTrace (none : Option (Fin n × W)) ↔ x = none :=
      (sparseTrace_injective n).eq_iff
    exact not_congr heq
  rw [prob_congr _ he]
  simp [prob,expect,sparseRoundLaw,optionalLaw,Fintype.sum_option]

end MatroidProphetSecretary.FiniteLaw
