import MatroidProphetSecretary.VirtualInitialization
import MatroidProphetSecretary.LayerSecondMoment
import MatroidProphetSecretary.AdaptiveOverlap

/-! Layer persistence and overlap growth in the explicit finite virtual process. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def virtualLiveMass (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M) (e : E) : ℝ :=
  μ.prob (fun y => e ∈ virtualLive M base hbase value s y)

def virtualCurrentOverlap (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M) : ℝ :=
  overlap μ value (virtualLive M base hbase value s)

theorem virtual_layer_indicator (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (e : E) (z : ℝ) :
    basisMarginal μ value (virtualLive M base hbase value s) e z =
      μ.expect (fun y => positiveLayer (value y e) z * virtualLiveIndicator M base hbase value s y e) := by
  unfold basisMarginal
  congr 1
  funext y
  unfold basisLayer virtualLiveIndicator
  split_ifs <;> simp

theorem virtualStep_layer_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) (e : E) (z : ℝ) :
    (1-dt*R)*basisMarginal μ value (virtualLive M base hbase value s) e z ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (fun event => basisMarginal μ value (virtualLive M base hbase value
          (virtualUpdate M base hbase value s event)) e z) := by
  simp_rw [virtual_layer_indicator]
  rw [FiniteLaw.expect_comm,← FiniteLaw.expect_const_mul]
  apply μ.expect_mono
  intro y
  rw [FiniteLaw.expect_const_mul]
  have hpos : 0 ≤ positiveLayer (value y e) z := by unfold positiveLayer; split_ifs <;> norm_num
  have h := mul_le_mul_of_nonneg_left
    (virtualStep_indicator_persistence μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall y e) hpos
  convert h using 1 <;> ring

theorem virtual_overlap_pointwise (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e) (s : VirtualState M) :
    virtualCurrentOverlap μ M base hbase value s ≤
      ∑ e, virtualLiveValue μ M base hbase value s e * virtualLiveMass μ M base hbase value s e := by
  unfold virtualCurrentOverlap overlap
  rw [integral_finset_sum univ (fun e _ => basisMarginal_sq_integrable μ value (virtualLive M base hbase value s) e)]
  apply sum_le_sum
  intro e he
  simpa only [virtualLiveValue,virtualLiveMass,mul_comm] using
    live_value_mass_ge_layer_square μ value hv (virtualLive M base hbase value s) e

theorem virtualStep_overlap_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hdtR : dt*R ≤ 1) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) :
    (1-dt*R)^2*virtualCurrentOverlap μ M base hbase value s ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (fun event => virtualCurrentOverlap μ M base hbase value (virtualUpdate M base hbase value s event)) := by
  exact expected_overlap_persistence _ μ value (virtualLive M base hbase value s)
    (fun event => virtualLive M base hbase value (virtualUpdate M base hbase value s event))
    (1-dt*R) (sub_nonneg.mpr hdtR)
    (fun e z => virtualStep_layer_persistence μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall e z)

theorem virtualProcess_overlap_accumulation (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (dt lam : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (hdtlam : dt*lam ≤ 1)
    (hsmall : dt*lam*Fintype.card E ≤ 1) (n : ℕ) (s : VirtualState M) :
    (1-dt*lam)^n*(1-(1-dt*lam)^n)*virtualCurrentOverlap μ M base hbase value s ≤
      dt*lam*FiniteLaw.accumulatedCrossMoment
        (fun state => virtualStepLaw μ M base hbase value state dt (fun _ => lam) lam hdt hlam
          (fun _ => hlam) (fun _ => le_rfl) hsmall)
        (virtualUpdate M base hbase value)
        (virtualLiveValue μ M base hbase value) (virtualLiveMass μ M base hbase value) n s := by
  have h := FiniteLaw.adaptive_overlap_accumulation
    (fun state => virtualStepLaw μ M base hbase value state dt (fun _ => lam) lam hdt hlam
      (fun _ => hlam) (fun _ => le_rfl) hsmall)
    (virtualUpdate M base hbase value)
    (virtualLiveValue μ M base hbase value) (virtualLiveMass μ M base hbase value)
    (virtualCurrentOverlap μ M base hbase value) (1-dt*lam)
    (sub_nonneg.mpr hdtlam) (sub_le_self _ (mul_nonneg hdt hlam))
    (fun state e => μ.prob_nonneg _)
    (fun state e => virtualStep_value_persistence μ M base hbase value hv state dt (fun _ => lam) lam
      hdt hlam (fun _ => hlam) (fun _ => le_rfl) hsmall e)
    (fun state => virtualStep_overlap_persistence μ M base hbase value state dt (fun _ => lam) lam
      hdt hlam hdtlam (fun _ => hlam) (fun _ => le_rfl) hsmall)
    (virtual_overlap_pointwise μ M base hbase value hv) n s
  simpa only [sub_sub_cancel] using h

end MatroidProphetSecretary
