import MatroidProphetSecretary.LayerInclusion
import MatroidProphetSecretary.PoissonConcavity
import MatroidProphetSecretary.FiniteIntegrals

/-! Both priority directions choose a basis of the active restriction. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [LinearOrder E]

def activeGreedyBasis (M : Matroid E) (v : E → ℝ) (x : E → Bool) : Finset E :=
  canonicalBasis (M ↾ bitSet x) v

theorem activeGreedyBasis_isBasis (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : E → ℝ) (x : E → Bool) : M.IsBasis (activeGreedyBasis M v x : Set E) (bitSet x) :=
  (Matroid.isBase_restrict_iff (fun e _ => hground e)).mp (canonicalBasis_isBase _ _)

theorem activeGreedyBasis_mem_iff (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : E → ℝ) (x : E → Bool) (e : E) :
    e ∈ activeGreedyBasis M v x ↔ x e = true ∧ nonspanEvent M e (priorityBefore v e) x := by
  by_cases he : x e = true
  · have hset : {f | f ∈ (M ↾ bitSet x).E ∧ priorityBefore v e f} =
        activeBlock M e (priorityBefore v e) x := by
      ext f
      have hne : priorityBefore v e f → f ≠ e := by
        intro h hfe
        subst f
        exact priorityBefore_irrefl _ _ h
      simp only [Matroid.restrict_ground_eq, bitSet, Set.mem_setOf_eq, activeBlock]
      constructor
      · rintro ⟨hf, hp⟩
        exact ⟨hground f, hne hp, hp, hf⟩
      · rintro ⟨_, _, hp, hf⟩
        exact ⟨hf, hp⟩
    rw [activeGreedyBasis, canonicalBasis_mem_iff (M ↾ bitSet x) v e he, hset,
      Matroid.restrict_closure_eq _ (fun f hf => hf.2.2.2) (fun f _ => hground f)]
    simp only [Set.mem_inter_iff, bitSet, Set.mem_setOf_eq, he, and_true, true_and, nonspanEvent]
  · have hn : e ∉ activeGreedyBasis M v x :=
      fun h => he ((activeGreedyBasis_isBasis M hground v x).subset h)
    simp [he, hn]

theorem selectedProbability_sum_eq_rank (laws : E → FiniteLaw Bool) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (v : E → ℝ) :
    (∑ e, selectedProbability laws M e (priorityBefore v e)) =
      (FiniteLaw.product laws).expect (fun x => realRank M (bitSet x)) := by
  simp only [selectedProbability, FiniteLaw.prob, FiniteLaw.expect]
  rw [sum_comm]
  apply sum_congr rfl
  intro x hx
  rw [← mul_sum]
  congr 1
  simp_rw [← activeGreedyBasis_mem_iff M hground v x]
  rw [realRank_eq_ncard (activeGreedyBasis_isBasis M hground v x)]
  simp

theorem reverse_priority_iff (v : E → ℝ) (e f : E) :
    priorityBefore (fun i => -canonicalPriority v i) e f ↔ priorityBefore v f e := by
  constructor
  · rintro (h | ⟨heq, hef⟩)
    · exact (canonicalPriority_lt_iff v f e).mp (neg_lt_neg_iff.mp h)
    · have hfe := canonicalPriority_injective v (neg_injective heq)
      exact (hef.ne hfe).elim
  · intro h
    exact Or.inl (neg_lt_neg (canonicalPriority_strict v h))

theorem reverse_selectedProbability_sum_eq_rank (laws : E → FiniteLaw Bool) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (v : E → ℝ) :
    (∑ e, selectedProbability laws M e (fun f => priorityBefore v f e)) =
      (FiniteLaw.product laws).expect (fun x => realRank M (bitSet x)) := by
  have h := selectedProbability_sum_eq_rank laws M hground (fun i => -canonicalPriority v i)
  have hp : ∀ e, (priorityBefore (fun i => -canonicalPriority v i) e) =
      (fun f => priorityBefore v f e) := fun e => funext (fun f => propext (reverse_priority_iff v e f))
  simpa only [hp] using h

end MatroidProphetSecretary
