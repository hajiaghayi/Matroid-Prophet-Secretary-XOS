import MatroidProphetSecretary.PoissonIntegerTable
import Mathlib.Data.Nat.Log

/-! Explicit binary encoding bounds for every integer in the Poisson sampling table. -/

namespace MatroidProphetSecretary

open Finset

def naturalEncodingBits (n : ℕ) : ℕ := Nat.clog 2 (n+1)

theorem naturalEncodingBits_of_le_pow (n a r : ℕ) (h : n ≤ a^r) :
    naturalEncodingBits n ≤ r*Nat.clog 2 a+1 := by
  apply (Nat.le_pow_iff_clog_le (by omega : 1 < 2)).mp
  have ha : a ≤ 2^(Nat.clog 2 a) := Nat.le_pow_clog (by omega) a
  have hn : n ≤ 2^(r*Nat.clog 2 a) := by
    calc
      n ≤ a^r := h
      _ ≤ (2^(Nat.clog 2 a))^r := Nat.pow_le_pow_left ha r
      _ = _ := by rw [← pow_mul,Nat.mul_comm]
  have hp : 1 ≤ 2^(r*Nat.clog 2 a) := Nat.one_le_pow _ _ (by omega)
  rw [pow_succ]
  omega

theorem poissonIntegerWeight_encoding (T n : ℕ) (hn : n ≤ T) :
    naturalEncodingBits (poissonIntegerWeight T n) ≤ T*Nat.clog 2 (2*(T+1))+1 :=
  naturalEncodingBits_of_le_pow _ _ _ (poissonIntegerWeight_bound T n hn)

theorem poissonIntegerTable_sum_bound (T : ℕ) :
    (∑ n : Fin (T+1), poissonIntegerWeight T n) ≤ (2*(T+1))^(T+1) := by
  calc
    _ ≤ ∑ _ : Fin (T+1), (2*(T+1))^T := sum_le_sum (fun n _ =>
      poissonIntegerWeight_bound T n (Nat.le_of_lt_succ n.isLt))
    _ = (T+1)*(2*(T+1))^T := by simp
    _ ≤ (2*(T+1))*(2*(T+1))^T := Nat.mul_le_mul_right _ (by omega)
    _ = _ := (pow_succ' _ _).symm

theorem poissonIntegerTable_sum_encoding (T : ℕ) :
    naturalEncodingBits (∑ n : Fin (T+1), poissonIntegerWeight T n) ≤
      (T+1)*Nat.clog 2 (2*(T+1))+1 :=
  naturalEncodingBits_of_le_pow _ _ _ (poissonIntegerTable_sum_bound T)

end MatroidProphetSecretary
