import MatroidProphetSecretary.ConditionalRankBound
import MatroidProphetSecretary.BlockResampling

/-! Averaging the conditional minor bound restores the original nonspanning probabilities. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem bitSet_resampleBlock (T : Set E) (x y : E → Bool) :
    bitSet (FiniteLaw.resampleBlock (fun e => e ∈ T) x y) =
      (bitSet y ∩ T) ∪ (bitSet x \ T) := by
  ext e
  by_cases he : e ∈ T <;> simp [bitSet, FiniteLaw.resampleBlock, he]

theorem conditionalMissing_average (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (T : Set E) (p : E → ℝ) (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (e : E) :
    (FiniteLaw.product (bernoulliLaws p hp0 hp1)).expect
      (fun x => conditionalMissing M (bitSet x \ T) T p e) =
      bernoulliEval p (insertDifference e (rankObservable M)) := by
  let laws := bernoulliLaws p hp0 hp1
  have h := FiniteLaw.product_resample_block laws (fun e => e ∈ T)
    (insertDifference e (rankObservable M))
  have hpoint (x y : E → Bool) :
      insertDifference e (rankObservable M) (FiniteLaw.resampleBlock (fun e => e ∈ T) x y) =
        if e ∈ M.closure ((bitSet y ∩ T) ∪ (bitSet x \ T)) then 0 else 1 := by
    rw [rank_insertDifference M hground, bitSet_resampleBlock]
  simp_rw [hpoint] at h
  simpa only [conditionalMissing, bernoulliEval_eq_expect p hp0 hp1] using h

theorem restricted_rank_missing_mass (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (T I : Set E) (hI : M.IsBasis I T) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (s : ℝ) (hs : 0 ≤ s) :
    (∑ e ∈ T.toFinset, p e * bernoulliEval p (insertDifference e (rankObservable M))) ≤
      realRank M T * Real.exp (-s) +
        s * ∑ e ∈ I.toFinset, bernoulliEval p (insertDifference e (rankObservable M)) := by
  let μ := FiniteLaw.product (bernoulliLaws p hp0 hp1)
  have h := μ.expect_mono (fun x => conditional_rank_missing_mass M (bitSet x \ T) T I hI
    (Set.disjoint_left.mpr (fun e he hdiff => hdiff.2 he)) p hp0 hp1 s hs)
  simp_rw [FiniteLaw.expect_finset_sum, FiniteLaw.expect_const_mul, FiniteLaw.expect_add,
    FiniteLaw.expect_const] at h
  simp_rw [FiniteLaw.expect_const_mul, FiniteLaw.expect_finset_sum] at h
  simpa only [μ, conditionalMissing_average M hground T p hp0 hp1] using h

/-- The conditional layer inequality used in Lemma 9, after averaging over outside activations. -/
theorem restricted_nonspan_inequality (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (T I : Set E) (hI : M.IsBasis I T) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (s : ℝ) (hs : 0 ≤ s) :
    let rho := fun e => nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True)
    (∑ e ∈ T.toFinset, p e * rho e) ≤
      (∑ e ∈ T.toFinset, (p e)^2 * rho e) + realRank M T * Real.exp (-s) +
        s * ∑ e ∈ I.toFinset, (1 - p e) * rho e := by
  dsimp only
  have h := restricted_rank_missing_mass M hground T I hI p hp0 hp1 s hs
  simp_rw [bernoulli_rank_marginal M hground p hp0 hp1] at h
  have halg :
      (∑ e ∈ T.toFinset, p e * ((1 - p e) * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True))) =
      (∑ e ∈ T.toFinset, p e * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True)) -
      ∑ e ∈ T.toFinset, (p e)^2 * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True) := by
    rw [← sum_sub_distrib]
    apply sum_congr rfl
    intro e he
    ring
  rw [halg] at h
  linarith

end MatroidProphetSecretary
