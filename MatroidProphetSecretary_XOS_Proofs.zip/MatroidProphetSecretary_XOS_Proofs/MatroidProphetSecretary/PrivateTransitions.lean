import MatroidProphetSecretary.PrivateHistory
import MatroidProphetSecretary.BernoulliVariation

/-! The conditional next-step law of a process driven by independent per-label tapes. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E Ω S : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

theorem privatePath_coordinate_positive (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n)) (e : E) :
    0 < (laws e).prob (privateCoordinateEvent label step path n e) := by
  have h := FiniteLaw.prob_mono (FiniteLaw.product laws) (fun x hx =>
    ((privatePathEvent_iff label step initial path hstart n x).mp hx) e)
  have he : (FiniteLaw.product laws).prob (fun x => privateCoordinateEvent label step path n e (x e)) =
      (laws e).prob (privateCoordinateEvent label step path n e) := by
    unfold FiniteLaw.prob
    convert FiniteLaw.product_expect_single_coordinate laws e
      (fun w => if privateCoordinateEvent label step path n e w then 1 else 0) using 1
  exact hp.trans_le (h.trans_eq he)

theorem privatePath_weighted_next (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (f : S → ℝ) :
    (FiniteLaw.product laws).prob (privatePathEvent label step initial path n) *
      ((laws (label n)).conditionOrSelf (privateCoordinateEvent label step path n (label n))).expect
        (fun w => f (step n (path n) w)) =
      (FiniteLaw.product laws).expect (fun x => if privatePathEvent label step initial path n x
        then f (privateStepRun label step initial x (n+1)) else 0) := by
  have h := privatePath_weighted_expect laws label step initial path hstart n
    (fun x => f (step n (path n) (x (label n))))
  rw [FiniteLaw.product_expect_single_coordinate
    (fun e => (laws e).conditionOrSelf (privateCoordinateEvent label step path n e))
    (label n) (fun w => f (step n (path n) w))] at h
  rw [h]
  congr 1
  funext x
  by_cases hx : privatePathEvent label step initial path n x
  · simp only [hx,if_true,privateStepRun,hx n le_rfl]
  · simp only [hx,if_false]

theorem privatePath_conditional_next (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n)) (f : S → ℝ) :
    ((FiniteLaw.product laws).conditionOrSelf (privatePathEvent label step initial path n)).expect
      (fun x => f (privateStepRun label step initial x (n+1))) =
    ((laws (label n)).conditionOrSelf (privateCoordinateEvent label step path n (label n))).expect
      (fun w => f (step n (path n) w)) := by
  apply mul_left_cancel₀ hp.ne'
  rw [FiniteLaw.conditionOrSelf_weighted_expect,privatePath_weighted_next laws label step initial path hstart n f]

theorem FiniteLaw.condition_probability_ratio {Ω : Type*} [Fintype Ω]
    (μ : FiniteLaw Ω) (P A : Ω → Prop) (hp : 0 < μ.prob P) :
    (μ.conditionOrSelf P).prob A = μ.prob (fun x => P x ∧ A x) / μ.prob P := by
  apply (eq_div_iff hp.ne').mpr
  rw [mul_comm]
  change μ.prob P * (μ.conditionOrSelf P).expect (fun x => if A x then 1 else 0) = _
  rw [conditionOrSelf_weighted_expect]
  unfold prob
  congr 1
  funext x
  by_cases hP : P x <;> by_cases hA : A x <;> simp [hP,hA]

theorem privatePath_next_probability (laws : E → FiniteLaw Ω) (label : ℕ → E)
    (step : ℕ → S → Ω → S) (initial : S) (path : ℕ → S) (hstart : path 0 = initial)
    (n : ℕ) (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n)) (A : S → Prop) :
    ((FiniteLaw.product laws).conditionOrSelf (privatePathEvent label step initial path n)).prob
      (fun x => A (privateStepRun label step initial x (n+1))) =
    (laws (label n)).prob (fun w => privateCoordinateEvent label step path n (label n) w ∧ A (step n (path n) w)) /
      (laws (label n)).prob (privateCoordinateEvent label step path n (label n)) := by
  have h := privatePath_conditional_next laws label step initial path hstart n hp (fun s => if A s then 1 else 0)
  change _ = ((laws (label n)).conditionOrSelf (privateCoordinateEvent label step path n (label n))).prob
    (fun w => A (step n (path n) w)) at h
  have hr := FiniteLaw.condition_probability_ratio (laws (label n))
    (privateCoordinateEvent label step path n (label n)) (fun w => A (step n (path n) w))
    (privatePath_coordinate_positive laws label step initial path hstart n hp (label n))
  exact h.trans hr

end MatroidProphetSecretary
