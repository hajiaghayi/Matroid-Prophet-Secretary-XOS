import MatroidProphetSecretary.XOSPartitions
import Mathlib.Data.Finset.Lattice.Fold

/-! An explicit finite, identical-prior XOS instance. We use ordered injections
as partition indices, avoiding any reliance on a choice of sorted enumeration.
Every partition is public, and every coefficient is either zero or one. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open Finset
open scoped Classical

abbrev Index (n L : ℕ) := Fin n ↪ Fin L
abbrev Goods (n L : ℕ) := Item (Index n L) n
abbrev Clause (n L : ℕ) := Index n L × Fin n

def allowed {n L : ℕ} (a : Fin L) : Finset (Clause n L) :=
  univ.filter (fun c => c.1 c.2 = a)

@[simp] theorem mem_allowed {n L : ℕ} (a : Fin L) (c : Clause n L) :
    c ∈ allowed a ↔ c.1 c.2 = a := by simp [allowed]

theorem allowed_nonempty {n L : ℕ} [NeZero n] (hnL : n ≤ L) (a : Fin L) :
    (allowed (n := n) a).Nonempty := by
  let e : Index n L := Fin.castLEEmb hnL
  let s : Index n L := e.trans (Equiv.swap (e 0) a).toEmbedding
  refine ⟨(s,0), ?_⟩
  simp [s, mem_allowed]

def value {n L : ℕ} (a : Fin L) (S : Finset (Goods n L)) : ℕ :=
  (allowed a).sup (fun c => (S ∩ part n c.1 c.2).card)

theorem clause_le_value {n L : ℕ} (a : Fin L) (S : Finset (Goods n L))
    (c : Clause n L) (hc : c.1 c.2 = a) : (S ∩ part n c.1 c.2).card ≤ value a S := by
  exact Finset.le_sup (f := fun d : Clause n L => (S ∩ part n d.1 d.2).card)
    ((mem_allowed a c).mpr hc)

theorem value_le_card {n L : ℕ} (a : Fin L) (S : Finset (Goods n L)) :
    value a S ≤ S.card :=
  Finset.sup_le (fun _ _ => card_le_card inter_subset_left)

@[simp] theorem value_empty {n L : ℕ} (a : Fin L) : value (n := n) a ∅ = 0 := by
  exact Nat.eq_zero_of_le_zero (value_le_card a ∅)

theorem value_mono {n L : ℕ} (a : Fin L) {S U : Finset (Goods n L)} (h : S ⊆ U) :
    value a S ≤ value a U := by
  apply Finset.sup_le
  intro c hc
  exact (card_le_card (inter_subset_inter h (Subset.refl _))).trans
    (Finset.le_sup (f := fun d : Clause n L => (U ∩ part n d.1 d.2).card) hc)

theorem value_attained {n L : ℕ} [NeZero n] (hnL : n ≤ L)
    (a : Fin L) (S : Finset (Goods n L)) :
    ∃ c : Clause n L, c.1 c.2 = a ∧ value a S = (S ∩ part n c.1 c.2).card := by
  obtain ⟨c,hc,heq⟩ := exists_mem_eq_sup (allowed a) (allowed_nonempty hnL a)
    (fun c => (S ∩ part n c.1 c.2).card)
  exact ⟨c,(mem_allowed a c).mp hc,heq⟩

/-- Public tie breaking: this function sees only the current label and allocated bundle. -/
def witness {n L : ℕ} [NeZero n] (hnL : n ≤ L)
    (a : Fin L) (S : Finset (Goods n L)) : Clause n L :=
  (value_attained hnL a S).choose

theorem witness_label {n L : ℕ} [NeZero n] (hnL : n ≤ L)
    (a : Fin L) (S : Finset (Goods n L)) : (witness hnL a S).1 (witness hnL a S).2 = a :=
  (value_attained hnL a S).choose_spec.1

theorem witness_value {n L : ℕ} [NeZero n] (hnL : n ≤ L)
    (a : Fin L) (S : Finset (Goods n L)) :
    value a S = (S ∩ part n (witness hnL a S).1 (witness hnL a S).2).card :=
  (value_attained hnL a S).choose_spec.2

def coefficient {n L : ℕ} (c : Clause n L) (x : Goods n L) : ℝ :=
  if x c.1 = c.2 then 1 else 0

theorem coefficient_binary {n L : ℕ} (c : Clause n L) (x : Goods n L) :
    coefficient c x = 0 ∨ coefficient c x = 1 := by
  unfold coefficient; split_ifs <;> simp

theorem clause_additive {n L : ℕ} (c : Clause n L) (S : Finset (Goods n L)) :
    (∑ x ∈ S, coefficient c x) = ((S ∩ part n c.1 c.2).card : ℝ) := by
  simp [coefficient, ← sum_filter, part, filter_mem_eq_inter, inter_filter]

/-- A finite maximum of nonnegative additive valuations, in the literal XOS sense. -/
theorem value_is_XOS {n L : ℕ} [NeZero n] (hnL : n ≤ L) (a : Fin L) :
    (∀ c ∈ allowed (n := n) a, ∀ x, 0 ≤ coefficient c x) ∧
    ∀ S : Finset (Goods n L),
      (∀ c ∈ allowed a, ∑ x ∈ S, coefficient c x ≤ (value a S : ℝ)) ∧
      ∃ c ∈ allowed a, (value a S : ℝ) = ∑ x ∈ S, coefficient c x := by
  constructor
  · intro c _ x; unfold coefficient; split_ifs <;> norm_num
  · intro S
    constructor
    · intro c hc
      rw [clause_additive]
      exact_mod_cast clause_le_value a S c ((mem_allowed a c).mp hc)
    · obtain ⟨c,hc,heq⟩ := value_attained hnL a S
      exact ⟨c,(mem_allowed a c).mpr hc,by rw [clause_additive,heq]⟩

end MatroidProphetSecretary.XOS
