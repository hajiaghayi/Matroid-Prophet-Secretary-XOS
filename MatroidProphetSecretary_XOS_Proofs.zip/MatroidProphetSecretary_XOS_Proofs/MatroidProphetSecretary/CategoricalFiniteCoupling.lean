import MatroidProphetSecretary.CategoricalExpectation
import MatroidProphetSecretary.FinitePairs

/-! A finite joint law packages the actual inverse-CDF coupling for adaptive execution proofs. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

theorem finiteRandomVariableLaw_prob {Ω A : Type*} [MeasurableSpace Ω]
    [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → A) (hX : Measurable X) (P : A → Prop) :
    (finiteRandomVariableLaw μ X hX).prob P = μ.real {ω | P (X ω)} := by
  rw [FiniteLaw.prob,finiteRandomVariableLaw_expect]
  have hm : MeasurableSet {ω | P (X ω)} := (Set.to_countable {a | P a}).measurableSet.preimage hX
  simpa only [Set.indicator,Set.mem_setOf_eq,Pi.one_apply] using integral_indicator_one (μ := μ) hm

def categoricalGridPair {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (G : ℕ) (hG : 0 < G)
    (u : ℝ) : Fin k × Fin k :=
  (categoricalFinDraw μ hk u,categoricalFinDraw μ hk (((uniformGridIndex G hG u).val:ℝ)/G))

theorem categoricalGridPair_measurable {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k)
    (G : ℕ) (hG : 0 < G) : Measurable (categoricalGridPair μ hk G hG) :=
  (categoricalFinDraw_measurable μ hk).prodMk
    ((measurable_of_countable (fun j : Fin G => categoricalFinDraw μ hk ((j.val:ℝ)/G))).comp
      (uniformGridIndex_measurable G hG))

def categoricalGridJoint {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (G : ℕ) (hG : 0 < G) :
    FiniteLaw (Fin k × Fin k) :=
  finiteRandomVariableLaw unitUniform (categoricalGridPair μ hk G hG) (categoricalGridPair_measurable μ hk G hG)

def categoricalGridLaw {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (G : ℕ) (hG : 0 < G) :
    FiniteLaw (Fin k) :=
  (@FiniteLaw.uniform (Fin G) _ ⟨⟨0,hG⟩⟩).map (fun j => categoricalFinDraw μ hk ((j.val:ℝ)/G))

theorem categoricalGridJoint_left {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (G : ℕ) (hG : 0 < G) :
    (categoricalGridJoint μ hk G hG).map Prod.fst = μ := by
  apply FiniteLaw.ext_expect
  intro f
  rw [FiniteLaw.map_expect,categoricalGridJoint,finiteRandomVariableLaw_expect]
  change (∫ u, f (categoricalFinDraw μ hk u) ∂unitUniform) = μ.expect f
  rw [← finiteRandomVariableLaw_expect unitUniform _ (categoricalFinDraw_measurable μ hk),categoricalFinDraw_law]

theorem categoricalGridJoint_right {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (G : ℕ) (hG : 0 < G) :
    (categoricalGridJoint μ hk G hG).map Prod.snd = categoricalGridLaw μ hk G hG := by
  apply FiniteLaw.ext_expect
  intro f
  rw [FiniteLaw.map_expect,categoricalGridJoint,finiteRandomVariableLaw_expect,categoricalGridLaw,
    FiniteLaw.map_expect,← uniformGridIndex_finiteLaw G hG,finiteRandomVariableLaw_expect]
  rfl

theorem categoricalGridJoint_error {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (G : ℕ) (hG : 0 < G) :
    (categoricalGridJoint μ hk G hG).prob (fun z => z.1 ≠ z.2) ≤ (k-1:ℕ)/(G:ℝ) := by
  have hp : (categoricalGridJoint μ hk G hG).prob (fun z => z.1 ≠ z.2) =
      unitUniform.real {u | (categoricalGridPair μ hk G hG u).1 ≠ (categoricalGridPair μ hk G hG u).2} := by
    convert finiteRandomVariableLaw_prob unitUniform (categoricalGridPair μ hk G hG)
      (categoricalGridPair_measurable μ hk G hG) (fun z => z.1 ≠ z.2) using 1
    unfold categoricalGridJoint
    congr 1
  rw [hp]
  apply ENNReal.toReal_le_of_le_ofReal (by positivity)
  have h := (categorical_grid_coupling μ G hG).1
  apply le_trans ?_ h
  change unitUniform {u | (categoricalGridPair μ hk G hG u).1 ≠ (categoricalGridPair μ hk G hG u).2} ≤ _
  rw [unitUniform,Measure.restrict_apply' measurableSet_Ico,Measure.restrict_apply' measurableSet_Ico]
  apply measure_mono
  intro u hu
  refine ⟨?_,hu.2⟩
  change categoricalDraw μ (uniformGridDown G u) ≠ categoricalDraw μ u
  have hn : categoricalDraw μ u ≠ categoricalDraw μ (((uniformGridIndex G hG u).val:ℝ)/G) := by
    intro he
    apply hu.1
    exact Fin.ext he
  rw [uniformGridIndex_down G hG u hu.2] at hn
  exact hn.symm

end MatroidProphetSecretary
