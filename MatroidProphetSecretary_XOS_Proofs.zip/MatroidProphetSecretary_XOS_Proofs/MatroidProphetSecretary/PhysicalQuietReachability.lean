import MatroidProphetSecretary.PhysicalRoundComparison

/-! A possible accepted history remains possible during any interval with no new acceptances. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem FiniteLaw.condition_joint_probability {R : Type*} [Fintype R] (μ : FiniteLaw R)
    (P Q : R → Prop) [DecidablePred P] [DecidablePred Q] :
    μ.prob (fun raw => P raw ∧ Q raw) = μ.prob P*(μ.conditionOrSelf P).prob Q := by
  symm
  change μ.prob P*(μ.conditionOrSelf P).expect (fun raw => if Q raw then 1 else 0) = _
  rw [FiniteLaw.conditionOrSelf_weighted_expect]
  unfold FiniteLaw.prob
  congr 1
  funext raw
  by_cases hp : P raw <;> by_cases hq : Q raw <;> simp [hp,hq]

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem quiet_step_reachable (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (hquiet : 0 < (cfg.historyKernel n history).mass none) :
    0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (n+1) = history) := by
  have hm : (cfg.historyKernel n history).mass none =
      ((FiniteLaw.product cfg.laws).conditionOrSelf (fun tapes => cfg.run tapes n = history)).prob
        (fun tapes => cfg.trace tapes n = none) := by
    rw [historyKernel,dif_pos hp,FiniteLaw.map_mass_probability]
    apply FiniteLaw.prob_irrel
  have hj : 0 < (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes n = history ∧ cfg.trace tapes n = none) := by
    rw [FiniteLaw.condition_joint_probability,← hm]
    exact mul_pos hp hquiet
  have hmono : (FiniteLaw.product cfg.laws).prob
      (fun tapes => cfg.run tapes n = history ∧ cfg.trace tapes n = none) ≤
      (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (n+1) = history) := by
    apply FiniteLaw.prob_mono
    intro tapes ht
    have hs := cfg.trace_update tapes n hn
    rw [ht.2] at hs
    exact hs.symm.trans ht.1
  exact hj.trans_le hmono

theorem quiet_interval_reachable (history : StampedHistory (Fin N) (Fin N → Option V)) (offset steps : ℕ)
    (horizon : offset+steps ≤ L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes offset = history))
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hsingle : (1/(L:ℝ))*((1/cfg.q)/omega) < 1) :
    0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (offset+steps) = history) := by
  induction steps with
  | zero => simpa using hp
  | succ steps ih =>
    have hprevious := ih (by omega)
    have hbound : offset+steps < L*N := by omega
    have hb := cfg.historyKernel_acceptance_bound history (offset+steps) hbound hsmall omega homega homega1 hlower
    have hquiet : 0 < (cfg.historyKernel (offset+steps) history).mass none := by linarith
    exact cfg.quiet_step_reachable history (offset+steps) hbound hprevious hquiet

end PrivateGridConfig
end MatroidProphetSecretary
