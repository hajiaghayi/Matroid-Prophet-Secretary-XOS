import MatroidProphetSecretary.ScheduledPolicyReplay
import MatroidProphetSecretary.ObservedTableSupport
import MatroidProphetSecretary.SortedPhysicalReward

/-! The physical continuation reward is the reward of a feasible policy using independent finite randomness. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

local instance (observed : Fin N → V → ℝ) (e : Fin N) : DecidableEq (ObservedValue observed e) :=
  fun a b => Classical.propDecidable (a = b)

def clockSeedLaw (hNL : N ≤ L) (observed : Fin N → V → ℝ) :
    FiniteLaw (ClockSchedule N L × ValueTapeTables N L observed) :=
  letI : Nonempty (ClockSchedule N L) :=
    ⟨⟨clockImage (lowerClockEmbedding N L hNL),clockImage_card _⟩⟩
  (FiniteLaw.uniform (ClockSchedule N L)).pair (cfg.valueTableLaw observed)

theorem privateClockPolicy_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (observed : Fin N → V → ℝ)
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hvalue : ∀ y e v, y e = some v → value y e = observed e v)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (schedule : ClockSchedule N L) (tables : ValueTapeTables N L observed)
    (ht : (cfg.valueTableLaw observed).mass tables ≠ 0) (sample : Fin N → V)
    (hs : (FiniteLaw.product cfg.prior).mass sample ≠ 0) (order : Equiv.Perm (Fin N)) :
    recordReward value (cfg.run (fun e => (decodeClocks (schedule,order.symm) e,
        tables e (observedValueAtom observed e (sample e)))) (L*N)) =
      weight (fun e => observed e (sample e))
        (acceptedSet (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) (schedule,tables)) 0
          (fun e => observed e (sample e)) order)) := by
  rw [cfg.privateClockPolicy_accepted M base hbase value hlive observed schedule tables sample order,
    cfg.run_reward_is_actual M base hbase observed value hvalue hlive _
      (cfg.value_table_clock_support observed tables ht sample _) (L*N) le_rfl]
  apply congrArg (fun w => weight w _)
  funext e
  exact cfg.value_table_consistency observed sample hs tables ht e

theorem sortedExpectedReward_revealed (hNL : N ≤ L) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (observed : Fin N → V → ℝ)
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hvalue : ∀ y e v, y e = some v → value y e = observed e v)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y) :
    cfg.sortedExpectedReward hNL value =
      (cfg.clockSeedLaw hNL observed).expect (fun seed =>
        (FiniteLaw.product cfg.prior).expect (fun sample =>
          (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
            weight (fun e => observed e (sample e))
              (acceptedSet (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) seed) 0
                (fun e => observed e (sample e)) order))))) := by
  letI : Nonempty (ClockSchedule N L) :=
    ⟨⟨clockImage (lowerClockEmbedding N L hNL),clockImage_card _⟩⟩
  unfold sortedExpectedReward clockSeedLaw
  rw [FiniteLaw.pair_expect]
  apply FiniteLaw.expect_congr_support
  intro schedule hschedule
  unfold clockReward
  simp_rw [cfg.value_table_unrolling observed]
  rw [FiniteLaw.expect_comm (FiniteLaw.uniform (Equiv.Perm (Fin N))) (FiniteLaw.product cfg.prior)]
  calc
    _ = (FiniteLaw.product cfg.prior).expect (fun sample =>
        (cfg.valueTableLaw observed).expect (fun tables =>
          (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
            weight (fun e => observed e (sample e))
              (acceptedSet (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) (schedule,tables)) 0
                (fun e => observed e (sample e)) order))))) := by
      apply FiniteLaw.expect_congr_support
      intro sample hs
      rw [FiniteLaw.expect_comm (FiniteLaw.uniform (Equiv.Perm (Fin N))) (cfg.valueTableLaw observed)]
      apply FiniteLaw.expect_congr_support
      intro tables ht
      apply FiniteLaw.expect_congr_support
      intro order ho
      exact cfg.privateClockPolicy_reward M base hbase observed value hvalue hlive schedule tables ht sample hs order
    _ = _ := FiniteLaw.expect_comm _ _ _

theorem sortedExpectedReward_policy {k : ℕ} (cfg : PrivateGridConfig N L (Fin k))
    (hNL : N ≤ L) (M : Matroid (Fin N)) (prior : RationalPriors N k)
    (hprior : cfg.prior = prior.law) (base : (Fin N → Option (Fin k)) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option (Fin k)) → Fin N → ℝ)
    (hvalue : ∀ y e v, y e = some v → value y e = (prior.value e v : ℝ))
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y) :
    cfg.sortedExpectedReward hNL value =
      (cfg.clockSeedLaw hNL (fun e v => (prior.value e v : ℝ))).expect (fun seed =>
        expectedPolicyReward prior (fixedPolicy (cfg.privateClockPolicy (fun e v => (prior.value e v : ℝ))) seed)) := by
  rw [cfg.sortedExpectedReward_revealed hNL M base hbase (fun e v => (prior.value e v : ℝ)) value hvalue hlive,hprior]
  simp only [expected_fixedPolicy,RationalPriors.realization]
  rfl

end MatroidProphetSecretary.PrivateGridConfig
