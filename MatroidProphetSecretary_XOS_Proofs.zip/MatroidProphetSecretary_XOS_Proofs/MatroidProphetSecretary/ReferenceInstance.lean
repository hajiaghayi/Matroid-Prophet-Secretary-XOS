import MatroidProphetSecretary.ReferenceValueLaw
import MatroidProphetSecretary.ReferenceLayerScaling
import MatroidProphetSecretary.ValueMissingMass
import MatroidProphetSecretary.FiniteIntegrals

/-! Actual independent finite reference priors and their layer representation. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

abbrev ReferenceAtom (V : E → Type*) [∀ e, Fintype (V e)] (e : E) :=
  Option (Fin (Fintype.card (V e)))

def referenceInstanceLaws (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ) (q : ℝ) :
    ∀ e, FiniteLaw (ReferenceAtom V e) := fun e =>
  referencePrior (laws e) (value e) (max 0 q) (le_max_left _ _)

def referenceInstanceValues (value : ∀ e, V e → ℝ) : ∀ e, ReferenceAtom V e → ℝ :=
  fun e => referencePriorValue (value e)

def referenceExpectedOptimum (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) : ℝ :=
  expectedOptimum (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value))

theorem referenceInstance_tail (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (q : ℝ) (hq : 0 ≤ q) (z : ℝ) (hz : 0 ≤ z) (e : E) :
    coordinateTail (referenceInstanceLaws laws value q) (referenceInstanceValues value) z e =
      scaledTail (coordinateTail laws value z e) q := by
  unfold coordinateTail referenceInstanceLaws referenceInstanceValues
  rw [referencePrior_tail _ _ _ _ z hz, max_eq_right hq]
  rfl

theorem value_expected_rank (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (z : ℝ) :
    (FiniteLaw.product laws).expect (fun x => realRank M (valueLayer M (coordinateValues value x) z)) =
      bernoulliEval (coordinateTail laws value z) (rankObservable M) := by
  rw [bernoulliEval_eq_expect (coordinateTail laws value z) (fun e => (laws e).prob_nonneg _)
    (fun e => (laws e).prob_le_one _), ← activityLaws_eq_bernoulli]
  unfold activityLaws
  rw [FiniteLaw.product_map_expect]
  congr 1
  funext x
  exact congrArg (realRank M) (bitSet_valueActivity M hground value z x).symm

theorem referenceInstance_expected_layer (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 ≤ q) (z : ℝ) :
    (FiniteLaw.product (referenceInstanceLaws laws value q)).expect (fun x =>
      positiveRankLayer M (coordinateValues (referenceInstanceValues value) x) z) =
      if 0 < z then referenceLayerRank M (coordinateTail laws value z) q else 0 := by
  by_cases hz : 0 < z
  · simp only [positiveRankLayer, hz, if_true]
    change (FiniteLaw.product (referenceInstanceLaws laws value q)).expect (fun x =>
      realRank M (valueLayer M (coordinateValues (referenceInstanceValues value) x) z)) = _
    rw [value_expected_rank _ M hground]
    have hp : coordinateTail (referenceInstanceLaws laws value q) (referenceInstanceValues value) z =
        fun e => scaledTail (coordinateTail laws value z e) q :=
      funext (referenceInstance_tail laws value q hq z hz.le)
    rw [hp]
    rfl
  · simp [positiveRankLayer, hz]

theorem referenceExpectedOptimum_integral (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 ≤ q) :
    referenceExpectedOptimum laws M value q =
      ∫ z, if 0 < z then referenceLayerRank M (coordinateTail laws value z) q else 0 := by
  have hv' : ∀ x e, 0 ≤ coordinateValues (referenceInstanceValues value) x e :=
    fun x e => referencePriorValue_nonneg (value e) (hv e) (x e)
  rw [referenceExpectedOptimum, expectedOptimum_eq_integral_expected_rank
    (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value)) hv']
  simp only [referenceInstance_expected_layer laws M hground value q hq]

theorem referenceExpectedOptimum_integrable_layers (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 ≤ q) :
    Integrable (fun z => if 0 < z then referenceLayerRank M (coordinateTail laws value z) q else 0) := by
  have h := (FiniteLaw.product (referenceInstanceLaws laws value q)).integrable_expect _
    (fun x => positiveRankLayer_integrable M (coordinateValues (referenceInstanceValues value) x)
      (fun e => referencePriorValue_nonneg (value e) (hv e) (x e)))
  simpa only [referenceInstance_expected_layer laws M hground value q hq] using h

theorem referenceExpectedOptimum_continuous (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) : Continuous (referenceExpectedOptimum laws M value) := by
  unfold referenceExpectedOptimum expectedOptimum FiniteLaw.expect FiniteLaw.product
  apply continuous_finset_sum
  intro x hx
  apply Continuous.mul _ continuous_const
  apply continuous_finset_prod
  intro e he
  cases x e with
  | none =>
    change Continuous (fun q : ℝ => 1 - min 1 (max 0 q * finiteIndexTail (sortedValueLaw (laws e) (value e)) 0))
    exact continuous_const.sub (continuous_const.min ((continuous_const.max continuous_id).mul continuous_const))
  | some i =>
    change Continuous (fun q : ℝ =>
      min 1 (max 0 q * finiteIndexTail (sortedValueLaw (laws e) (value e)) i.val) -
      min 1 (max 0 q * finiteIndexTail (sortedValueLaw (laws e) (value e)) (i.val+1)))
    exact (continuous_const.min ((continuous_const.max continuous_id).mul continuous_const)).sub
      (continuous_const.min ((continuous_const.max continuous_id).mul continuous_const))

end MatroidProphetSecretary
