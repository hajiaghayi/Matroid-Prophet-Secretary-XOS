import MatroidProphetSecretary.ExchangeInvariant
import Mathlib.Data.Matroid.Circuit
import Mathlib.Tactic.Set
import Mathlib.Tactic.Tauto
import Mathlib.Data.Finset.Card

/-! Construction of exchange maps from the matroid axioms. -/

noncomputable section

namespace MatroidProphetSecretary

open Set

variable {E : Type*} [DecidableEq E]

omit [DecidableEq E] in
/-- Symmetric exchange, with a prescribed source element. -/
theorem symmetric_exchange {M : Matroid E} {C B : Set E}
    (hC : M.IsBase C) (hB : M.IsBase B) {e : E} (heC : e ∈ C) (heB : e ∉ B) :
    ∃ b ∈ B \ C, M.IsBase (insert e (B \ {b})) ∧ M.IsBase (insert b (C \ {e})) := by
  let Γ := M.fundCircuit e B
  have heE := hC.subset_ground heC
  have hΓ : M.IsCircuit Γ := hB.fundCircuit_isCircuit heE heB
  have heΓ : e ∈ Γ := M.mem_fundCircuit e B
  have hecl : e ∈ M.closure (Γ \ {e}) := hΓ.mem_closure_diff_singleton_of_mem heΓ
  have hnot : e ∉ M.closure (C \ {e}) := by
    exact hC.indep.not_mem_closure_diff_of_mem heC
  have hex : ∃ b ∈ Γ \ {e}, b ∉ M.closure (C \ {e}) := by
    by_contra h
    push_neg at h
    apply hnot
    have hh := M.closure_subset_closure h
    rw [M.closure_closure] at hh
    exact hh hecl
  obtain ⟨b, hbΓ, hbnot⟩ := hex
  have hbB : b ∈ B := by
    have hb := M.fundCircuit_subset_insert e B hbΓ.1
    rcases hb with hbe | hb
    · exact (hbΓ.2 hbe).elim
    · exact hb
  have hbC : b ∉ C := by
    intro hb
    apply hbnot
    exact M.mem_closure_of_mem ⟨hb, hbΓ.2⟩ (Set.diff_subset.trans hC.subset_ground)
  refine ⟨b, ⟨hbB, hbC⟩, ?_,
    hC.exchange_base_of_not_mem_closure heC hbnot (hB.subset_ground hbB)⟩
  have hi := (hB.indep.mem_fundCircuit_iff (by rw [hB.closure_eq]; exact heE) heB).mp hbΓ.1
  have hid : insert e B \ {b} = insert e (B \ {b}) := by
    ext x
    simp only [mem_diff, mem_insert_iff, mem_singleton_iff]
    have hbe : b ≠ e := hbΓ.2
    have heb := hbe.symm
    constructor
    · rintro ⟨hx | hx, hxb⟩
      · exact Or.inl hx
      · exact Or.inr ⟨hx, hxb⟩
    · rintro (rfl | ⟨hx, hxb⟩)
      · exact ⟨Or.inl rfl, heb⟩
      · exact ⟨Or.inr hx, hxb⟩
  rw [hid] at hi
  exact hB.exchange_isBase_of_indep heB hi

theorem exchangeMap_exists (M : Matroid E) (C B : Finset E)
    (hC : M.IsBase (C : Set E)) (hB : M.IsBase (B : Set E)) :
    Nonempty (ExchangeMap M C B) := by
  classical
  suffices aux : ∀ k : ℕ, ∀ C : Finset E, (C \ B).card = k →
      M.IsBase (C : Set E) → Nonempty (ExchangeMap M C B) from aux _ C rfl hC
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    intro C hk hC
    by_cases hCB : C = B
    · subst C
      exact ⟨{
        map := id
        image_mem := fun e he => he
        inj := fun e _ f _ h => h
        fixes := fun _ _ _ => rfl
        exchange := fun e he => by simpa [Finset.insert_erase he] using hB
      }⟩
    · have hdiff : (C \ B).Nonempty := by
        by_contra hempty
        have hs : C ⊆ B := by
          intro x hx
          by_contra hxb
          exact hempty ⟨x, Finset.mem_sdiff.mpr ⟨hx, hxb⟩⟩
        apply hCB
        exact Finset.coe_injective (hC.eq_of_subset_isBase hB hs)
      obtain ⟨e, he⟩ := hdiff
      obtain ⟨heC, heB⟩ := Finset.mem_sdiff.mp he
      obtain ⟨b, hb, hBe, hCb⟩ := symmetric_exchange hC hB heC heB
      have hbB : b ∈ B := hb.1
      have hbC : b ∉ C := hb.2
      let C' := insert b (C.erase e)
      have hC' : M.IsBase (C' : Set E) := by
        simpa [C', Finset.coe_insert, Finset.coe_erase] using hCb
      have hdecrease : C' \ B = (C \ B).erase e := by
        ext x
        simp only [C', Finset.mem_sdiff, Finset.mem_insert, Finset.mem_erase]
        constructor
        · rintro ⟨hxb | ⟨hxe, hxC⟩, hxB⟩
          · exact (hxB (hxb ▸ hbB)).elim
          · exact ⟨hxe, hxC, hxB⟩
        · rintro ⟨hxe, hxC, hxB⟩
          exact ⟨Or.inr ⟨hxe, hxC⟩, hxB⟩
      have hk' : (C' \ B).card < k := by
        rw [hdecrease, ← hk]
        exact Finset.card_erase_lt_of_mem he
      obtain ⟨ψ⟩ := ih _ hk' C' rfl hC'
      have hold : ∀ x ∈ C, x ≠ e → x ∈ C' := by
        intro x hx hxe
        exact Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨hxe, hx⟩)
      have hbC' : b ∈ C' := Finset.mem_insert_self _ _
      have hψb : ψ.map b = b := ψ.fixes b hbC' hbB
      refine ⟨{
        map := fun x => if x = e then b else ψ.map x
        image_mem := ?_
        inj := ?_
        fixes := ?_
        exchange := ?_
      }⟩
      · intro x hx
        split_ifs with hxe
        · exact hbB
        · exact ψ.image_mem x (hold x hx hxe)
      · intro x hx y hy hxy
        by_cases hxe : x = e
        · by_cases hye : y = e
          · exact hxe.trans hye.symm
          · simp only [if_pos hxe, if_neg hye] at hxy
            have hyb : y = b := ψ.inj y (hold y hy hye) b hbC' (hxy.symm.trans hψb.symm)
            exact (hbC (hyb ▸ hy)).elim
        · by_cases hye : y = e
          · simp only [if_neg hxe, if_pos hye] at hxy
            have hxb : x = b := ψ.inj x (hold x hx hxe) b hbC' (hxy.trans hψb.symm)
            exact (hbC (hxb ▸ hx)).elim
          · simp only [if_neg hxe, if_neg hye] at hxy
            exact ψ.inj x (hold x hx hxe) y (hold y hy hye) hxy
      · intro x hxC hxB
        have hxe : x ≠ e := by rintro rfl; exact heB hxB
        rw [if_neg hxe]
        exact ψ.fixes x (hold x hxC hxe) hxB
      · intro x hx
        by_cases hxe : x = e
        · subst x
          simp only [if_pos rfl]
          simpa [Finset.coe_insert, Finset.coe_erase] using hBe
        · rw [if_neg hxe]
          exact ψ.exchange x (hold x hx hxe)

/-- A single map is fixed for each ordered pair of bases. -/
noncomputable def chosenExchangeMap (M : Matroid E) (C B : Finset E)
    (hC : M.IsBase (C : Set E)) (hB : M.IsBase (B : Set E)) : ExchangeMap M C B :=
  Classical.choice (exchangeMap_exists M C B hC hB)

theorem ExchangeMap.image_eq {M : Matroid E} {C B : Finset E}
    (φ : ExchangeMap M C B) (hC : M.IsBase (C : Set E))
    (hB : M.IsBase (B : Set E)) : C.image φ.map = B := by
  apply Finset.eq_of_subset_of_card_le
  · intro b hb
    obtain ⟨e, he, rfl⟩ := Finset.mem_image.mp hb
    exact φ.image_mem e he
  · have hcard : C.card = B.card := by
      simpa using hC.ncard_eq_ncard_of_isBase hB
    rw [Finset.card_image_iff.mpr (fun e he f hf h => φ.inj e he f hf h), hcard]

theorem ExchangeMap.bijectiveOn {M : Matroid E} {C B : Finset E}
    (φ : ExchangeMap M C B) (hC : M.IsBase (C : Set E))
    (hB : M.IsBase (B : Set E)) : Set.BijOn φ.map C B := by
  refine ⟨fun e he => φ.image_mem e he, fun e he f hf h => φ.inj e he f hf h, ?_⟩
  intro b hb
  have hb' : b ∈ C.image φ.map := by rw [φ.image_eq hC hB]; exact hb
  obtain ⟨e, he, hmap⟩ := Finset.mem_image.mp hb'
  exact ⟨e, he, hmap⟩

end MatroidProphetSecretary
