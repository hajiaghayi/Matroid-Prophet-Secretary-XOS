import MatroidProphetSecretary.ReferenceLayerDerivative
import MatroidProphetSecretary.BernoulliCoupling
import MatroidProphetSecretary.RightDerivativeConcavity

/-! Monotonicity and concavity of each saturated reference rank layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem realRank_mono_sets (M : Matroid E) {S T : Set E} (hST : S ⊆ T) (hT : T ⊆ M.E) :
    realRank M S ≤ realRank M T := by
  obtain ⟨I, hI⟩ := M.exists_isBasis S (hST.trans hT)
  rw [realRank_eq_ncard hI]
  exact indep_ncard_le_realRank hI.indep (hI.subset.trans hST) hT

theorem bitSet_mono {x y : E → Bool} (hxy : x ≤ y) : bitSet x ⊆ bitSet y := by
  intro e he
  have h := hxy e
  change x e = true at he
  change y e = true
  cases hy : y e
  · rw [he, hy] at h
    exact (not_le_of_gt (by decide : false < true) h).elim
  · rfl

theorem rankObservable_monotone (M : Matroid E) (hground : ∀ e, e ∈ M.E) :
    Monotone (rankObservable M) := by
  intro x y hxy
  exact realRank_mono_sets M (bitSet_mono hxy) (fun e _ => hground e)

theorem rank_replaceDifference_antitone (M : Matroid E) (hground : ∀ e, e ∈ M.E) (e : E) :
    Antitone (replaceDifference e (rankObservable M)) := by
  intro x y hxy
  rw [rank_replaceDifference M hground, rank_replaceDifference M hground]
  by_cases hx : e ∈ M.closure (bitSet x \ {e})
  · have hy : e ∈ M.closure (bitSet y \ {e}) :=
      M.closure_subset_closure (Set.diff_subset_diff_left (bitSet_mono hxy)) hx
    simp [hx, hy]
  · simp only [if_neg hx]
    split_ifs <;> norm_num

theorem referenceLayerRank_monotone (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) : MonotoneOn (referenceLayerRank M p) (Set.Ici 0) := by
  intro q hq r hr hqr
  exact bernoulliEval_mono_parameters _ _
    (fun e => (scaledTail_bounds (p e) q (hp e) hq).1)
    (fun e => scaledTail_monotone (p e) (hp e) hqr)
    (fun e => (scaledTail_bounds (p e) r (hp e) hr).2)
    (rankObservable M) (rankObservable_monotone M hground)

theorem referenceLayerRho_antitone (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) (e : E) :
    AntitoneOn (fun q => referenceLayerRho M p q e) (Set.Ici 0) := by
  intro q hq r hr hqr
  exact bernoulliEval_antitone_parameters _ _
    (fun f => (scaledTail_bounds (p f) q (hp f) hq).1)
    (fun f => scaledTail_monotone (p f) (hp f) hqr)
    (fun f => (scaledTail_bounds (p f) r (hp f) hr).2)
    _ (rank_replaceDifference_antitone M hground e)

theorem scaledTailRightSlope_nonneg (p q : ℝ) (hp : 0 ≤ p) : 0 ≤ scaledTailRightSlope p q := by
  unfold scaledTailRightSlope
  split_ifs <;> linarith

theorem scaledTailRightSlope_antitone (p : ℝ) (hp : 0 ≤ p) : Antitone (scaledTailRightSlope p) := by
  intro q r hqr
  by_cases hr : r * p < 1
  · have hq : q * p < 1 := (mul_le_mul_of_nonneg_right hqr hp).trans_lt hr
    simp [scaledTailRightSlope, hr, hq]
  · rw [scaledTailRightSlope, if_neg hr]
    exact scaledTailRightSlope_nonneg p q hp

theorem referenceLayerRightDerivative_antitone (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) :
    AntitoneOn (referenceLayerRightDerivative M p) (Set.Ici 0) := by
  intro q hq r hr hqr
  apply sum_le_sum
  intro e he
  exact mul_le_mul (scaledTailRightSlope_antitone (p e) (hp e) hqr)
    (referenceLayerRho_antitone M hground p hp e hq hr hqr)
    (referenceLayerRho_nonneg M hground p hp r hr e) (scaledTailRightSlope_nonneg (p e) q (hp e))

theorem referenceLayerRank_concave (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp : ∀ e, 0 ≤ p e) : ConcaveOn ℝ (Set.Ici 0) (referenceLayerRank M p) :=
  concaveOn_of_antitone_right_derivative (convex_Ici 0) _ _
    (referenceLayerRank_continuous M p).continuousOn
    (fun q _ => referenceLayerRank_right_derivative M p hp q)
    (referenceLayerRightDerivative_antitone M hground p hp)

end MatroidProphetSecretary
