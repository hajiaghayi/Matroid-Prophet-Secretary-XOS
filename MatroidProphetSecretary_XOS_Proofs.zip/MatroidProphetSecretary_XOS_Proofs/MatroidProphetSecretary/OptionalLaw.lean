import MatroidProphetSecretary.FiniteProbability
import Mathlib.Data.Fintype.Option
import Mathlib.Data.Fintype.BigOperators

/-! A finite subprobability kernel completed with an explicit no-event outcome. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

def optionalLaw (weight : Ω → ℝ) (hw0 : ∀ x, 0 ≤ weight x) (hw1 : ∑ x, weight x ≤ 1) : FiniteLaw (Option Ω) where
  mass x := match x with
    | none => 1-∑ y, weight y
    | some y => weight y
  nonneg x := by cases x; exact sub_nonneg.mpr hw1; exact hw0 _
  total := by rw [Fintype.sum_option]; ring

theorem optionalLaw_expect (weight : Ω → ℝ) (hw0 : ∀ x, 0 ≤ weight x) (hw1 : ∑ x, weight x ≤ 1)
    (f : Option Ω → ℝ) :
    (optionalLaw weight hw0 hw1).expect f = (1-∑ y, weight y)*f none + ∑ y, weight y*f (some y) := by
  simp only [expect,optionalLaw,Fintype.sum_option]

theorem optionalLaw_expect_zero (weight : Ω → ℝ) (hw0 : ∀ x, 0 ≤ weight x) (hw1 : ∑ x, weight x ≤ 1)
    (f : Option Ω → ℝ) (hf : f none = 0) :
    (optionalLaw weight hw0 hw1).expect f = ∑ y, weight y*f (some y) := by
  rw [optionalLaw_expect,hf,mul_zero,zero_add]

theorem optionalLaw_expect_loss (weight : Ω → ℝ) (hw0 : ∀ x, 0 ≤ weight x) (hw1 : ∑ x, weight x ≤ 1)
    (f : Option Ω → ℝ) :
    (optionalLaw weight hw0 hw1).expect f = f none-∑ y, weight y*(f none-f (some y)) := by
  rw [optionalLaw_expect]
  simp only [mul_sub,sum_sub_distrib,← sum_mul]
  ring

end MatroidProphetSecretary.FiniteLaw
