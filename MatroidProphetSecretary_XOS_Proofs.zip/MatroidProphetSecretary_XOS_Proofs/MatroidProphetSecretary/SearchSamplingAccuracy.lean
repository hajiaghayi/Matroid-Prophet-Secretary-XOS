import MatroidProphetSecretary.SearchSamplingState
import MatroidProphetSecretary.AdaptiveStreamHistory

/-! The reference search's accuracy event follows from the good queries on its sampled adaptive path. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {B : Type*} [Fintype B]

theorem search_stream_accuracy (positive negative : ℝ → B → Bool) (Good : SearchRecord B → Prop)
    (δ q : ℝ) (batches : ℕ → B) (n : ℕ)
    (hgood : ∀ i < n+1, Good ⟨searchQueryPoint
      (FiniteLaw.scanState (searchQueryStep positive negative δ) (Sum.inl q) batches i),batches i⟩) :
    referenceSearchAccurate positive negative (fun i => batches (i+1)) ⟨q,batches 0⟩ Good δ n := by
  constructor
  · exact hgood 0 (Nat.zero_lt_succ n)
  · cases hp : positive q (batches 0)
    · cases hn : negative q (batches 0)
      · simp only [hp,hn,Bool.false_eq_true,if_false]
      · simp only [hp,hn,Bool.false_eq_true,if_false,if_true]
        intro i hi
        have h := hgood (i+1) (Nat.succ_lt_succ hi)
        rw [← FiniteLaw.scanState_shift] at h
        simp only [searchQueryStep,hp,hn,Bool.false_eq_true,if_false,if_true] at h
        rw [searchQueryScan_branch] at h
        simpa only [searchQueryPoint,searchDirectionTest,Bool.false_eq_true,if_false] using h
    · simp only [hp,if_true]
      intro i hi
      have h := hgood (i+1) (Nat.succ_lt_succ hi)
      rw [← FiniteLaw.scanState_shift] at h
      simp only [searchQueryStep,hp,if_true] at h
      rw [searchQueryScan_branch] at h
      simpa only [searchQueryPoint,searchDirectionTest,if_true] using h

def clampedSearchPoint (δ : ℝ) (state : SearchQueryState) : ℝ :=
  max (1-4*δ) (min (1+4*δ) (searchQueryPoint state))

theorem clampedSearchPoint_mem (δ : ℝ) (hδ : 0 ≤ δ) (state : SearchQueryState) :
    clampedSearchPoint δ state ∈ searchInterval δ := by
  exact ⟨le_max_left _ _,max_le (by linarith) (min_le_left _ _)⟩

theorem clampedSearchPoint_eq (δ : ℝ) (state : SearchQueryState) (hs : SearchQueryValid δ state) :
    clampedSearchPoint δ state = searchQueryPoint state := by
  have h := searchQueryPoint_mem δ state hs
  exact (congrArg (max (1-4*δ)) (min_eq_right h.2)).trans (max_eq_right h.1)

def referenceSearchTapeLaw (positive negative : ℝ → B → Bool) (batch : ℝ → FiniteLaw B)
    (δ q : ℝ) (n : ℕ) : FiniteLaw (Fin (n+1) → B) :=
  FiniteLaw.adaptiveBatches (fun s => batch (clampedSearchPoint δ s))
    (searchQueryStep positive negative δ) (n+1) (Sum.inl q)

theorem reference_search_tape_failure (positive negative : ℝ → B → Bool) (batch : ℝ → FiniteLaw B)
    (Good : SearchRecord B → Prop) (δ q err : ℝ) (hδ : 0 ≤ δ) (hq : q ∈ searchInterval δ)
    (herr : 0 ≤ err) (hbatch : ∀ r ∈ searchInterval δ, (batch r).prob (fun x => ¬ Good ⟨r,x⟩) ≤ err)
    (n : ℕ) :
    (referenceSearchTapeLaw positive negative batch δ q n).prob (fun tape =>
      ¬ referenceSearchAccurate positive negative (fun i => finiteTapeStream tape (i+1))
        ⟨q,tape 0⟩ Good δ n) ≤ (n+1:ℕ)*err := by
  let update := searchQueryStep positive negative δ
  let bad := fun state x => ¬ Good ⟨clampedSearchPoint δ state,x⟩
  have hcontain (tape : Fin (n+1) → B)
      (hbad : ¬ referenceSearchAccurate positive negative (fun i => finiteTapeStream tape (i+1)) ⟨q,tape 0⟩ Good δ n) :
      FiniteLaw.trajectoryBad update bad (n+1) (Sum.inl q) tape := by
    by_contra htraj
    have htraj' : ¬ FiniteLaw.trajectoryBad update bad (n+1) (Sum.inl q)
        (fun i : Fin (n+1) => finiteTapeStream tape i.val) := by rwa [finiteTapeStream_restrict]
    have hg := (FiniteLaw.trajectory_good_stream update (fun s x => Good ⟨clampedSearchPoint δ s,x⟩)
      (n+1) (Sum.inl q) (finiteTapeStream tape)).mp htraj'
    have hg' (i : ℕ) (hi : i < n+1) : Good ⟨searchQueryPoint
        (FiniteLaw.scanState update (Sum.inl q) (finiteTapeStream tape) i),finiteTapeStream tape i⟩ := by
      have h := hg i hi
      rw [clampedSearchPoint_eq δ _ (searchQueryScan_valid positive negative δ (Sum.inl q) hq _ i)] at h
      exact h
    apply hbad
    have h := search_stream_accuracy positive negative Good δ q (finiteTapeStream tape) n hg'
    simpa only [show finiteTapeStream tape 0 = tape 0 from finiteTapeStream_prefix tape 0] using h
  apply (FiniteLaw.prob_mono _ hcontain).trans
  apply FiniteLaw.adaptiveBatches_failure_bound (fun s => batch (clampedSearchPoint δ s)) update bad err herr
  intro s
  convert hbatch _ (clampedSearchPoint_mem δ hδ s) using 1
  congr 1

end MatroidProphetSecretary
