import MatroidProphetSecretary.EulerExposureGeometry
import MatroidProphetSecretary.EulerEarlyLaw
import MatroidProphetSecretary.CorrectedVirtualExposure

/-! The early physical exchange process supplies the overlap term in the late reward estimate. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem euler_early_weighted_value (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (hcut : cfg.cut ≤ L) :
    (1-(1/(L:ℝ))*(1/cfg.q))*(1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut*
      virtualTotalLiveValue (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M)+
      (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut*(1-(1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut)*
        virtualCurrentOverlap (FiniteLaw.product cfg.reference) M base hbase value (initialVirtualState M) ≤
    (FiniteLaw.adaptiveBatches
      (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget)
      cfg.eulerBlockUpdate cfg.cut (0,[])).expect
      (fun x => virtualWeightedLiveValue (FiniteLaw.product cfg.reference) M base hbase value
        (fun e => 1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
          ((1/(L:ℝ))*(1/cfg.q)) cfg.cut (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x).2 e-
          ((1/(L:ℝ))*(1/cfg.q)))
        (recordReplay M base hbase value (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x).2)) := by
  have hpoint (x : Fin cfg.cut → Option (Fin N × (Fin N → Option V))) :
      virtualWeightedLiveValue (FiniteLaw.product cfg.reference) M base hbase value
        (fun e => 1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
          ((1/(L:ℝ))*(1/cfg.q)) cfg.cut (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x).2 e-
          ((1/(L:ℝ))*(1/cfg.q)))
        (recordReplay M base hbase value (FiniteLaw.stateAfter cfg.eulerBlockUpdate cfg.cut (0,[]) x).2) =
      virtualWeightedLiveValue (FiniteLaw.product cfg.reference) M base hbase value
        (fun e => 1+virtualEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
          (1/(L:ℝ)) (1/cfg.q) cfg.cut (initialVirtualState M) x e-((1/(L:ℝ))*(1/cfg.q)))
        (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.cut (initialVirtualState M) x) := by
    simp_rw [cfg.initial_euler_exposure (FiniteLaw.product cfg.reference) M base hbase value
      (1/(L:ℝ)) (1/cfg.q) cfg.cut hcut x]
    have hp := FiniteLaw.stateAfter_projection
      (fun state : BlockState N V => recordReplay M base hbase value state.2) cfg.eulerBlockUpdate
      (virtualUpdate M base hbase value) (cfg.eulerBlockUpdate_replay M base hbase value) cfg.cut (0,[]) x
    dsimp only at hp
    rw [hp]
    rfl
  simp_rw [hpoint]
  rw [cfg.euler_early_law M base hbase value hsmall omega homega homega1 hlower hbudget hcut]
  exact virtualProcess_corrected_exposure_value (FiniteLaw.product cfg.reference) M base hbase value hv
    (1/(L:ℝ)) (1/cfg.q) ((1/(L:ℝ))*(1/cfg.q))
    (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)
    hsmall.le (cfg.early_grid_mass omega homega homega1 hbudget) hsmall.le cfg.cut (initialVirtualState M)

end MatroidProphetSecretary.PrivateGridConfig
