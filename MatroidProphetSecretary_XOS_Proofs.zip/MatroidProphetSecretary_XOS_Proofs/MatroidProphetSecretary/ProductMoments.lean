import MatroidProphetSecretary.FiniteProbability
import Mathlib.Data.Fintype.BigOperators

/-! Product moments and exact coordinate-block probabilities of finite independent laws. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)]

theorem product_expect_prod (laws : ∀ i, FiniteLaw (V i)) (f : ∀ i, V i → ℝ) :
    (product laws).expect (fun x => ∏ i, f i (x i)) = ∏ i, (laws i).expect (f i) := by
  simp only [expect, product, ← prod_mul_distrib]
  exact (Fintype.prod_sum (fun i x => (laws i).mass x * f i x)).symm

theorem indicator_forall_eq_prod (P : ι → Prop) [DecidablePred P] :
    (if ∀ i, P i then (1 : ℝ) else 0) = ∏ i, if P i then 1 else 0 := by
  by_cases h : ∀ i, P i
  · simp [h]
  · rw [if_neg h]
    push_neg at h
    obtain ⟨i, hi⟩ := h
    exact (prod_eq_zero (mem_univ i) (by simp [hi])).symm

theorem product_prob_coordinates (laws : ∀ i, FiniteLaw (V i)) (P : ∀ i, V i → Prop)
    [∀ i, DecidablePred (P i)] :
    (product laws).prob (fun x => ∀ i, P i (x i)) = ∏ i, (laws i).prob (P i) := by
  unfold prob
  simp_rw [indicator_forall_eq_prod]
  exact product_expect_prod laws (fun i x => if P i x then 1 else 0)

theorem product_prob_exact_block (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (a : ∀ i, V i) :
    (product laws).prob (fun x => ∀ i, p i → x i = a i) =
      ∏ i, if p i then (laws i).mass (a i) else 1 := by
  rw [product_prob_coordinates laws (fun i x => p i → x = a i)]
  apply prod_congr rfl
  intro i hi
  by_cases hp : p i <;> simp [hp, prob, expect, ← sum_mul, (laws i).total]

end MatroidProphetSecretary.FiniteLaw
