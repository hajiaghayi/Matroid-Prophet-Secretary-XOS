import MatroidProphetSecretary.AdaptiveExpectation
import Mathlib.Algebra.BigOperators.Fin

/-! The exact probability of an adaptive finite trajectory factors over its visited states. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω S : Type*} [Fintype Ω]

theorem adaptiveBatches_mass_cons (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (n : ℕ) (s : S) (x : Ω) (tail : Fin n → Ω) :
    (adaptiveBatches batch update (n+1) s).mass (Fin.cons x tail) =
      (batch s).mass x*(adaptiveBatches batch update n (update s x)).mass tail := by
  simp [adaptiveBatches,bind,map,Fin.cons_inj,ite_and]

theorem adaptiveBatches_mass_succ (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (n : ℕ) (s : S) (x : Fin (n+1) → Ω) :
    (adaptiveBatches batch update (n+1) s).mass x =
      (batch s).mass (x 0)*(adaptiveBatches batch update n (update s (x 0))).mass (fun i => x i.succ) := by
  have h := adaptiveBatches_mass_cons batch update n s (x 0) (Fin.tail x)
  rwa [Fin.cons_self_tail] at h

theorem adaptiveBatches_mass_product (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (n : ℕ) (s : S) (x : Fin n → Ω) :
    (adaptiveBatches batch update n s).mass x = ∏ i, (batch (stateBefore update n s x i)).mass (x i) := by
  induction n generalizing s with
  | zero =>
    simp only [adaptiveBatches,pointMass,Fin.prod_univ_zero,ite_eq_left_iff,zero_ne_one,imp_false,not_not]
    funext i
    exact Fin.elim0 i
  | succ n ih =>
    rw [adaptiveBatches_mass_succ,ih,Fin.prod_univ_succ]
    simp only [stateBefore,Fin.cases_zero,Fin.cases_succ]

theorem adaptiveBatches_support_steps (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (n : ℕ) (s : S) (x : Fin n → Ω)
    (hx : (adaptiveBatches batch update n s).mass x ≠ 0) (i : Fin n) :
    (batch (stateBefore update n s x i)).mass (x i) ≠ 0 := by
  rw [adaptiveBatches_mass_product] at hx
  exact fun hi => hx (prod_eq_zero (mem_univ i) hi)

end MatroidProphetSecretary.FiniteLaw
