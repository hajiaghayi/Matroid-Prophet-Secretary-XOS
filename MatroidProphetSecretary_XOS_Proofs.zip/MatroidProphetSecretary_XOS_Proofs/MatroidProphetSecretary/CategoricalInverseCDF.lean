import MatroidProphetSecretary.InverseCDF
import MatroidProphetSecretary.FiniteProbability

/-! The inverse-CDF procedure samples the stated categorical probabilities. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

def cumulativeBoundaries : ℝ → List ℝ → List ℝ
  | _, [] => []
  | a, p::ps => (a+p)::cumulativeBoundaries (a+p) ps

theorem cumulativeBoundaries_length (a : ℝ) (ps : List ℝ) :
    (cumulativeBoundaries a ps).length = ps.length := by
  induction ps generalizing a with
  | nil => rfl
  | cons p ps ih => simp [cumulativeBoundaries,ih]

theorem inverseCDF_append_last (bs : List ℝ) (b u : ℝ) (hu : u < b) :
    inverseCDF (bs++[b]) u = inverseCDF bs u := by
  induction bs with
  | nil => simp [inverseCDF,hu]
  | cons c bs ih => simp only [List.cons_append,inverseCDF,ih]

theorem cumulativeBoundaries_last (a : ℝ) (ps : List ℝ) (hps : ps ≠ []) :
    cumulativeBoundaries a ps = (cumulativeBoundaries a ps).dropLast ++ [a+ps.sum] := by
  induction ps generalizing a with
  | nil => exact False.elim (hps rfl)
  | cons p ps ih =>
    cases ps with
    | nil => simp [cumulativeBoundaries]
    | cons q qs =>
      have h := ih (a+p) (by simp)
      simp only [cumulativeBoundaries,List.dropLast_cons₂,List.cons_append,List.sum_cons] at h ⊢
      convert congrArg (List.cons (a+p)) h using 1 <;> congr 2 <;> ring

theorem categorical_lookup_trim (a : ℝ) (ps : List ℝ) (hps : ps ≠ []) (u : ℝ)
    (hu : u < a+ps.sum) :
    inverseCDF (cumulativeBoundaries a ps) u = inverseCDF (cumulativeBoundaries a ps).dropLast u := by
  conv_lhs => rw [cumulativeBoundaries_last a ps hps]
  exact inverseCDF_append_last _ _ _ hu

theorem cumulative_inverseCDF_mass (a : ℝ) (ps : List ℝ)
    (hp : ∀ p ∈ ps, 0 ≤ p) (i : ℕ) :
    volume ({u : ℝ | inverseCDF (cumulativeBoundaries a ps) u = i} ∩ Set.Ico a (a+ps.sum)) =
      ENNReal.ofReal (ps[i]?.getD 0) := by
  induction ps generalizing a i with
  | nil => simp
  | cons p ps ih =>
    have hp0 := hp p (by simp)
    have htail : ∀ q ∈ ps, 0 ≤ q := fun q hq => hp q (by simp [hq])
    have hs : 0 ≤ ps.sum := List.sum_nonneg htail
    cases i with
    | zero =>
      have he : {u : ℝ | inverseCDF (cumulativeBoundaries a (p::ps)) u = 0} ∩
          Set.Ico a (a+(p::ps).sum) = Set.Ico a (a+p) := by
        ext u
        simp only [cumulativeBoundaries,inverseCDF,Set.mem_inter_iff,Set.mem_setOf_eq,
          Set.mem_Ico,List.sum_cons]
        by_cases hu : u < a+p
        · simp only [hu,if_true,true_and,and_true]
          constructor
          · exact fun h => h.1
          · exact fun h => ⟨h,by linarith⟩
        · simp [hu,not_lt.mp hu]
      rw [he]
      simp
    | succ i =>
      have he : {u : ℝ | inverseCDF (cumulativeBoundaries a (p::ps)) u = i+1} ∩
          Set.Ico a (a+(p::ps).sum) =
          {u : ℝ | inverseCDF (cumulativeBoundaries (a+p) ps) u = i} ∩ Set.Ico (a+p) (a+p+ps.sum) := by
        ext u
        simp only [cumulativeBoundaries,inverseCDF,Set.mem_inter_iff,Set.mem_setOf_eq,
          Set.mem_Ico,List.sum_cons]
        by_cases hu : u < a+p
        · simp [hu,not_le.mpr hu]
        · simp only [hu,if_false]
          constructor
          · rintro ⟨hi,hlo,hhi⟩
            exact ⟨by omega,le_of_not_gt hu,by linarith⟩
          · rintro ⟨hi,hlo,hhi⟩
            exact ⟨by omega,by linarith,by linarith⟩
      rw [he,ih (a+p) htail i]
      simp

def categoricalBoundaries {k : ℕ} (μ : FiniteLaw (Fin k)) : List ℝ :=
  (cumulativeBoundaries 0 (List.ofFn μ.mass)).dropLast

def categoricalDraw {k : ℕ} (μ : FiniteLaw (Fin k)) (u : ℝ) : ℕ :=
  inverseCDF (categoricalBoundaries μ) u

theorem categoricalBoundaries_length {k : ℕ} (μ : FiniteLaw (Fin k)) :
    (categoricalBoundaries μ).length = k-1 := by
  simp [categoricalBoundaries,List.length_dropLast,cumulativeBoundaries_length]

theorem categoricalDraw_mass {k : ℕ} (μ : FiniteLaw (Fin k)) (i : Fin k) :
    (volume.restrict (Set.Ico (0:ℝ) 1)) {u | categoricalDraw μ u = i.val} = ENNReal.ofReal (μ.mass i) := by
  have hsum : (List.ofFn μ.mass).sum = 1 := by rw [List.sum_ofFn]; exact μ.total
  have hne : List.ofFn μ.mass ≠ [] := by intro h; rw [h] at hsum; simp at hsum
  have htrim (u : ℝ) (hu : u < 1) := categorical_lookup_trim 0 (List.ofFn μ.mass) hne u (by simpa [hsum] using hu)
  rw [Measure.restrict_apply' measurableSet_Ico]
  have he : {u : ℝ | categoricalDraw μ u = i.val} ∩ Set.Ico 0 1 =
      {u : ℝ | inverseCDF (cumulativeBoundaries 0 (List.ofFn μ.mass)) u = i.val} ∩ Set.Ico 0 1 := by
    ext u
    by_cases hu : u ∈ Set.Ico (0:ℝ) 1
    · simp only [Set.mem_inter_iff,hu,and_true,Set.mem_setOf_eq,categoricalDraw,categoricalBoundaries,← htrim u hu.2]
    · simp [hu]
  rw [he]
  have h := cumulative_inverseCDF_mass 0 (List.ofFn μ.mass)
    (fun p hp => by obtain ⟨j,rfl⟩ := List.mem_ofFn.mp hp; exact μ.nonneg j) i.val
  simpa [hsum] using h

theorem categorical_grid_coupling {k : ℕ} (μ : FiniteLaw (Fin k)) (G : ℕ) (hG : 0 < G) :
    (volume.restrict (Set.Ico (0:ℝ) 1))
      {u | categoricalDraw μ (uniformGridDown G u) ≠ categoricalDraw μ u} ≤
      ENNReal.ofReal ((k-1:ℕ)/G) ∧
    (∀ u, 0 ≤ u → categoricalDraw μ (uniformGridDown G u) ≤ categoricalDraw μ u) := by
  constructor
  · simpa only [categoricalDraw,categoricalBoundaries_length] using inverseCDF_grid_error (categoricalBoundaries μ) G hG
  · exact fun u hu => inverseCDF_grid_le (categoricalBoundaries μ) G hG u hu

end MatroidProphetSecretary
