import MatroidProphetSecretary.VirtualInitialization

/-! The final-phase reward estimate for explicit finite exchange kernels with bounded rates. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def virtualWeightedLiveValue (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (multiplier : E → ℝ) (s : VirtualState M) : ℝ :=
  ∑ e, multiplier e * virtualLiveValue μ M base hbase value s e

theorem virtualStep_weighted_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (multiplier : E → ℝ) (hm : ∀ e, 0 ≤ multiplier e)
    (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) :
    (1-dt*R)*virtualWeightedLiveValue μ M base hbase value multiplier s ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (fun event => virtualWeightedLiveValue μ M base hbase value multiplier (virtualUpdate M base hbase value s event)) := by
  simp only [virtualWeightedLiveValue,mul_sum,FiniteLaw.expect_finset_sum,FiniteLaw.expect_const_mul]
  apply sum_le_sum
  intro e he
  have h := mul_le_mul_of_nonneg_left
    (virtualStep_value_persistence μ M base hbase value hv s dt rate R hdt hR hrate0 hrate1 hsmall e) (hm e)
  convert h using 1 <;> ring

theorem virtualStep_weighted_credit (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (multiplier : E → ℝ) (lam : ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1)
    (hlower : ∀ e, lam*multiplier e ≤ rate e) :
    dt*lam*virtualWeightedLiveValue μ M base hbase value multiplier s ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (virtualCredit M base hbase value s) := by
  rw [virtualStep_expected_credit]
  unfold virtualWeightedLiveValue
  rw [mul_assoc,mul_sum]
  apply mul_le_mul_of_nonneg_left _ hdt
  apply sum_le_sum
  intro e he
  have h := mul_le_mul_of_nonneg_right (hlower e) (virtualLiveValue_nonneg μ M base hbase value hv s e)
  simpa only [mul_assoc] using h

theorem virtualProcess_late_reward (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (multiplier : E → ℝ) (hm : ∀ e, 0 ≤ multiplier e)
    (dt lam omega : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (hstep : dt*(lam/omega) ≤ 1) (hsmall : dt*(lam/omega)*Fintype.card E ≤ 1)
    (rate : VirtualState M → E → ℝ) (hrate0 : ∀ s e, 0 ≤ rate s e)
    (hrate1 : ∀ s e, rate s e ≤ lam/omega) (hlower : ∀ s e, lam*multiplier e ≤ rate s e)
    (n : ℕ) (s : VirtualState M) :
    omega*(1-(1-dt*(lam/omega))^n)*virtualWeightedLiveValue μ M base hbase value multiplier s ≤
      (FiniteLaw.adaptiveBatches
        (fun state => virtualStepLaw μ M base hbase value state dt (rate state) (lam/omega)
          hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall)
        (virtualUpdate M base hbase value) n s).expect
        (FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value) n s) := by
  have hR : 0 ≤ lam/omega := div_nonneg hlam homega.le
  have hpersist (state : VirtualState M) :
      (1-dt*(lam/omega))*(omega*virtualWeightedLiveValue μ M base hbase value multiplier state) ≤
      (virtualStepLaw μ M base hbase value state dt (rate state) (lam/omega) hdt hR (hrate0 state) (hrate1 state) hsmall).expect
        (fun event => omega*virtualWeightedLiveValue μ M base hbase value multiplier (virtualUpdate M base hbase value state event)) := by
    rw [FiniteLaw.expect_const_mul]
    have h := mul_le_mul_of_nonneg_left
      (virtualStep_weighted_persistence μ M base hbase value hv multiplier hm state dt (rate state)
        (lam/omega) hdt hR (hrate0 state) (hrate1 state) hsmall) homega.le
    convert h using 1 <;> ring
  have hcredit (state : VirtualState M) :
      (1-(1-dt*(lam/omega)))*(omega*virtualWeightedLiveValue μ M base hbase value multiplier state) ≤
      (virtualStepLaw μ M base hbase value state dt (rate state) (lam/omega) hdt hR (hrate0 state) (hrate1 state) hsmall).expect
        (virtualCredit M base hbase value state) := by
    have h := virtualStep_weighted_credit μ M base hbase value hv multiplier lam state dt (rate state)
      (lam/omega) hdt hR (hrate0 state) (hrate1 state) hsmall (hlower state)
    convert h using 1 <;> field_simp <;> ring
  have h := FiniteLaw.adaptive_reward_lower
    (fun state => virtualStepLaw μ M base hbase value state dt (rate state) (lam/omega) hdt hR
      (hrate0 state) (hrate1 state) hsmall)
    (virtualUpdate M base hbase value) (virtualCredit M base hbase value)
    (fun state => omega*virtualWeightedLiveValue μ M base hbase value multiplier state)
    (1-dt*(lam/omega)) (sub_nonneg.mpr hstep) (sub_le_self _ (mul_nonneg hdt hR))
    hpersist hcredit n s
  convert h using 1 <;> ring

end MatroidProphetSecretary
