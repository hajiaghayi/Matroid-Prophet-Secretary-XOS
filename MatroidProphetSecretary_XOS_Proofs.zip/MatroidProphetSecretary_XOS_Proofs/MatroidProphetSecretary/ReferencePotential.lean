import MatroidProphetSecretary.ReferenceDerivativeBounds
import MatroidProphetSecretary.Potential
import Mathlib.Analysis.Convex.Deriv

/-! The actual reference potential and derivative certificates for the reference search. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
  {V : E → Type*} [∀ e, Fintype (V e)]

def referencePotential (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (θ q : ℝ) : ℝ :=
  (1-θ*q) * referenceExpectedOptimum laws M value q

def referencePotentialSlope (left : Bool) (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (θ q : ℝ) : ℝ :=
  -θ * referenceExpectedOptimum laws M value q + (1-θ*q) * referenceOptimumSlope left laws M value q

def referenceDeletion (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) : ℝ :=
  deletionSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value))

def referenceStable (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) : ℝ :=
  stableSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value)) hnonloop

theorem referencePotential_hasDerivWithinAt (left : Bool) (laws : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (θ q : ℝ) (hq : 0 < q) :
    HasDerivWithinAt (referencePotential laws M value θ)
      (referencePotentialSlope left laws M value θ q) (referenceSide left q) q := by
  have hd : HasDerivAt (fun x : ℝ => 1-θ*x) (-θ) q := by
    convert (hasDerivAt_const q (1:ℝ)).sub ((hasDerivAt_id q).const_mul θ) using 1 <;> simp
  exact hd.hasDerivWithinAt.mul (referenceExpectedOptimum_derivative left laws M value q hq)

theorem referencePotential_concave (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (θ : ℝ) (hθ : 0 ≤ θ) (J : Set ℝ) (hJ : Convex ℝ J) (hJ0 : J ⊆ Set.Ici 0)
    (ha : ∀ q ∈ J, 0 ≤ 1-θ*q) : ConcaveOn ℝ J (referencePotential laws M value θ) := by
  apply affine_potential_concave
    ((referenceExpectedOptimum_concave laws M hground value hv).subset hJ0 hJ)
    ((referenceExpectedOptimum_monotone laws M hground value hv).mono hJ0)
  · intro q hq
    exact FiniteLaw.expect_nonneg _ (fun x => optimum_nonneg M _)
  · exact hθ
  · exact ha

theorem referencePotential_derivative_bounds (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (θ q : ℝ) (hq : 0 < q) (ha : 0 ≤ 1-θ*q) :
    (1-θ*q)*(referenceDeletion laws M value q - referenceStable laws M value hnonloop q) -
        θ*q*referenceExpectedOptimum laws M value q ≤ q*referencePotentialSlope false laws M value θ q ∧
    referencePotentialSlope false laws M value θ q ≤ referencePotentialSlope true laws M value θ q ∧
    q*referencePotentialSlope true laws M value θ q ≤
      (1-θ*q)*referenceDeletion laws M value q - θ*q*referenceExpectedOptimum laws M value q := by
  have h := finite_reference_derivative_bounds laws M value hv hnonloop q hq
  change referenceDeletion laws M value q - referenceStable laws M value hnonloop q ≤ _ ∧
    _ ≤ _ ∧ _ ≤ referenceDeletion laws M value q at h
  have h1 := mul_le_mul_of_nonneg_left h.1 ha
  have h2 := mul_le_mul_of_nonneg_left h.2.1 ha
  have h3 := mul_le_mul_of_nonneg_left h.2.2 ha
  unfold referencePotentialSlope
  refine ⟨?_, ?_, ?_⟩
  · nlinarith only [h1]
  · have hh : q * ((1-θ*q)*referenceOptimumSlope false laws M value q) ≤
        q * ((1-θ*q)*referenceOptimumSlope true laws M value q) := by nlinarith only [h2]
    have hh' := (mul_le_mul_left hq).mp hh
    linarith
  · nlinarith only [h3]

theorem concave_increase_from_positive_left_derivative {g : ℝ → ℝ} {J : Set ℝ}
    (hg : ConcaveOn ℝ J g) {x y d : ℝ} (hx : x ∈ J) (hy : y ∈ J) (hxy : x < y)
    (hd : HasDerivWithinAt g d (Set.Iic y) y) (hdpos : 0 < d) : g x < g y := by
  have h := hg.le_slope_of_hasDerivWithinAt_Iio hx hy hxy (hd.mono Set.Iio_subset_Iic_self)
  have hs : 0 < slope g x y := hdpos.trans_le h
  rw [slope_def_field] at hs
  exact sub_pos.mp ((div_pos_iff.mp hs).resolve_right (by
    rintro ⟨_, hn⟩
    exact (not_lt_of_ge (sub_nonneg.mpr hxy.le)) hn)).1

theorem concave_increase_from_negative_right_derivative {g : ℝ → ℝ} {J : Set ℝ}
    (hg : ConcaveOn ℝ J g) {x y d : ℝ} (hx : x ∈ J) (hy : y ∈ J) (hxy : x < y)
    (hd : HasDerivWithinAt g d (Set.Ici x) x) (hdneg : d < 0) : g y < g x := by
  have h := hg.slope_le_of_hasDerivWithinAt_Ioi hx hy hxy (hd.mono Set.Ioi_subset_Ici_self)
  have hs : slope g x y < 0 := h.trans_lt hdneg
  rw [slope_def_field] at hs
  have hn := (div_lt_iff₀ (sub_pos.mpr hxy)).mp hs
  norm_num at hn
  linarith

end MatroidProphetSecretary
