import MatroidProphetSecretary.AlignedReferenceLaw
import MatroidProphetSecretary.ReferencePotential
import MatroidProphetSecretary.CanonicalBasis
import MatroidProphetSecretary.Overlap

/-! All reference statistics are invariant under transporting atoms back to the input support. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem aligned_reference_two_expect (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (q : ℝ) (f : (E → ℝ) → (E → ℝ) → ℝ) :
    (FiniteLaw.product (alignedReferenceLaws laws value q)).expect (fun y =>
      (FiniteLaw.product (alignedReferenceLaws laws value q)).expect (fun z =>
        f (optionalCoordinateValues value y) (optionalCoordinateValues value z))) =
      (FiniteLaw.product (referenceInstanceLaws laws value q)).expect (fun y =>
        (FiniteLaw.product (referenceInstanceLaws laws value q)).expect (fun z =>
          f (coordinateValues (referenceInstanceValues value) y) (coordinateValues (referenceInstanceValues value) z))) := by
  simp_rw [aligned_reference_expect laws value q]
  exact aligned_reference_expect laws value q (fun v =>
    (FiniteLaw.product (referenceInstanceLaws laws value q)).expect (fun z =>
      f v (coordinateValues (referenceInstanceValues value) z)))

theorem aligned_reference_deletion (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) :
    deletionSurplus (FiniteLaw.product (alignedReferenceLaws laws value q)) M (optionalCoordinateValues value) =
      referenceDeletion laws M value q := by
  unfold deletionSurplus referenceDeletion
  apply sum_congr rfl
  intro e he
  exact aligned_reference_expect laws value q (fun v => optimum M v-deletionValue M v e)

theorem aligned_reference_stable (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) :
    stableSurplus (FiniteLaw.product (alignedReferenceLaws laws value q)) M (optionalCoordinateValues value) hnonloop =
      referenceStable laws M value hnonloop q := by
  unfold stableSurplus referenceStable
  apply sum_congr rfl
  intro e he
  exact aligned_reference_two_expect laws value q
    (fun v w => posPart (min (v e) (w e)-exclusionThreshold M v e (hnonloop e)))

theorem aligned_reference_mean (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) (e : E) :
    meanThreshold (FiniteLaw.product (alignedReferenceLaws laws value q)) M (optionalCoordinateValues value) hnonloop e =
      meanThreshold (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) hnonloop e :=
  aligned_reference_expect laws value q (fun v => exclusionThreshold M v e (hnonloop e))

theorem aligned_reference_overlap [LinearOrder E] (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (q : ℝ) :
    overlap (FiniteLaw.product (alignedReferenceLaws laws value q)) (optionalCoordinateValues value)
        (fun y => canonicalBasis M (optionalCoordinateValues value y)) =
      overlap (FiniteLaw.product (referenceInstanceLaws laws value q)) (coordinateValues (referenceInstanceValues value))
        (fun y => canonicalBasis M (coordinateValues (referenceInstanceValues value) y)) := by
  unfold overlap basisMarginal
  apply congrArg (fun f : ℝ → ℝ => ∫ z, f z)
  funext z
  apply sum_congr rfl
  intro e he
  apply congrArg (fun r : ℝ => r^2)
  exact aligned_reference_expect laws value q (fun v => basisLayer v (canonicalBasis M v) e z)

end MatroidProphetSecretary
