import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.GCongr
import Mathlib.Tactic.SplitIfs
import Mathlib.Tactic.Ring

/-!
Scalar parts of Sections 3 and 7. Every dependency is an explicit hypothesis.
These lemmas do not assert that a matroid instance satisfies those hypotheses.
-/

namespace MatroidProphetSecretary

def posPart (x : ℝ) : ℝ := max x 0

theorem posPart_nonneg (x : ℝ) : 0 ≤ posPart x := le_max_right _ _

theorem surplus_split (y t w : ℝ) :
    posPart (y - t) ≤ posPart (y - w) + posPart (min y w - t) := by
  unfold posPart
  rcases le_total y w with h | h
  · rw [min_eq_left h, max_eq_right (sub_nonpos.mpr h)]
    simp
  · rw [min_eq_right h, max_eq_left (sub_nonneg.mpr h)]
    apply max_le
    · have := le_max_left (w - t) 0
      linarith
    · have := le_max_right (w - t) 0
      linarith

theorem surplus_threshold_shift (y p w : ℝ) :
    posPart (y - w) ≤ posPart (y - p) + posPart (p - w) := by
  unfold posPart
  apply max_le
  · have := le_max_left (y - p) 0
    have := le_max_left (p - w) 0
    linarith
  · positivity

/-- The two deletion/contraction identities (3.1), once the optimum is split. -/
theorem optimum_split_identities (y deletion contraction : ℝ)
    (h : contraction ≤ deletion) :
    max deletion (y + contraction) - deletion =
        posPart (y - (deletion - contraction)) ∧
    max deletion (y + contraction) - contraction =
        max y (deletion - contraction) := by
  unfold posPart
  constructor <;> rcases le_total deletion (y + contraction) with h' | h'
  · rw [max_eq_right h', max_eq_left (by linarith)]
    ring
  · rw [max_eq_left h', max_eq_right (by linarith)]
    ring
  · rw [max_eq_right h', max_eq_left (by linarith)]
    ring
  · rw [max_eq_left h', max_eq_right (by linarith)]

/-- Eliminate the cap deficit and price gap, the algebra in Corollary 10. -/
theorem threshold_surplus_of_decomposition
    (F D H P G cap S K b s e : ℝ)
    (hF : 0 < F) (hb : 0 < b) (hb1 : b ≤ 1) (hs : 0 < s)
    (hG : 0 ≤ G) (hcap : 0 ≤ cap) (he : 0 ≤ e)
    (hP : P ≤ F)
    (hSurplus : (1 - b) * F + b * G + cap ≤ S)
    (hDeletion : D ≤ S + K)
    (hCap : K ≤ H + b * P * e + s * (G + cap)) :
    1 - b + b / (b + s) * (D / F - (1 - b) - H / F - b * e) ≤ S / F := by
  have hgap : b * (G + cap) ≤ S - (1 - b) * F := by
    nlinarith [mul_nonneg (sub_nonneg.mpr hb1) hcap]
  have hprice : b * P * e ≤ b * F * e := by gcongr
  have hmain : b * D ≤ b * S + b * H + b ^ 2 * F * e +
      s * (S - (1 - b) * F) := by
    nlinarith [mul_le_mul_of_nonneg_left hCap hb.le,
      mul_le_mul_of_nonneg_left hDeletion hb.le,
      mul_le_mul_of_nonneg_left hprice hb.le,
      mul_le_mul_of_nonneg_left hgap hs.le]
  apply (le_div_iff₀ hF).mpr
  have hbs : 0 < b + s := by linarith
  apply (mul_le_mul_right hbs).mp
  have hid : (1 - b + b / (b + s) * (D / F - (1 - b) - H / F - b * e)) *
      F * (b + s) = (1 - b) * F * (b + s) + b * (D - (1 - b) * F - H - b * e * F) := by
    field_simp
    <;> ring
  rw [hid]
  nlinarith

/-- The normalized strong-overlap inequality, after (3.6) is established. -/
theorem normalized_overlap (F D H Q : ℝ) (hF : 0 < F)
    (hden : 0 < F - D + H)
    (hoverlap : H ^ 2 ≤ Q * (F - D + H)) :
    (H / F) ^ 2 / (1 - D / F + H / F) ≤ Q / F := by
  have hden' : 0 < 1 - D / F + H / F := by
    have : 1 - D / F + H / F = (F - D + H) / F := by field_simp
    rw [this]
    exact div_pos hden hF
  apply (div_le_iff₀ hden').mpr
  apply (mul_le_mul_right (sq_pos_of_pos hF)).mp
  convert hoverlap using 1 <;> field_simp [ne_of_gt hF] <;> ring <;> simp

theorem square_div_add_mono (c x y : ℝ) (hc : 0 < c)
    (hx : 0 ≤ x) (hxy : x ≤ y) :
    x ^ 2 / (c + x) ≤ y ^ 2 / (c + y) := by
  have hxden : 0 < c + x := by linarith
  have hyden : 0 < c + y := by linarith
  have hy : 0 ≤ y := le_trans hx hxy
  have hdiff : 0 ≤ y - x := sub_nonneg.mpr hxy
  apply (div_le_div_iff₀ hxden hyden).mpr
  have h1 : 0 ≤ c * (y - x) * (x + y) := by positivity
  have h2 : 0 ≤ x * y * (y - x) := by positivity
  nlinarith

/-- The surplus comparison used in the small-stability branch of Lemma 18. -/
theorem original_surplus_pays_deletion
    (Sref Sactual F D q b a eps : ℝ)
    (hq : 0 < q) (hD : 0 ≤ D) (hab : a ≤ b)
    (href : b * q * D + 2 * eps * F < Sref)
    (htransfer : Sref < q * Sactual + 2 * eps * F) :
    a * D < Sactual := by
  have : q * (b * D) < q * Sactual := by nlinarith
  have : b * D < Sactual := (mul_lt_mul_left hq).mp this
  exact lt_of_le_of_lt (mul_le_mul_of_nonneg_right hab hD) this

/-- A fixed-label threshold decision dominates deletion by its surplus. -/
theorem threshold_decision_progress (v p a Fdel Fcon : ℝ)
    (hprice : a * (Fdel - Fcon) ≤ p) :
    a * Fdel + posPart (v - p) ≤
      if p < v then v + a * Fcon else a * Fdel := by
  split_ifs with h
  · rw [posPart, max_eq_left (sub_nonneg.mpr h.le)]
    nlinarith
  · have : v ≤ p := le_of_not_gt h
    rw [posPart, max_eq_right (sub_nonpos.mpr this)]
    simp

end MatroidProphetSecretary
