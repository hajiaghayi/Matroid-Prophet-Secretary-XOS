import MatroidProphetSecretary.TwoPhasePrivateIntensity
import MatroidProphetSecretary.FiniteSupport

/-! Every accepted candidate carries the actual own value shared by its private tape. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

namespace FiniteLaw

theorem map_support_exists {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]
    (μ : FiniteLaw Ω) (f : Ω → Ψ) (y : Ψ) (hy : (μ.map f).mass y ≠ 0) :
    ∃ x, μ.mass x ≠ 0 ∧ f x = y := by
  obtain ⟨x,hx,hm⟩ := exists_ne_zero_of_sum_ne_zero hy
  by_cases he : f x = y
  · exact ⟨x,by simpa only [if_pos he] using hm,he⟩
  · exact False.elim (hm (if_neg he))

theorem bind_support_exists {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]
    (μ : FiniteLaw Ω) (ν : Ω → FiniteLaw Ψ) (y : Ψ) (hy : (μ.bind ν).mass y ≠ 0) :
    ∃ x, μ.mass x ≠ 0 ∧ (ν x).mass y ≠ 0 := by
  obtain ⟨x,hx,hm⟩ := exists_ne_zero_of_sum_ne_zero hy
  exact ⟨x,(mul_ne_zero_iff.mp hm).1,(mul_ne_zero_iff.mp hm).2⟩

theorem dependentPair_support {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]
    (μ : FiniteLaw Ω) (ν : Ω → FiniteLaw Ψ) (x : Ω × Ψ)
    (hx : (μ.dependentPair ν).mass x ≠ 0) : μ.mass x.1 ≠ 0 ∧ (ν x.1).mass x.2 ≠ 0 := by
  obtain ⟨a,ha,hb⟩ := bind_support_exists μ (fun a => (ν a).map (fun b => (a,b))) x hx
  obtain ⟨b,hbsupport,he⟩ := map_support_exists (ν a) (fun b => (a,b)) x hb
  subst x
  exact ⟨ha,hbsupport⟩

theorem sharedValueTapes_slot_support {V C D : Type*}
    [Fintype V] [Fintype C] [DecidableEq C] [Fintype D]
    (prior : FiniteLaw V) (slots : V → C → FiniteLaw D) (tape : V × (C → D))
    (ht : (sharedValueTapes prior slots).mass tape ≠ 0) (c : C) :
    (slots tape.1 c).mass (tape.2 c) ≠ 0 :=
  product_support (slots tape.1) tape.2 (dependentPair_support prior (fun v => product (slots v)) tape ht).2 c

end FiniteLaw

variable {E V : Type*} [Fintype E] [DecidableEq E] [Fintype V]

theorem conditionalScreenedCandidate_own_value (prior : FiniteLaw V)
    (references : E → FiniteLaw (Option V)) (e : E) (q : ℝ) (hq : 0 < q)
    (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v) (v : V) (y : E → Option V)
    (hy : (conditionalScreenedCandidate prior references e q hq hdom v).mass (some y) ≠ 0) : y e = some v := by
  obtain ⟨b,hb,hy⟩ := FiniteLaw.bind_support_exists _ _ _ hy
  obtain ⟨world,hw,he⟩ := FiniteLaw.map_support_exists _ _ _ hy
  cases b with
  | false => simp at he
  | true =>
    simp only [if_true,Option.some.injEq] at he
    rw [← he]
    exact Function.update_self _ _ _

theorem referencePrivateDecision_some {C P : Type*}
    (live : (E → Option V) → Prop) (pass : P → Prop) (c : C)
    (tape : V × (C → P × Option (E → Option V))) (y : E → Option V)
    (hy : referencePrivateDecision live pass c tape = some y) :
    (tape.2 c).2 = some y ∧ live y := by
  unfold referencePrivateDecision attenuateOption at hy
  by_cases hp : pass (tape.2 c).1
  · rw [if_pos hp] at hy
    cases hc : (tape.2 c).2 with
    | none => simp [hc,liveCandidate] at hy
    | some z =>
      by_cases hz : live z
      · simp only [hc,liveCandidate,if_pos hz,Option.some.injEq] at hy
        subst y
        exact ⟨rfl,hz⟩
      · simp [hc,liveCandidate,hz] at hy
  · simp [hp] at hy

theorem phasePrivateDecision_some {L : ℕ} (cut : ℕ) (live : ℕ → (E → Option V) → Prop)
    (c : Fin L) (tape : V × (Fin L → (Fin L → Bool × (E → Option V)) × Option (E → Option V)))
    (y : E → Option V) (hy : phasePrivateDecision cut live c tape = some y) :
    (tape.2 c).2 = some y ∧ live c.val y := by
  unfold phasePrivateDecision at hy
  split_ifs at hy
  · exact referencePrivateDecision_some _ _ _ tape y hy
  · exact referencePrivateDecision_some _ _ _ tape y hy

theorem phasePrivateDecision_own_value (prior : FiniteLaw V) (references : E → FiniteLaw (Option V))
    (e : E) (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (L : ℕ) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) (cut : ℕ)
    (live : ℕ → (E → Option V) → Prop) (c : Fin L)
    (tape : V × (Fin L → (Fin L → Bool × (E → Option V)) × Option (E → Option V)))
    (ht : (earlyPrivateTapeLaw prior references e q hq hdom L p hp0 hp1).mass tape ≠ 0)
    (y : E → Option V) (hy : phasePrivateDecision cut live c tape = some y) : y e = some tape.1 := by
  have hs := FiniteLaw.sharedValueTapes_slot_support prior
    (fun (v : V) (_ : Fin L) => (gridProbeLaw (FiniteLaw.product references) L p hp0 hp1).pair
      (conditionalScreenedCandidate prior references e q hq hdom v)) tape ht c
  have hk : (conditionalScreenedCandidate prior references e q hq hdom tape.1).mass ((tape.2 c).2) ≠ 0 :=
    (mul_ne_zero_iff.mp hs).2
  rw [(phasePrivateDecision_some cut live c tape y hy).1] at hk
  exact conditionalScreenedCandidate_own_value prior references e q hq hdom tape.1 y hk

end MatroidProphetSecretary
