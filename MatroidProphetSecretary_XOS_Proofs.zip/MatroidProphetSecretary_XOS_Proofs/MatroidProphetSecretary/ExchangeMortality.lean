import MatroidProphetSecretary.ExchangeInvariant
import MatroidProphetSecretary.FiniteProbability
import Mathlib.Tactic.Positivity

/-! The unique-killer exchange map bounds the integrated death intensity of a live target. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def sourceKillRate {M : Matroid E} {C B : Finset E} (phi : ExchangeMap M C B)
    (live : E → Prop) (rate : E → ℝ) (target : E) : ℝ :=
  ∑ e, if e ∈ C ∧ live e ∧ phi.map e = target then rate e else 0

theorem sourceKillRate_nonneg {M : Matroid E} {C B : Finset E} (phi : ExchangeMap M C B)
    (live : E → Prop) (rate : E → ℝ) (hrate : ∀ e, 0 ≤ rate e) (target : E) :
    0 ≤ sourceKillRate phi live rate target := by
  apply sum_nonneg
  intro e he
  split_ifs
  · exact hrate e
  · exact le_rfl

theorem sourceKillRate_le {M : Matroid E} {C B : Finset E} (phi : ExchangeMap M C B)
    (live : E → Prop) (rate : E → ℝ) (R : ℝ) (hR : 0 ≤ R) (hrate : ∀ e, rate e ≤ R) (target : E) :
    sourceKillRate phi live rate target ≤ R := by
  by_cases hex : ∃ e, e ∈ C ∧ live e ∧ phi.map e = target
  · obtain ⟨e,he⟩ := hex
    have hsum : sourceKillRate phi live rate target = rate e := by
      unfold sourceKillRate
      rw [sum_eq_single e]
      · simp [he]
      · intro f hf hfe
        have hn : ¬ (f ∈ C ∧ live f ∧ phi.map f = target) := by
          rintro ⟨hfC,_,hfkill⟩
          exact hfe (phi.inj f hfC e he.1 (hfkill.trans he.2.2.symm))
        simp [hn]
      · simp
    rw [hsum]
    exact hrate e
  · have hnone (e : E) : ¬ (e ∈ C ∧ live e ∧ phi.map e = target) := fun h => hex ⟨e,h⟩
    simp only [sourceKillRate,if_neg (hnone _),sum_const_zero]
    exact hR

theorem integrated_killing_intensity_le {W : Type*} [Fintype W] (μ : FiniteLaw W)
    {M : Matroid E} {B : Finset E} (C : W → Finset E) (phi : ∀ y, ExchangeMap M (C y) B)
    (live : E → W → Prop) (rate : E → ℝ) (R : ℝ) (hR : 0 ≤ R) (hrate : ∀ e, rate e ≤ R) (target : E) :
    μ.expect (fun y => sourceKillRate (phi y) (fun e => live e y) rate target) ≤ R := by
  calc
    _ ≤ μ.expect (fun _ => R) := μ.expect_mono (fun y => sourceKillRate_le (phi y) _ rate R hR hrate target)
    _ = R := μ.expect_const R

theorem integrated_killing_probability_le {W : Type*} [Fintype W] (μ : FiniteLaw W)
    {M : Matroid E} {B : Finset E} (C : W → Finset E) (phi : ∀ y, ExchangeMap M (C y) B)
    (live : E → W → Prop) (rate : E → ℝ) (R dt : ℝ) (hR : 0 ≤ R) (hdt : 0 ≤ dt)
    (hrate : ∀ e, rate e ≤ R) (target : E) :
    μ.expect (fun y => ∑ e, if e ∈ C y ∧ live e y ∧ (phi y).map e = target then dt*rate e else 0) ≤ dt*R := by
  have heq : (fun y => ∑ e, if e ∈ C y ∧ live e y ∧ (phi y).map e = target then dt*rate e else 0) =
      (fun y => dt * sourceKillRate (phi y) (fun e => live e y) rate target) := by
    funext y
    simp only [sourceKillRate,mul_sum]
    apply sum_congr rfl
    intro e he
    split_ifs <;> simp
  rw [heq,FiniteLaw.expect_const_mul]
  exact mul_le_mul_of_nonneg_left (integrated_killing_intensity_le μ C phi live rate R hR hrate target) hdt

end MatroidProphetSecretary
