import Mathlib.Data.Real.Basic
import Mathlib.Algebra.BigOperators.Field
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.Order.BigOperators.Ring.Finset
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Positivity

/-! Finite probability spaces for the finite-prior part of the proof. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset

structure FiniteLaw (Ω : Type*) [Fintype Ω] where
  mass : Ω → ℝ
  nonneg : ∀ w, 0 ≤ mass w
  total : ∑ w, mass w = 1

namespace FiniteLaw

variable {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω)

def uniform (Ω : Type*) [Fintype Ω] [Nonempty Ω] : FiniteLaw Ω where
  mass _ := 1 / Fintype.card Ω
  nonneg _ := by positivity
  total := by
    have hn : (Fintype.card Ω : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
    simp [Finset.sum_const, nsmul_eq_mul, hn]

def product {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)] (laws : ∀ i, FiniteLaw (V i)) :
    FiniteLaw (∀ i, V i) where
  mass x := ∏ i, (laws i).mass (x i)
  nonneg x := Finset.prod_nonneg (fun i _ => (laws i).nonneg (x i))
  total := by
    rw [← Fintype.prod_sum]
    simp only [FiniteLaw.total, Finset.prod_const_one]

def expect (f : Ω → ℝ) : ℝ := ∑ w, μ.mass w * f w

def prob (event : Ω → Prop) [DecidablePred event] : ℝ :=
  μ.expect (fun w => if event w then 1 else 0)

theorem expect_mono {f g : Ω → ℝ} (h : ∀ w, f w ≤ g w) :
    μ.expect f ≤ μ.expect g :=
  sum_le_sum (fun w _ => mul_le_mul_of_nonneg_left (h w) (μ.nonneg w))

theorem expect_nonneg {f : Ω → ℝ} (h : ∀ w, 0 ≤ f w) : 0 ≤ μ.expect f :=
  sum_nonneg (fun w _ => mul_nonneg (μ.nonneg w) (h w))

@[simp] theorem expect_const (c : ℝ) : μ.expect (fun _ => c) = c := by
  simp [expect, ← sum_mul, μ.total]

theorem expect_add (f g : Ω → ℝ) :
    μ.expect (fun w => f w + g w) = μ.expect f + μ.expect g := by
  simp [expect, mul_add, sum_add_distrib]

theorem expect_sub (f g : Ω → ℝ) :
    μ.expect (fun w => f w - g w) = μ.expect f - μ.expect g := by
  simp [expect, mul_sub, sum_sub_distrib]

theorem expect_mul_const (f : Ω → ℝ) (c : ℝ) :
    μ.expect (fun w => f w * c) = μ.expect f * c := by
  simp [expect, mul_assoc, sum_mul]

theorem expect_const_mul (f : Ω → ℝ) (c : ℝ) :
    μ.expect (fun w => c * f w) = c * μ.expect f := by
  simp only [expect, mul_sum]
  apply sum_congr rfl
  intro w hw
  ring

theorem prob_nonneg (event : Ω → Prop) [DecidablePred event] :
    0 ≤ μ.prob event := by
  apply μ.expect_nonneg
  intro w
  split_ifs <;> norm_num

theorem prob_le_one (event : Ω → Prop) [DecidablePred event] :
    μ.prob event ≤ 1 := by
  rw [← μ.expect_const 1]
  apply μ.expect_mono
  intro w
  split_ifs <;> norm_num

/-- Bounded welfare under a coupling: agreement off a bad event loses at
most its probability times the pointwise welfare bound. -/
theorem coupling_welfare_loss (f g : Ω → ℝ) (bad : Ω → Prop)
    [DecidablePred bad] (B : ℝ)
    (hf : ∀ w, f w ≤ B) (hg : ∀ w, 0 ≤ g w)
    (heq : ∀ w, ¬ bad w → f w = g w) :
    μ.expect f - μ.expect g ≤ B * μ.prob bad := by
  have pointwise : ∀ w, f w - g w ≤ B * (if bad w then 1 else 0) := by
    intro w
    by_cases hw : bad w
    · simp only [hw, if_true, mul_one]
      linarith [hf w, hg w]
    · simp only [hw, if_false, mul_zero, heq w hw, sub_self, le_refl]
  have h := μ.expect_mono pointwise
  rw [μ.expect_sub, μ.expect_const_mul] at h
  exact h

/-- A finite union bound, allowing arbitrarily dependent bad events. -/
theorem union_bound {ι : Type*} [Fintype ι] (bad : ι → Ω → Prop)
    [∀ i, DecidablePred (bad i)] :
    μ.prob (fun w => ∃ i, bad i w) ≤ ∑ i, μ.prob (bad i) := by
  classical
  have pointwise : ∀ w, (if ∃ i, bad i w then (1 : ℝ) else 0) ≤
      ∑ i, if bad i w then 1 else 0 := by
    intro w
    split_ifs with h
    · obtain ⟨i, hi⟩ := h
      exact le_trans (by simp [hi])
        (single_le_sum (fun j _ => by split_ifs <;> norm_num) (mem_univ i))
    · apply sum_nonneg
      intro i hi
      split_ifs <;> norm_num
  have h := μ.expect_mono pointwise
  dsimp [prob, expect] at h ⊢
  simp_rw [mul_sum] at h
  rw [sum_comm] at h
  exact h

end FiniteLaw

end MatroidProphetSecretary
