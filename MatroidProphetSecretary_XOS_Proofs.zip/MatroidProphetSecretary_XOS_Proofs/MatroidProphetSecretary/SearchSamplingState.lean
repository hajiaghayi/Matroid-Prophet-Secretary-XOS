import MatroidProphetSecretary.ReferenceSearchAlgorithm
import MatroidProphetSecretary.FiniteTraceLaw

/-! A state machine for the actual initial query and its adaptive midpoint queries. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

abbrev SearchQueryState := ℝ ⊕ (Bool × SearchBracket)

def searchQueryPoint : SearchQueryState → ℝ
  | Sum.inl q => q
  | Sum.inr state => state.2.midpoint

def searchDirectionTest {B : Type*} (positive negative : ℝ → B → Bool) (direction : Bool) : ℝ → B → Bool :=
  if direction then positive else fun q x => !(negative q x)

def searchQueryStep {B : Type*} (positive negative : ℝ → B → Bool) (δ : ℝ) : SearchQueryState → B → SearchQueryState
  | Sum.inl q, batch =>
      if positive q batch then Sum.inr (true,⟨q,1+4*δ⟩)
      else if negative q batch then Sum.inr (false,⟨1-4*δ,q⟩)
      else Sum.inr (true,⟨q,q⟩)
  | Sum.inr state, batch =>
      Sum.inr (state.1,bisectBracket (searchDirectionTest positive negative state.1 state.2.midpoint batch) state.2)

def SearchQueryValid (δ : ℝ) : SearchQueryState → Prop
  | Sum.inl q => q ∈ searchInterval δ
  | Sum.inr state => 1-4*δ ≤ state.2.lower ∧ state.2.lower ≤ state.2.upper ∧ state.2.upper ≤ 1+4*δ

theorem searchQueryPoint_mem (δ : ℝ) (state : SearchQueryState) (hs : SearchQueryValid δ state) :
    searchQueryPoint state ∈ searchInterval δ := by
  cases state with
  | inl q => exact hs
  | inr state =>
    have hm := midpoint_mem_bracket state.2 hs.2.1
    exact ⟨hs.1.trans hm.1,hm.2.trans hs.2.2⟩

theorem searchQueryStep_valid {B : Type*} (positive negative : ℝ → B → Bool) (δ : ℝ)
    (state : SearchQueryState) (hs : SearchQueryValid δ state) (batch : B) :
    SearchQueryValid δ (searchQueryStep positive negative δ state batch) := by
  cases state with
  | inl q =>
    change 1-4*δ ≤ q ∧ q ≤ 1+4*δ at hs
    simp only [searchQueryStep]
    split_ifs
    · exact ⟨hs.1,hs.2,le_rfl⟩
    · exact ⟨le_rfl,hs.1,hs.2⟩
    · exact ⟨hs.1,le_rfl,hs.2⟩
  | inr state =>
    have h := bisectBracket_nested (searchDirectionTest positive negative state.1 state.2.midpoint batch) state.2 hs.2.1
    exact ⟨hs.1.trans h.1,h.2.1,h.2.2.trans hs.2.2⟩

theorem searchQueryScan_branch {B : Type*} (positive negative : ℝ → B → Bool) (δ : ℝ)
    (direction : Bool) (bracket : SearchBracket) (batches : ℕ → B) (n : ℕ) :
    FiniteLaw.scanState (searchQueryStep positive negative δ) (Sum.inr (direction,bracket)) batches n =
      Sum.inr (direction,feedbackBracket (searchDirectionTest positive negative direction) batches n bracket) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [FiniteLaw.scanState,ih]
    rfl

theorem searchQueryScan_valid {B : Type*} (positive negative : ℝ → B → Bool) (δ : ℝ)
    (state : SearchQueryState) (hs : SearchQueryValid δ state) (batches : ℕ → B) (n : ℕ) :
    SearchQueryValid δ (FiniteLaw.scanState (searchQueryStep positive negative δ) state batches n) := by
  induction n with
  | zero => exact hs
  | succ n ih => exact searchQueryStep_valid positive negative δ _ ih (batches n)

end MatroidProphetSecretary
