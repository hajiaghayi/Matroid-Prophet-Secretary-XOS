import MatroidProphetSecretary.LiftedVirtualProcess
import MatroidProphetSecretary.IndexedAdaptiveDrift

/-! Late exchange reward with rate lower bounds needed only on supported states within the horizon. -/

noncomputable section

namespace MatroidProphetSecretary

variable {E W S : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem supported_virtual_late_gain (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (project : S → VirtualState M) (update : S → Option (E × W) → S)
    (hupdate : ∀ s x, project (update s x) = virtualUpdate M base hbase value (project s) x)
    (multiplier : E → ℝ) (hm : ∀ e, 0 ≤ multiplier e)
    (dt lam omega : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (hstep : dt*(lam/omega) ≤ 1) (hsmall : dt*(lam/omega)*Fintype.card E ≤ 1)
    (rate : S → E → ℝ) (hrate0 : ∀ s e, 0 ≤ rate s e) (hrate1 : ∀ s e, rate s e ≤ lam/omega)
    (total : S → ℝ) (Good : ℕ → S → Prop) (n offset : ℕ) (s : S) (hs : Good offset s)
    (hpreserve : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state → ∀ x,
      (virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
        hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall).mass x ≠ 0 →
      Good (j+1) (update state x))
    (hlower : ∀ j, offset ≤ j → j < offset+n → ∀ state, Good j state → ∀ e, lam*multiplier e ≤ rate state e)
    (hcredit : ∀ state,
      (virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
        hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall).expect
        (fun x => total (update state x)) = total state+
      (virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
        hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall).expect
        (virtualCredit M base hbase value (project state))) :
    total s+omega*(1-(1-dt*(lam/omega))^n)*virtualWeightedLiveValue μ M base hbase value multiplier (project s) ≤
      (FiniteLaw.adaptiveBatches
        (fun state => virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
          hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall)
        update n s).expect (fun x => total (FiniteLaw.stateAfter update n s x)) := by
  let batch := fun state => virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
    hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall
  let potential := fun state => omega*virtualWeightedLiveValue μ M base hbase value multiplier (project state)
  have hpersist (state : S) : (1-dt*(lam/omega))*potential state ≤
      (batch state).expect (fun event => potential (update state event)) := by
    simp only [potential,hupdate,FiniteLaw.expect_const_mul]
    have h := mul_le_mul_of_nonneg_left
      (virtualStep_weighted_persistence μ M base hbase value hv multiplier hm (project state) dt (rate state)
        (lam/omega) hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall) homega.le
    convert h using 1 <;> ring
  have hgain (j : ℕ) (hj : offset ≤ j) (hjn : j < offset+n) (state : S) (hstate : Good j state) :
      total state+(1-(1-dt*(lam/omega)))*potential state ≤ (batch state).expect (fun x => total (update state x)) := by
    rw [hcredit]
    apply add_le_add_left
    have h := virtualStep_weighted_credit μ M base hbase value hv multiplier lam (project state) dt (rate state)
      (lam/omega) hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall (hlower j hj hjn state hstate)
    convert h using 1
    dsimp only [potential]
    field_simp
    <;> ring
  have h := FiniteLaw.adaptive_gain_lower_on_interval batch update total potential Good n offset s hs
    (1-dt*(lam/omega)) (sub_nonneg.mpr hstep)
    (sub_le_self _ (mul_nonneg hdt (div_nonneg hlam homega.le)))
    hpreserve (fun _ _ _ state _ => hpersist state) hgain
  convert h using 1
  dsimp only [potential]
  ring

end MatroidProphetSecretary
