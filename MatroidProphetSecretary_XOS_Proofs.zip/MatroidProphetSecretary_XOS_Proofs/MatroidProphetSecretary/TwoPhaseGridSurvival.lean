import MatroidProphetSecretary.OneArrivalGrid

/-! Survival for attenuated early slots followed by unattenuated late slots. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def phaseArrivalMass (dose : ℕ → ℝ) (cut i : ℕ) : ℝ :=
  if i < cut then gridSurvival dose i*dose i else dose i

def phaseSurvival (dose : ℕ → ℝ) (cut n : ℕ) : ℝ :=
  1-∑ i ∈ range n, phaseArrivalMass dose cut i

theorem phaseSurvival_early (dose : ℕ → ℝ) (cut n : ℕ) (hn : n ≤ cut) :
    phaseSurvival dose cut n = gridSurvival dose n := by
  have he : (∑ i ∈ range n, phaseArrivalMass dose cut i) =
      ∑ i ∈ range n, gridSurvival dose i*dose i := by
    apply sum_congr rfl
    intro i hi
    exact if_pos ((mem_range.mp hi).trans_le hn)
  rw [phaseSurvival,he,gridSurvival_mass]
  ring

theorem phaseSurvival_late (dose : ℕ → ℝ) (cut n : ℕ) :
    phaseSurvival dose cut (cut+n) = gridSurvival dose cut-∑ i ∈ range n, dose (cut+i) := by
  have he : (∑ i ∈ range n, phaseArrivalMass dose cut (cut+i)) = ∑ i ∈ range n, dose (cut+i) := by
    apply sum_congr rfl
    intro i hi
    exact if_neg (by omega)
  have hc := phaseSurvival_early dose cut cut le_rfl
  unfold phaseSurvival at hc ⊢
  rw [sum_range_add,he]
  linarith only [hc]

theorem phaseSurvival_bounds (dose : ℕ → ℝ) (p : ℝ) (hp : p ≤ 1)
    (hd0 : ∀ i, 0 ≤ dose i) (hd1 : ∀ i, dose i ≤ p) (cut n : ℕ) :
    (1-p)^cut-n*p ≤ phaseSurvival dose cut (cut+n) ∧
      phaseSurvival dose cut (cut+n) ≤ gridSurvival dose cut := by
  rw [phaseSurvival_late]
  have hs0 : 0 ≤ ∑ i ∈ range n, dose (cut+i) := sum_nonneg (fun i _ => hd0 _)
  have hs1 : (∑ i ∈ range n, dose (cut+i)) ≤ n*p := by
    calc
      _ ≤ ∑ i ∈ range n, p := sum_le_sum (fun i _ => hd1 _)
      _ = _ := by simp
  constructor
  · linarith [gridSurvival_lower dose p hp hd1 cut]
  · linarith

theorem phaseSurvival_rate_bounds (dose : ℕ → ℝ)
    (hd0 : ∀ i, 0 ≤ dose i) (hd1 : ∀ i, dose i < 1)
    (cut n : ℕ) (lam omega : ℝ) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (hlower : omega ≤ phaseSurvival dose cut (cut+n)) :
    lam*(1+accumulatedExposure dose cut) ≤ lam/phaseSurvival dose cut (cut+n) ∧
      lam/phaseSurvival dose cut (cut+n) ≤ lam/omega := by
  have hS := homega.trans_le hlower
  have hSupper : phaseSurvival dose cut (cut+n) ≤ gridSurvival dose cut := by
    rw [phaseSurvival_late]
    exact sub_le_self _ (sum_nonneg (fun i _ => hd0 _))
  constructor
  · have h1 := mul_le_mul_of_nonneg_left (gridSurvival_inverse_exposure dose hd0 hd1 cut) hlam
    rw [mul_one_div] at h1
    exact h1.trans (div_le_div_of_nonneg_left hlam hS hSupper)
  · exact div_le_div_of_nonneg_left hlam homega hlower

theorem oneArrival_phase_survival {Ω A : Type*} [Fintype Ω]
    (L : ℕ) (hL : 0 < L) (tape : FiniteLaw Ω) (decision : Fin L → Ω → Option A)
    (dose : ℕ → ℝ) (cut n : ℕ) (hn : n ≤ L)
    (hkernel : ∀ i : Fin L, i.val < n →
      tape.prob (fun w => decision i w ≠ none) = (L:ℝ)*phaseArrivalMass dose cut i.val) :
    letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
    ((FiniteLaw.uniform (Fin L)).pair tape).prob
      (FiniteLaw.oneArrivalAbsent (fun t => t.val < n) decision) = phaseSurvival dose cut n := by
  letI : Nonempty (Fin L) := ⟨⟨0,hL⟩⟩
  rw [FiniteLaw.oneArrival_survival]
  have hL' : (L:ℝ) ≠ 0 := by exact_mod_cast hL.ne'
  have hpoint (i : Fin L) :
      (if i.val < n then (FiniteLaw.uniform (Fin L)).mass i*tape.prob (fun w => decision i w ≠ none) else 0) =
      if i.val < n then phaseArrivalMass dose cut i.val else 0 := by
    by_cases hi : i.val < n
    · rw [if_pos hi,if_pos hi,hkernel i hi]
      simp [FiniteLaw.uniform,Fintype.card_fin,hL']
    · simp only [hi,if_false]
  calc
    _ = 1-∑ i : Fin L, if i.val < n then phaseArrivalMass dose cut i.val else 0 := by
      congr 1
      apply sum_congr rfl
      intro i hi
      convert hpoint i using 1
      split_ifs
      · congr 1
      · rfl
    _ = _ := by rw [sum_fin_initial_segment _ L n hn]; rfl

end MatroidProphetSecretary
