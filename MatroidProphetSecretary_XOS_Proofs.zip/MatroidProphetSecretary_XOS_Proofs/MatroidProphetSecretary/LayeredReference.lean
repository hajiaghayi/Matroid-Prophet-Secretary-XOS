import MatroidProphetSecretary.ReferenceLayerScaling

/-! Reference analysis for finite weighted families of Bernoulli value layers.
The identification of these layer sums with a prior's reference distributions is a separate step. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E ι : Type*} [Fintype E] [DecidableEq E] [Fintype ι]

def layeredReferenceRank (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) (q : ℝ) : ℝ :=
  ∑ i, width i * referenceLayerRank M (tail i) q

def layeredReferenceD (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) (q : ℝ) : ℝ :=
  ∑ i, width i * referenceLayerD M (tail i) q

def layeredReferenceH (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) (q : ℝ) : ℝ :=
  ∑ i, width i * referenceLayerH M (tail i) q

def layeredReferenceRightDerivative (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) (q : ℝ) : ℝ :=
  ∑ i, width i * referenceLayerRightDerivative M (tail i) q

def layeredReferenceLeftDerivative (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) (q : ℝ) : ℝ :=
  ∑ i, width i * referenceLayerLeftDerivative M (tail i) q

theorem layeredReferenceRank_continuous (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) :
    Continuous (layeredReferenceRank M width tail) :=
  continuous_finset_sum _ (fun i _ => continuous_const.mul (referenceLayerRank_continuous M (tail i)))

theorem layeredReferenceRank_zero (M : Matroid E) (width : ι → ℝ) (tail : ι → E → ℝ) :
    layeredReferenceRank M width tail 0 = 0 := by
  simp [layeredReferenceRank, referenceLayerRank_zero]

theorem layeredReferenceRank_monotone (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (width : ι → ℝ) (tail : ι → E → ℝ) (hw : ∀ i, 0 ≤ width i) (hp : ∀ i e, 0 ≤ tail i e) :
    MonotoneOn (layeredReferenceRank M width tail) (Set.Ici 0) := by
  intro q hq r hr hqr
  exact sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left
    (referenceLayerRank_monotone M hground (tail i) (hp i) hq hr hqr) (hw i))

theorem layeredReferenceRank_concave (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (width : ι → ℝ) (tail : ι → E → ℝ) (hw : ∀ i, 0 ≤ width i) (hp : ∀ i e, 0 ≤ tail i e) :
    ConcaveOn ℝ (Set.Ici 0) (layeredReferenceRank M width tail) := by
  refine ⟨convex_Ici 0, ?_⟩
  intro q hq r hr a b ha hb hab
  simp only [layeredReferenceRank, smul_eq_mul, mul_sum, ← sum_add_distrib]
  apply sum_le_sum
  intro i hi
  have h := mul_le_mul_of_nonneg_left
    ((referenceLayerRank_concave M hground (tail i) (hp i)).2 hq hr ha hb hab) (hw i)
  simp only [smul_eq_mul] at h
  nlinarith

theorem layeredReferenceRank_right_derivative (M : Matroid E)
    (width : ι → ℝ) (tail : ι → E → ℝ) (hp : ∀ i e, 0 ≤ tail i e) (q : ℝ) :
    HasDerivWithinAt (layeredReferenceRank M width tail) (layeredReferenceRightDerivative M width tail q)
      (Set.Ici q) q :=
  HasDerivWithinAt.sum (u := univ) (fun i _ =>
    (referenceLayerRank_right_derivative M (tail i) (hp i) q).const_mul (width i))

theorem layeredReferenceRank_left_derivative (M : Matroid E)
    (width : ι → ℝ) (tail : ι → E → ℝ) (hp : ∀ i e, 0 ≤ tail i e) (q : ℝ) :
    HasDerivWithinAt (layeredReferenceRank M width tail) (layeredReferenceLeftDerivative M width tail q)
      (Set.Iic q) q :=
  HasDerivWithinAt.sum (u := univ) (fun i _ =>
    (referenceLayerRank_left_derivative M (tail i) (hp i) q).const_mul (width i))

theorem layeredReference_derivative_bounds (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (width : ι → ℝ) (tail : ι → E → ℝ) (hw : ∀ i, 0 ≤ width i) (hp : ∀ i e, 0 ≤ tail i e)
    (q : ℝ) (hq : 0 ≤ q) :
    layeredReferenceD M width tail q - layeredReferenceH M width tail q ≤
        q * layeredReferenceRightDerivative M width tail q ∧
      q * layeredReferenceRightDerivative M width tail q ≤ q * layeredReferenceLeftDerivative M width tail q ∧
      q * layeredReferenceLeftDerivative M width tail q ≤ layeredReferenceD M width tail q := by
  have hi := fun i => referenceLayer_derivative_bounds M hground (tail i) (hp i) q hq
  constructor
  · unfold layeredReferenceD layeredReferenceH layeredReferenceRightDerivative
    rw [← sum_sub_distrib, mul_sum]
    apply sum_le_sum
    intro i hmem
    have h := mul_le_mul_of_nonneg_left (hi i).1 (hw i)
    nlinarith
  constructor
  · unfold layeredReferenceRightDerivative layeredReferenceLeftDerivative
    rw [mul_sum, mul_sum]
    apply sum_le_sum
    intro i hmem
    have h := mul_le_mul_of_nonneg_left (hi i).2.1 (hw i)
    nlinarith
  · unfold layeredReferenceLeftDerivative layeredReferenceD
    rw [mul_sum]
    apply sum_le_sum
    intro i hmem
    have h := mul_le_mul_of_nonneg_left (hi i).2.2 (hw i)
    nlinarith

theorem layeredReferenceRank_scaling (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (width : ι → ℝ) (tail : ι → E → ℝ) (hw : ∀ i, 0 ≤ width i) (hp : ∀ i e, 0 ≤ tail i e)
    (q : ℝ) (hq : 0 ≤ q) :
    min 1 q * layeredReferenceRank M width tail 1 ≤ layeredReferenceRank M width tail q ∧
      layeredReferenceRank M width tail q ≤ max 1 q * layeredReferenceRank M width tail 1 :=
  concave_zero_scaling _ (layeredReferenceRank_concave M hground width tail hw hp)
    (layeredReferenceRank_monotone M hground width tail hw hp) (layeredReferenceRank_zero M width tail) q hq

end MatroidProphetSecretary
