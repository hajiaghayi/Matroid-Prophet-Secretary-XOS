import MatroidProphetSecretary.BalancedQueryTree
import MatroidProphetSecretary.FundamentalCircuitOracle

/-! Fundamental-circuit group tests recover all coloops while charging each removed basis element once. -/

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

variable {E : Type*} [DecidableEq E]

def coloopRecoveryRun (oracle : Finset E → Bool) (B : Finset E) (tree : QueryTree E) :
    List E → Finset E → Finset E × ℕ
  | [], U => (U,0)
  | f :: rest, U =>
      let first := groupTest (fundamentalCircuitTest oracle B f) tree U
      let tail := coloopRecoveryRun oracle B tree rest first.1
      (tail.1,first.2+tail.2)

theorem coloopRecoveryRun_correct (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (B : Finset E) (hB : M.IsBase (B : Set E))
    (tree : QueryTree E) (htree : tree.labels = B) (xs : List E)
    (hxs : ∀ f ∈ xs, f ∈ M.E ∧ f ∉ B) (U : Finset E) (hU : U ⊆ B) :
    (coloopRecoveryRun oracle B tree xs U).1 = U.filter (fun e => ∀ f ∈ xs, e ∉ M.fundCircuit f (B : Set E)) := by
  induction xs generalizing U with
  | nil => simp [coloopRecoveryRun]
  | cons f rest ih =>
    let test := fundamentalCircuitTest oracle B f
    let bad := fun e => e ∈ B ∧ e ∈ M.fundCircuit f (B : Set E)
    have htest : ∀ S, test S = true ↔ ∃ e ∈ S, bad e :=
      fundamentalCircuitTest_spec M oracle horacle B hB f (hxs f (by simp)).1 (hxs f (by simp)).2
    have hfirst := groupTest_correct test bad htest tree U
    have hsub := groupTest_subset test bad htest tree U
    simp only [coloopRecoveryRun]
    rw [ih (fun g hg => hxs g (by simp [hg])) _ (hsub.trans hU),hfirst,filter_filter]
    ext e
    simp only [mem_filter,htree,List.mem_cons,forall_eq_or_imp]
    by_cases he : e ∈ U
    · have heB := hU he
      simp only [he,heB,true_and,not_true_eq_false,false_or,bad,true_and]
    · simp [he]

theorem coloopRecoveryRun_subset (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (B : Finset E) (hB : M.IsBase (B : Set E))
    (tree : QueryTree E) (htree : tree.labels = B) (xs : List E)
    (hxs : ∀ f ∈ xs, f ∈ M.E ∧ f ∉ B) (U : Finset E) (hU : U ⊆ B) :
    (coloopRecoveryRun oracle B tree xs U).1 ⊆ U := by
  rw [coloopRecoveryRun_correct M oracle horacle B hB tree htree xs hxs U hU]
  exact filter_subset _ _

theorem coloopRecoveryRun_query_bound (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (B : Finset E) (hB : M.IsBase (B : Set E))
    (tree : QueryTree E) (htree : tree.labels = B) (xs : List E)
    (hxs : ∀ f ∈ xs, f ∈ M.E ∧ f ∉ B) (U : Finset E) (hU : U ⊆ B) :
    (coloopRecoveryRun oracle B tree xs U).2 ≤
      xs.length+2*tree.depth*(U.card-(coloopRecoveryRun oracle B tree xs U).1.card) := by
  induction xs generalizing U with
  | nil => simp [coloopRecoveryRun]
  | cons f rest ih =>
    let test := fundamentalCircuitTest oracle B f
    let bad := fun e => e ∈ B ∧ e ∈ M.fundCircuit f (B : Set E)
    have htest : ∀ S, test S = true ↔ ∃ e ∈ S, bad e :=
      fundamentalCircuitTest_spec M oracle horacle B hB f (hxs f (by simp)).1 (hxs f (by simp)).2
    let first := groupTest test tree U
    let tail := coloopRecoveryRun oracle B tree rest first.1
    have hsub := groupTest_subset test bad htest tree U
    have hrest : ∀ g ∈ rest, g ∈ M.E ∧ g ∉ B := fun g hg => hxs g (by simp [hg])
    have hsub' := coloopRecoveryRun_subset M oracle horacle B hB tree htree rest hrest first.1 (hsub.trans hU)
    have hfirst := groupTest_query_bound test bad htest tree U
    have htail := ih hrest first.1 (hsub.trans hU)
    change first.2 ≤ 1+2*tree.depth*(U.card-first.1.card) at hfirst
    change tail.2 ≤ rest.length+2*tree.depth*(first.1.card-tail.1.card) at htail
    have hcard : (U.card-first.1.card)+(first.1.card-tail.1.card) = U.card-tail.1.card := by
      have h1 : first.1.card ≤ U.card := card_le_card hsub
      have h2 : tail.1.card ≤ first.1.card := card_le_card hsub'
      omega
    change first.2+tail.2 ≤ (rest.length+1)+2*tree.depth*(U.card-tail.1.card)
    nlinarith

end MatroidProphetSecretary
