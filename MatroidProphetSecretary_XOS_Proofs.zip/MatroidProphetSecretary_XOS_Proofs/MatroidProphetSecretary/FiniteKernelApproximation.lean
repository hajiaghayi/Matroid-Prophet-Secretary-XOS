import MatroidProphetSecretary.AdaptiveBatches
import MatroidProphetSecretary.BernoulliVariation

/-! Quantitative propagation of finite transition-law errors to the full adaptive trajectory. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {Ω S : Type*} [Fintype Ω]

def massDistance (μ ν : FiniteLaw Ω) : ℝ := ∑ x, |μ.mass x-ν.mass x|

theorem massDistance_nonneg (μ ν : FiniteLaw Ω) : 0 ≤ massDistance μ ν :=
  sum_nonneg (fun x _ => abs_nonneg _)

theorem expect_difference_massDistance (μ ν : FiniteLaw Ω) (f : Ω → ℝ) (B : ℝ)
    (hf : ∀ x, |f x| ≤ B) : |μ.expect f-ν.expect f| ≤ B*massDistance μ ν := by
  have he : μ.expect f-ν.expect f = ∑ x, (μ.mass x-ν.mass x)*f x := by
    simp only [expect,sub_mul,sum_sub_distrib]
  rw [he]
  calc
    _ ≤ ∑ x, |(μ.mass x-ν.mass x)*f x| := abs_sum_le_sum_abs _ _
    _ ≤ ∑ x, |μ.mass x-ν.mass x| * B := by
      apply sum_le_sum
      intro x hx
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_left (hf x) (abs_nonneg _)
    _ = B*massDistance μ ν := by rw [← sum_mul]; unfold massDistance; ring

theorem expect_difference_functions (μ : FiniteLaw Ω) (f g : Ω → ℝ) (B : ℝ)
    (h : ∀ x, |f x-g x| ≤ B) : |μ.expect f-μ.expect g| ≤ B := by
  rw [← expect_sub]
  exact (abs_expect_le μ _).trans ((μ.expect_mono h).trans_eq (expect_const μ B))

theorem expect_abs_bound (μ : FiniteLaw Ω) (f : Ω → ℝ) (B : ℝ)
    (hf : ∀ x, |f x| ≤ B) : |μ.expect f| ≤ B :=
  (abs_expect_le μ f).trans ((μ.expect_mono hf).trans_eq (expect_const μ B))

theorem adaptiveBatches_expect_approximation (batch other : S → FiniteLaw Ω)
    (update : S → Ω → S) (err B : ℝ) (hB : 0 ≤ B)
    (hstep : ∀ s, massDistance (batch s) (other s) ≤ err)
    (n : ℕ) (s : S) (f : (Fin n → Ω) → ℝ) (hf : ∀ x, |f x| ≤ B) :
    |(adaptiveBatches batch update n s).expect f-(adaptiveBatches other update n s).expect f| ≤ n*err*B := by
  induction n generalizing s with
  | zero => simp [adaptiveBatches]
  | succ n ih =>
    simp only [adaptiveBatches,bind_expect,map_expect]
    let F := fun x => (adaptiveBatches batch update n (update s x)).expect (fun y => f (Fin.cons x y))
    let G := fun x => (adaptiveBatches other update n (update s x)).expect (fun y => f (Fin.cons x y))
    change |(batch s).expect F-(other s).expect G| ≤ _
    have hlocal : |(batch s).expect F-(other s).expect F| ≤ err*B := by
      have h := expect_difference_massDistance (batch s) (other s) F B
        (fun x => expect_abs_bound _ _ B (fun y => hf (Fin.cons x y)))
      have hb := mul_le_mul_of_nonneg_left (hstep s) hB
      exact h.trans (by simpa only [mul_comm] using hb)
    have hfuture : |(other s).expect F-(other s).expect G| ≤ n*err*B :=
      expect_difference_functions (other s) F G _ (fun x => ih (update s x) _ (fun y => hf (Fin.cons x y)))
    calc
      _ ≤ |(batch s).expect F-(other s).expect F|+|(other s).expect F-(other s).expect G| := abs_sub_le _ _ _
      _ ≤ err*B+n*err*B := add_le_add hlocal hfuture
      _ = (↑(n+1):ℝ)*err*B := by push_cast; ring

end MatroidProphetSecretary.FiniteLaw
