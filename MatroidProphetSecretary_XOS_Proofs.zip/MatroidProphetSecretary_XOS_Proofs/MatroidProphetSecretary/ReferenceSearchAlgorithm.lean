import MatroidProphetSecretary.BranchSearch
import MatroidProphetSecretary.SearchBudget

/-! The reference search, with correctness conditional only on its actual queried batches. -/

noncomputable section

namespace MatroidProphetSecretary

variable {B : Type*}

def searchInterval (δ : ℝ) : Set ℝ := Set.Icc (1-4*δ) (1+4*δ)

def runReferenceSearch (positive negative : ℝ → B → Bool) (batches : ℕ → B)
    (initial : SearchRecord B) (δ : ℝ) (n : ℕ) : SearchRecord B :=
  if positive initial.point initial.batch then
    positiveBranch positive batches ⟨initial.point,1+4*δ⟩ initial n
  else if negative initial.point initial.batch then
    negativeBranch negative batches ⟨1-4*δ,initial.point⟩ initial n
  else initial

def referenceSearchAccurate (positive negative : ℝ → B → Bool) (batches : ℕ → B)
    (initial : SearchRecord B) (Good : SearchRecord B → Prop) (δ : ℝ) (n : ℕ) : Prop :=
  Good initial ∧
    if positive initial.point initial.batch then
      ∀ i < n, Good ⟨(feedbackBracket positive batches i ⟨initial.point,1+4*δ⟩).midpoint,batches i⟩
    else if negative initial.point initial.batch then
      ∀ i < n, Good ⟨(feedbackBracket (fun q x => !(negative q x)) batches i ⟨1-4*δ,initial.point⟩).midpoint,batches i⟩
    else True

/-- Analytic facts sufficient for the search; later instantiated with the actual finite matroid priors. -/
structure SearchAnalyticBounds (positive negative : ℝ → B → Bool)
    (Good : SearchRecord B → Prop) (C D g : ℝ → ℝ) (ε δ L : ℝ) : Prop where
  ordered : ∀ q ∈ searchInterval δ, C q ≤ D q
  positive_certificate : ∀ q ∈ searchInterval δ, ∀ x, Good ⟨q,x⟩ →
    if positive q x then 0 < C q else C q ≤ 15*ε
  negative_certificate : ∀ q ∈ searchInterval δ, ∀ x, Good ⟨q,x⟩ →
    if negative q x then D q < 0 else -15*ε ≤ D q
  C_lipschitz : ∀ x ∈ searchInterval δ, ∀ y ∈ searchInterval δ, |C x-C y| ≤ L*|x-y|
  D_lipschitz : ∀ x ∈ searchInterval δ, ∀ y ∈ searchInterval δ, |D x-D y| ≤ L*|x-y|
  positive_potential : ∀ x ∈ searchInterval δ, ∀ q ∈ searchInterval δ, x ≤ q → 0 < C q → g x ≤ g q
  negative_potential : ∀ q ∈ searchInterval δ, ∀ x ∈ searchInterval δ, q ≤ x → D q < 0 → g x ≤ g q

theorem runReferenceSearch_correct (positive negative : ℝ → B → Bool) (batches : ℕ → B)
    (initial : SearchRecord B) (Good : SearchRecord B → Prop) (C D g : ℝ → ℝ)
    (N : ℕ) (hN : 0 < N) (ε δ : ℝ) (hε : 0 < ε)
    (hsmall : ε/(4*(N:ℝ)^2) < δ) (hinit : initial.point ∈ searchInterval δ)
    (hbound : SearchAnalyticBounds positive negative Good C D g ε δ (16*(N:ℝ)^2))
    (hgood : referenceSearchAccurate positive negative batches initial Good δ (referenceSearchSteps N δ ε)) :
    let r := runReferenceSearch positive negative batches initial δ (referenceSearchSteps N δ ε)
    Good r ∧ r.point ∈ searchInterval δ ∧ g initial.point ≤ g r.point ∧
      (|r.point-1| < 3*δ → -20*ε ≤ D r.point ∧ C r.point ≤ 20*ε) := by
  obtain ⟨hgood0,hqueries⟩ := hgood
  have hδ : 0 < δ := lt_of_le_of_lt (by positivity) hsmall
  have hip := hinit
  change 1-4*δ ≤ initial.point ∧ initial.point ≤ 1+4*δ at hip
  cases hp : positive initial.point initial.batch
  · cases hn : negative initial.point initial.batch
    · simp only [runReferenceSearch,hp,hn,Bool.false_eq_true,if_false]
      have hC := hbound.positive_certificate _ hinit _ hgood0
      have hD := hbound.negative_certificate _ hinit _ hgood0
      simp only [hp,hn,Bool.false_eq_true,if_false] at hC hD
      exact ⟨hgood0,hinit,le_rfl,fun _ => ⟨by linarith,by linarith⟩⟩
    · simp only [runReferenceSearch,hp,hn,Bool.false_eq_true,if_false,if_true]
      simp only [hp,hn,Bool.false_eq_true,if_false,if_true] at hqueries
      let b : SearchBracket := ⟨1-4*δ,initial.point⟩
      have hb : b.lower ≤ b.upper := hip.1
      have hsub : Set.Icc b.lower b.upper ⊆ searchInterval δ := fun q hq => ⟨hq.1,hq.2.trans hip.2⟩
      have hw : b.upper-b.lower ≤ 8*δ := by dsimp [b]; linarith [hip.2]
      have hw' := referenceSearchSteps_width (feedbackAnswers (fun q x => !(negative q x)) batches b) b N hN δ ε hε hw
      have hl := referenceSearchSteps_continuity_loss (feedbackAnswers (fun q x => !(negative q x)) batches b) b N hN δ ε hε hw
      have hr := negativeBranch_correct negative batches b initial (referenceSearchSteps N δ ε) hb rfl
        C D g Good ε δ (16*(N:ℝ)^2) hε.le rfl hgood0 hn
        (fun q hq => hbound.negative_certificate q (hsub hq)) hqueries
        (fun q hq => hbound.ordered q (hsub hq))
        (fun x hx y hy => hbound.D_lipschitz x (hsub hx) y (hsub hy))
        (fun q hq hc => hbound.negative_potential q (hsub hq) initial.point hinit hq.2 hc)
        (by simpa only [feedbackBracket_eq_run] using hw'.trans_lt hsmall)
        (by simpa only [feedbackBracket_eq_run] using hl)
      exact ⟨hr.1,hsub hr.2.1,hr.2.2⟩
  · simp only [runReferenceSearch,hp,if_true]
    simp only [hp,if_true] at hqueries
    let b : SearchBracket := ⟨initial.point,1+4*δ⟩
    have hb : b.lower ≤ b.upper := hip.2
    have hsub : Set.Icc b.lower b.upper ⊆ searchInterval δ := fun q hq => ⟨hip.1.trans hq.1,hq.2⟩
    have hw : b.upper-b.lower ≤ 8*δ := by dsimp [b]; linarith [hip.1]
    have hw' := referenceSearchSteps_width (feedbackAnswers positive batches b) b N hN δ ε hε hw
    have hl := referenceSearchSteps_continuity_loss (feedbackAnswers positive batches b) b N hN δ ε hε hw
    have hr := positiveBranch_correct positive batches b initial (referenceSearchSteps N δ ε) hb rfl
      C D g Good ε δ (16*(N:ℝ)^2) hε.le rfl hgood0 hp
      (fun q hq => hbound.positive_certificate q (hsub hq)) hqueries
      (fun q hq => hbound.ordered q (hsub hq))
      (fun x hx y hy => hbound.C_lipschitz x (hsub hx) y (hsub hy))
      (fun q hq hc => hbound.positive_potential initial.point hinit q (hsub hq) hq.1 hc)
      (by simpa only [feedbackBracket_eq_run] using hw'.trans_lt hsmall)
      (by simpa only [feedbackBracket_eq_run] using hl)
    exact ⟨hr.1,hsub hr.2.1,hr.2.2⟩

end MatroidProphetSecretary
