import MatroidProphetSecretary.FiniteProbability
import Mathlib.Data.Fintype.BigOperators

/-! Pushforwards of finite laws and coordinatewise maps of independent priors. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]

def map (μ : FiniteLaw Ω) (f : Ω → Ψ) : FiniteLaw Ψ where
  mass y := ∑ x, if f x = y then μ.mass x else 0
  nonneg y := sum_nonneg (fun x _ => by split_ifs; exact μ.nonneg x; exact le_rfl)
  total := by
    rw [sum_comm]
    simpa using μ.total

theorem map_expect (μ : FiniteLaw Ω) (f : Ω → Ψ) (g : Ψ → ℝ) :
    (μ.map f).expect g = μ.expect (fun x => g (f x)) := by
  simp only [expect, map, sum_mul]
  rw [sum_comm]
  apply sum_congr rfl
  intro x hx
  simp

theorem map_prob (μ : FiniteLaw Ω) (f : Ω → Ψ) (A : Ψ → Prop)
    [DecidablePred A] [DecidablePred (fun x => A (f x))] :
    (μ.map f).prob A = μ.prob (fun x => A (f x)) := by
  unfold prob
  rw [map_expect]
  congr 1
  funext x
  by_cases h : A (f x) <;> simp [h]

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V W : ι → Type*} [∀ i, Fintype (V i)] [∀ i, Fintype (W i)]

theorem product_map_expect (laws : ∀ i, FiniteLaw (V i)) (f : ∀ i, V i → W i)
    (g : (∀ i, W i) → ℝ) :
    (product (fun i => (laws i).map (f i))).expect g =
      (product laws).expect (fun x => g (fun i => f i (x i))) := by
  have hpoint (x : ∀ i, V i) (y : ∀ i, W i) :
      (∏ i, if f i (x i) = y i then (laws i).mass (x i) else 0) =
      if (fun i => f i (x i)) = y then ∏ i, (laws i).mass (x i) else 0 := by
    by_cases hxy : (fun i => f i (x i)) = y
    · subst y
      simp
    · rw [if_neg hxy]
      have hex : ∃ i, f i (x i) ≠ y i := by
        by_contra hn
        push_neg at hn
        exact hxy (funext hn)
      obtain ⟨i, hi⟩ := hex
      apply prod_eq_zero (mem_univ i)
      simp [hi]
  simp only [expect, product, map]
  simp_rw [Fintype.prod_sum, sum_mul]
  rw [sum_comm]
  apply sum_congr rfl
  intro x hx
  simp_rw [hpoint]
  simp

theorem product_map_prob (laws : ∀ i, FiniteLaw (V i)) (f : ∀ i, V i → W i)
    (A : (∀ i, W i) → Prop) [DecidablePred A]
    [DecidablePred (fun x : ∀ i, V i => A (fun i => f i (x i)))] :
    (product (fun i => (laws i).map (f i))).prob A =
      (product laws).prob (fun x => A (fun i => f i (x i))) := by
  unfold prob
  rw [product_map_expect]
  congr 1
  funext x
  by_cases h : A (fun i => f i (x i)) <;> simp [h]

theorem ext_mass (μ ν : FiniteLaw Ω) (h : μ.mass = ν.mass) : μ = ν := by
  cases μ
  cases ν
  cases h
  rfl

end MatroidProphetSecretary.FiniteLaw
