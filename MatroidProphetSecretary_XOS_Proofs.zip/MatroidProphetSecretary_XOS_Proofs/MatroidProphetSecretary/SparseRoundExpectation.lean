import MatroidProphetSecretary.SparseRoundLaw

/-! A one-event round has an exact terminal-potential identity. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {S W : Type*} [Fintype W]

theorem stateAfter_none (update : S → Option W → S) (hnone : ∀ s, update s none = s)
    (n : ℕ) (s : S) : stateAfter update n s (fun _ => none) = s := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih => simpa only [stateAfter,hnone] using ih s

theorem stateAfter_oneMark (update : S → Option W → S) (hnone : ∀ s, update s none = s)
    (n : ℕ) (s : S) (i : Fin n) (w : W) :
    stateAfter update n s (oneMarkTrace i w) = update s (some w) := by
  induction n generalizing s with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    refine Fin.cases ?_ (fun j => ?_) i
    · rw [oneMarkTrace_zero]
      simp only [stateAfter,Fin.cons_zero,Fin.cons_succ]
      exact stateAfter_none update hnone n _
    · rw [oneMarkTrace_succ]
      simp only [stateAfter,Fin.cons_zero,Fin.cons_succ,hnone]
      exact ih s j

theorem sparseRound_terminal_expect_loss (kernel : ℕ → S → FiniteLaw (Option W))
    (update : S → Option W → S) (hnone : ∀ s, update s none = s)
    (h : ℝ) (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) (F : S → ℝ) :
    (sparseRoundTraceLaw kernel h hsmall n offset s hbudget).expect
      (fun x => F (stateAfter update n s x)) =
      F s-∑ i : Fin n, (kernel (offset+i.val) s).expect (fun mark => F s-F (update s mark)) := by
  rw [sparseRoundTraceLaw,map_expect,sparseRoundLaw,optionalLaw_expect_loss]
  simp only [sparseTrace,stateAfter_none update hnone,stateAfter_oneMark update hnone]
  congr 1
  rw [Fintype.sum_prod_type]
  apply sum_congr rfl
  intro i hi
  simp only [sparseRoundWeight,expect,Fintype.sum_option,hnone,sub_self,mul_zero,zero_add]

end MatroidProphetSecretary.FiniteLaw
