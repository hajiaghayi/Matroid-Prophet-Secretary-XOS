import MatroidProphetSecretary.DistinctClockLaw
import MatroidProphetSecretary.GridSchedule
import Mathlib.Data.List.Sort
import Mathlib.Data.List.OfFn

/-! Distinct sorted clocks identify exactly the nonempty slots of the physical grid scan. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {N L : ℕ}

def scheduledSlot (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N)) (i : Fin N) : ℕ :=
  gridSlot (schedule.val.orderEmbOfFin schedule.property i) (order i)

theorem scheduledSlot_lt (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N)) (i : Fin N) :
    scheduledSlot schedule order i < L*N := gridSlot_lt N L _ _

theorem scheduledSlot_strictMono (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N)) :
    StrictMono (scheduledSlot schedule order) := by
  intro i j hij
  have hc := (schedule.val.orderEmbOfFin schedule.property).strictMono hij
  have hcv : (schedule.val.orderEmbOfFin schedule.property i).val+1 ≤
      (schedule.val.orderEmbOfFin schedule.property j).val := hc
  have hm := Nat.mul_le_mul_right N hcv
  have he := (order i).isLt
  unfold scheduledSlot gridSlot
  rw [Nat.add_mul,Nat.one_mul] at hm
  omega

theorem decoded_schedule_clock (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N)) (i : Fin N) :
    decodeClocks (schedule,order.symm) (order i) = schedule.val.orderEmbOfFin schedule.property i := by
  simpa using decoded_clocks_follow_permutation schedule order.symm i

theorem scheduledSlot_arrival_iff (hN : 0 < N) (hL : 0 < L)
    (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N)) (n : ℕ) (hn : n < L*N) :
    decodeClocks (schedule,order.symm) (gridLabel N hN n) = gridClock N L hL n ↔
      ∃ i, scheduledSlot schedule order i = n := by
  constructor
  · intro h
    refine ⟨order.symm (gridLabel N hN n),?_⟩
    unfold scheduledSlot
    have hc := decoded_schedule_clock schedule order (order.symm (gridLabel N hN n))
    rw [order.apply_symm_apply] at hc ⊢
    rw [← hc,h]
    exact gridSlot_clock_label N L hN hL n hn
  · rintro ⟨i,rfl⟩
    unfold scheduledSlot
    rw [gridLabel_slot N L hN,gridClock_slot N L hL,decoded_schedule_clock]

theorem scheduledSlot_list (hN : 0 < N) (hL : 0 < L)
    (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N)) :
    (List.range (L*N)).filter
      (fun n => decide (decodeClocks (schedule,order.symm) (gridLabel N hN n) = gridClock N L hL n)) =
      List.ofFn (scheduledSlot schedule order) := by
  apply List.Sorted.eq_of_mem_iff
    ((List.sorted_lt_range (L*N)).filter _)
    (List.sorted_lt_ofFn_iff.mpr (scheduledSlot_strictMono schedule order))
  intro n
  simp only [List.mem_filter,List.mem_range,decide_eq_true_eq,List.mem_ofFn]
  constructor
  · rintro ⟨hn,harrival⟩
    exact (scheduledSlot_arrival_iff hN hL schedule order n hn).mp harrival
  · rintro ⟨i,hi⟩
    have hn : n < L*N := hi ▸ scheduledSlot_lt schedule order i
    exact ⟨hn,(scheduledSlot_arrival_iff hN hL schedule order n hn).mpr ⟨i,hi⟩⟩

end MatroidProphetSecretary
