import MatroidProphetSecretary.LayerIntegral
import MatroidProphetSecretary.RankMarginals
import MatroidProphetSecretary.SurplusDecomposition

/-! Contraction costs as integrals of closure indicators (Lemma 6). -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

def closureLayer (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) : ℝ :=
  if 0 < z ∧ e ∈ M.closure (valueLayer M v z) then 1 else 0

theorem closureLayer_eq_rank_difference (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) (z : ℝ) :
    closureLayer M v e z = positiveRankLayer M v z - positiveRankLayer (M ／ {e}) v z := by
  classical
  unfold closureLayer positiveRankLayer
  by_cases hz : 0 < z
  · simp only [hz, if_true, true_and]
    rw [valueLayer_contract_singleton]
    exact (realRank_contraction_marginal M (valueLayer M v z) (fun _ h => h.1) e he).symm
  · simp [hz]

theorem closureLayer_integrable (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (e : E) (he : M.Indep ({e} : Set E)) : Integrable (closureLayer M v e) := by
  have hid := funext (closureLayer_eq_rank_difference M v e he)
  rw [hid]
  exact (positiveRankLayer_integrable M v hv).sub (positiveRankLayer_integrable (M ／ {e}) v hv)

/-- The second deterministic layer identity in the proof of Lemma 6. -/
theorem contractionCost_eq_integral_closure (M : Matroid E) (v : E → ℝ)
    (hv : ∀ e, 0 ≤ v e) (e : E) (he : M.Indep ({e} : Set E)) :
    contractionCost M v e he = ∫ z, closureLayer M v e z := by
  unfold contractionCost
  rw [contractionValue_eq_contract_optimum, optimum_eq_integral_rank M v hv,
    optimum_eq_integral_rank (M ／ {e}) v hv]
  rw [← integral_sub (positiveRankLayer_integrable M v hv)
    (positiveRankLayer_integrable (M ／ {e}) v hv)]
  congr 1
  funext z
  exact (closureLayer_eq_rank_difference M v e he z).symm

theorem sum_closureLayer_le_rank (M : Matroid E) (v : E → ℝ) (B : Finset E)
    (hB : M.Indep (B : Set E)) (z : ℝ) :
    (∑ e ∈ B, closureLayer M v e z) ≤ positiveRankLayer M v z := by
  classical
  by_cases hz : 0 < z
  · let I := B.filter (fun e => e ∈ M.closure (valueLayer M v z))
    have hI : M.Indep (I : Set E) := hB.subset (filter_subset _ B)
    have hIc : (I : Set E) ⊆ M.closure (valueLayer M v z) := fun _ h => (mem_filter.mp h).2
    obtain ⟨J, hJ, hIJ⟩ := hI.subset_isBasis_of_subset hIc (M.closure_subset_ground _)
    have hc : I.card ≤ J.ncard := by
      simpa using Set.ncard_le_ncard hIJ
    have hsum : (∑ e ∈ B, closureLayer M v e z) = (I.card : ℝ) := by
      simp only [closureLayer, hz, true_and]
      rw [← sum_filter]
      simp [I]
    rw [hsum]
    rw [positiveRankLayer, if_pos hz]
    change (I.card : ℝ) ≤ realRank M (valueLayer M v z)
    rw [← realRank_closure, realRank_eq_ncard hJ]
    exact_mod_cast hc
  · simp [closureLayer, positiveRankLayer, hz]

def realizedLayerGap (M : Matroid E) (v : E → ℝ) (B : Finset E) (z : ℝ) : ℝ :=
  positiveRankLayer M v z - ∑ e ∈ B, closureLayer M v e z

theorem realizedLayerGap_nonneg (M : Matroid E) (v : E → ℝ) (B : Finset E)
    (hB : M.Indep (B : Set E)) (z : ℝ) : 0 ≤ realizedLayerGap M v B z :=
  sub_nonneg.mpr (sum_closureLayer_le_rank M v B hB z)

theorem realizedLayerGap_integrable (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (B : Finset E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    Integrable (realizedLayerGap M v B) :=
  (positiveRankLayer_integrable M v hv).sub
    (integrable_finset_sum B (fun e _ => closureLayer_integrable M v hv e (hnonloop e)))

theorem realized_gap_eq_integral (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (B : Finset E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    optimum M v - (∑ e ∈ B, contractionCost M v e (hnonloop e)) =
      ∫ z, realizedLayerGap M v B z := by
  unfold realizedLayerGap
  rw [integral_sub (positiveRankLayer_integrable M v hv)
    (integrable_finset_sum B (fun e _ => closureLayer_integrable M v hv e (hnonloop e))),
    integral_finset_sum B (fun e _ => closureLayer_integrable M v hv e (hnonloop e)),
    ← optimum_eq_integral_rank M v hv]
  simp only [contractionCost_eq_integral_closure M v hv]

variable {Ω : Type*} [Fintype Ω]

theorem priceGap_eq_integral (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ)
    (hv : ∀ w e, 0 ≤ v w e) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (B : Finset E) (hopt : priceOptimum μ M v hnonloop = weight (contractionPrice μ M v hnonloop) B) :
    priceGap μ M v hnonloop = ∫ z, μ.expect (fun w => realizedLayerGap M (v w) B z) := by
  have hsum : weight (contractionPrice μ M v hnonloop) B =
      μ.expect (fun w => ∑ e ∈ B, contractionCost M (v w) e (hnonloop e)) := by
    unfold weight contractionPrice FiniteLaw.expect
    simp_rw [mul_sum]
    exact sum_comm
  unfold priceGap
  rw [hopt, hsum]
  change μ.expect (fun w => optimum M (v w)) - _ = _
  rw [← μ.expect_sub]
  unfold FiniteLaw.expect
  rw [integral_finset_sum univ (fun w _ =>
    (realizedLayerGap_integrable M (v w) (hv w) B hnonloop).const_mul (μ.mass w))]
  simp only [integral_const_mul]
  apply sum_congr rfl
  intro w hw
  rw [realized_gap_eq_integral M (v w) (hv w) B hnonloop]

end MatroidProphetSecretary
