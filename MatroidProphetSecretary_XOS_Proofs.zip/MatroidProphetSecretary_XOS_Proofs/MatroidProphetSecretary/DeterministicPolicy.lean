import MatroidProphetSecretary.FiniteRandomPolicy

/-! A finite randomized policy has a deterministic seed with at least its expected reward. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem FiniteLaw.exists_expect_le {A : Type*} [Fintype A] (μ : FiniteLaw A) (f : A → ℝ) :
    ∃ a, μ.expect f ≤ f a := by
  by_contra h
  push_neg at h
  have hpos : ∃ a, 0 < μ.mass a := by
    by_contra hn
    push_neg at hn
    have hz : ∀ a, μ.mass a = 0 := fun a => le_antisymm (hn a) (μ.nonneg a)
    have ht := μ.total
    simp only [hz,Finset.sum_const_zero] at ht
    norm_num at ht
  obtain ⟨a,ha⟩ := hpos
  have hh : μ.expect f < μ.expect (fun _ => μ.expect f) := by
    apply Finset.sum_lt_sum
    · intro x hx
      exact mul_le_mul_of_nonneg_left (h x).le (μ.nonneg x)
    · exact ⟨a,Finset.mem_univ _,mul_lt_mul_of_pos_left (h a) ha⟩
  rw [μ.expect_const] at hh
  exact lt_irrefl _ hh

theorem expectedPolicyReward_zero_bits {N k : ℕ} (prior : RationalPriors N k) (policy : OnlinePolicy N 0) :
    expectedPolicyReward prior policy = (FiniteLaw.product prior.law).expect (fun values =>
      (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
        weight (prior.realization values) (acceptedSet (completedHistory policy 0 (prior.realization values) order)))) := by
  unfold expectedPolicyReward
  have hs (seed : Fin (2^0)) : seed = 0 := by apply Fin.ext; have h := seed.isLt; norm_num at h; omega
  simp only [hs,FiniteLaw.expect_const]

theorem deterministic_policy_dominates {N k K : ℕ} (prior : RationalPriors N k)
    (M : Matroid (Fin N)) (policy : OnlinePolicy N K) (hf : PolicyFeasible M policy) :
    ∃ deterministic : OnlinePolicy N 0, PolicyFeasible M deterministic ∧
      expectedPolicyReward prior policy ≤ expectedPolicyReward prior deterministic := by
  have heq : expectedPolicyReward prior policy = (FiniteLaw.uniform (Fin (2^K))).expect
      (fun seed => expectedPolicyReward prior (fixedPolicy policy seed)) := by
    have h := expected_seededPolicy prior policy (fun x => x)
    exact h
  obtain ⟨seed,hs⟩ := FiniteLaw.exists_expect_le (FiniteLaw.uniform (Fin (2^K)))
    (fun seed => expectedPolicyReward prior (fixedPolicy policy seed))
  refine ⟨fixedPolicy policy seed,?_,by rwa [heq]⟩
  intro seed' values order
  have h := runPolicy_seed_congr (fixedPolicy policy seed) policy seed' seed (fun _ _ _ => rfl) values
    ((List.finRange N).map order) []
  change M.Indep (acceptedSet (runPolicy (fixedPolicy policy seed) seed' values _ []) : Set (Fin N))
  rw [h]
  exact hf seed values order

end MatroidProphetSecretary
