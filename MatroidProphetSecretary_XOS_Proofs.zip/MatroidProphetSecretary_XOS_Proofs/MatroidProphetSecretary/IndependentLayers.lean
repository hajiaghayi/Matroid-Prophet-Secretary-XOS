import MatroidProphetSecretary.StableLayers
import MatroidProphetSecretary.BlockIndependence

/-! The product-tail identities (3.2) for independent finite priors. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

def coordinateValues (value : ∀ e, V e → ℝ) (x : ∀ e, V e) (e : E) : ℝ := value e (x e)

def otherNonspanProbability (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (e : E) (z : ℝ) : ℝ :=
  (FiniteLaw.product laws).prob (fun x => e ∉ M.closure (valueLayer M (coordinateValues value x) z \ {e}))

theorem otherNonspan_ignores_own (M : Matroid E) (value : ∀ e, V e → ℝ)
    (e : E) (z : ℝ) (x y : ∀ e, V e) (hxy : ∀ f, f ≠ e → x f = y f) :
    (e ∉ M.closure (valueLayer M (coordinateValues value x) z \ {e})) ↔
      (e ∉ M.closure (valueLayer M (coordinateValues value y) z \ {e})) := by
  have hid : valueLayer M (coordinateValues value x) z \ {e} =
      valueLayer M (coordinateValues value y) z \ {e} := by
    ext f
    by_cases hfe : f = e
    · simp [hfe]
    · simp [valueLayer, coordinateValues, hfe, hxy f hfe]
  rw [hid]

theorem expected_coloop_eq_tail_nonspan (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (e : E) (he : e ∈ M.E) (z : ℝ) :
    (FiniteLaw.product laws).expect (fun x => coloopLayer M (coordinateValues value x) e z) =
      positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z *
        otherNonspanProbability laws M value e z := by
  let μ := FiniteLaw.product laws
  by_cases hz : 0 < z
  · have hprod := FiniteLaw.product_prob_and_of_disjoint laws (fun f => f = e)
      (fun x => z < value e (x e))
      (fun x => e ∉ M.closure (valueLayer M (coordinateValues value x) z \ {e}))
      (fun x y hxy => by dsimp only; rw [hxy e rfl]) (otherNonspan_ignores_own M value e z)
    have hcoloop : μ.expect (fun x => coloopLayer M (coordinateValues value x) e z) =
        μ.prob (fun x => z < value e (x e) ∧
          e ∉ M.closure (valueLayer M (coordinateValues value x) z \ {e})) := by
      unfold FiniteLaw.prob
      congr 1
      funext x
      simp only [coloopLayer, hz, true_and, valueLayer, Set.mem_setOf_eq, he, coordinateValues]
    have htail : positiveTailProbability μ (coordinateValues value) e z =
        μ.prob (fun x => z < value e (x e)) := by
      unfold positiveTailProbability FiniteLaw.prob
      congr 1
      funext x
      simp [positiveLayer, coordinateValues, hz]
    change μ.expect _ = _
    rw [hcoloop, htail]
    exact hprod
  · simp [coloopLayer, positiveTailProbability, positiveLayer, hz, FiniteLaw.expect_const]

/-- The D identity of (3.2), with both factors computed from the product prior. -/
theorem independent_deletion_layers (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    deletionSurplus (FiniteLaw.product laws) M (coordinateValues value) =
      ∫ z, ∑ e, positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z *
        otherNonspanProbability laws M value e z := by
  rw [deletionSurplus_eq_integral_coloop_count (FiniteLaw.product laws) M (coordinateValues value)
    (fun x e => hv e (x e))]
  congr 1
  funext z
  apply Finset.sum_congr rfl
  intro e he
  exact expected_coloop_eq_tail_nonspan laws M value e
    ((hnonloop e).subset_ground (Set.mem_singleton e)) z

/-- The H identity of (3.2): an independent own-value copy squares the tail probability. -/
theorem independent_stable_layers (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop =
      ∫ z, ∑ e, (positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z) ^ 2 *
        otherNonspanProbability laws M value e z := by
  rw [stableSurplus_eq_integral_tail_coloop (FiniteLaw.product laws) M (coordinateValues value)
    (fun x e => hv e (x e)) hnonloop]
  congr 1
  funext z
  apply Finset.sum_congr rfl
  intro e he
  rw [expected_coloop_eq_tail_nonspan laws M value e
    ((hnonloop e).subset_ground (Set.mem_singleton e)) z]
  ring

end MatroidProphetSecretary
