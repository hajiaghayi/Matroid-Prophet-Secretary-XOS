import Mathlib.MeasureTheory.Function.Floor
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic

/-! Measurable downward rounding to bounded rational grids, converging to every nonnegative value. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory Filter
open scoped Topology

def quantizeIndex (n : ℕ) (x : ℝ) : Fin ((n+1)^2+1) :=
  ⟨min ((n+1)^2) ⌊x*(n+1)⌋₊,Nat.lt_succ_of_le (min_le_left _ _)⟩

def quantizeValue (n : ℕ) (i : Fin ((n+1)^2+1)) : ℚ := (i.val:ℚ)/(n+1)

def rationalRound (n : ℕ) (x : ℝ) : ℝ := quantizeValue n (quantizeIndex n x)

theorem quantizeValue_nonneg (n : ℕ) (i : Fin ((n+1)^2+1)) : 0 ≤ quantizeValue n i := by
  unfold quantizeValue
  positivity

theorem rationalRound_formula (n : ℕ) (x : ℝ) :
    rationalRound n x = min (n+1:ℝ) ((⌊x*(n+1)⌋₊:ℝ)/(n+1)) := by
  have hn : (0:ℝ) < n+1 := by positivity
  simp only [rationalRound,quantizeValue,quantizeIndex,Rat.cast_div,Rat.cast_natCast,Rat.cast_add,Rat.cast_one,
    Nat.cast_min,Nat.cast_pow,Nat.cast_add,Nat.cast_one,Rat.cast_min,Rat.cast_pow]
  rw [← min_div_div_right hn.le]
  congr 1
  field_simp
  ring

theorem rationalRound_bounds (n : ℕ) (x : ℝ) (hx : 0 ≤ x) :
    0 ≤ rationalRound n x ∧ rationalRound n x ≤ x := by
  constructor
  · change (0:ℝ) ≤ (quantizeValue n (quantizeIndex n x) : ℝ)
    exact_mod_cast quantizeValue_nonneg n (quantizeIndex n x)
  · rw [rationalRound_formula]
    apply (min_le_right _ _).trans
    apply (div_le_iff₀ (by positivity : (0:ℝ) < n+1)).mpr
    exact Nat.floor_le (mul_nonneg hx (by positivity))

theorem measurable_quantizeIndex (n : ℕ) : Measurable (quantizeIndex n) := by
  let f : ℕ → Fin ((n+1)^2+1) := fun j => ⟨min ((n+1)^2) j,Nat.lt_succ_of_le (min_le_left _ _)⟩
  exact (measurable_of_countable f).comp (Nat.measurable_floor.comp (measurable_id.mul_const (n+1:ℝ)))

theorem measurable_rationalRound (n : ℕ) : Measurable (rationalRound n) :=
  (measurable_of_countable (fun i => (quantizeValue n i : ℝ))).comp (measurable_quantizeIndex n)

theorem rationalRound_tendsto (x : ℝ) (hx : 0 ≤ x) : Tendsto (fun n => rationalRound n x) atTop (𝓝 x) := by
  have hn : Tendsto (fun n : ℕ => (n:ℝ)+1) atTop atTop := tendsto_atTop_add_const_right _ 1 tendsto_natCast_atTop_atTop
  have hfloor := (tendsto_nat_floor_mul_div_atTop hx).comp hn
  apply hfloor.congr'
  filter_upwards [hn.eventually (eventually_ge_atTop x)] with n hnx
  have hb : (⌊x*(n+1)⌋₊:ℝ)/(n+1) ≤ n+1 :=
    ((div_le_iff₀ (by positivity : (0:ℝ) < n+1)).mpr
      (Nat.floor_le (mul_nonneg hx (by positivity)))).trans hnx
  exact ((rationalRound_formula n x).trans (min_eq_right hb)).symm

end MatroidProphetSecretary
