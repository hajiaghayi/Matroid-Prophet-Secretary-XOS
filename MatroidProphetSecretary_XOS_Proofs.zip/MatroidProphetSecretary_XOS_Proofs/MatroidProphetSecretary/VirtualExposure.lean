import MatroidProphetSecretary.VirtualLayerPersistence
import MatroidProphetSecretary.VirtualLateReward
import MatroidProphetSecretary.TwoStageLaws

/-! The stored early exposure and the weighted initial value of the final phase. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def virtualEarlyExposure (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (dt lam : ℝ)
    (n : ℕ) (s : VirtualState M) (x : Fin n → Option (E × W)) (e : E) : ℝ :=
  dt*lam*FiniteLaw.trajectoryReward (virtualUpdate M base hbase value)
    (fun state _ => virtualLiveMass μ M base hbase value state e) n s x

def virtualExposureValue (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (dt lam : ℝ)
    (n : ℕ) (s : VirtualState M) (x : Fin n → Option (E × W)) : ℝ :=
  ∑ e, virtualEarlyExposure μ M base hbase value dt lam n s x e *
    virtualLiveValue μ M base hbase value (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x) e

theorem virtualEarlyExposure_bounds (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (dt lam : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (n : ℕ) (s : VirtualState M)
    (x : Fin n → Option (E × W)) (e : E) :
    0 ≤ virtualEarlyExposure μ M base hbase value dt lam n s x e ∧
      virtualEarlyExposure μ M base hbase value dt lam n s x e ≤ dt*lam*n := by
  have h := FiniteLaw.trajectoryReward_bounds (virtualUpdate M base hbase value)
    (fun state _ => virtualLiveMass μ M base hbase value state e) 1
    (fun state _ => μ.prob_nonneg _) (fun state _ => μ.prob_le_one _) n s x
  unfold virtualEarlyExposure
  refine ⟨mul_nonneg (mul_nonneg hdt hlam) h.1,?_⟩
  simpa only [mul_one] using mul_le_mul_of_nonneg_left h.2 (mul_nonneg hdt hlam)

theorem virtualExposureValue_expect (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (batch : VirtualState M → FiniteLaw (Option (E × W))) (dt lam : ℝ) (n : ℕ) (s : VirtualState M) :
    (FiniteLaw.adaptiveBatches batch (virtualUpdate M base hbase value) n s).expect
      (virtualExposureValue μ M base hbase value dt lam n s) =
      dt*lam*FiniteLaw.accumulatedCrossMoment batch (virtualUpdate M base hbase value)
        (virtualLiveValue μ M base hbase value) (virtualLiveMass μ M base hbase value) n s := by
  unfold virtualExposureValue virtualEarlyExposure FiniteLaw.accumulatedCrossMoment
  rw [← FiniteLaw.expect_const_mul]
  congr 1
  funext x
  rw [mul_sum]
  apply sum_congr rfl
  intro e he
  ring

theorem virtual_exposure_weighted_value (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (dt lam : ℝ) (n : ℕ) (s : VirtualState M) (x : Fin n → Option (E × W)) :
    virtualWeightedLiveValue μ M base hbase value
      (fun e => 1+virtualEarlyExposure μ M base hbase value dt lam n s x e)
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x) =
    virtualTotalLiveValue μ M base hbase value (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x) +
      virtualExposureValue μ M base hbase value dt lam n s x := by
  simp only [virtualWeightedLiveValue,virtualTotalLiveValue,virtualExposureValue,add_mul,one_mul,sum_add_distrib]

theorem virtual_exposure_rate_upper (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (dt lam omega : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (n : ℕ) (hbudget : omega*(1+dt*lam*n) ≤ 1) (s : VirtualState M)
    (x : Fin n → Option (E × W)) (e : E) :
    lam*(1+virtualEarlyExposure μ M base hbase value dt lam n s x e) ≤ lam/omega := by
  have h := (virtualEarlyExposure_bounds μ M base hbase value dt lam hdt hlam n s x e).2
  have hscale := mul_le_mul_of_nonneg_left (add_le_add_left h 1) homega.le
  have hfinal := mul_le_mul_of_nonneg_left (hscale.trans hbudget) hlam
  apply (le_div_iff₀ homega).mpr
  nlinarith only [hfinal]

end MatroidProphetSecretary
