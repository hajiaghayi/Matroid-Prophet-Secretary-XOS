import MatroidProphetSecretary.ReferenceCandidateKernel
import MatroidProphetSecretary.SurplusDecomposition

/-! Reference atom domination transfers positive-part surplus to the actual revealed value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem reference_atom_surplus {k : ℕ} (prior : FiniteLaw (Fin k)) (reference : FiniteLaw (Option (Fin k)))
    (value : Fin k → ℝ) (q p : ℝ) (hp : 0 ≤ p)
    (hdom : ∀ v, reference.mass (some v) ≤ q*prior.mass v) :
    reference.expect (fun v => posPart (referenceValue value v-p)) ≤
      q*prior.expect (fun v => posPart (value v-p)) := by
  unfold FiniteLaw.expect
  rw [Fintype.sum_option]
  simp only [referenceValue,zero_sub,posPart,max_eq_right (neg_nonpos.mpr hp),mul_zero,zero_add]
  rw [mul_sum]
  apply sum_le_sum
  intro v hv
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_right (hdom v) (le_max_right (value v-p) 0)

variable {E : Type*} [Fintype E] [DecidableEq E] {k : ℕ}

theorem reference_total_surplus_transfer (prior : E → FiniteLaw (Fin k))
    (reference : E → FiniteLaw (Option (Fin k))) (value : E → Fin k → ℝ)
    (q : ℝ) (p mean : E → ℝ) (b : ℝ) (hp : ∀ e, 0 ≤ p e)
    (hdom : ∀ e v, (reference e).mass (some v) ≤ q*(prior e).mass v) :
    thresholdSurplus (FiniteLaw.product reference) (fun y e => referenceValue (value e) (y e)) mean b ≤
      q*(∑ e, (prior e).expect (fun v => posPart (value e v-p e)))+
        ∑ e, posPart (p e-b*mean e) := by
  unfold thresholdSurplus
  rw [mul_sum,← sum_add_distrib]
  apply sum_le_sum
  intro e he
  change (FiniteLaw.product reference).expect (fun w => posPart (referenceValue (value e) (w e)-b*mean e)) ≤ _
  rw [FiniteLaw.product_expect_single_coordinate reference e (fun v => posPart (referenceValue (value e) v-b*mean e))]
  calc
    _ ≤ (reference e).expect (fun v => posPart (referenceValue (value e) v-p e)+posPart (p e-b*mean e)) :=
      (reference e).expect_mono (fun v => surplus_threshold_shift (referenceValue (value e) v) (p e) (b*mean e))
    _ = (reference e).expect (fun v => posPart (referenceValue (value e) v-p e))+posPart (p e-b*mean e) := by
      rw [FiniteLaw.expect_add,FiniteLaw.expect_const]
    _ ≤ _ := add_le_add_right (reference_atom_surplus (prior e) (reference e) (value e) q (p e) (hp e) (hdom e)) _

theorem reference_threshold_surplus_pays (prior : E → FiniteLaw (Fin k))
    (reference : E → FiniteLaw (Option (Fin k))) (value : E → Fin k → ℝ)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (q a b eps : ℝ) (p : E → ℝ) (hq : 0 < q) (hab : a ≤ b) (hp : ∀ e, 0 ≤ p e)
    (hdom : ∀ e v, (reference e).mass (some v) ≤ q*(prior e).mass v)
    (hsurplus : b*q*deletionSurplus (FiniteLaw.product reference) M (fun y e => referenceValue (value e) (y e))+
        2*eps*expectedOptimum (FiniteLaw.product reference) M (fun y e => referenceValue (value e) (y e)) <
      thresholdSurplus (FiniteLaw.product reference) (fun y e => referenceValue (value e) (y e))
        (meanThreshold (FiniteLaw.product reference) M (fun y e => referenceValue (value e) (y e)) hnonloop) b)
    (herror : (∑ e, posPart (p e-b*meanThreshold (FiniteLaw.product reference) M
        (fun y e => referenceValue (value e) (y e)) hnonloop e)) <
      2*eps*expectedOptimum (FiniteLaw.product reference) M (fun y e => referenceValue (value e) (y e))) :
    a*deletionSurplus (FiniteLaw.product reference) M (fun y e => referenceValue (value e) (y e)) <
      ∑ e, (prior e).expect (fun v => posPart (value e v-p e)) := by
  have htransfer := reference_total_surplus_transfer prior reference value q p
    (meanThreshold (FiniteLaw.product reference) M (fun y e => referenceValue (value e) (y e)) hnonloop) b hp hdom
  exact original_surplus_pays_deletion _ _ _ _ q b a eps hq (deletionSurplus_nonneg _ _ _) hab hsurplus
    (htransfer.trans_lt (add_lt_add_left herror _))

end MatroidProphetSecretary
