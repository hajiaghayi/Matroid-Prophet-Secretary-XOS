import MatroidProphetSecretary.PolicyFeasibility

/-! Feeding transformed observed values to a policy preserves its online information and feasibility. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def transformObservation {N : ℕ} (transform : Fin N → ℝ → ℝ) (x : Observation N) : Observation N :=
  ⟨x.label,transform x.label x.value,x.accepted⟩

def transformedPolicy {N K : ℕ} (transform : Fin N → ℝ → ℝ) (policy : OnlinePolicy N K) : OnlinePolicy N K :=
  fun seed history e v => policy seed (history.map (transformObservation transform)) e (transform e v)

theorem run_transformedPolicy {N K : ℕ} (transform : Fin N → ℝ → ℝ) (policy : OnlinePolicy N K)
    (seed : Fin (2^K)) (values : Fin N → ℝ) (order : List (Fin N)) (history : List (Observation N)) :
    (runPolicy (transformedPolicy transform policy) seed values order history).map (transformObservation transform) =
      runPolicy policy seed (fun e => transform e (values e)) order (history.map (transformObservation transform)) := by
  induction order generalizing history with
  | nil => rfl
  | cons e rest ih =>
    simp only [runPolicy,transformedPolicy]
    rw [ih]
    simp only [List.map_append,List.map_cons,List.map_nil,transformObservation]

theorem acceptedSet_transform {N : ℕ} (transform : Fin N → ℝ → ℝ) (history : List (Observation N)) :
    acceptedSet (history.map (transformObservation transform)) = acceptedSet history := by
  unfold acceptedSet
  simp only [List.filter_map,List.map_map,Function.comp_def,transformObservation]

theorem completed_transformedPolicy_accepted {N K : ℕ} (transform : Fin N → ℝ → ℝ)
    (policy : OnlinePolicy N K) (seed : Fin (2^K)) (values : Fin N → ℝ) (order : Equiv.Perm (Fin N)) :
    acceptedSet (completedHistory (transformedPolicy transform policy) seed values order) =
      acceptedSet (completedHistory policy seed (fun e => transform e (values e)) order) := by
  rw [← acceptedSet_transform transform]
  unfold completedHistory
  rw [run_transformedPolicy]
  rfl

theorem transformedPolicy_feasible {N K : ℕ} (M : Matroid (Fin N)) (transform : Fin N → ℝ → ℝ)
    (policy : OnlinePolicy N K) (hf : PolicyFeasible M policy) : PolicyFeasible M (transformedPolicy transform policy) := by
  intro seed values order
  rw [completed_transformedPolicy_accepted]
  exact hf seed _ order

theorem transformedPolicy_reward_lower {N K : ℕ} (transform : Fin N → ℝ → ℝ)
    (policy : OnlinePolicy N K) (seed : Fin (2^K)) (values : Fin N → ℝ) (order : Equiv.Perm (Fin N))
    (ht : ∀ e, transform e (values e) ≤ values e) :
    weight (fun e => transform e (values e)) (acceptedSet (completedHistory policy seed (fun e => transform e (values e)) order)) ≤
      weight values (acceptedSet (completedHistory (transformedPolicy transform policy) seed values order)) := by
  rw [completed_transformedPolicy_accepted]
  exact sum_le_sum (fun e _ => ht e)

end MatroidProphetSecretary
