import MatroidProphetSecretary.VirtualInitialOverlap
import Mathlib.Analysis.SpecialFunctions.Pow.Deriv

/-! Admissible finite time meshes and convergence of the proved virtual reward factor. -/

noncomputable section

namespace MatroidProphetSecretary

open Filter
open scoped Topology

theorem mesh_step_bounds (t r : ℝ) (ht : 0 ≤ t) (hr : 0 ≤ r) (N n : ℕ)
    (hn : 0 < n) (hsize : t*r*(N+1) ≤ n) :
    t/n*r ≤ 1 ∧ t/n*r*N ≤ 1 := by
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hN : (0 : ℝ) ≤ N := Nat.cast_nonneg _
  have htr : 0 ≤ t*r := mul_nonneg ht hr
  have hfirst : t*r ≤ n := by nlinarith [mul_nonneg htr hN]
  have hsecond : t*r*N ≤ n := by nlinarith
  constructor
  · rw [div_mul_eq_mul_div,div_le_iff₀ hn']
    simpa using hfirst
  · rw [div_mul_eq_mul_div,div_mul_eq_mul_div,div_le_iff₀ hn']
    simpa using hsecond

def meshContinuationConfig (N : ℕ) (t d lam omega : ℝ)
    (ht : 0 ≤ t) (hd : 0 ≤ d) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (hbudget : omega*(1+t*lam) ≤ 1) (n : ℕ) (hn : 0 < n)
    (hearly : t*lam*(N+1) ≤ n) (hlate : d*(lam/omega)*(N+1) ≤ n) :
    FiniteContinuationConfig N where
  earlyStep := t/n
  lateStep := d/n
  rate := lam
  omega := omega
  earlySteps := n
  lateSteps := n
  earlyStep_nonneg := div_nonneg ht (Nat.cast_nonneg _)
  lateStep_nonneg := div_nonneg hd (Nat.cast_nonneg _)
  rate_nonneg := hlam
  omega_pos := homega
  early_decay := (mesh_step_bounds t lam ht hlam N n hn hearly).1
  late_decay := (mesh_step_bounds d (lam/omega) hd (div_nonneg hlam homega.le) N n hn hlate).1
  early_mass := (mesh_step_bounds t lam ht hlam N n hn hearly).2
  late_mass := (mesh_step_bounds d (lam/omega) hd (div_nonneg hlam homega.le) N n hn hlate).2
  exposure_budget := by
    have hn' : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne'
    convert hbudget using 1 <;> field_simp <;> ring

theorem mesh_sizes_eventually (N : ℕ) (t d lam omega : ℝ) :
    ∀ᶠ n : ℕ in atTop, 0 < n ∧ t*lam*(N+1) ≤ n ∧ d*(lam/omega)*(N+1) ≤ n := by
  obtain ⟨B,hB⟩ := exists_nat_gt (max 0 (max (t*lam*(N+1)) (d*(lam/omega)*(N+1))))
  filter_upwards [eventually_ge_atTop B] with n hn
  have hBn : (B : ℝ) ≤ n := by exact_mod_cast hn
  have hn0 : (0 : ℝ) < n := lt_of_le_of_lt (le_max_left _ _) (hB.trans_le hBn)
  refine ⟨by exact_mod_cast hn0,?_,?_⟩
  · exact (le_trans (le_max_left _ _) (le_max_right _ _)).trans (hB.le.trans hBn)
  · exact (le_trans (le_max_right _ _) (le_max_right _ _)).trans (hB.le.trans hBn)

def meshContinuationFactor (t d lam omega z : ℝ) (n : ℕ) : ℝ :=
  let a := (1-t/n*lam)^n
  let b := omega*(1-(1-d/n*(lam/omega))^n)
  1-a+a*b*(1+(1-a)*z)

def limitingContinuationFactor (t d lam omega z : ℝ) : ℝ :=
  let a := Real.exp (-t*lam)
  let b := omega*(1-Real.exp (-d*(lam/omega)))
  1-a+a*b*(1+(1-a)*z)

theorem mesh_factor_eq (N : ℕ) (t d lam omega z : ℝ)
    (ht : 0 ≤ t) (hd : 0 ≤ d) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (hbudget : omega*(1+t*lam) ≤ 1) (n : ℕ) (hn : 0 < n)
    (hearly : t*lam*(N+1) ≤ n) (hlate : d*(lam/omega)*(N+1) ≤ n) :
    finiteContinuationFactor (meshContinuationConfig N t d lam omega ht hd hlam homega hbudget n hn hearly hlate) z =
      meshContinuationFactor t d lam omega z n := rfl

theorem mesh_decay_tendsto (t lam : ℝ) :
    Tendsto (fun n : ℕ => (1-t/n*lam)^n) atTop (𝓝 (Real.exp (-t*lam))) := by
  convert tendsto_one_plus_div_pow_exp (-t*lam) using 1
  ext n
  congr 1
  ring

theorem mesh_factor_tendsto (t d lam omega z : ℝ) :
    Tendsto (meshContinuationFactor t d lam omega z) atTop
      (𝓝 (limitingContinuationFactor t d lam omega z)) := by
  have ha := mesh_decay_tendsto t lam
  have hb : Tendsto (fun n : ℕ => omega*(1-(1-d/n*(lam/omega))^n)) atTop
      (𝓝 (omega*(1-Real.exp (-d*(lam/omega))))) :=
    tendsto_const_nhds.mul (tendsto_const_nhds.sub (mesh_decay_tendsto d (lam/omega)))
  exact (tendsto_const_nhds.sub ha).add
    ((ha.mul hb).mul (tendsto_const_nhds.add ((tendsto_const_nhds.sub ha).mul tendsto_const_nhds)))

theorem exists_mesh_factor_lower (N : ℕ) (t d lam omega z c : ℝ)
    (hc : c < limitingContinuationFactor t d lam omega z) :
    ∃ n : ℕ, 0 < n ∧ t*lam*(N+1) ≤ n ∧ d*(lam/omega)*(N+1) ≤ n ∧
      c < meshContinuationFactor t d lam omega z n := by
  have hf := (mesh_factor_tendsto t d lam omega z).eventually_const_lt hc
  obtain ⟨n,hn,hf⟩ := ((mesh_sizes_eventually N t d lam omega).and hf).exists
  exact ⟨n,hn.1,hn.2.1,hn.2.2,hf⟩

end MatroidProphetSecretary
