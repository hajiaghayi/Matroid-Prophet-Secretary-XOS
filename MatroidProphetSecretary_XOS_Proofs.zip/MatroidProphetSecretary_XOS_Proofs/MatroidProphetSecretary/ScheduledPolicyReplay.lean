import MatroidProphetSecretary.ScheduledRecordMachine
import MatroidProphetSecretary.IndexedFoldCounter

/-! The revealed-value policy replays exactly the collision-free physical accepted history. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem scheduled_machine_fold (observed : Fin N → V → ℝ) (schedule : ClockSchedule N L)
    (tables : ValueTapeTables N L observed) (sample : Fin N → V) (order : Equiv.Perm (Fin N)) :
    ((List.finRange N).map order).foldl
      (fun state e => (cfg.scheduledPolicyStep observed schedule tables state e (observed e (sample e))).1) (0,[]) =
      (N,(List.finRange N).foldl
        (fun history i => cfg.arrivalUpdate (schedule.val.orderEmbOfFin schedule.property i) (order i) history
          (tables (order i) (observedValueAtom observed (order i) (sample (order i))))) []) := by
  let orderAt := fun j : ℕ => order (⟨j%N,Nat.mod_lt j cfg.labels_pos⟩ : Fin N)
  let update := fun j (history : StampedHistory (Fin N) (Fin N → Option V)) =>
    if hj : j < N then cfg.arrivalUpdate (schedule.val.orderEmbOfFin schedule.property ⟨j,hj⟩)
      (order ⟨j,hj⟩) history (tables (order ⟨j,hj⟩) (observedValueAtom observed (order ⟨j,hj⟩) (sample (order ⟨j,hj⟩))))
    else history
  have hat (j : ℕ) (hj : j < N) : orderAt j = order ⟨j,hj⟩ := by
    apply congrArg order
    apply Fin.ext
    exact Nat.mod_eq_of_lt hj
  have hdiag (j : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V)) :
      (cfg.scheduledPolicyStep observed schedule tables (j,history) (orderAt j) (observed (orderAt j) (sample (orderAt j)))).1 =
        (j+1,update j history) := by
    by_cases hj : j < N
    · rw [hat j hj]
      simp only [scheduledPolicyStep,dif_pos hj,readValueTape_atom,update]
    · simp only [scheduledPolicyStep,dif_neg hj,update]
  have hlist : (List.finRange N).map order = (List.range N).map orderAt := by
    rw [← List.map_coe_finRange N,List.map_map]
    apply congrArg (fun f => (List.finRange N).map f)
    funext i
    exact (hat i.val i.isLt).symm
  rw [hlist,List.foldl_map]
  rw [range_fold_counter
    (fun state j => (cfg.scheduledPolicyStep observed schedule tables state (orderAt j) (observed (orderAt j) (sample (orderAt j)))).1)
    update hdiag [] N]
  apply congrArg (fun history => (N,history))
  rw [← List.map_coe_finRange N,List.foldl_map]
  apply congrArg (fun f => (List.finRange N).foldl f [])
  funext history i
  dsimp only [update]
  rw [dif_pos i.isLt]

theorem privateClockPolicy_replay (observed : Fin N → V → ℝ) (schedule : ClockSchedule N L)
    (tables : ValueTapeTables N L observed) (sample : Fin N → V) (order : Equiv.Perm (Fin N)) :
    replayPolicyState (0,[]) (cfg.scheduledPolicyStep observed schedule tables)
      (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) (schedule,tables)) 0
        (fun e => observed e (sample e)) order) =
      (N,cfg.run (fun e => (decodeClocks (schedule,order.symm) e,tables e (observedValueAtom observed e (sample e)))) (L*N)) := by
  change replayPolicyState (0,[]) (cfg.scheduledPolicyStep observed schedule tables)
    (runPolicy (replayedPolicy (0,[]) (cfg.scheduledPolicyStep observed schedule tables)) 0
      (fun e => observed e (sample e)) ((List.finRange N).map order) []) = _
  rw [replayedPolicy_run_state]
  change ((List.finRange N).map order).foldl
    (fun state e => (cfg.scheduledPolicyStep observed schedule tables state e (observed e (sample e))).1) (0,[]) = _
  rw [cfg.scheduled_machine_fold observed schedule tables sample order,cfg.run_eq_arrival_fold]

theorem privateClockPolicy_accepted (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (observed : Fin N → V → ℝ) (schedule : ClockSchedule N L) (tables : ValueTapeTables N L observed)
    (sample : Fin N → V) (order : Equiv.Perm (Fin N)) :
    acceptedSet (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) (schedule,tables)) 0
      (fun e => observed e (sample e)) order) =
      recordLabels (cfg.run (fun e => (decodeClocks (schedule,order.symm) e,tables e (observedValueAtom observed e (sample e)))) (L*N)) := by
  have h := replayedPolicy_run_invariant (0,[]) (cfg.scheduledPolicyStep observed schedule tables)
    (ScheduledStateGood M base hbase value schedule) (fun state => recordLabels state.2)
    (cfg.scheduledPolicyStep_good M base hbase value hlive observed schedule tables) 0
    (fun e => observed e (sample e)) ((List.finRange N).map order) []
    (show ScheduledStateGood M base hbase value schedule (0,[]) from ⟨ValidExchangeRecords.nil,rfl⟩) rfl
  have he := h.2
  change acceptedSet (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) (schedule,tables)) 0
      (fun e => observed e (sample e)) order) =
    recordLabels (replayPolicyState (0,[]) (cfg.scheduledPolicyStep observed schedule tables)
      (completedHistory (fixedPolicy (cfg.privateClockPolicy observed) (schedule,tables)) 0
        (fun e => observed e (sample e)) order)).2 at he
  rw [cfg.privateClockPolicy_replay observed schedule tables sample order] at he
  exact he

end MatroidProphetSecretary.PrivateGridConfig
