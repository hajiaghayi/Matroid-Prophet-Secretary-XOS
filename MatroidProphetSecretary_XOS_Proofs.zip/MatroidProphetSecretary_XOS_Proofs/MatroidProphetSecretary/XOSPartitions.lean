import MatroidProphetSecretary.ProductMoments
import MatroidProphetSecretary.BlockIndependence
import MatroidProphetSecretary.FinitePushforward
import Mathlib.Data.Fintype.Pi
import Mathlib.Data.Fintype.EquivFin

/-! Independent public partitions for the XOS lower bound (Section 10).
The probability of a set of items is its cardinality divided by the total number of items.
This is a counting device, not randomness hidden from the online algorithm. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open Finset
open scoped Classical

theorem uniform_prob_card {A : Type*} [Fintype A] [Nonempty A] (s : Finset A)
    [DecidablePred (fun a => a ∈ s)] :
    (FiniteLaw.uniform A).prob (fun a => a ∈ s) = (s.card : ℝ) / Fintype.card A := by
  simp [FiniteLaw.prob, FiniteLaw.expect, FiniteLaw.uniform, mul_ite,
    ← Finset.sum_filter, Finset.filter_mem_eq_inter, div_eq_mul_inv, mul_comm]

theorem uniform_product {I A : Type*} [Fintype I] [DecidableEq I] [Fintype A] [Nonempty A] :
    FiniteLaw.product (fun _ : I => FiniteLaw.uniform A) = FiniteLaw.uniform (I → A) := by
  apply FiniteLaw.ext_mass
  funext x
  simp [FiniteLaw.product, FiniteLaw.uniform, Fintype.card_fun, Nat.cast_pow, one_div]

theorem prob_not {A : Type*} [Fintype A] (μ : FiniteLaw A) (P : A → Prop)
    [DecidablePred P] [DecidablePred (fun a => ¬ P a)] :
    μ.prob (fun a => ¬ P a) = 1 - μ.prob P := by
  have h : (fun a => if ¬ P a then (1 : ℝ) else 0) =
      fun a => 1 - (if P a then 1 else 0) := by funext a; split_ifs <;> simp_all
  rw [FiniteLaw.prob, h, μ.expect_sub, μ.expect_const]
  rfl

abbrev Item (T : Type*) (n : ℕ) := T → Fin n

def part {T : Type*} [Fintype T] (n : ℕ) (s : T) (r : Fin n) : Finset (Item T n) :=
  univ.filter (fun x => x s = r)

@[simp] theorem mem_part {T : Type*} [Fintype T] {n : ℕ} (s : T) (r : Fin n)
    (x : Item T n) : x ∈ part n s r ↔ x s = r := by simp [part]

theorem prob_coordinate_ne {n : ℕ} [NeZero n] (r : Fin n) :
    (FiniteLaw.uniform (Fin n)).prob (fun x => x ≠ r) = 1 - 1 / (n : ℝ) := by
  rw [prob_not _ (fun x => x = r)]
  have h := uniform_prob_card ({r} : Finset (Fin n))
  simpa using congrArg (fun z : ℝ => 1 - z) h

/-- Exact union count for distinct partition indices, including adaptive choices. -/
theorem partition_union_card {T I : Type*} [Fintype T] [Fintype I]
    {n : ℕ} [NeZero n] (s : I → T) (hs : Function.Injective s) (r : I → Fin n) :
    ((univ.biUnion (fun i => part n (s i) (r i))).card : ℝ) =
      (Fintype.card (Item T n) : ℝ) *
        (1 - (1 - 1 / (n : ℝ)) ^ Fintype.card I) := by
  let U := univ.image s
  let R : T → Fin n := fun t => if h : ∃ i, s i = t then r h.choose else 0
  have hR (i : I) : R (s i) = r i := by
    dsimp [R]
    split_ifs with h
    · congr 1
      exact hs h.choose_spec
    · exact (h ⟨i,rfl⟩).elim
  have hevent (x : Item T n) :
      (x ∉ univ.biUnion (fun i => part n (s i) (r i))) ↔
        ∀ t, t ∈ U → x t ≠ R t := by
    simp only [mem_biUnion, mem_univ, true_and, mem_part, not_exists]
    constructor
    · intro h t ht
      obtain ⟨i,_,rfl⟩ := mem_image.mp ht
      simpa [hR] using h i
    · intro h i
      simpa [hR] using h (s i) (mem_image.mpr ⟨i,mem_univ _,rfl⟩)
  have hp := FiniteLaw.product_prob_coordinates (fun _ : T => FiniteLaw.uniform (Fin n))
    (fun t x => t ∈ U → x ≠ R t)
  have hcoord (t : T) :
      (FiniteLaw.uniform (Fin n)).prob (fun x => t ∈ U → x ≠ R t) =
        if t ∈ U then 1 - 1 / (n : ℝ) else 1 := by
    by_cases ht : t ∈ U
    · simpa [ht] using prob_coordinate_ne (R t)
    · simp [ht, FiniteLaw.prob]
  simp_rw [hcoord] at hp
  rw [uniform_product] at hp
  have hprod : (∏ t : T, if t ∈ U then 1 - 1 / (n : ℝ) else 1) =
      (1 - 1 / (n : ℝ)) ^ Fintype.card I := by
    rw [Finset.prod_ite_mem]
    simp [U, card_image_of_injective _ hs]
  rw [hprod] at hp
  have hprob := (FiniteLaw.uniform (Item T n)).prob_congr hevent
  rw [prob_not _ (fun x => x ∈ univ.biUnion (fun i => part n (s i) (r i))),
    uniform_prob_card] at hprob
  rw [hp] at hprob
  have hm : (Fintype.card (Item T n) : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  rw [mul_comm]
  apply (div_eq_iff hm).mp
  linarith

end MatroidProphetSecretary.XOS
