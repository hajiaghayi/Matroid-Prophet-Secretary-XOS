import MatroidProphetSecretary.OwnValueInvariant

/-! Stable surplus layers, using an independent second draw of the own value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

theorem update_min_nonneg (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) (e : E) (u : ℝ) (hu : 0 ≤ u) :
    ∀ f, 0 ≤ Function.update v e (min (v e) u) f := by
  intro f
  by_cases hfe : f = e
  · subst f
    rw [Function.update_self]
    exact le_min (hv e) hu
  · rw [Function.update_of_ne hfe]
    exact hv f

theorem coloop_mul_positiveLayer_integrable (M : Matroid E) (v : E → ℝ)
    (hv : ∀ e, 0 ≤ v e) (e : E) (u : ℝ) (hu : 0 ≤ u) :
    Integrable (fun z => coloopLayer M v e z * positiveLayer u z) := by
  have hid : (fun z => coloopLayer M v e z * positiveLayer u z) =
      coloopLayer M (Function.update v e (min (v e) u)) e :=
    funext (fun z => (coloopLayer_update_min M v e u z).symm)
  rw [hid]
  exact coloopLayer_integrable M _ (update_min_nonneg v hv e u hu) e

theorem stable_pair_eq_integral (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (e : E) (he : M.Indep ({e} : Set E)) (u : ℝ) (hu : 0 ≤ u) :
    posPart (min (v e) u - exclusionThreshold M v e he) =
      ∫ z, coloopLayer M v e z * positiveLayer u z := by
  have hpair := (deletion_contraction_identities M (Function.update v e (min (v e) u)) e he).1
  simp only [Function.update_self, exclusionThreshold_update] at hpair
  rw [← hpair, deletion_surplus_eq_integral_coloop M _ (update_min_nonneg v hv e u hu) e]
  congr 1
  funext z
  exact coloopLayer_update_min M v e u z

def positiveTailProbability (μ : FiniteLaw Ω) (v : Ω → E → ℝ) (e : E) (z : ℝ) : ℝ :=
  μ.expect (fun w => positiveLayer (v w e) z)

theorem expected_stableLayer_integrable (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e) (e : E) :
    Integrable (fun z => μ.expect (fun w => μ.expect (fun w' =>
      coloopLayer M (v w) e z * positiveLayer (v w' e) z))) := by
  apply integrable_finset_sum univ
  intro w hw
  apply Integrable.const_mul
  apply integrable_finset_sum univ
  intro w' hw'
  exact (coloop_mul_positiveLayer_integrable M (v w) (hv w) e (v w' e) (hv w' e)).const_mul _

/-- Stable surplus equals the integral of tail probability times expected coloop count.
Factoring the latter under independent coordinates gives the squared-tail form of (3.2). -/
theorem stableSurplus_eq_integral_tail_coloop (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    stableSurplus μ M v hnonloop = ∫ z, ∑ e,
      positiveTailProbability μ v e z * μ.expect (fun w => coloopLayer M (v w) e z) := by
  have hLayer : ∀ e z,
      μ.expect (fun w => μ.expect (fun w' => coloopLayer M (v w) e z * positiveLayer (v w' e) z)) =
        positiveTailProbability μ v e z * μ.expect (fun w => coloopLayer M (v w) e z) := by
    intro e z
    simp_rw [μ.expect_const_mul]
    rw [μ.expect_mul_const]
    exact mul_comm _ _
  simp_rw [← hLayer]
  rw [integral_finset_sum univ (fun e _ => expected_stableLayer_integrable μ M v hv e)]
  unfold stableSurplus
  apply sum_congr rfl
  intro e he
  unfold FiniteLaw.expect
  rw [integral_finset_sum univ (fun w _ =>
    (integrable_finset_sum univ (fun w' _ =>
      (coloop_mul_positiveLayer_integrable M (v w) (hv w) e (v w' e) (hv w' e)).const_mul (μ.mass w'))).const_mul
      (μ.mass w))]
  simp only [integral_const_mul]
  apply sum_congr rfl
  intro w hw
  congr 1
  rw [integral_finset_sum univ (fun w' _ =>
    (coloop_mul_positiveLayer_integrable M (v w) (hv w) e (v w' e) (hv w' e)).const_mul (μ.mass w'))]
  simp only [integral_const_mul]
  apply sum_congr rfl
  intro w' hw'
  rw [stable_pair_eq_integral M (v w) (hv w) e (hnonloop e) (v w' e) (hv w' e)]

end MatroidProphetSecretary
