import MatroidProphetSecretary.FiniteOptimum
import Mathlib.Topology.Order.Lattice
import Mathlib.MeasureTheory.Constructions.BorelSpace.Real
import Mathlib.MeasureTheory.Order.Lattice
import Mathlib.Topology.Algebra.InfiniteSum.Basic

/-! The finite matroid optimum is a continuous, measurable function of its value vector. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

theorem continuous_weight {E : Type*} [Fintype E] [DecidableEq E] (I : Finset E) :
    Continuous (fun v : E → ℝ => weight v I) := by
  apply continuous_finset_sum
  intro e he
  exact continuous_apply e

theorem continuous_optimum {E : Type*} [Fintype E] [DecidableEq E] (M : Matroid E) :
    Continuous (optimum M) := by
  unfold optimum optimumOver
  apply Continuous.finset_sup'_apply
  intro I hI
  exact continuous_weight I

theorem measurable_optimum {E : Type*} [Fintype E] [DecidableEq E] (M : Matroid E) :
    Measurable (optimum M) := (continuous_optimum M).measurable

end MatroidProphetSecretary
