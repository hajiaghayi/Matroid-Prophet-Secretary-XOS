import MatroidProphetSecretary.TruncatedPoisson
import Mathlib.Data.Nat.Cast.Field

/-! Integer weights implement the truncated Poisson law without exponential evaluation. -/

namespace MatroidProphetSecretary

open Finset

def poissonIntegerWeight (T n : ℕ) : ℕ := 2^n*(T.factorial/n.factorial)

noncomputable section

theorem poissonIntegerWeight_cast (T n : ℕ) (hn : n ≤ T) :
    (poissonIntegerWeight T n : ℝ) = T.factorial*poissonTwoWeight n := by
  rw [poissonIntegerWeight,Nat.cast_mul,Nat.cast_pow,Nat.cast_ofNat,
    Nat.cast_div (Nat.factorial_dvd_factorial hn) (by positivity)]
  unfold poissonTwoWeight
  ring

theorem poissonIntegerWeight_bound (T n : ℕ) (hn : n ≤ T) :
    poissonIntegerWeight T n ≤ (2*(T+1))^T := by
  calc
    _ ≤ 2^T*T.factorial := Nat.mul_le_mul (Nat.pow_le_pow_right (by omega) hn) (Nat.div_le_self _ _)
    _ ≤ 2^T*(T+1)^T := Nat.mul_le_mul_left _
      ((Nat.factorial_le_pow T).trans (Nat.pow_le_pow_left (Nat.le_succ T) T))
    _ = _ := (mul_pow _ _ _).symm

theorem poissonIntegerWeight_zero (T : ℕ) : poissonIntegerWeight T 0 = T.factorial := by
  simp [poissonIntegerWeight]

theorem poissonIntegerTable_total_pos (T : ℕ) : 0 < ∑ n : Fin (T+1), poissonIntegerWeight T n := by
  have h := single_le_sum (s := (univ : Finset (Fin (T+1))))
    (fun n _ => Nat.zero_le (poissonIntegerWeight T n)) (mem_univ (0 : Fin (T+1)))
  have h0 : 0 < poissonIntegerWeight T (0 : Fin (T+1)) := by
    rw [Fin.val_zero,poissonIntegerWeight_zero]
    exact Nat.factorial_pos T
  exact h0.trans_le h

theorem poissonIntegerTable_total_cast (T : ℕ) :
    ((∑ n : Fin (T+1), poissonIntegerWeight T n : ℕ) : ℝ) = T.factorial*poissonTwoNormalizer T := by
  rw [Nat.cast_sum]
  simp_rw [poissonIntegerWeight_cast T _ (Nat.le_of_lt_succ (Fin.isLt _))]
  rw [← mul_sum,Fin.sum_univ_eq_sum_range]
  rfl

theorem poissonIntegerTable_distribution (T : ℕ) (n : Fin (T+1)) :
    (poissonIntegerWeight T n : ℝ) / (∑ j : Fin (T+1), poissonIntegerWeight T j : ℕ) =
      (truncatedPoissonTwo T).mass n := by
  rw [poissonIntegerWeight_cast T _ (Nat.le_of_lt_succ n.isLt),poissonIntegerTable_total_cast]
  change _ = poissonTwoWeight n / poissonTwoNormalizer T
  have hf : (T.factorial:ℝ) ≠ 0 := by positivity
  exact mul_div_mul_left _ _ hf

theorem truncatedPoissonTwo_conditional_mass (T : ℕ) (n : Fin (T+1)) :
    (truncatedPoissonTwo T).mass n = ProbabilityTheory.poissonPMFReal 2 n /
      (∑ j : Fin (T+1), ProbabilityTheory.poissonPMFReal 2 j) := by
  have hp (j : ℕ) : ProbabilityTheory.poissonPMFReal 2 j = Real.exp (-2)*poissonTwoWeight j := by
    simp only [ProbabilityTheory.poissonPMFReal,NNReal.coe_ofNat,poissonTwoWeight]
    ring
  simp_rw [hp]
  rw [← mul_sum,Fin.sum_univ_eq_sum_range]
  change poissonTwoWeight n / poissonTwoNormalizer T =
    Real.exp (-2)*poissonTwoWeight n/(Real.exp (-2)*poissonTwoNormalizer T)
  exact (mul_div_mul_left _ _ (ne_of_gt (Real.exp_pos _))).symm

end

end MatroidProphetSecretary
