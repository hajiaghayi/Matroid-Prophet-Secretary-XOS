import MatroidProphetSecretary.MatroidPhysicalContinuation
import MatroidProphetSecretary.SortedPhysicalReward

/-! The finite continuation guarantee after clock collisions are removed. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N : ℕ} {V : Type*} [Fintype V]

theorem exists_sorted_physical_continuation (hN : 0 < N) (prior : Fin N → FiniteLaw V)
    (reference : Fin N → FiniteLaw (Option V))
    (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hzero : ∀ y e, y e = none → value y e = 0)
    (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (hF : 0 < expectedOptimum (FiniteLaw.product reference) M value) {q c : ℝ}
    (hq : q ∈ interval) (hdom : ∀ e v, (reference e).mass (some v) ≤ q*(prior e).mass v)
    (hc : c < phi q (overlap (FiniteLaw.product reference) value base/expectedOptimum (FiniteLaw.product reference) M value)) :
    ∃ (L : ℕ) (cfg : PrivateGridConfig N L V) (hNL : N ≤ L),
      cfg.prior = prior ∧ cfg.reference = reference ∧ cfg.q = q ∧
      (∀ history e y, cfg.live history e y ↔
        e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y) ∧
      c*expectedOptimum (FiniteLaw.product reference) M value < cfg.sortedExpectedReward hNL value := by
  obtain ⟨L,cfg,hNL,hprior,href,hqeq,hlive,hgain⟩ :=
    exists_finite_physical_continuation hN prior reference M base hbase value hv hzero hopt hF hq hdom hc
  refine ⟨L,cfg,hNL,hprior,href,hqeq,hlive,?_⟩
  have herror := cfg.physical_sorted_reward_loss hNL M base hbase value hv hlive
  linarith only [hgain,herror]

end MatroidProphetSecretary
