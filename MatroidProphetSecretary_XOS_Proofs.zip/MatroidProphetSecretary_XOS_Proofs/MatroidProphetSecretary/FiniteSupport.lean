import MatroidProphetSecretary.FiniteProbability
import Mathlib.Data.Fintype.BigOperators

/-! Expectation identities only need to hold on the support of a finite law. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

theorem expect_congr_support (μ : FiniteLaw Ω) {f g : Ω → ℝ}
    (h : ∀ x, μ.mass x ≠ 0 → f x = g x) : μ.expect f = μ.expect g := by
  apply sum_congr rfl
  intro x hx
  by_cases hm : μ.mass x = 0
  · simp [hm]
  · rw [h x hm]

theorem prob_congr_support (μ : FiniteLaw Ω) {A B : Ω → Prop} [DecidablePred A] [DecidablePred B]
    (h : ∀ x, μ.mass x ≠ 0 → (A x ↔ B x)) : μ.prob A = μ.prob B := by
  apply expect_congr_support
  intro x hx
  simp only [h x hx]

theorem product_support {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)] (laws : ∀ i, FiniteLaw (V i))
    (x : ∀ i, V i) (hx : (product laws).mass x ≠ 0) (i : ι) : (laws i).mass (x i) ≠ 0 := by
  intro hi
  exact hx (prod_eq_zero (mem_univ i) hi)

theorem prob_eq_zero_of_le (μ : FiniteLaw Ω) {A B : Ω → Prop} [DecidablePred A] [DecidablePred B]
    (h : ∀ x, A x → B x) (hB : μ.prob B = 0) : μ.prob A = 0 := by
  apply le_antisymm _ (μ.prob_nonneg A)
  rw [← hB]
  apply μ.expect_mono
  intro x
  by_cases hA : A x
  · simp [hA, h x hA]
  · simp only [if_neg hA]
    split_ifs <;> norm_num

end MatroidProphetSecretary.FiniteLaw
