import MatroidProphetSecretary.TwoPhasePrivateIntensity
import MatroidProphetSecretary.GridSchedule

/-! Counterfactual private decisions depend only on the reconstructed past at their clock. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 512

theorem gridProbePass_congr_prefix {W : Type*} {L n : ℕ}
    (live other : ℕ → W → Prop) (h : ∀ i < n, ∀ y, live i y ↔ other i y)
    (probes : Fin L → Bool × W) : gridProbePass live n probes ↔ gridProbePass other n probes := by
  unfold gridProbePass finiteProbePass
  apply forall_congr'
  intro i
  apply forall_congr'
  intro hi
  rw [h i.val hi]

theorem earlyPrivateDecision_congr_prefix {E V : Type*} {L : ℕ}
    (live other : ℕ → (E → Option V) → Prop) (c : Fin L)
    (h : ∀ i ≤ c.val, ∀ y, live i y ↔ other i y) :
    earlyPrivateDecision live c = earlyPrivateDecision other c := by
  have hl : live c.val = other c.val := funext (fun y => propext (h _ le_rfl y))
  have hp : gridProbePass (L := L) live c.val = gridProbePass other c.val := by
    funext probes
    exact propext (gridProbePass_congr_prefix live other (fun i hi => h i hi.le) probes)
  unfold earlyPrivateDecision
  rw [hl,hp]

theorem phasePrivateDecision_congr_prefix {E V : Type*} {L : ℕ}
    (cut : ℕ) (live other : ℕ → (E → Option V) → Prop) (c : Fin L)
    (h : ∀ i ≤ c.val, ∀ y, live i y ↔ other i y) :
    phasePrivateDecision cut live c = phasePrivateDecision cut other c := by
  unfold phasePrivateDecision
  split_ifs
  · exact earlyPrivateDecision_congr_prefix live other c h
  · have hl : live c.val = other c.val := funext (fun y => propext (h _ le_rfl y))
    rw [hl]

def gridHistoryProfile {N : ℕ} {A W : Type*}
    (live : StampedHistory (Fin N) A → Fin N → W → Prop)
    (history : StampedHistory (Fin N) A) (e : Fin N) (j : ℕ) (y : W) : Prop :=
  live (recordsBefore (j*N+e.val) history) e y

theorem gridHistoryProfile_on_path {N L : ℕ} {A W Ω : Type*} [Fintype Ω]
    (hN : 0 < N) (hL : 0 < L) (laws : Fin N → FiniteLaw (Fin L × Ω))
    (decision : ℕ → StampedHistory (Fin N) A → Ω → Option A)
    (live : StampedHistory (Fin N) A → Fin N → W → Prop)
    (path : ℕ → StampedHistory (Fin N) A) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent (gridLabel N hN)
        (markedStep (gridLabel N hN) (gridClock N L hL) (stampDecision decision)) [] path n))
    (i : ℕ) (hin : i ≤ n) (hiL : i < L*N) (j : ℕ) (hj : j ≤ (gridClock N L hL i).val) (y : W) :
    gridHistoryProfile live (path i) (gridLabel N hN i) j y ↔
      gridHistoryProfile live (path n) (gridLabel N hN i) j y := by
  obtain ⟨tapes,hpath⟩ := FiniteLaw.exists_of_prob_pos _ _ hp
  have hslot : j*N+(gridLabel N hN i).val ≤ i := by
    calc
      _ ≤ (gridClock N L hL i).val*N+(gridLabel N hN i).val :=
        Nat.add_le_add_right (Nat.mul_le_mul_right N hj) _
      _ = i := gridSlot_clock_label N L hN hL i hiL
  unfold gridHistoryProfile
  rw [← hpath i hin,← hpath n le_rfl]
  change live (recordsBefore _ (stampedRun _ _ _ tapes i)) _ _ ↔
    live (recordsBefore _ (stampedRun _ _ _ tapes n)) _ _
  rw [recordsBefore_stampedRun _ _ _ tapes hslot,
    recordsBefore_stampedRun _ _ _ tapes (hslot.trans hin)]

def gridPrivateDecision {N L : ℕ} {V : Type*} (hN : 0 < N) (hL : 0 < L)
    (cut : ℕ) (live : StampedHistory (Fin N) (Fin N → Option V) → Fin N → (Fin N → Option V) → Prop)
    (i : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V)) :=
  phasePrivateDecision cut (gridHistoryProfile live history (gridLabel N hN i)) (gridClock N L hL i)

theorem gridPrivateDecision_on_path {N L : ℕ} {V : Type*} [Fintype V]
    (hN : 0 < N) (hL : 0 < L)
    (laws : Fin N → FiniteLaw (Fin L ×
      (V × (Fin L → (Fin L → Bool × (Fin N → Option V)) × Option (Fin N → Option V)))))
    (cut : ℕ) (live : StampedHistory (Fin N) (Fin N → Option V) → Fin N → (Fin N → Option V) → Prop)
    (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent (gridLabel N hN)
        (markedStep (gridLabel N hN) (gridClock N L hL) (stampDecision (gridPrivateDecision hN hL cut live))) [] path n))
    (i : ℕ) (hin : i ≤ n) (hiL : i < L*N) :
    gridPrivateDecision hN hL cut live i (path i) = gridPrivateDecision hN hL cut live i (path n) := by
  apply phasePrivateDecision_congr_prefix
  intro j hj y
  exact gridHistoryProfile_on_path hN hL laws _ live path n hp i hin hiL j hj y

end MatroidProphetSecretary
