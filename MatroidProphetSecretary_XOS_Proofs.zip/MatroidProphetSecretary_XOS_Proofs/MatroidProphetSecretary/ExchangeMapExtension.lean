import MatroidProphetSecretary.OrderedExchangeStep

/-! Extending a map after one step of the fixed-target symmetric exchange scan. -/

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [DecidableEq E]

def extendExchangeMap (M : Matroid E) (C B : Finset E) (e b : E)
    (he : e ∈ C \ B) (hb : b ∈ B \ C)
    (hBe : M.IsBase ((insert e (B.erase b) : Finset E) : Set E))
    (ψ : ExchangeMap M (insert b (C.erase e)) B) : ExchangeMap M C B where
  map x := if x = e then b else ψ.map x
  image_mem x hx := by
    by_cases hxe : x = e
    · simpa only [if_pos hxe] using (mem_sdiff.mp hb).1
    · simp only [if_neg hxe]
      exact ψ.image_mem x (mem_insert_of_mem (mem_erase.mpr ⟨hxe, hx⟩))
  inj := by
    intro x hx y hy hxy
    have hold : ∀ z ∈ C, z ≠ e → z ∈ insert b (C.erase e) :=
      fun z hz hze => mem_insert_of_mem (mem_erase.mpr ⟨hze, hz⟩)
    have hbC' : b ∈ insert b (C.erase e) := mem_insert_self _ _
    have hψb : ψ.map b = b := ψ.fixes b hbC' (mem_sdiff.mp hb).1
    by_cases hxe : x = e
    · by_cases hye : y = e
      · exact hxe.trans hye.symm
      · simp only [if_pos hxe, if_neg hye] at hxy
        have hyb : y = b := ψ.inj y (hold y hy hye) b hbC' (hxy.symm.trans hψb.symm)
        exact ((mem_sdiff.mp hb).2 (hyb ▸ hy)).elim
    · by_cases hye : y = e
      · simp only [if_neg hxe, if_pos hye] at hxy
        have hxb : x = b := ψ.inj x (hold x hx hxe) b hbC' (hxy.trans hψb.symm)
        exact ((mem_sdiff.mp hb).2 (hxb ▸ hx)).elim
      · simp only [if_neg hxe, if_neg hye] at hxy
        exact ψ.inj x (hold x hx hxe) y (hold y hy hye) hxy
  fixes x hxC hxB := by
    have hxe : x ≠ e := by rintro rfl; exact (mem_sdiff.mp he).2 hxB
    rw [if_neg hxe]
    exact ψ.fixes x (mem_insert_of_mem (mem_erase.mpr ⟨hxe, hxC⟩)) hxB
  exchange x hx := by
    by_cases hxe : x = e
    · subst x
      simpa only [if_pos rfl] using hBe
    · rw [if_neg hxe]
      exact ψ.exchange x (mem_insert_of_mem (mem_erase.mpr ⟨hxe, hx⟩))

def identityExchangeMap (M : Matroid E) (B : Finset E) (hB : M.IsBase (B : Set E)) : ExchangeMap M B B where
  map := id
  image_mem _ h := h
  inj _ _ _ _ h := h
  fixes _ _ _ := rfl
  exchange e he := by simpa [insert_erase he] using hB

end MatroidProphetSecretary
