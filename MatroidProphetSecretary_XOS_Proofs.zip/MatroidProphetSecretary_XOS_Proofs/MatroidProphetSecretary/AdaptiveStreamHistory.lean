import MatroidProphetSecretary.FiniteTraceLaw

/-! Finite adaptive histories agree with the prefix of a sequential input stream. -/

noncomputable section

namespace MatroidProphetSecretary

namespace FiniteLaw

variable {S W : Type*} [Fintype W]

theorem stateBefore_stream (update : S → W → S) (n : ℕ) (s : S) (x : ℕ → W) (i : Fin n) :
    stateBefore update n s (fun i => x i.val) i = scanState update s x i.val := by
  induction n generalizing s x with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    refine Fin.cases ?_ (fun j => ?_) i
    · rfl
    · change stateBefore update n (update s (x 0)) (fun i => x (i.val+1)) j = _
      rw [ih (update s (x 0)) (fun j => x (j+1)) j,scanState_shift]
      rfl

theorem trajectory_good_stream (update : S → W → S) (Good : S → W → Prop)
    (n : ℕ) (s : S) (x : ℕ → W) :
    ¬ trajectoryBad update (fun s w => ¬ Good s w) n s (fun i => x i.val) ↔
      ∀ j < n, Good (scanState update s x j) (x j) := by
  rw [trajectoryBad_iff]
  simp only [not_exists,not_not,stateBefore_stream]
  constructor
  · intro h j hj
    exact h ⟨j,hj⟩
  · intro h j
    exact h j.val j.isLt

end FiniteLaw

def finiteTapeStream {n : ℕ} {B : Type*} (tape : Fin (n+1) → B) (j : ℕ) : B :=
  tape ⟨j%(n+1),Nat.mod_lt j (Nat.zero_lt_succ n)⟩

theorem finiteTapeStream_prefix {n : ℕ} {B : Type*} (tape : Fin (n+1) → B) (j : Fin (n+1)) :
    finiteTapeStream tape j.val = tape j := by
  unfold finiteTapeStream
  apply congrArg tape
  apply Fin.ext
  exact Nat.mod_eq_of_lt j.isLt

theorem finiteTapeStream_restrict {n : ℕ} {B : Type*} (tape : Fin (n+1) → B) :
    (fun i : Fin (n+1) => finiteTapeStream tape i.val) = tape := funext (finiteTapeStream_prefix tape)

end MatroidProphetSecretary
