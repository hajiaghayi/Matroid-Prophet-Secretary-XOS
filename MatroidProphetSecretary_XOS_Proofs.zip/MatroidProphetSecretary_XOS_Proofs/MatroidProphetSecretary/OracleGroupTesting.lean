import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Lattice.Basic
import Mathlib.Tactic

/-! Adaptive binary group testing, with queries charged to candidates actually removed. -/

namespace MatroidProphetSecretary

open Finset

inductive QueryTree (E : Type*) where
  | leaf : Option E → QueryTree E
  | node : QueryTree E → QueryTree E → QueryTree E

variable {E : Type*} [DecidableEq E]

def QueryTree.labels : QueryTree E → Finset E
  | .leaf none => ∅
  | .leaf (some e) => {e}
  | .node left right => left.labels ∪ right.labels

def QueryTree.depth : QueryTree E → ℕ
  | .leaf _ => 0
  | .node left right => 1+max left.depth right.depth

def groupTest (oracle : Finset E → Bool) : QueryTree E → Finset E → Finset E × ℕ
  | tree, candidates =>
      if oracle (candidates ∩ tree.labels) then
        match tree with
        | .leaf none => (candidates,1)
        | .leaf (some e) => (candidates.erase e,1)
        | .node left right =>
            let first := groupTest oracle left candidates
            let second := groupTest oracle right first.1
            (second.1,1+first.2+second.2)
      else (candidates,1)

theorem groupTest_correct (oracle : Finset E → Bool) (bad : E → Prop) [DecidablePred bad]
    (horacle : ∀ S, oracle S = true ↔ ∃ e ∈ S, bad e) (tree : QueryTree E) (U : Finset E) :
    (groupTest oracle tree U).1 = U.filter (fun e => e ∉ tree.labels ∨ ¬ bad e) := by
  induction tree generalizing U with
  | leaf label =>
    cases label with
    | none =>
      have hn : oracle (U ∩ (QueryTree.leaf (none : Option E)).labels) = false := by
        apply Bool.eq_false_iff.mpr
        intro h
        simpa [QueryTree.labels] using (horacle _).mp h
      simp [groupTest,hn,QueryTree.labels]
    | some e =>
      by_cases ht : oracle (U ∩ (QueryTree.leaf (some e)).labels) = true
      · have he : e ∈ U ∧ bad e := by simpa [QueryTree.labels] using (horacle _).mp ht
        simp only [groupTest,ht,if_true,QueryTree.labels]
        ext x
        simp only [mem_erase,mem_filter,mem_singleton]
        by_cases hxe : x = e <;> simp_all
      · have hn : ¬ (e ∈ U ∧ bad e) := by
          intro he
          exact ht ((horacle _).mpr (by simpa [QueryTree.labels] using he))
        have hfalse : oracle (U ∩ {e}) = false := Bool.eq_false_iff.mpr ht
        simp only [groupTest,QueryTree.labels,hfalse,Bool.false_eq_true,if_false]
        symm
        apply filter_eq_self.mpr
        intro x hx
        by_cases hxe : x = e
        · subst x
          exact Or.inr (fun hb => hn ⟨hx,hb⟩)
        · exact Or.inl (by simpa only [mem_singleton] using hxe)
  | node left right ihl ihr =>
    by_cases ht : oracle (U ∩ (QueryTree.node left right).labels) = true
    · simp only [groupTest,ht,if_true]
      rw [ihr,ihl,filter_filter]
      ext e
      simp only [mem_filter,QueryTree.labels,mem_union]
      tauto
    · have hn : ∀ e ∈ U, e ∈ left.labels ∪ right.labels → ¬ bad e := by
        intro e he hl hb
        exact ht ((horacle _).mpr ⟨e,mem_inter.mpr ⟨he,hl⟩,hb⟩)
      simp only [groupTest,ht,if_false]
      ext e
      simp only [mem_filter,QueryTree.labels]
      constructor
      · intro he
        exact ⟨he,by by_cases hl : e ∈ left.labels ∪ right.labels; exact Or.inr (hn e he hl); exact Or.inl hl⟩
      · exact And.left

theorem groupTest_subset (oracle : Finset E → Bool) (bad : E → Prop) [DecidablePred bad]
    (horacle : ∀ S, oracle S = true ↔ ∃ e ∈ S, bad e) (tree : QueryTree E) (U : Finset E) :
    (groupTest oracle tree U).1 ⊆ U := by
  rw [groupTest_correct oracle bad horacle]
  exact filter_subset _ _

theorem groupTest_strict_card (oracle : Finset E → Bool) (bad : E → Prop) [DecidablePred bad]
    (horacle : ∀ S, oracle S = true ↔ ∃ e ∈ S, bad e) (tree : QueryTree E) (U : Finset E)
    (htrue : oracle (U ∩ tree.labels) = true) : (groupTest oracle tree U).1.card < U.card := by
  obtain ⟨e,he,hb⟩ := (horacle _).mp htrue
  apply card_lt_card
  apply ssubset_iff_subset_ne.mpr
  refine ⟨groupTest_subset oracle bad horacle tree U,?_⟩
  intro hEq
  have hm : e ∈ (groupTest oracle tree U).1 := hEq.symm ▸ (mem_inter.mp he).1
  rw [groupTest_correct oracle bad horacle] at hm
  exact (mem_filter.mp hm).2.elim (fun h => h (mem_inter.mp he).2) (fun h => h hb)

theorem groupTest_query_bound (oracle : Finset E → Bool) (bad : E → Prop) [DecidablePred bad]
    (horacle : ∀ S, oracle S = true ↔ ∃ e ∈ S, bad e) (tree : QueryTree E) (U : Finset E) :
    (groupTest oracle tree U).2 ≤ 1+2*tree.depth*(U.card-(groupTest oracle tree U).1.card) := by
  induction tree generalizing U with
  | leaf label =>
    cases label <;> simp [groupTest,QueryTree.depth] <;> split_ifs <;> simp
  | node left right ihl ihr =>
    by_cases ht : oracle (U ∩ (QueryTree.node left right).labels) = true
    · let first := groupTest oracle left U
      let second := groupTest oracle right first.1
      have hfirst : first.1.card ≤ U.card := card_le_card (groupTest_subset oracle bad horacle left U)
      have hsecond : second.1.card ≤ first.1.card := card_le_card (groupTest_subset oracle bad horacle right first.1)
      have hstrict := groupTest_strict_card oracle bad horacle (.node left right) U ht
      change (groupTest oracle (.node left right) U).1.card < U.card at hstrict
      simp only [groupTest,ht,if_true] at hstrict ⊢
      change 1+first.2+second.2 ≤ 1+2*(1+max left.depth right.depth)*(U.card-second.1.card)
      have hc1 := ihl U
      have hc2 := ihr first.1
      change first.2 ≤ 1+2*left.depth*(U.card-first.1.card) at hc1
      change second.2 ≤ 1+2*right.depth*(first.1.card-second.1.card) at hc2
      have hsum : (U.card-first.1.card)+(first.1.card-second.1.card) = U.card-second.1.card := by omega
      have hpos : 1 ≤ U.card-second.1.card := by change second.1.card < U.card at hstrict; omega
      have hl := Nat.mul_le_mul_right (U.card-first.1.card) (Nat.mul_le_mul_left 2 (le_max_left left.depth right.depth))
      have hr := Nat.mul_le_mul_right (first.1.card-second.1.card) (Nat.mul_le_mul_left 2 (le_max_right left.depth right.depth))
      nlinarith
    · simp [groupTest,ht,QueryTree.depth]

end MatroidProphetSecretary
