import MatroidProphetSecretary.ThresholdChildPotentials
import MatroidProphetSecretary.PolicyFeasibility

/-! A first-arrival decision followed by a policy on the actual residual labels. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def remainingIndex {n : ℕ} (e x : Fin (n+1)) (hx : x ≠ e) : Fin n :=
  Classical.choose (remainingLabel_surjective_away e x hx)

theorem remainingLabel_index {n : ℕ} (e x : Fin (n+1)) (hx : x ≠ e) :
    remainingLabel e (remainingIndex e x hx) = x :=
  Classical.choose_spec (remainingLabel_surjective_away e x hx)

theorem remainingIndex_label {n : ℕ} (e : Fin (n+1)) (i : Fin n) (h : remainingLabel e i ≠ e) :
    remainingIndex e (remainingLabel e i) h = i :=
  remainingLabel_injective e (remainingLabel_index e _ h)

def liftObservation {n : ℕ} (e : Fin (n+1)) (x : Observation n) : Observation (n+1) :=
  ⟨remainingLabel e x.label,x.value,x.accepted⟩

def lowerObservation {n : ℕ} (e : Fin (n+1)) (x : Observation (n+1)) : Option (Observation n) :=
  if h : x.label ≠ e then some ⟨remainingIndex e x.label h,x.value,x.accepted⟩ else none

theorem lower_lift_observation {n : ℕ} (e : Fin (n+1)) (x : Observation n) :
    lowerObservation e (liftObservation e x) = some x := by
  simp only [lowerObservation,liftObservation]
  rw [dif_pos (remainingLabel_ne e x.label),remainingIndex_label]

theorem lower_lift_history {n : ℕ} (e : Fin (n+1)) (history : List (Observation n)) :
    (history.map (liftObservation e)).filterMap (lowerObservation e) = history := by
  induction history with
  | nil => rfl
  | cons x xs ih => simp only [List.map_cons,List.filterMap_cons,lower_lift_observation,ih]

def firstArrivalPolicy {n : ℕ} (decision : Fin (n+1) → ℝ → Bool)
    (child : Fin (n+1) → Bool → OnlinePolicy n 0) : OnlinePolicy (n+1) 0 :=
  fun _ history e v => match history with
    | [] => decision e v
    | first :: rest => if h : e ≠ first.label then
        child first.label first.accepted 0 (rest.filterMap (lowerObservation first.label))
          (remainingIndex first.label e h) v
      else false

theorem firstArrivalPolicy_after {n : ℕ} (decision : Fin (n+1) → ℝ → Bool)
    (child : Fin (n+1) → Bool → OnlinePolicy n 0) (seed : Fin (2^0))
    (first : Observation (n+1)) (history : List (Observation n)) (i : Fin n) (v : ℝ) :
    firstArrivalPolicy decision child seed (first :: history.map (liftObservation first.label))
      (remainingLabel first.label i) v = child first.label first.accepted 0 history i v := by
  simp only [firstArrivalPolicy]
  rw [dif_pos (remainingLabel_ne first.label i),lower_lift_history,remainingIndex_label]

theorem run_firstArrivalPolicy {n : ℕ} (decision : Fin (n+1) → ℝ → Bool)
    (child : Fin (n+1) → Bool → OnlinePolicy n 0) (seed : Fin (2^0))
    (values : Fin (n+1) → ℝ) (first : Observation (n+1))
    (order : List (Fin n)) (history : List (Observation n)) :
    runPolicy (firstArrivalPolicy decision child) seed values (order.map (remainingLabel first.label))
      (first :: history.map (liftObservation first.label)) =
      first :: (runPolicy (child first.label first.accepted) 0 (fun i => values (remainingLabel first.label i))
        order history).map (liftObservation first.label) := by
  induction order generalizing history with
  | nil => rfl
  | cons i rest ih =>
    simp only [List.map_cons,runPolicy,firstArrivalPolicy_after]
    have hh : (first :: List.map (liftObservation first.label) history) ++
        [⟨remainingLabel first.label i,values (remainingLabel first.label i),
          child first.label first.accepted 0 history i (values (remainingLabel first.label i))⟩] =
        first :: (history ++ [(⟨i,values (remainingLabel first.label i),
          child first.label first.accepted 0 history i (values (remainingLabel first.label i))⟩ : Observation n)]).map (liftObservation first.label) := by
      simp only [List.map_append,List.map_cons,List.map_nil,List.cons_append,liftObservation]
    rw [hh,ih]

theorem completed_firstArrivalPolicy {n : ℕ} (decision : Fin (n+1) → ℝ → Bool)
    (child : Fin (n+1) → Bool → OnlinePolicy n 0) (seed : Fin (2^0))
    (values : Fin (n+1) → ℝ) (e : Fin (n+1)) (order : Equiv.Perm (Fin n)) :
    completedHistory (firstArrivalPolicy decision child) seed values (Equiv.Perm.decomposeFin.symm (e,order)) =
      ⟨e,values e,decision e (values e)⟩ ::
        (completedHistory (child e (decision e (values e))) 0 (fun i => values (remainingLabel e i)) order).map (liftObservation e) := by
  rw [completedHistory_uncons]
  change runPolicy _ _ _ _ (⟨e,values e,decision e (values e)⟩ :: List.map (liftObservation e) []) = _
  have hm : (List.finRange n).map (fun i => remainingLabel e (order i)) =
      ((List.finRange n).map order).map (remainingLabel e) := by rw [List.map_map]; rfl
  rw [hm]
  exact run_firstArrivalPolicy decision child seed values ⟨e,values e,decision e (values e)⟩
    ((List.finRange n).map order) []

theorem acceptedSet_lift {n : ℕ} (e : Fin (n+1)) (history : List (Observation n)) :
    acceptedSet (history.map (liftObservation e)) = (acceptedSet history).image (remainingLabel e) := by
  simp only [acceptedSet,List.filter_map,List.map_map,Function.comp_def,liftObservation]
  ext x
  simp

theorem acceptedSet_first_lift {n : ℕ} (first : Observation (n+1)) (history : List (Observation n)) :
    acceptedSet (first :: history.map (liftObservation first.label)) =
      if first.accepted then insert first.label ((acceptedSet history).image (remainingLabel first.label))
      else (acceptedSet history).image (remainingLabel first.label) := by
  have hc : acceptedSet (first :: history.map (liftObservation first.label)) =
      if first.accepted then insert first.label (acceptedSet (history.map (liftObservation first.label)))
      else acceptedSet (history.map (liftObservation first.label)) := by
    cases h : first.accepted <;> simp [acceptedSet,List.filter_cons,h]
  rw [hc,acceptedSet_lift]

theorem firstArrivalPolicy_feasible {n : ℕ} (M : Matroid (Fin (n+1)))
    (decision : Fin (n+1) → ℝ → Bool) (child : Fin (n+1) → Bool → OnlinePolicy n 0)
    (haccept : ∀ e v, decision e v = true → M.Indep ({e} : Set (Fin (n+1))))
    (hdelete : ∀ e, PolicyFeasible (remainingDelete M e) (child e false))
    (hcontract : ∀ e, M.Indep ({e} : Set (Fin (n+1))) → PolicyFeasible (remainingContract M e) (child e true)) :
    PolicyFeasible M (firstArrivalPolicy decision child) := by
  intro seed values order
  obtain ⟨⟨e,rest⟩,rfl⟩ := Equiv.Perm.decomposeFin.symm.surjective order
  rw [completed_firstArrivalPolicy,acceptedSet_first_lift]
  cases ht : decision e (values e)
  · simp only [ht,Bool.false_eq_true,if_false]
    exact remainingDelete_feasible M e _ (hdelete e 0 _ rest)
  · simp only [ht,if_true]
    simpa only [Finset.coe_insert] using remainingContract_feasible M e (haccept e _ ht) _
      (hcontract e (haccept e _ ht) 0 (fun i => values (remainingLabel e i)) rest)

end MatroidProphetSecretary
