import MatroidProphetSecretary.ObservedRandomTables

/-! Private tapes are realized by independent finite tables queried by the revealed real value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

def observedValueSupport (observed : Fin N → V → ℝ) (e : Fin N) : Finset ℝ := univ.image (observed e)
abbrev ObservedValue (observed : Fin N → V → ℝ) (e : Fin N) := ↥(observedValueSupport observed e)

local instance (observed : Fin N → V → ℝ) (e : Fin N) : DecidableEq (ObservedValue observed e) :=
  fun a b => Classical.propDecidable (a = b)

def observedValueAtom (observed : Fin N → V → ℝ) (e : Fin N) (v : V) : ObservedValue observed e :=
  ⟨observed e v,by simp [observedValueSupport]⟩

def observeGridTape (observed : Fin N → V → ℝ) (e : Fin N) (tape : GridPrivateTape N L V) : ObservedValue observed e :=
  observedValueAtom observed e tape.1

abbrev ValueTapeTables (N L : ℕ) {V : Type*} [Fintype V] (observed : Fin N → V → ℝ) :=
  ∀ e, ObservedValue observed e → GridPrivateTape N L V

def readValueTape (observed : Fin N → V → ℝ) (table : ValueTapeTables N L observed)
    (e : Fin N) (v : ℝ) : Option (GridPrivateTape N L V) :=
  if hv : v ∈ observedValueSupport observed e then some (table e ⟨v,hv⟩) else none

theorem readValueTape_atom (observed : Fin N → V → ℝ) (table : ValueTapeTables N L observed)
    (e : Fin N) (v : V) : readValueTape observed table e (observed e v) = some (table e (observedValueAtom observed e v)) := by
  simp [readValueTape,observedValueSupport,observedValueAtom]

namespace PrivateGridConfig

variable (cfg : PrivateGridConfig N L V)

def valueTableLaw (observed : Fin N → V → ℝ) : FiniteLaw (ValueTapeTables N L observed) :=
  FiniteLaw.product (fun e => FiniteLaw.observedTableLaw (cfg.tapes e) (observeGridTape observed e))

theorem tapes_observed_law (observed : Fin N → V → ℝ) (e : Fin N) :
    (cfg.tapes e).map (observeGridTape observed e) = (cfg.prior e).map (observedValueAtom observed e) := by
  apply FiniteLaw.ext_expect
  intro f
  simp [FiniteLaw.map_expect,tapes,earlyPrivateTapeLaw,referencePrivateTapeLaw,FiniteLaw.sharedValueTapes,
    FiniteLaw.dependentPair,FiniteLaw.bind_expect,observeGridTape]

theorem value_table_unrolling (observed : Fin N → V → ℝ) (f : (Fin N → GridPrivateTape N L V) → ℝ) :
    (FiniteLaw.product cfg.tapes).expect f =
      (FiniteLaw.product cfg.prior).expect (fun values =>
        (cfg.valueTableLaw observed).expect (fun tables =>
          f (fun e => tables e (observedValueAtom observed e (values e))))) := by
  have he : (fun e => (cfg.tapes e).map (observeGridTape observed e)) =
      (fun e => (cfg.prior e).map (observedValueAtom observed e)) := by
    funext e
    exact cfg.tapes_observed_law observed e
  have h := FiniteLaw.product_observed_table_expectation cfg.tapes (observeGridTape observed) f
  rw [he,FiniteLaw.product_map_expect] at h
  exact h

theorem value_table_consistency (observed : Fin N → V → ℝ) (sample : Fin N → V)
    (hs : (FiniteLaw.product cfg.prior).mass sample ≠ 0) (tables : ValueTapeTables N L observed)
    (ht : (cfg.valueTableLaw observed).mass tables ≠ 0) (e : Fin N) :
    observed e (tables e (observedValueAtom observed e (sample e))).1 = observed e (sample e) := by
  have hs' := FiniteLaw.product_support cfg.prior sample hs e
  have hp : 0 < (cfg.prior e).mass (sample e) :=
    lt_of_le_of_ne ((cfg.prior e).nonneg _) (Ne.symm hs')
  have hobs : ((cfg.tapes e).map (observeGridTape observed e)).mass (observedValueAtom observed e (sample e)) ≠ 0 := by
    rw [cfg.tapes_observed_law observed e,FiniteLaw.map_mass_probability]
    exact ne_of_gt (hp.trans_le (FiniteLaw.mass_le_prob (cfg.prior e)
      (fun v => observedValueAtom observed e v = observedValueAtom observed e (sample e)) (sample e) rfl))
  have heq := FiniteLaw.observed_table_consistency (cfg.tapes e) (observeGridTape observed e)
    (observedValueAtom observed e (sample e)) (tables e) hobs
    (FiniteLaw.product_support (fun i => FiniteLaw.observedTableLaw (cfg.tapes i) (observeGridTape observed i)) tables ht e)
  exact congrArg Subtype.val heq

end PrivateGridConfig
end MatroidProphetSecretary
