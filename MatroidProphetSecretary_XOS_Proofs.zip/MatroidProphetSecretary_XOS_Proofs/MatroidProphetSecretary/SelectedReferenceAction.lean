import MatroidProphetSecretary.ReferenceContinuationPolicy
import MatroidProphetSecretary.ReferenceThresholdProgress

/-! All branches of the selected-reference action pay its potential on an accurate saved batch. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

def referenceThresholdEpochReward {N k B : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N)))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    (q : ℝ) {m : ℕ} (x : Fin m → (Fin G.last × (Fin N → Bool))) : ℝ :=
  letI : Nonempty (Fin N) := ⟨⟨0,hN⟩⟩
  (FiniteLaw.uniform (Fin N)).expect (fun e => (prior.law e).expect (fun v =>
    thresholdEpochValue (FiniteLaw.product (alignedReferenceLaws prior.law (fun e v => (prior.value e v : ℝ)) q)) M
      (optionalCoordinateValues (fun e v => (prior.value e v : ℝ))) hnonloop (discount q)
      (referenceSavedThreshold prior.law (fun e v => (prior.value e v : ℝ)) G M q B x) e (prior.value e v)))

theorem selected_reference_action_pays {N k B : ℕ} (hN : 0 < N) (hB : 0 < B) (hNB : N ≤ B)
    (prior : RationalPriors N k) (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N)))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    {q : ℝ} (hq : q ∈ interval) {m : ℕ} (x : Fin m → (Fin G.last × (Fin N → Bool)))
    (hF : 0 < referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws prior.law (fun e v => (prior.value e v : ℝ)) q)
      (referenceInstanceValues (fun e v => (prior.value e v : ℝ))) G M hnonloop B epsilon x)
    (hstationary : |q-1| < 3*delta →
      stationaryRatio q-20*epsilon ≤ referenceDeletion prior.law M (fun e v => (prior.value e v : ℝ)) q/
          referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ∧
        referenceDeletion prior.law M (fun e v => (prior.value e v : ℝ)) q/
            referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ stationaryRatio q+
          referenceStable prior.law M (fun e v => (prior.value e v : ℝ)) hnonloop q/
            referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q+20*epsilon) :
    if 3*delta ≤ |q-1| ∨ eta < referenceStabilityEstimate prior.law (fun e v => (prior.value e v : ℝ)) G M q x then
      ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧
        discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ expectedPolicyReward prior policy
    else discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤
      referenceThresholdEpochReward (B := B) hN prior M hnonloop G q x := by
  by_cases hg : 3*delta ≤ |q-1|
  · rw [if_pos (Or.inl hg)]
    obtain ⟨K,policy,hfeasible,hreward⟩ := reference_guard_policy hN prior M hq hg hF
    exact ⟨K,policy,hfeasible,hreward.le⟩
  · have hs := hstationary (lt_of_not_ge hg)
    have hstable := referenceStabilityEstimate_branches prior.law (fun e v => (prior.value e v : ℝ)) G M hnonloop q B x
    rw [fin_order_decidableEq] at hstable
    have hstable := hstable hF hgood
    by_cases ht : eta < referenceStabilityEstimate prior.law (fun e v => (prior.value e v : ℝ)) G M q x
    · rw [if_pos (Or.inr ht)]
      rw [if_pos ht] at hstable
      obtain ⟨K,policy,hfeasible,hreward⟩ := reference_stability_policy hN prior M hnonloop hq hF hs.1 hstable.le
      exact ⟨K,policy,hfeasible,hreward.le⟩
    · rw [if_neg (not_or.mpr ⟨hg,ht⟩)]
      rw [if_neg ht] at hstable
      exact reference_threshold_epoch_progress hN hB hNB prior M hnonloop G hq x hF hgood hs.1 hs.2 hstable

end MatroidProphetSecretary
