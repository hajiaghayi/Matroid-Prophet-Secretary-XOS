import MatroidProphetSecretary.MarkedKernelExpectation

/-! Physical kernel expectations act on replayed matroid states by the explicit exchange generator. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

theorem recordReplay_updateGridHistory (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (mark : Option (GridMark N L V)) :
    recordReplay M base hbase value (updateGridHistory history mark) =
      virtualUpdate M base hbase value (recordReplay M base hbase value history)
        (mark.map (fun event => (event.1,event.2.2))) := by
  cases mark with
  | none => rfl
  | some event => exact recordReplay_append M base hbase value history event.1 _ event.2.2

namespace PrivateGridConfig

variable (cfg : PrivateGridConfig N L V)

theorem reachable_history_valid (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) (hn : n ≤ L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history)) :
    ValidExchangeRecords M base hbase value history := by
  obtain ⟨tapes,ht⟩ := FiniteLaw.exists_of_prob_pos (FiniteLaw.product cfg.laws)
    (fun tapes => cfg.run tapes n = history) (by convert hp using 1; congr 1)
  rw [← ht]
  exact cfg.run_valid M base hbase value hlive tapes n hn

theorem historyKernel_replay_loss (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (F : VirtualState M → ℝ) :
    (cfg.historyKernel n history).expect (fun mark => F (recordReplay M base hbase value history)-
      F (recordReplay M base hbase value (updateGridHistory history mark))) =
      ((1/(L:ℝ))*cfg.historyRate history n)*(FiniteLaw.product cfg.reference).expect
        (fun y => if gridLabel N cfg.labels_pos n ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y
          then F (recordReplay M base hbase value history)-
            F (virtualUpdate M base hbase value (recordReplay M base hbase value history) (some (gridLabel N cfg.labels_pos n,y)))
          else 0) := by
  by_cases hseen : gridLabel N cfg.labels_pos n ∈ recordLabels history
  · rw [cfg.historyKernel_seen n hn history hseen,FiniteLaw.pointMass_expect]
    have hvalid := cfg.reachable_history_valid M base hbase value hlive history n hn.le hp
    have hnot (y : Fin N → Option V) :
        gridLabel N cfg.labels_pos n ∉ virtualLive M base hbase value (recordReplay M base hbase value history) y := by
      intro hmem
      exact hvalid.fresh M base hbase value history _ y hmem hseen
    simp only [hnot,if_false,FiniteLaw.expect_const,mul_zero]
    simp [updateGridHistory,appendOptional]
  · rw [cfg.historyKernel_expect_zero history n hn hp hseen _ (by simp [updateGridHistory,appendOptional])]
    congr 1
    apply congrArg (FiniteLaw.expect _)
    funext y
    simp [hlive,recordReplay_updateGridHistory]

end PrivateGridConfig
end MatroidProphetSecretary
