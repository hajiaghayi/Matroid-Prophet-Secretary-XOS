import MatroidProphetSecretary.BlockPinning

/-! Sampling a nonempty product layer by its first active label. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def firstActiveEvent (b : E) (x : E → Bool) : Prop := x b = true ∧ ∀ i, i < b → x i = false

def firstActiveSample (b : E) (x : E → Bool) : E → Bool :=
  FiniteLaw.resampleBlock (fun i => i ≤ b) x (fun i => decide (i = b))

theorem firstActiveEvent_eq_block (b : E) (x : E → Bool) :
    firstActiveEvent b x ↔ ∀ i, i ≤ b → x i = decide (i = b) := by
  constructor
  · rintro ⟨hb, hbefore⟩ i hi
    rcases lt_or_eq_of_le hi with hi | rfl
    · simpa only [decide_eq_false (ne_of_lt hi)] using hbefore i hi
    · simpa using hb
  · intro h
    constructor
    · simpa using h b le_rfl
    · intro i hi
      simpa only [decide_eq_false (ne_of_lt hi)] using h i hi.le

theorem firstActiveSample_is_first (b : E) (x : E → Bool) : firstActiveEvent b (firstActiveSample b x) := by
  rw [firstActiveEvent_eq_block]
  intro i hi
  simp [firstActiveSample, FiniteLaw.resampleBlock, hi]

theorem firstActiveEvent_unique (x : E → Bool) {b c : E}
    (hb : firstActiveEvent b x) (hc : firstActiveEvent c x) : b = c := by
  rcases lt_trichotomy b c with h | h | h
  · have hf := hc.2 b h
    rw [hb.1] at hf
    contradiction
  · exact h
  · have hf := hb.2 c h
    rw [hc.1] at hf
    contradiction

theorem firstActiveEvent_exists (x : E → Bool) (hx : ∃ e, x e = true) : ∃ b, firstActiveEvent b x := by
  let S := univ.filter (fun e => x e = true)
  have hS : S.Nonempty := by
    obtain ⟨e, he⟩ := hx
    exact ⟨e, mem_filter.mpr ⟨mem_univ _, he⟩⟩
  let b := S.min' hS
  refine ⟨b, (mem_filter.mp (min'_mem S hS)).2, ?_⟩
  intro i hi
  have hn : x i ≠ true := by
    intro hxi
    have hbi : b ≤ i := min'_le S i (mem_filter.mpr ⟨mem_univ _, hxi⟩)
    exact (not_lt_of_ge hbi) hi
  cases hxi : x i <;> simp_all

theorem firstActive_indicator_sum (x : E → Bool) (v : ℝ) :
    (∑ b, if firstActiveEvent b x then v else 0) = if ∃ e, x e = true then v else 0 := by
  by_cases hx : ∃ e, x e = true
  · rw [if_pos hx]
    obtain ⟨b, hb⟩ := firstActiveEvent_exists x hx
    rw [sum_eq_single b]
    · simp [hb]
    · intro c hc hcb
      have hn : ¬ firstActiveEvent c x := fun h => hcb (firstActiveEvent_unique x h hb)
      simp [hn]
    · simp
  · have hn (b : E) : ¬ firstActiveEvent b x := fun hb => hx ⟨b, hb.1⟩
    simp [hx, hn]

theorem firstActive_sampling_identity (laws : E → FiniteLaw Bool) (b : E) (f : (E → Bool) → ℝ) :
    (FiniteLaw.product laws).prob (firstActiveEvent b) *
        (FiniteLaw.product laws).expect (fun x => f (firstActiveSample b x)) =
      (FiniteLaw.product laws).expect (fun x => if firstActiveEvent b x then f x else 0) := by
  have h := FiniteLaw.product_pin_block_expect laws (fun i => i ≤ b) (fun i => decide (i = b)) f
  simpa only [FiniteLaw.prob, firstActiveSample, ← firstActiveEvent_eq_block] using h

theorem firstActive_mixture_expect (laws : E → FiniteLaw Bool) (f : (E → Bool) → ℝ) :
    (∑ b, (FiniteLaw.product laws).prob (firstActiveEvent b) *
      (FiniteLaw.product laws).expect (fun x => f (firstActiveSample b x))) =
      (FiniteLaw.product laws).expect (fun x => if ∃ e, x e = true then f x else 0) := by
  simp_rw [firstActive_sampling_identity]
  rw [← FiniteLaw.expect_finset_sum]
  simp only [firstActive_indicator_sum]

theorem firstActive_probability (laws : E → FiniteLaw Bool) (b : E) :
    (FiniteLaw.product laws).prob (firstActiveEvent b) =
      (laws b).mass true * ∏ i, if i < b then (laws i).mass false else 1 := by
  have hp : (FiniteLaw.product laws).prob (firstActiveEvent b) =
      ∏ i, if i ≤ b then (laws i).mass (decide (i = b)) else 1 := by
    have h := FiniteLaw.product_prob_exact_block laws (fun i => i ≤ b) (fun i => decide (i = b))
    simp only [FiniteLaw.prob, ← firstActiveEvent_eq_block] at h
    refine h.trans ?_
    apply prod_congr rfl
    intro i hi
    by_cases hib : i ≤ b <;> simp [hib]
  rw [hp]
  have hterm (i : E) : (if i ≤ b then (laws i).mass (decide (i = b)) else 1) =
      (if i < b then (laws i).mass false else 1) * (if i = b then (laws b).mass true else 1) := by
    rcases lt_trichotomy i b with h | rfl | h
    · simp [h, h.le, ne_of_lt h]
    · simp
    · simp [not_le_of_gt h, not_lt_of_ge h.le, ne_of_gt h]
  simp_rw [hterm]
  rw [prod_mul_distrib]
  simp only [Fintype.prod_ite_eq']
  exact mul_comm _ _

theorem firstActive_probabilities_sum (laws : E → FiniteLaw Bool) :
    (∑ b, (FiniteLaw.product laws).prob (firstActiveEvent b)) =
      (FiniteLaw.product laws).prob (fun x => ∃ e, x e = true) := by
  have h := firstActive_mixture_expect laws (fun _ => (1 : ℝ))
  simpa only [FiniteLaw.expect_const, mul_one] using h

end MatroidProphetSecretary
