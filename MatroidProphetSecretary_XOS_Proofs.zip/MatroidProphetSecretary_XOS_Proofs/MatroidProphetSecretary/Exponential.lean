import Mathlib.Data.Complex.ExponentialBounds
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace MatroidProphetSecretary

/-- A small-argument Taylor bound obtained directly from mathlib's
exponential-series remainder certificate. -/
theorem exp_small_upper {t : ℝ} (ht : |t| ≤ 1 / 100) :
    Real.exp t ≤ 1 + t + (503 / 1000) * t ^ 2 := by
  have ht1 : |t| ≤ 1 := by linarith
  have h := (abs_le.mp (Real.exp_bound ht1 (by norm_num : 0 < (3 : ℕ)))).2
  norm_num [Finset.sum_range_succ, Nat.factorial] at h
  have hrem : |t| ^ 3 ≤ (1 / 100) * t ^ 2 := by
    have := mul_le_mul_of_nonneg_right ht (sq_nonneg t)
    nlinarith [sq_abs t]
  nlinarith [sq_nonneg t]

theorem exp_tiny_upper {t : ℝ} (ht : |t| ≤ 1 / 400) :
    Real.exp t ≤ 1 + t + (501 / 1000) * t ^ 2 := by
  have ht1 : |t| ≤ 1 := by linarith
  have h := (abs_le.mp (Real.exp_bound ht1 (by norm_num : 0 < (3 : ℕ)))).2
  norm_num [Finset.sum_range_succ, Nat.factorial] at h
  have hrem : |t| ^ 3 ≤ (1 / 400) * t ^ 2 := by
    have := mul_le_mul_of_nonneg_right ht (sq_nonneg t)
    nlinarith [sq_abs t]
  nlinarith [sq_nonneg t]

theorem exp_neg_quadratic_upper {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    Real.exp (-x) ≤ 1 - x + x ^ 2 / 2 := by
  have ht : |(-x)| ≤ 1 := by simpa [abs_neg, abs_of_nonneg hx]
  have h := (abs_le.mp (Real.exp_bound ht (by norm_num : 0 < (4 : ℕ)))).2
  norm_num [Finset.sum_range_succ, Nat.factorial, abs_neg, abs_of_nonneg hx] at h
  have hpow : x ^ 4 ≤ x ^ 3 := by
    have := mul_le_mul_of_nonneg_right hx1 (pow_nonneg hx 3)
    nlinarith
  nlinarith [pow_nonneg hx 3]

theorem exp_neg_cubic_lower {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) :
    1 - x + x ^ 2 / 2 - (2 / 9) * x ^ 3 ≤ Real.exp (-x) := by
  have ht : |(-x)| ≤ 1 := by simpa [abs_neg, abs_of_nonneg hx]
  have h := (abs_le.mp (Real.exp_bound ht (by norm_num : 0 < (3 : ℕ)))).1
  norm_num [Finset.sum_range_succ, Nat.factorial, abs_neg, abs_of_nonneg hx] at h
  linarith

end MatroidProphetSecretary
