import MatroidProphetSecretary.BlockResampling
import MatroidProphetSecretary.BlockIndependence
import MatroidProphetSecretary.ProductMoments

/-! Pinning independent coordinates realizes conditioning without rejection sampling. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open scoped Classical

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V : ι → Type*} [∀ i, Fintype (V i)]

theorem resampleBlock_eq_self_of_matches (p : ι → Prop) (a x : ∀ i, V i)
    (h : ∀ i, p i → x i = a i) : resampleBlock p x a = x := by
  funext i
  by_cases hi : p i <;> simp [resampleBlock, hi, h i]

theorem product_pin_block_expect (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (a : ∀ i, V i) (f : (∀ i, V i) → ℝ) :
    (product laws).prob (fun x => ∀ i, p i → x i = a i) *
        (product laws).expect (fun x => f (resampleBlock p x a)) =
      (product laws).expect (fun x => if ∀ i, p i → x i = a i then f x else 0) := by
  have hind := product_expect_mul_of_disjoint laws p
    (fun x => if ∀ i, p i → x i = a i then (1 : ℝ) else 0)
    (fun x => f (resampleBlock p x a)) (by
      intro x y hxy
      have heq : (∀ i, p i → x i = a i) ↔ (∀ i, p i → y i = a i) := by
        constructor
        · intro hx i hi
          exact (hxy i hi).symm.trans (hx i hi)
        · intro hy i hi
          exact (hxy i hi).trans (hy i hi)
      simp only [heq]) (by
      intro x y hxy
      change f (resampleBlock p x a) = f (resampleBlock p y a)
      congr 1
      funext i
      by_cases hi : p i <;> simp [resampleBlock, hi, hxy i])
  change (product laws).expect _ * (product laws).expect _ = _
  rw [← hind]
  congr 1
  funext x
  by_cases hx : ∀ i, p i → x i = a i
  · simp [hx, resampleBlock_eq_self_of_matches p a x hx]
  · simp [hx]

theorem product_pin_block_prob (laws : ∀ i, FiniteLaw (V i)) (p : ι → Prop)
    (a : ∀ i, V i) (A : (∀ i, V i) → Prop) :
    (product laws).prob (fun x => ∀ i, p i → x i = a i) *
        (product laws).prob (fun x => A (resampleBlock p x a)) =
      (product laws).prob (fun x => (∀ i, p i → x i = a i) ∧ A x) := by
  have h := product_pin_block_expect laws p a (fun x => if A x then 1 else 0)
  convert h using 1
  unfold prob
  congr 1
  funext x
  split_ifs <;> simp_all

end MatroidProphetSecretary.FiniteLaw
