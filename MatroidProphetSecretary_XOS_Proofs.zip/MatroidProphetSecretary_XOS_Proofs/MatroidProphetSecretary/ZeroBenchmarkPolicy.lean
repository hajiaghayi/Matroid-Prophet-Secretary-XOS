import MatroidProphetSecretary.PolicyFeasibility
import MatroidProphetSecretary.FiniteRandomPolicy

/-! Empty and zero-benchmark instances admit the policy that rejects every arrival. -/

namespace MatroidProphetSecretary

def rejectAllPolicy (N : ℕ) : OnlinePolicy N 0 := fun _ _ _ _ => false

theorem rejectAll_run_accepted {N : ℕ} (seed : Fin (2^0)) (values : Fin N → ℝ)
    (order : List (Fin N)) (history : List (Observation N)) :
    acceptedSet (runPolicy (rejectAllPolicy N) seed values order history) = acceptedSet history := by
  induction order generalizing history with
  | nil => rfl
  | cons e rest ih =>
    change acceptedSet (runPolicy (rejectAllPolicy N) seed values rest (history++[⟨e,values e,false⟩])) = _
    rw [ih,acceptedSet_append_observation]
    rfl

theorem rejectAll_completed_accepted {N : ℕ} (seed : Fin (2^0)) (values : Fin N → ℝ)
    (order : Equiv.Perm (Fin N)) : acceptedSet (completedHistory (rejectAllPolicy N) seed values order) = ∅ :=
  rejectAll_run_accepted seed values _ []

theorem rejectAll_feasible {N : ℕ} (M : Matroid (Fin N)) : PolicyFeasible M (rejectAllPolicy N) := by
  intro seed values order
  rw [rejectAll_completed_accepted]
  simpa using M.empty_indep

theorem rejectAll_expected_reward {N k : ℕ} (prior : RationalPriors N k) :
    expectedPolicyReward prior (rejectAllPolicy N) = 0 := by
  unfold expectedPolicyReward
  simp only [rejectAll_completed_accepted,weight,Finset.sum_empty,FiniteLaw.expect_const]

theorem competitiveness_of_zero_benchmark {N k : ℕ} (M : Matroid (Fin N)) (prior : RationalPriors N k)
    (hzero : expectedProphet M prior = 0) :
    ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧
      targetRatio*expectedProphet M prior ≤ expectedPolicyReward prior policy := by
  exact ⟨0,rejectAllPolicy N,rejectAll_feasible M,by rw [hzero,rejectAll_expected_reward,mul_zero]⟩

theorem expectedProphet_empty {k : ℕ} (M : Matroid (Fin 0)) (prior : RationalPriors 0 k) :
    expectedProphet M prior = 0 := by
  have hopt (v : Fin 0 → ℝ) : optimum M v = 0 := by
    apply le_antisymm _ (optimum_nonneg M v)
    apply optimumOver_le
    intro I hI
    have hI0 : I = ∅ := Finset.eq_empty_of_forall_not_mem (fun e he => Fin.elim0 e)
    rw [hI0]
    rfl
  unfold expectedProphet
  simp only [hopt,FiniteLaw.expect_const]

end MatroidProphetSecretary
