import MatroidProphetSecretary.ReferenceScreen
import MatroidProphetSecretary.ConditionalSampling
import MatroidProphetSecretary.AdaptiveBatches
import MatroidProphetSecretary.BlockResampling
import MatroidProphetSecretary.BernoulliVariation

/-! Sampling a candidate from the current value and fresh reference coordinates gives the claimed kernel. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {V E : Type*} [Fintype V] [Fintype E] [DecidableEq E]

def atomScreenProbability (prior : FiniteLaw V) (reference : FiniteLaw (Option V)) (q : ℝ) (v : V) : ℝ :=
  reference.mass (some v)/(q*prior.mass v)

theorem atomScreenProbability_bounds (prior : FiniteLaw V) (reference : FiniteLaw (Option V))
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, reference.mass (some v) ≤ q*prior.mass v) (v : V) :
    0 ≤ atomScreenProbability prior reference q v ∧ atomScreenProbability prior reference q v ≤ 1 := by
  by_cases hm : prior.mass v = 0
  · simp [atomScreenProbability,hm]
  · exact reference_screen_probability q (prior.mass v) (reference.mass (some v)) hq
      (lt_of_le_of_ne (prior.nonneg v) (fun h => hm h.symm)) (reference.nonneg _) (hdom v)

theorem atomScreenProbability_weight (prior : FiniteLaw V) (reference : FiniteLaw (Option V))
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, reference.mass (some v) ≤ q*prior.mass v) (v : V) :
    prior.mass v*atomScreenProbability prior reference q v = (1/q)*reference.mass (some v) := by
  by_cases hm : prior.mass v = 0
  · have hz : reference.mass (some v) = 0 := by
      have hb := hdom v
      rw [hm,mul_zero] at hb
      exact le_antisymm hb (reference.nonneg _)
    simp [hm,hz]
  · exact screened_atom_identity q (prior.mass v) (reference.mass (some v)) hq
      (lt_of_le_of_ne (prior.nonneg v) (fun h => hm h.symm))

def screenedAtomLaw (prior : FiniteLaw V) (reference : FiniteLaw (Option V))
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, reference.mass (some v) ≤ q*prior.mass v) : FiniteLaw (Option V) :=
  prior.bind (fun v =>
    (bernoulliLaw (atomScreenProbability prior reference q v)
      (atomScreenProbability_bounds prior reference q hq hdom v).1
      (atomScreenProbability_bounds prior reference q hq hdom v).2).map
      (fun b => if b = true then some v else none))

theorem screenedAtomLaw_expect (prior : FiniteLaw V) (reference : FiniteLaw (Option V))
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, reference.mass (some v) ≤ q*prior.mass v)
    (f : Option V → ℝ) (hf : f none = 0) :
    (screenedAtomLaw prior reference q hq hdom).expect f = (1/q)*reference.expect f := by
  simp only [screenedAtomLaw,FiniteLaw.bind_expect,FiniteLaw.map_expect,bernoulliLaw_expect,
    if_true,Bool.false_eq_true,if_false,hf,mul_zero,add_zero]
  unfold FiniteLaw.expect
  rw [Fintype.sum_option,hf,mul_zero,zero_add,mul_sum]
  apply sum_congr rfl
  intro v hv
  rw [← mul_assoc,atomScreenProbability_weight prior reference q hq hdom v]
  ring

theorem FiniteLaw.product_replace_coordinate (laws : E → FiniteLaw V) (e : E)
    (f : (E → V) → ℝ) :
    (laws e).expect (fun v => (FiniteLaw.product laws).expect (fun x => f (Function.update x e v))) =
      (FiniteLaw.product laws).expect f := by
  have heq (x y : E → V) : FiniteLaw.resampleBlock (fun i => i = e) x y = Function.update x e (y e) := by
    funext i
    by_cases hi : i = e
    · subst i; simp [FiniteLaw.resampleBlock]
    · simp [FiniteLaw.resampleBlock,hi]
  have h := FiniteLaw.product_resample_block laws (fun i => i = e) f
  simp_rw [heq] at h
  have hcoord (x : E → V) := FiniteLaw.product_expect_single_coordinate laws e
    (fun v => f (Function.update x e v))
  simp_rw [hcoord] at h
  rw [FiniteLaw.expect_comm] at h
  exact h

def screenedCandidateLaw (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v) :
    FiniteLaw (Option (E → Option V)) :=
  (screenedAtomLaw prior (references e) q hq hdom).bind (fun v => match v with
    | none => FiniteLaw.pointMass none
    | some value => (FiniteLaw.product references).map (fun x => some (Function.update x e (some value))))

theorem screenedCandidateLaw_expect (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (f : (E → Option V) → ℝ) (hf : ∀ x, x e = none → f x = 0) :
    (screenedCandidateLaw prior references e q hq hdom).expect (fun x => match x with
      | none => 0 | some y => f y) = (1/q)*(FiniteLaw.product references).expect f := by
  unfold screenedCandidateLaw
  rw [FiniteLaw.bind_expect]
  have hpoint (v : Option V) :
      (match v with
        | none => FiniteLaw.pointMass none
        | some value => (FiniteLaw.product references).map (fun x => some (Function.update x e (some value)))).expect
          (fun x => match x with | none => 0 | some y => f y) =
      (FiniteLaw.product references).expect (fun x => f (Function.update x e v)) := by
    cases v with
    | none => simp [FiniteLaw.pointMass_expect,hf]
    | some v => exact FiniteLaw.map_expect _ _ _
  simp_rw [hpoint]
  rw [screenedAtomLaw_expect _ _ _ hq hdom _ (by simp [hf]),FiniteLaw.product_replace_coordinate]

end MatroidProphetSecretary
