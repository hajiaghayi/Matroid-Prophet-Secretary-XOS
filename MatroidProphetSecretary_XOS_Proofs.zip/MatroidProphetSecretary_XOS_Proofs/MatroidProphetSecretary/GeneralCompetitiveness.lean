import MatroidProphetSecretary.FiniteRealProbabilityCompetitiveness
import MatroidProphetSecretary.QuantizedFiniteLaw
import MatroidProphetSecretary.QuantizedOptimumConvergence
import MatroidProphetSecretary.MeasurablePolicyReward

/-! The competitiveness existence theorem for arbitrary independent nonnegative integrable priors. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory ProbabilityTheory
open scoped Classical

theorem orderAveragedReward_reject (N : ℕ) (values : Fin N → ℝ) :
    orderAveragedReward (rejectAllPolicy N) values = 0 := by
  unfold orderAveragedReward
  simp only [rejectAll_completed_accepted,weight,Finset.sum_empty,FiniteLaw.expect_const]

theorem quantized_policy_reward_transfer {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hind : iIndepFun X μ) (hv : ∀ ω e, 0 ≤ X e ω)
    (hint : Integrable (fun ω => optimum M (fun e => X e ω)) μ)
    (n : ℕ) (policy : OnlinePolicy N 0) (hf : PolicyFeasible M policy) :
    finitePriorReward (quantizedMarginal μ X hX n) (fun _ i => (quantizeValue n i : ℝ)) policy ≤
      ∫ ω, orderAveragedReward (transformedPolicy (fun _ => rationalRound n) policy) (fun e => X e ω) ∂μ := by
  let indices := fun ω e => quantizeIndex n (X e ω)
  let value := fun _ : Fin N => fun i => (quantizeValue n i : ℝ)
  let rounded := fun ω => finitePolicyObservable value policy (indices ω)
  let actual := fun ω => orderAveragedReward (transformedPolicy (fun _ => rationalRound n) policy) (fun e => X e ω)
  have hindices : Measurable indices := measurable_pi_lambda _ (fun e => (measurable_quantizeIndex n).comp (hX e))
  have hrounded : Measurable rounded := (measurable_of_countable (finitePolicyObservable value policy)).comp hindices
  have hroundedint : Integrable rounded μ := by
    apply hint.mono' hrounded.aestronglyMeasurable
    exact Filter.Eventually.of_forall (fun ω => by
      have hb := orderAveragedReward_bounds M policy hf (fun e => rationalRound n (X e ω))
        (fun e => (rationalRound_bounds n (X e ω) (hv ω e)).1)
      change ‖orderAveragedReward policy (fun e => rationalRound n (X e ω))‖ ≤ _
      rw [Real.norm_eq_abs,abs_of_nonneg hb.1]
      exact hb.2.trans (optimum_mono M (fun e => (rationalRound_bounds n (X e ω) (hv ω e)).2)))
  have hactualint : Integrable actual μ := integrable_finite_observation_reward μ M X hX hv hint
    (fun _ => quantizeIndex n) (fun _ => measurable_quantizeIndex n) value policy hf
  have hpoint (ω : Ω) : rounded ω ≤ actual ω := by
    apply FiniteLaw.expect_mono
    intro order
    exact transformedPolicy_reward_lower (fun _ => rationalRound n) policy 0 (fun e => X e ω) order
      (fun e => (rationalRound_bounds n (X e ω) (hv ω e)).2)
  have h := integral_mono hroundedint hactualint hpoint
  have heq := quantized_independent_integral μ X hX hind n (finitePolicyObservable value policy)
  change (∫ ω, rounded ω ∂μ) = finitePriorReward (quantizedMarginal μ X hX n) value policy at heq
  rw [heq] at h
  exact h

theorem matroid_prophet_secretary_competitive {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hind : iIndepFun X μ) (hv : ∀ ω e, 0 ≤ X e ω)
    (hint : Integrable (fun ω => optimum M (fun e => X e ω)) μ) :
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      Measurable (fun ω => orderAveragedReward policy (fun e => X e ω)) ∧
      Integrable (fun ω => orderAveragedReward policy (fun e => X e ω)) μ ∧
      targetRatio*(∫ ω, optimum M (fun e => X e ω) ∂μ) ≤
        ∫ ω, orderAveragedReward policy (fun e => X e ω) ∂μ := by
  let F := ∫ ω, optimum M (fun e => X e ω) ∂μ
  have hF0 : 0 ≤ F := integral_nonneg (fun ω => optimum_nonneg M _)
  by_cases hz : F = 0
  · refine ⟨rejectAllPolicy N,rejectAll_feasible M,?_,?_,?_⟩
    · simpa only [orderAveragedReward_reject] using (measurable_const : Measurable (fun _ : Ω => (0:ℝ)))
    · simpa only [orderAveragedReward_reject] using (integrable_zero Ω ℝ μ)
    · change targetRatio*F ≤ _
      simp only [hz,mul_zero,orderAveragedReward_reject,integral_zero,le_refl]
  have hF : 0 < F := lt_of_le_of_ne hF0 (Ne.symm hz)
  have hbeta : 0 < beta := by norm_num [beta,theta,rho]
  have hgap : targetRatio < beta := parameter_choice.2.2.2
  let err := (beta-targetRatio)*F/(2*beta)
  have herr : 0 < err := div_pos (mul_pos (sub_pos.mpr hgap) hF) (by positivity)
  have hscale : 2*beta*err = (beta-targetRatio)*F := by dsimp [err]; field_simp
  obtain ⟨n,hn⟩ := exists_expected_quantized_optimum_close μ M X hX hv hint err herr
  obtain ⟨policy,hfeasible,hreward⟩ := finite_real_probability_beta (Nat.zero_lt_succ _) M
    (fun _ => quantizeValue n) (fun _ => quantizeValue_nonneg n) (quantizedMarginal μ X hX n)
  let lifted := transformedPolicy (fun _ => rationalRound n) policy
  refine ⟨lifted,transformedPolicy_feasible M _ policy hfeasible,?_,?_,?_⟩
  · exact measurable_finite_observation_reward X hX (fun _ => quantizeIndex n)
      (fun _ => measurable_quantizeIndex n) (fun _ i => (quantizeValue n i : ℝ)) policy
  · exact integrable_finite_observation_reward μ M X hX hv hint (fun _ => quantizeIndex n)
      (fun _ => measurable_quantizeIndex n) (fun _ i => (quantizeValue n i : ℝ)) policy hfeasible
  · have htransfer := quantized_policy_reward_transfer μ M X hX hind hv hint n policy hfeasible
    rw [← quantized_optimum_integral μ M X hX hind n] at hreward
    change F-err < _ at hn
    change targetRatio*F ≤ _
    change _ ≤ ∫ ω, orderAveragedReward lifted (fun e => X e ω) ∂μ at htransfer
    nlinarith

end MatroidProphetSecretary
