import MatroidProphetSecretary.CappedSurplus
import MatroidProphetSecretary.Parameters

/-! The finite-instance surplus bound for the small-stability branch of Lemma 18. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem finite_small_stability_surplus (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e v, 0 ≤ value e v)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) {q : ℝ} (hq : q ∈ interval)
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (hDlo : stationaryRatio q-20*epsilon ≤
      deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (hDhi : deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) ≤ stationaryRatio q+
      stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)+20*epsilon)
    (hH : stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop/
        expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) ≤ hPlus) :
    thresholdFactor q*q*deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)+
        2*epsilon*expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) <
      thresholdSurplus (FiniteLaw.product laws) (coordinateValues value)
        (meanThreshold (FiniteLaw.product laws) M (coordinateValues value) hnonloop) (thresholdFactor q) := by
  let F := expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)
  let D := deletionSurplus (FiniteLaw.product laws) M (coordinateValues value)
  let H := stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop
  let S := thresholdSurplus (FiniteLaw.product laws) (coordinateValues value)
    (meanThreshold (FiniteLaw.product laws) M (coordinateValues value) hnonloop) (thresholdFactor q)
  have hb := threshold_factor_bounds hq
  have hb0 : 0 < thresholdFactor q := by linarith only [hb.2.2.1]
  have hb1 : thresholdFactor q ≤ 1 := by linarith only [hb.2.2.2]
  have hsur := finite_threshold_surplus laws M value hv hnonloop hF (thresholdFactor q) hb0 hb1 3 (by norm_num)
  change 1-thresholdFactor q+thresholdFactor q/(thresholdFactor q+3)*
    (D/F-(1-thresholdFactor q)-H/F-thresholdFactor q*Real.exp (-3)) ≤ S/F at hsur
  change stationaryRatio q-20*epsilon ≤ D/F at hDlo
  change D/F ≤ stationaryRatio q+H/F+20*epsilon at hDhi
  change H/F ≤ hPlus at hH
  have hterm : stationaryRatio q-20*epsilon-(1-thresholdFactor q)-hPlus-thresholdFactor q*Real.exp (-3) ≤
      D/F-(1-thresholdFactor q)-H/F-thresholdFactor q*Real.exp (-3) := by linarith only [hDlo,hH]
  have hcoef : 0 ≤ thresholdFactor q/(thresholdFactor q+3) := div_nonneg hb0.le (by linarith)
  have hL : surplusLower q ≤ S/F := by
    unfold surplusLower
    exact (add_le_add_left (mul_le_mul_of_nonneg_left hterm hcoef) _).trans hsur
  have hD : D/F ≤ stationaryRatio q+hPlus+20*epsilon := by linarith only [hDhi,hH]
  have hstrict : thresholdFactor q*q*(D/F)+2*epsilon < S/F :=
    (add_le_add_right (mul_le_mul_of_nonneg_left hD (mul_nonneg hb0.le (q_pos hq).le)) _).trans_lt
      ((threshold_parameter_condition hq).trans_le hL)
  have hscaled := mul_lt_mul_of_pos_right hstrict hF
  have he : (thresholdFactor q*q*(D/F)+2*epsilon)*F = thresholdFactor q*q*D+2*epsilon*F := by
    field_simp
  rw [he,div_mul_cancel₀ _ hF.ne'] at hscaled
  exact hscaled

end MatroidProphetSecretary
