import MatroidProphetSecretary.ContractionLayers
import MatroidProphetSecretary.RankDeficit

/-! The deterministic layer inequality for the integrated cap missing mass. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def capMissingLayer (M : Matroid E) (v c : E → ℝ) (B : Finset E) (z : ℝ) : ℝ :=
  ∑ e ∈ B, positiveLayer (c e) z * (1 - closureLayer M v e z)

theorem capMissingLayer_nonneg (M : Matroid E) (v c : E → ℝ) (B : Finset E) (z : ℝ) :
    0 ≤ capMissingLayer M v c B z := by
  apply sum_nonneg
  intro e he
  unfold positiveLayer closureLayer
  split_ifs <;> norm_num

theorem capMissingLayer_integrable (M : Matroid E) (v c : E → ℝ) (hv : ∀ e, 0 ≤ v e)
    (B : Finset E) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    Integrable (capMissingLayer M v c B) := by
  apply integrable_finset_sum
  intro e he
  have hp := positiveLayer_integrable (c e)
  have hc := closureLayer_integrable M v hv e (hnonloop e)
  have hprod : Integrable (fun z => positiveLayer (c e) z * closureLayer M v e z) := by
    apply hc.bdd_mul hp.aestronglyMeasurable
    refine ⟨1, fun z => ?_⟩
    unfold positiveLayer
    split_ifs <;> norm_num
  convert hp.sub hprod using 1
  funext z
  simp only [Pi.sub_apply]
  ring

theorem sum_mem_indicator_eq_ncard (B : Finset E) (S : Set E) :
    (∑ e ∈ B, if e ∈ S then (1 : ℝ) else 0) = (((B : Set E) ∩ S).ncard : ℝ) := by
  rw [Finset.sum_boole, Set.ncard_eq_toFinset_card']
  congr 2
  ext e
  simp

theorem valueLayer_min (M : Matroid E) (v c : E → ℝ) (z : ℝ) :
    valueLayer M (fun e => min (v e) (c e)) z = valueLayer M v z ∩ valueLayer M c z := by
  ext e
  simp [valueLayer, lt_min_iff, and_assoc, and_left_comm, and_comm]

theorem optimal_basis_inter_layer {M : Matroid E} {c : E → ℝ} {B : Finset E}
    (hB : M.IsBase (B : Set E)) (hopt : optimum M c = weight c B) (z : ℝ) :
    M.IsBasis ((B : Set E) ∩ valueLayer M c z) (valueLayer M c z) := by
  have heq : ((B.filter (fun e => z < c e) : Finset E) : Set E) =
      (B : Set E) ∩ valueLayer M c z := by
    ext e
    simp only [Finset.mem_coe, mem_filter, Set.mem_inter_iff, valueLayer, mem_setOf_eq]
    constructor
    · intro h
      exact ⟨h.1, hB.subset_ground h.1, h.2⟩
    · intro h
      exact ⟨h.1, h.2.2⟩
  rw [← heq]
  exact optimal_basis_superlevel_isBasis hB hopt z

theorem capMissingLayer_le_deficits (M : Matroid E) (v c : E → ℝ) (B : Finset E)
    (hB : M.IsBase (B : Set E)) (hopt : optimum M c = weight c B) (z : ℝ) :
    capMissingLayer M v c B z ≤
      positiveRankLayer M c z - positiveRankLayer M (fun e => min (v e) (c e)) z +
        realizedLayerGap M v B z := by
  by_cases hz : 0 < z
  · let S := valueLayer M v z
    let T := valueLayer M c z
    have hBT := optimal_basis_inter_layer hB hopt z
    have h := cap_rank_deficit hB.indep hBT (show S ⊆ M.E from fun e he => he.1)
    have hmissing : capMissingLayer M v c B z =
        realRank M T - (((B : Set E) ∩ T ∩ M.closure S).ncard : ℝ) := by
      rw [realRank_eq_ncard hBT, Set.inter_assoc,
        ← sum_mem_indicator_eq_ncard B T,
        ← sum_mem_indicator_eq_ncard B (T ∩ M.closure S), ← sum_sub_distrib]
      apply sum_congr rfl
      intro e he
      have heE := hB.subset_ground he
      simp only [capMissingLayer, positiveLayer, closureLayer, hz, true_and,
        T, S, valueLayer, mem_setOf_eq, mem_inter_iff, heE]
      split_ifs <;> norm_num <;> tauto
    have hclosure : (∑ e ∈ B, closureLayer M v e z) =
        (((B : Set E) ∩ M.closure S).ncard : ℝ) := by
      simp only [closureLayer, hz, true_and]
      exact sum_mem_indicator_eq_ncard B (M.closure S)
    rw [hmissing]
    unfold realizedLayerGap
    rw [hclosure]
    simp only [positiveRankLayer, hz, if_true, valueLayer_min]
    dsimp only [S, T, realRank] at h ⊢
    linarith
  · simp [capMissingLayer, positiveLayer, closureLayer, positiveRankLayer,
      realizedLayerGap, hz]

end MatroidProphetSecretary
