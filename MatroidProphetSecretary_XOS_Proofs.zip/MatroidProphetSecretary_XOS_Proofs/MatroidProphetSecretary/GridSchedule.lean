import MatroidProphetSecretary.StampedHistory

/-! A finite clock grid is visited in clock order, with each label visited once per clock. -/

noncomputable section

namespace MatroidProphetSecretary

def gridLabel (N : ℕ) (hN : 0 < N) (i : ℕ) : Fin N := ⟨i%N,Nat.mod_lt _ hN⟩

def gridClock (N L : ℕ) (hL : 0 < L) (i : ℕ) : Fin L := ⟨(i/N)%L,Nat.mod_lt _ hL⟩

def gridSlot {N L : ℕ} (c : Fin L) (e : Fin N) : ℕ := c.val*N+e.val

theorem gridLabel_slot (N L : ℕ) (hN : 0 < N) (c : Fin L) (e : Fin N) :
    gridLabel N hN (gridSlot c e) = e := by
  apply Fin.ext
  simp [gridLabel,gridSlot,Nat.add_mod,Nat.mod_eq_of_lt e.isLt]

theorem gridClock_slot (N L : ℕ) (hL : 0 < L) (c : Fin L) (e : Fin N) :
    gridClock N L hL (gridSlot c e) = c := by
  have hN : 0 < N := Nat.zero_lt_of_lt e.isLt
  apply Fin.ext
  have hd : (c.val*N+e.val)/N = c.val := by
    rw [Nat.add_comm,Nat.add_mul_div_right _ _ hN,Nat.div_eq_of_lt e.isLt,Nat.zero_add]
  simpa only [gridClock,gridSlot,hd,Nat.mod_eq_of_lt c.isLt]

theorem gridSlot_lt (N L : ℕ) (c : Fin L) (e : Fin N) : gridSlot c e < L*N := by
  unfold gridSlot
  have h1 := Nat.mul_le_mul_right N (Nat.succ_le_of_lt c.isLt)
  simp only [Nat.succ_mul] at h1
  omega

theorem gridClock_val (N L : ℕ) (hN : 0 < N) (hL : 0 < L) (i : ℕ) (hi : i < L*N) :
    (gridClock N L hL i).val = i/N := by
  apply Nat.mod_eq_of_lt
  exact (Nat.div_lt_iff_lt_mul hN).mpr hi

theorem gridSlot_clock_label (N L : ℕ) (hN : 0 < N) (hL : 0 < L) (i : ℕ) (hi : i < L*N) :
    gridSlot (gridClock N L hL i) (gridLabel N hN i) = i := by
  unfold gridSlot
  rw [gridClock_val N L hN hL i hi]
  simpa only [gridLabel,Nat.mul_comm] using Nat.div_add_mod i N

theorem gridSlot_same_label_lt {N L : ℕ} (c t : Fin L) (e : Fin N) :
    gridSlot c e < gridSlot t e ↔ c.val < t.val := by
  have hN : 0 < N := Nat.zero_lt_of_lt e.isLt
  simp only [gridSlot,Nat.add_lt_add_iff_right,Nat.mul_lt_mul_right hN]

theorem grid_schedule_fresh (N L : ℕ) (hN : 0 < N) (hL : 0 < L)
    (n : ℕ) (hn : n < L*N) (i : ℕ) (hi : i < n)
    (he : gridLabel N hN i = gridLabel N hN n) :
    gridClock N L hL i ≠ gridClock N L hL n := by
  intro hc
  have hx := gridSlot_clock_label N L hN hL i (hi.trans hn)
  rw [he,hc,gridSlot_clock_label N L hN hL n hn] at hx
  omega

theorem grid_past_same_label {N L : ℕ} (hN : 0 < N) (hL : 0 < L)
    (n : ℕ) (hn : n < L*N) (c : Fin L) :
    gridSlot c (gridLabel N hN n) < n ↔ c.val < (gridClock N L hL n).val := by
  conv_lhs => rw [← gridSlot_clock_label N L hN hL n hn]
  rw [gridLabel_slot]
  exact gridSlot_same_label_lt _ _ _

end MatroidProphetSecretary
