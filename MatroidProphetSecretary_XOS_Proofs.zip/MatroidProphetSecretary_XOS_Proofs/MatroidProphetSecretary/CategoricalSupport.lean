import MatroidProphetSecretary.RationalCategorical

/-! Zero-probability categories are never selected; exact rational lookup has bounded work. -/

namespace MatroidProphetSecretary

def rationalInverseCDFWithCost : List ℚ → ℚ → ℕ × ℕ
  | [], _ => (0,0)
  | b::bs, u => if u < b then (0,1) else
      let tail := rationalInverseCDFWithCost bs u
      (1+tail.1,1+tail.2)

theorem rationalInverseCDFWithCost_value (bs : List ℚ) (u : ℚ) :
    (rationalInverseCDFWithCost bs u).1 = rationalInverseCDF bs u := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp only [rationalInverseCDFWithCost,rationalInverseCDF]; split_ifs <;> simp [ih]

theorem rationalInverseCDFWithCost_bound (bs : List ℚ) (u : ℚ) :
    (rationalInverseCDFWithCost bs u).2 ≤ bs.length := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp only [rationalInverseCDFWithCost,List.length_cons]; split_ifs <;> simp only [] <;> omega

noncomputable section

open scoped Classical

theorem cumulative_lookup_supported (a : ℝ) (ps : List ℝ) (u : ℝ)
    (ha : a ≤ u) (hu : u < a+ps.sum) :
    inverseCDF (cumulativeBoundaries a ps) u < ps.length ∧
      0 < (ps[inverseCDF (cumulativeBoundaries a ps) u]?.getD 0) := by
  induction ps generalizing a with
  | nil => simp only [List.sum_nil,add_zero] at hu; linarith
  | cons p ps ih =>
    by_cases hp : u < a+p
    · simp only [cumulativeBoundaries,inverseCDF,hp,if_true,List.length_cons,List.getElem?_cons_zero,Option.getD_some]
      exact ⟨by omega,by linarith⟩
    · have ht := ih (a+p) (le_of_not_gt hp) (by simpa only [List.sum_cons,add_assoc] using hu)
      simp only [cumulativeBoundaries,inverseCDF,hp,if_false,List.length_cons]
      simpa only [Nat.add_comm 1,List.getElem?_cons_succ] using
        (show 1+inverseCDF (cumulativeBoundaries (a+p) ps) u < ps.length+1 ∧
          0 < (ps[inverseCDF (cumulativeBoundaries (a+p) ps) u]?.getD 0) from ⟨by omega,ht.2⟩)

theorem categoricalDraw_supported {k : ℕ} (μ : FiniteLaw (Fin k)) (u : ℝ)
    (hu : u ∈ Set.Ico (0:ℝ) 1) :
    ∃ i : Fin k, categoricalDraw μ u = i.val ∧ 0 < μ.mass i := by
  have hs : (List.ofFn μ.mass).sum = 1 := by rw [List.sum_ofFn]; exact μ.total
  have hn : List.ofFn μ.mass ≠ [] := by intro h; rw [h] at hs; simp at hs
  have hc := cumulative_lookup_supported 0 (List.ofFn μ.mass) u hu.1 (by simpa [hs] using hu.2)
  have ht := categorical_lookup_trim 0 (List.ofFn μ.mass) hn u (by simpa [hs] using hu.2)
  change inverseCDF (cumulativeBoundaries 0 (List.ofFn μ.mass)) u = categoricalDraw μ u at ht
  rw [ht,List.length_ofFn] at hc
  let i : Fin k := ⟨categoricalDraw μ u,hc.1⟩
  refine ⟨i,rfl,?_⟩
  simpa only [List.getElem?_ofFn,hc.1,dif_pos,Option.getD_some] using hc.2

theorem rationalCategoricalDraw_supported {k G : ℕ} (p : Fin k → ℚ)
    (hp : ∀ i, 0 ≤ p i) (ht : ∑ i, p i = 1) (j : Fin G) :
    ∃ i : Fin k, rationalCategoricalDraw p j = i.val ∧ 0 < p i := by
  have hG : (0:ℝ) < G := by exact_mod_cast Nat.zero_lt_of_lt j.isLt
  have hu : (j.val:ℝ)/G ∈ Set.Ico (0:ℝ) 1 :=
    ⟨by positivity,(div_lt_one hG).mpr (by exact_mod_cast j.isLt)⟩
  obtain ⟨i,hi,hp'⟩ := categoricalDraw_supported (rationalCategoryLaw p hp ht) _ hu
  refine ⟨i,?_,?_⟩
  · rw [rationalCategoricalDraw_eq p hp ht]
    exact hi
  · change (0:ℝ) < (p i:ℝ) at hp'
    exact_mod_cast hp'

end

end MatroidProphetSecretary
