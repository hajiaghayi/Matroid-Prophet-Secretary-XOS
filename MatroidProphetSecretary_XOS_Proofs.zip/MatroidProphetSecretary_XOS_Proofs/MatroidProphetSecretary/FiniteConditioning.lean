import MatroidProphetSecretary.FinitePushforward
import MatroidProphetSecretary.BlockIndependence

/-! Conditioning finite laws, including a harmless fallback for null events. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

theorem mass_le_prob (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A]
    (x : Ω) (hx : A x) : μ.mass x ≤ μ.prob A := by
  have h := single_le_sum (s := univ)
    (f := fun w => μ.mass w * if A w then (1 : ℝ) else 0)
    (fun w _ => mul_nonneg (μ.nonneg w) (by split_ifs <;> norm_num)) (mem_univ x)
  simpa only [if_pos hx, mul_one] using h

def condition (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A] (hp : 0 < μ.prob A) : FiniteLaw Ω where
  mass x := if A x then μ.mass x / μ.prob A else 0
  nonneg x := by
    split_ifs
    · exact div_nonneg (μ.nonneg x) hp.le
    · exact le_rfl
  total := by
    have hsum : (∑ x, if A x then μ.mass x else 0) = μ.prob A := by
      simp [prob, expect, mul_ite]
    calc
      (∑ x, if A x then μ.mass x / μ.prob A else 0) =
          ∑ x, (if A x then μ.mass x else 0) / μ.prob A := by
        apply sum_congr rfl
        intro x hx
        split_ifs <;> simp
      _ = (∑ x, if A x then μ.mass x else 0) / μ.prob A := (sum_div ..).symm
      _ = 1 := by rw [hsum, div_self hp.ne']

def conditionOrSelf (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A] : FiniteLaw Ω :=
  if hp : 0 < μ.prob A then μ.condition A hp else μ

theorem condition_weighted_mass (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A]
    (hp : 0 < μ.prob A) (x : Ω) :
    μ.prob A * (μ.condition A hp).mass x = if A x then μ.mass x else 0 := by
  by_cases hx : A x
  · simp only [condition, if_pos hx]
    exact mul_div_cancel₀ _ hp.ne'
  · simp [condition, hx]

theorem conditionOrSelf_weighted_mass (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A] (x : Ω) :
    μ.prob A * (μ.conditionOrSelf A).mass x = if A x then μ.mass x else 0 := by
  by_cases hp : 0 < μ.prob A
  · simp only [conditionOrSelf, dif_pos hp]
    exact condition_weighted_mass μ A hp x
  · have hz : μ.prob A = 0 := le_antisymm (le_of_not_gt hp) (μ.prob_nonneg A)
    rw [hz, zero_mul]
    by_cases hx : A x
    · rw [if_pos hx]
      exact (le_antisymm ((μ.mass_le_prob A x hx).trans_eq hz) (μ.nonneg x)).symm
    · simp [hx]

theorem conditionOrSelf_weighted_expect (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A]
    (f : Ω → ℝ) :
    μ.prob A * (μ.conditionOrSelf A).expect f = μ.expect (fun x => if A x then f x else 0) := by
  unfold expect
  rw [mul_sum]
  apply sum_congr rfl
  intro x hx
  rw [← mul_assoc, conditionOrSelf_weighted_mass]
  by_cases hA : A x <;> simp [hA]

theorem conditionOrSelf_support (μ : FiniteLaw Ω) (A : Ω → Prop) [DecidablePred A]
    (hp : 0 < μ.prob A) (x : Ω) (hx : (μ.conditionOrSelf A).mass x ≠ 0) : A x := by
  by_contra hA
  apply hx
  simp [conditionOrSelf, hp, condition, hA]

end MatroidProphetSecretary.FiniteLaw
