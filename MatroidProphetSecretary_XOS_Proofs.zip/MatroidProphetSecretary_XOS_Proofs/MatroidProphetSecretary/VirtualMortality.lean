import MatroidProphetSecretary.VirtualStep
import MatroidProphetSecretary.BlockResampling

/-! Exact live-pair losses and persistence for the finite virtual exchange kernel. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def virtualExchange (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (s : VirtualState M) (source target : W) :
    ExchangeMap M (s.2.replay (base source) (hbase source)).basis (s.2.replay (base target) (hbase target)).basis :=
  chosenExchangeMap M _ _ (s.2.replay (base source) (hbase source)).isBase (s.2.replay (base target) (hbase target)).isBase

def virtualLiveIndicator (M : Matroid E) (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (y : W) (e : E) : ℝ :=
  if e ∈ virtualLive M base hbase value s y then 1 else 0

theorem virtualUpdate_live_iff (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M)
    (source target : W) (e f : E) (he : e ∈ virtualLive M base hbase value s source) :
    f ∈ virtualLive M base hbase value (virtualUpdate M base hbase value s (some (e,source))) target ↔
      f ∈ virtualLive M base hbase value s target ∧ (virtualExchange M base hbase s source target).map e ≠ f := by
  unfold virtualUpdate
  dsimp only
  split_ifs
  have hs := mem_sdiff.mp (mem_filter.mp he).1
  simpa only [virtualLive,virtualExchange] using ExchangeHistory.liveSet_snoc_iff s.2
    (s.2.replay (base source) (hbase source)).basis (s.2.replay (base source) (hbase source)).isBase
    (s.2.replay (base source) (hbase source)).contains e hs.1 hs.2 (base target) (hbase target) (value target) f

theorem virtualStep_weighted_indicator_loss (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (target source : W) (f e : E) (hf : f ∈ virtualLive M base hbase value s target) :
    virtualStepWeight μ M base hbase value s dt rate (e,source) *
      (1-virtualLiveIndicator M base hbase value (virtualUpdate M base hbase value s (some (e,source))) target f) =
    dt*μ.mass source *
      (if e ∈ (s.2.replay (base source) (hbase source)).basis ∧
        e ∈ virtualLive M base hbase value s source ∧ (virtualExchange M base hbase s source target).map e = f
        then rate e else 0) := by
  by_cases he : e ∈ virtualLive M base hbase value s source
  · have heB : e ∈ (s.2.replay (base source) (hbase source)).basis := (mem_sdiff.mp (mem_filter.mp he).1).1
    have hl := virtualUpdate_live_iff M base hbase value s source target e f he
    by_cases hk : (virtualExchange M base hbase s source target).map e = f
    · have hdead : f ∉ virtualLive M base hbase value (virtualUpdate M base hbase value s (some (e,source))) target :=
        fun h => (hl.mp h).2 hk
      simp [virtualStepWeight,virtualLiveIndicator,he,heB,hk,hdead]
      ring
    · have halive := hl.mpr ⟨hf,hk⟩
      simp [virtualStepWeight,virtualLiveIndicator,he,heB,hk,halive]
  · simp [virtualStepWeight,he]

theorem virtualStep_total_indicator_loss (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (target : W) (f : E) (hf : f ∈ virtualLive M base hbase value s target) :
    (∑ event, virtualStepWeight μ M base hbase value s dt rate event *
      (1-virtualLiveIndicator M base hbase value (virtualUpdate M base hbase value s (some event)) target f)) =
    dt * μ.expect (fun source => sourceKillRate (virtualExchange M base hbase s source target)
      (fun e => e ∈ virtualLive M base hbase value s source) rate f) := by
  rw [Fintype.sum_prod_type]
  simp_rw [virtualStep_weighted_indicator_loss μ M base hbase value s dt rate target _ f _ hf]
  rw [sum_comm]
  simp only [FiniteLaw.expect,sourceKillRate,mul_sum,mul_assoc]
  apply sum_congr rfl
  intro y hy
  apply sum_congr rfl
  intro e he
  split_ifs <;> rfl

theorem virtualStep_indicator_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) (target : W) (f : E) :
    (1-dt*R)*virtualLiveIndicator M base hbase value s target f ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (fun event => virtualLiveIndicator M base hbase value (virtualUpdate M base hbase value s event) target f) := by
  by_cases hf : f ∈ virtualLive M base hbase value s target
  · rw [virtualStepLaw,FiniteLaw.optionalLaw_expect_loss]
    have hnone : virtualLiveIndicator M base hbase value (virtualUpdate M base hbase value s none) target f = 1 := by
      simp [virtualUpdate,virtualLiveIndicator,hf]
    rw [hnone,virtualStep_total_indicator_loss μ M base hbase value s dt rate target f hf]
    simp only [virtualLiveIndicator,if_pos hf,mul_one]
    have hkill := integrated_killing_intensity_le μ
      (fun source => (s.2.replay (base source) (hbase source)).basis)
      (fun source => virtualExchange M base hbase s source target)
      (fun e source => e ∈ virtualLive M base hbase value s source) rate R hR hrate1 f
    exact sub_le_sub_left (mul_le_mul_of_nonneg_left hkill hdt) 1
  · simp only [virtualLiveIndicator,if_neg hf,mul_zero]
    apply FiniteLaw.expect_nonneg
    intro event
    split_ifs <;> norm_num

end MatroidProphetSecretary
