import MatroidProphetSecretary.InverseCDF
import MatroidProphetSecretary.FiniteMeasureLaw
import MatroidProphetSecretary.FinitePushforward
import Mathlib.MeasureTheory.Function.Floor

/-! Rounding a shared uniform real produces an exactly uniform bounded integer seed. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

def unitUniform : Measure ℝ := volume.restrict (Set.Ico (0:ℝ) 1)

instance unitUniform_probability : IsProbabilityMeasure unitUniform := ⟨by simp [unitUniform]⟩

def uniformGridIndex (G : ℕ) (hG : 0 < G) (u : ℝ) : Fin G :=
  ⟨min ⌊(G:ℝ)*u⌋₊ (G-1),lt_of_le_of_lt (min_le_right _ _) (by omega)⟩

theorem uniformGridIndex_measurable (G : ℕ) (hG : 0 < G) : Measurable (uniformGridIndex G hG) := by
  have h : Measurable (fun u : ℝ => min ⌊(G:ℝ)*u⌋₊ (G-1)) :=
    ((measurable_const.mul measurable_id).nat_floor).min measurable_const
  let f : ℕ → Fin G := fun j => ⟨min j (G-1),lt_of_le_of_lt (min_le_right _ _) (by omega)⟩
  have hf := (measurable_of_countable f).comp h
  convert hf using 1
  funext u
  apply Fin.ext
  simp [uniformGridIndex,f,min_assoc]

theorem uniformGridIndex_on_unit (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : u ∈ Set.Ico (0:ℝ) 1) :
    (uniformGridIndex G hG u).val = ⌊(G:ℝ)*u⌋₊ := by
  have hG' : (0:ℝ) < G := by exact_mod_cast hG
  have hf : ⌊(G:ℝ)*u⌋₊ < G := (Nat.floor_lt (mul_nonneg hG'.le hu.1)).mpr (by nlinarith [hu.2])
  exact min_eq_left (by omega)

theorem uniformGridIndex_cell (G : ℕ) (hG : 0 < G) (j : Fin G) :
    {u : ℝ | uniformGridIndex G hG u = j} ∩ Set.Ico 0 1 =
      Set.Ico ((j:ℝ)/G) (((j:ℝ)+1)/G) := by
  have hG' : (0:ℝ) < G := by exact_mod_cast hG
  have hj0 : (0:ℝ) ≤ j := by positivity
  have hjG : (j:ℝ)+1 ≤ G := by exact_mod_cast j.isLt
  ext u
  constructor
  · rintro ⟨he,hu⟩
    have hf : ⌊(G:ℝ)*u⌋₊ = j.val := by
      rw [← uniformGridIndex_on_unit G hG u hu,he]
    have hb := (Nat.floor_eq_iff (mul_nonneg hG'.le hu.1)).mp hf
    exact ⟨(div_le_iff₀ hG').mpr (by nlinarith [hb.1]),(lt_div_iff₀ hG').mpr (by nlinarith [hb.2])⟩
  · intro hu
    have hu0 : 0 ≤ u := (div_nonneg hj0 hG'.le).trans hu.1
    have hu1 : u < 1 := hu.2.trans_le ((div_le_one hG').mpr hjG)
    refine ⟨Fin.ext ?_,hu0,hu1⟩
    rw [uniformGridIndex_on_unit G hG u ⟨hu0,hu1⟩]
    apply (Nat.floor_eq_iff (mul_nonneg hG'.le hu0)).mpr
    constructor
    · have h := (div_le_iff₀ hG').mp hu.1; nlinarith
    · have h := (lt_div_iff₀ hG').mp hu.2; nlinarith

theorem uniformGridIndex_mass (G : ℕ) (hG : 0 < G) (j : Fin G) :
    unitUniform {u | uniformGridIndex G hG u = j} = ENNReal.ofReal (1/(G:ℝ)) := by
  rw [unitUniform,Measure.restrict_apply' measurableSet_Ico,uniformGridIndex_cell]
  rw [Real.volume_Ico]
  congr 1
  ring

theorem uniformGridIndex_finiteLaw (G : ℕ) (hG : 0 < G) :
    finiteRandomVariableLaw unitUniform (uniformGridIndex G hG) (uniformGridIndex_measurable G hG) =
      @FiniteLaw.uniform (Fin G) _ ⟨⟨0,hG⟩⟩ := by
  apply FiniteLaw.ext_mass
  funext j
  change (unitUniform.map (uniformGridIndex G hG)).real {j} = 1/Fintype.card (Fin G)
  rw [measureReal_def,Measure.map_apply (uniformGridIndex_measurable G hG) (measurableSet_singleton j)]
  change (unitUniform {u | uniformGridIndex G hG u = j}).toReal = _
  rw [uniformGridIndex_mass,ENNReal.toReal_ofReal (by positivity),Fintype.card_fin]

theorem uniformGridIndex_down (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : u ∈ Set.Ico (0:ℝ) 1) :
    ((uniformGridIndex G hG u).val : ℝ)/G = uniformGridDown G u := by
  rw [uniformGridIndex_on_unit G hG u hu]
  rfl

end MatroidProphetSecretary
