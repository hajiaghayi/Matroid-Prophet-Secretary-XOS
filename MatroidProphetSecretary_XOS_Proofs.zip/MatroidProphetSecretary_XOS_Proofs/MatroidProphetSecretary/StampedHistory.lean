import MatroidProphetSecretary.MarkedHistory

/-! Accepted records reconstruct every earlier accepted history from their step stamps. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E T Ω A : Type*}

abbrev StampedHistory (E A : Type*) := List (E × (ℕ × A))

def recordsBefore (n : ℕ) (history : StampedHistory E A) : StampedHistory E A :=
  history.filter (fun record => record.2.1 < n)

def stampDecision (decision : ℕ → StampedHistory E A → Ω → Option A)
    (i : ℕ) (history : StampedHistory E A) (tape : Ω) : Option (ℕ × A) :=
  (decision i history tape).map (fun mark => (i,mark))

def stampedRun (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → Ω → Option A)
    (tapes : E → T × Ω) : ℕ → StampedHistory E A :=
  privateStepRun label (markedStep label time (stampDecision decision)) [] tapes

theorem stampedRun_mem_before (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → Ω → Option A)
    (tapes : E → T × Ω) (n : ℕ) (record : E × (ℕ × A))
    (hrecord : record ∈ stampedRun label time decision tapes n) : record.2.1 < n := by
  induction n with
  | zero => simp [stampedRun,privateStepRun] at hrecord
  | succ n ih =>
    change record ∈ markedStep label time (stampDecision decision) n
      (stampedRun label time decision tapes n) (tapes (label n)) at hrecord
    unfold markedStep stampDecision at hrecord
    split_ifs at hrecord
    · cases hd : decision n (stampedRun label time decision tapes n) (tapes (label n)).2 with
      | none =>
        simp only [hd,Option.map_none] at hrecord
        exact (ih hrecord).trans (Nat.lt_succ_self n)
      | some mark =>
        simp only [hd,Option.map_some] at hrecord
        change record ∈ (stampedRun label time decision tapes n) ++ [(label n,(n,mark))] at hrecord
        rcases List.mem_append.mp hrecord with hold | hnew
        · exact (ih hold).trans (Nat.lt_succ_self n)
        · have heq := List.mem_singleton.mp hnew
          rw [heq]
          exact Nat.lt_succ_self n
    · exact (ih hrecord).trans (Nat.lt_succ_self n)

theorem recordsBefore_stampedRun_self (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → Ω → Option A)
    (tapes : E → T × Ω) (n : ℕ) :
    recordsBefore n (stampedRun label time decision tapes n) = stampedRun label time decision tapes n := by
  apply List.filter_eq_self.mpr
  intro record hr
  simpa using stampedRun_mem_before label time decision tapes n record hr

theorem recordsBefore_stamped_step (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → Ω → Option A)
    (history : StampedHistory E A) (tape : T × Ω) (i n : ℕ) (hin : i ≤ n) :
    recordsBefore i (markedStep label time (stampDecision decision) n history tape) = recordsBefore i history := by
  unfold markedStep stampDecision
  split_ifs
  · cases hd : decision n history tape.2 with
    | none => simp
    | some mark => simp [recordsBefore,show ¬ n < i by omega]
  · rfl

theorem recordsBefore_stampedRun (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → Ω → Option A)
    (tapes : E → T × Ω) {i n : ℕ} (hin : i ≤ n) :
    recordsBefore i (stampedRun label time decision tapes n) = stampedRun label time decision tapes i := by
  induction n with
  | zero =>
    have hi : i = 0 := by omega
    subst i
    exact recordsBefore_stampedRun_self label time decision tapes 0
  | succ n ih =>
    rcases Nat.eq_or_lt_of_le hin with hi | hi
    · subst i
      exact recordsBefore_stampedRun_self label time decision tapes (n+1)
    · change recordsBefore i (markedStep label time (stampDecision decision) n
        (stampedRun label time decision tapes n) (tapes (label n))) = _
      rw [recordsBefore_stamped_step label time decision _ _ i n (by omega)]
      exact ih (by omega)

theorem accepted_path_reconstruction [Fintype E] [DecidableEq E] [Fintype T] [Fintype Ω]
    (laws : E → FiniteLaw (T × Ω)) (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → StampedHistory E A → Ω → Option A)
    (path : ℕ → StampedHistory E A) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent label (markedStep label time (stampDecision decision)) [] path n))
    {i : ℕ} (hin : i ≤ n) : recordsBefore i (path n) = path i := by
  obtain ⟨tapes,hpath⟩ := FiniteLaw.exists_of_prob_pos _ _ hp
  rw [← hpath n le_rfl,← hpath i hin]
  exact recordsBefore_stampedRun label time decision tapes hin

end MatroidProphetSecretary
