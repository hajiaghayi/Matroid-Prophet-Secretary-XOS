import MatroidProphetSecretary.ResidualReferencePotential
import MatroidProphetSecretary.ReferenceThresholdProgress

/-! Threshold-action potentials and feasibility agree with the actual smaller residual instances. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical Matroid

theorem thresholdEpochValue_child_potentials {n k : ℕ} (prior : RationalPriors (n+1) k)
    (M : Matroid (Fin (n+1))) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin (n+1))))
    (q a : ℝ) (p : Fin (n+1) → ℝ) (e : Fin (n+1)) (v : ℝ) :
    thresholdEpochValue (FiniteLaw.product (alignedReferenceLaws prior.law (fun e v => (prior.value e v : ℝ)) q)) M
      (optionalCoordinateValues (fun e v => (prior.value e v : ℝ))) hnonloop a p e v =
      if p e < v then v+a*referenceExpectedOptimum (prior.remaining e).law (remainingContract M e)
          (fun i v => ((prior.remaining e).value i v : ℝ)) q
      else a*referenceExpectedOptimum (prior.remaining e).law (remainingDelete M e)
          (fun i v => ((prior.remaining e).value i v : ℝ)) q := by
  unfold thresholdEpochValue
  rw [aligned_reference_expect prior.law (fun e v => (prior.value e v : ℝ)) q
      (fun values => contractionValue M values e (hnonloop e)),
    aligned_reference_expect prior.law (fun e v => (prior.value e v : ℝ)) q
      (fun values => deletionValue M values e),
    ← reference_remaining_contract prior M e (hnonloop e) q,← reference_remaining_delete prior M e q]

theorem remainingDelete_feasible {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1))
    (I : Finset (Fin n)) (hI : (remainingDelete M e).Indep (I : Set (Fin n))) :
    M.Indep (I.image (remainingLabel e) : Set (Fin (n+1))) := by
  have h := (Matroid.comap_indep_iff.mp hI).1
  exact (Matroid.delete_indep_iff.mp (by simpa only [Finset.coe_image] using h)).1

theorem remainingContract_feasible {n : ℕ} (M : Matroid (Fin (n+1))) (e : Fin (n+1))
    (he : M.Indep ({e} : Set (Fin (n+1)))) (I : Finset (Fin n))
    (hI : (remainingContract M e).Indep (I : Set (Fin n))) :
    M.Indep (insert e (I.image (remainingLabel e)) : Set (Fin (n+1))) := by
  have h := (he.contract_indep_iff.mp (Matroid.comap_indep_iff.mp hI).1).2
  simpa only [Finset.coe_insert,Finset.coe_image,Set.union_singleton] using h

end MatroidProphetSecretary
