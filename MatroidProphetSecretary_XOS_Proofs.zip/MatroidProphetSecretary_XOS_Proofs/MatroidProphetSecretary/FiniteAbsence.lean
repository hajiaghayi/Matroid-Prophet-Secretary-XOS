import MatroidProphetSecretary.FiniteConditioning
import MatroidProphetSecretary.FinitePairs

/-! One-arrival survival and conditional marked-event probabilities on a finite time grid. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω T M : Type*} [Fintype Ω] [Fintype T]

theorem prob_not (μ : FiniteLaw Ω) (A : Ω → Prop) : μ.prob (fun x => ¬ A x) = 1-μ.prob A := by
  have hi (x : Ω) : (if ¬ A x then (1:ℝ) else 0) = 1-(if A x then 1 else 0) := by
    by_cases hx : A x <;> simp [hx]
  unfold prob
  simp_rw [hi]
  rw [expect_sub,expect_const]

theorem condition_prob_of_subset (μ : FiniteLaw Ω) (A B : Ω → Prop) (hBA : ∀ x, B x → A x) :
    μ.prob A * (μ.conditionOrSelf A).prob B = μ.prob B := by
  change μ.prob A * (μ.conditionOrSelf A).expect (fun x => if B x then 1 else 0) = _
  rw [conditionOrSelf_weighted_expect]
  unfold prob
  congr 1
  funext x
  by_cases hb : B x
  · simp [hb,hBA x hb]
  · simp [hb]

theorem condition_prob_eq_div (μ : FiniteLaw Ω) (A B : Ω → Prop)
    (hBA : ∀ x, B x → A x) (hA : 0 < μ.prob A) :
    (μ.conditionOrSelf A).prob B = μ.prob B / μ.prob A := by
  apply (eq_div_iff hA.ne').mpr
  simpa only [mul_comm] using condition_prob_of_subset μ A B hBA

theorem pair_prob_at_time (clock : FiniteLaw T) (tape : FiniteLaw Ω) (t : T) (A : Ω → Prop) :
    (clock.pair tape).prob (fun x => x.1 = t ∧ A x.2) = clock.mass t * tape.prob A := by
  unfold prob
  rw [pair_expect]
  have hi (u : T) : tape.expect (fun w => if u = t ∧ A w then (1:ℝ) else 0) =
      if u = t then tape.expect (fun w => if A w then 1 else 0) else 0 := by
    by_cases hu : u = t <;> simp [hu]
  simp_rw [hi]
  simp [expect]

def oneArrivalAbsent (before : T → Prop) (decision : T → Ω → Option M) (x : T × Ω) : Prop :=
  ¬ (before x.1 ∧ decision x.1 x.2 ≠ none)

def acceptanceKernel (tape : FiniteLaw Ω) (decision : T → Ω → Option M) (t : T) (A : M → Prop) : ℝ :=
  tape.prob (fun w => ∃ mark, decision t w = some mark ∧ A mark)

theorem oneArrival_survival (clock : FiniteLaw T) (tape : FiniteLaw Ω)
    (before : T → Prop) (decision : T → Ω → Option M) :
    (clock.pair tape).prob (oneArrivalAbsent before decision) =
      1-∑ t, if before t then clock.mass t * tape.prob (fun w => decision t w ≠ none) else 0 := by
  have hi (x : T × Ω) : (if oneArrivalAbsent before decision x then (1:ℝ) else 0) =
      1-(if before x.1 then (if decision x.1 x.2 ≠ none then 1 else 0) else 0) := by
    by_cases hb : before x.1 <;> by_cases hd : decision x.1 x.2 ≠ none <;>
      simp [oneArrivalAbsent,hb,hd]
  unfold prob
  simp_rw [hi]
  rw [expect_sub,expect_const,pair_expect]
  congr 1
  unfold expect
  apply sum_congr rfl
  intro t ht
  by_cases hb : before t <;> simp [hb]

theorem oneArrival_conditional_mark (clock : FiniteLaw T) (tape : FiniteLaw Ω)
    (before : T → Prop) (decision : T → Ω → Option M) (t : T) (ht : ¬ before t)
    (A : M → Prop) (hS : 0 < (clock.pair tape).prob (oneArrivalAbsent before decision)) :
    ((clock.pair tape).conditionOrSelf (oneArrivalAbsent before decision)).prob
      (fun x => x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ A mark) =
        clock.mass t * acceptanceKernel tape decision t A /
          (clock.pair tape).prob (oneArrivalAbsent before decision) := by
  apply (eq_div_iff hS.ne').mpr
  rw [mul_comm]
  change (clock.pair tape).prob (oneArrivalAbsent before decision) *
    ((clock.pair tape).conditionOrSelf (oneArrivalAbsent before decision)).expect
      (fun x => if x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ A mark then 1 else 0) = _
  rw [conditionOrSelf_weighted_expect]
  have hsub (x : T × Ω) (hx : x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ A mark) :
      oneArrivalAbsent before decision x := fun h => ht (hx.1 ▸ h.1)
  have heq : (fun x : T × Ω => if oneArrivalAbsent before decision x then
      (if x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ A mark then (1:ℝ) else 0) else 0) =
      (fun x => if x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ A mark then 1 else 0) := by
    funext x
    by_cases hx : x.1 = t ∧ ∃ mark, decision t x.2 = some mark ∧ A mark
    · simp [hx,hsub x hx]
    · simp [hx]
  rw [heq]
  have h := pair_prob_at_time clock tape t (fun w => ∃ mark, decision t w = some mark ∧ A mark)
  unfold prob at h
  convert h using 1
  unfold acceptanceKernel prob
  congr 2 <;> (funext x; split_ifs <;> rfl)

end MatroidProphetSecretary.FiniteLaw
