import MatroidProphetSecretary.EulerReachability
import MatroidProphetSecretary.EulerRecordReward
import MatroidProphetSecretary.BinExposureFreezing
import MatroidProphetSecretary.SupportedVirtualLateReward

/-! The late reward bound for the actual history-dependent exchange rates. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem euler_late_reward (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1)
    (n : ℕ) (hhorizon : cfg.cut+n ≤ L) (history : StampedHistory (Fin N) (Fin N → Option V))
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (cfg.cut*N) = history)) :
    recordReward value history+
      omega*(1-(1-(1/(L:ℝ))*((1/cfg.q)/omega))^n)*
        virtualWeightedLiveValue (FiniteLaw.product cfg.reference) M base hbase value
          (fun e => 1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
            ((1/(L:ℝ))*(1/cfg.q)) cfg.cut history e-((1/(L:ℝ))*(1/cfg.q)))
          (recordReplay M base hbase value history) ≤
      (FiniteLaw.adaptiveBatches
        (cfg.eulerBlockBatch M base hbase value hsmall omega homega homega1 hlower hbudget.le)
        cfg.eulerBlockUpdate n (cfg.cut*N,history)).expect
        (fun x => recordReward value (FiniteLaw.stateAfter cfg.eulerBlockUpdate n (cfg.cut*N,history) x).2) := by
  let p := (1/(L:ℝ))*(1/cfg.q)
  let multiplier := fun e => 1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value p cfg.cut history e-p
  let project := fun s : BlockState N V => recordReplay M base hbase value s.2
  let rate := fun s : BlockState N V => cfg.eulerRate s.2 (gridClock N L cfg.clocks_pos s.1)
  let Good := fun j (s : BlockState N V) => cfg.blockReachable j s ∧ recordsBefore (cfg.cut*N) s.2 = history
  have hs : Good cfg.cut (cfg.cut*N,history) :=
    ⟨⟨rfl,hp⟩,cfg.current_history_fixed history (cfg.cut*N) hp⟩
  have hdt : 0 ≤ 1/(L:ℝ) := one_div_nonneg.mpr (Nat.cast_nonneg L)
  have hlam : 0 ≤ 1/cfg.q := one_div_nonneg.mpr cfg.q_pos.le
  have hm (e : Fin N) : 0 ≤ multiplier e := by
    have hb := (binEarlyExposure_bounds (FiniteLaw.product cfg.reference) M base hbase value p
      (mul_nonneg hdt hlam) cfg.cut history e).1
    dsimp only [multiplier]
    dsimp only [p] at hb ⊢
    linarith
  have hr0 (s : BlockState N V) (e : Fin N) : 0 ≤ rate s e :=
    (cfg.historyRate_bounds s.2 (gridSlot (gridClock N L cfg.clocks_pos s.1) e) hsmall omega homega homega1 hlower).1
  have hr1 (s : BlockState N V) (e : Fin N) : rate s e ≤ (1/cfg.q)/omega :=
    (cfg.historyRate_bounds s.2 (gridSlot (gridClock N L cfg.clocks_pos s.1) e) hsmall omega homega homega1 hlower).2
  have hmass : (1/(L:ℝ))*((1/cfg.q)/omega)*Fintype.card (Fin N) ≤ 1 := by
    simpa only [Fintype.card_fin,mul_comm] using hbudget.le
  have hstep : (1/(L:ℝ))*((1/cfg.q)/omega) ≤ 1 := by
    have hN : (1:ℝ) ≤ N := by exact_mod_cast cfg.labels_pos
    have hnonneg := mul_nonneg hdt (div_nonneg hlam homega.le)
    nlinarith
  apply supported_virtual_late_gain (FiniteLaw.product cfg.reference) M base hbase value hv
    project cfg.eulerBlockUpdate (cfg.eulerBlockUpdate_replay M base hbase value)
    multiplier hm (1/(L:ℝ)) (1/cfg.q) omega hdt hlam homega hstep hmass rate hr0 hr1
    (fun s => recordReward value s.2) Good n cfg.cut (cfg.cut*N,history) hs
  · intro j hj hjn state hstate event hevent
    have hjL : j < L := by omega
    refine ⟨cfg.euler_block_reachable M base hbase value hlive hsmall omega homega homega1 hlower hbudget
      j hjL state hstate.1 event hevent,?_⟩
    have hrec := cfg.eulerBlock_recordsBefore (⟨j,hjL⟩ : Fin L) state.2 event (cfg.cut*N)
      (Nat.mul_le_mul_right N hj)
    have hsame : recordsBefore (cfg.cut*N) (cfg.eulerBlockUpdate state event).2 = recordsBefore (cfg.cut*N) state.2 := by
      simpa only [← hstate.1.1,Prod.mk.eta] using hrec
    exact hsame.trans hstate.2
  · intro j hj hjn state hstate e
    have hjL : j < L := by omega
    have hc : gridClock N L cfg.clocks_pos state.1 = (⟨j,hjL⟩ : Fin L) := by
      rw [hstate.1.1]
      exact cfg.gridClock_round ⟨j,hjL⟩
    have hpstate : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (j*N) = state.2) := by
      simpa only [hstate.1.1] using hstate.1.2
    have hr := cfg.bin_start_rate_lower M base hbase value hlive state.2 ⟨j,hjL⟩ hpstate hj
      hsmall omega homega homega1 hlower hbudget e
    have hfreeze := binEarlyExposure_frozen (FiniteLaw.product cfg.reference) M base hbase value p cfg.cut state.2 e
    rw [hstate.2] at hfreeze
    dsimp only [rate,multiplier]
    rw [hc,hfreeze]
    exact hr
  · intro state
    exact cfg.eulerBlock_expected_reward M base hbase value hsmall omega homega homega1 hlower hbudget.le state

end MatroidProphetSecretary.PrivateGridConfig
