import MatroidProphetSecretary.XOSInstance
import MatroidProphetSecretary.BlockResampling

/-! Future-label independence with adaptive, history-dependent choices. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open Finset
open scoped Classical

def labelsLaw (n L : ℕ) [NeZero L] : FiniteLaw (Fin n → Fin L) :=
  FiniteLaw.product (fun _ => FiniteLaw.uniform (Fin L))

theorem product_expect_eval {I A : Type*} [Fintype I] [DecidableEq I] [Fintype A]
    (laws : I → FiniteLaw A) (i : I) (f : A → ℝ) :
    (FiniteLaw.product laws).expect (fun x => f (x i)) = (laws i).expect f := by
  have h := FiniteLaw.product_expect_prod laws (fun j a => if j = i then f a else 1)
  have he (j : I) : (laws j).expect (fun a => if j = i then f a else 1) =
      if j = i then (laws i).expect f else 1 := by
    by_cases hj : j = i
    · subst j; simp
    · simp [hj]
  simp_rw [he] at h
  simpa using h

/-- A set chosen without seeing coordinate `u` hits that coordinate with probability `k/L`. -/
theorem future_hit_probability {n L : ℕ} [NeZero L] (u : Fin n)
    (W : (Fin n → Fin L) → Finset (Fin L)) (k : ℕ)
    (hcard : ∀ x, (W x).card = k)
    (hind : ∀ x y, (∀ i, i ≠ u → x i = y i) → W x = W y) :
    (labelsLaw n L).prob (fun x => x u ∈ W x) = (k : ℝ) / L := by
  let μ := labelsLaw n L
  have hpoint (x : Fin n → Fin L) :
      (if x u ∈ W x then (1 : ℝ) else 0) =
        ∑ b : Fin L, (if x u = b then 1 else 0) * (if b ∈ W x then 1 else 0) := by
    simp
  have hsplit (b : Fin L) :
      μ.expect (fun x => (if x u = b then (1 : ℝ) else 0) *
        (if b ∈ W x then 1 else 0)) =
        (1 / (L : ℝ)) * μ.expect (fun x => if b ∈ W x then 1 else 0) := by
    have h := FiniteLaw.product_expect_mul_of_disjoint
      (fun _ : Fin n => FiniteLaw.uniform (Fin L)) (fun i => i = u)
      (fun x => if x u = b then (1 : ℝ) else 0)
      (fun x => if b ∈ W x then (1 : ℝ) else 0)
      (by intro x y h; dsimp only; rw [h u rfl])
      (by intro x y h; dsimp only; rw [hind x y h])
    have heval : (FiniteLaw.product (fun _ : Fin n => FiniteLaw.uniform (Fin L))).expect
        (fun x => if x u = b then (1 : ℝ) else 0) = 1 / (L : ℝ) := by
      rw [product_expect_eval (fun _ : Fin n => FiniteLaw.uniform (Fin L)) u
        (fun a => if a = b then (1 : ℝ) else 0)]
      simp [FiniteLaw.expect, FiniteLaw.uniform]
    simpa only [μ, labelsLaw, heval] using h
  change μ.expect _ = _
  simp_rw [hpoint]
  rw [μ.expect_finset_sum]
  simp_rw [hsplit]
  rw [← mul_sum, ← μ.expect_finset_sum]
  have hsum (x : Fin n → Fin L) :
      (∑ b : Fin L, if b ∈ W x then (1 : ℝ) else 0) = k := by simp [hcard]
  simp_rw [hsum]
  rw [μ.expect_const]
  ring

theorem label_collision_bound {n L : ℕ} [NeZero L] :
    (labelsLaw n L).prob (fun x => ¬ Function.Injective x) ≤ (n : ℝ)^2 / L := by
  let bad : (Fin n × Fin n) → (Fin n → Fin L) → Prop :=
    fun p x => p.1 ≠ p.2 ∧ x p.1 = x p.2
  have heq (x : Fin n → Fin L) : ¬ Function.Injective x ↔ ∃ p, bad p x := by
    simp only [Function.Injective, not_forall]
    constructor
    · rintro ⟨i,j,h⟩
      exact ⟨(i,j),by simpa [bad, _root_.not_imp, and_comm] using h⟩
    · rintro ⟨⟨i,j⟩,h⟩
      exact ⟨i,j,by simpa [bad, _root_.not_imp, and_comm] using h⟩
  rw [(labelsLaw n L).prob_congr heq]
  refine (FiniteLaw.union_bound _ bad).trans ?_
  have hb (p : Fin n × Fin n) : (labelsLaw n L).prob (bad p) ≤ 1 / (L : ℝ) := by
    by_cases hp : p.1 = p.2
    · simp [bad, hp, FiniteLaw.prob]
    · have h := future_hit_probability (L := L) p.2 (fun x => {x p.1}) 1 (by simp)
        (by intro x y h; dsimp only; rw [h p.1 hp])
      simpa [bad,hp,eq_comm] using h.le
  calc
    _ ≤ ∑ _p : Fin n × Fin n, 1 / (L : ℝ) := sum_le_sum (fun p _ => hb p)
    _ = (n : ℝ)^2 / L := by simp [Fintype.card_prod, pow_two]; ring

end MatroidProphetSecretary.XOS
