import MatroidProphetSecretary.FinitePairs
import Mathlib.Tactic.FieldSimp

/-! Categorical draws and finite mixtures of conditional sampling laws. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]

def ofWeights (w : Ω → ℝ) (hw : ∀ x, 0 ≤ w x) (hZ : 0 < ∑ x, w x) : FiniteLaw Ω where
  mass x := w x / ∑ y, w y
  nonneg x := div_nonneg (hw x) hZ.le
  total := by rw [← sum_div, div_self hZ.ne']

theorem ofWeights_expect (w : Ω → ℝ) (hw : ∀ x, 0 ≤ w x) (hZ : 0 < ∑ x, w x) (f : Ω → ℝ) :
    (∑ x, w x) * (ofWeights w hw hZ).expect f = ∑ x, w x * f x := by
  unfold expect ofWeights
  rw [mul_sum]
  apply sum_congr rfl
  intro x hx
  rw [← mul_assoc, mul_div_cancel₀ _ hZ.ne']

def bind (μ : FiniteLaw Ω) (ν : Ω → FiniteLaw Ψ) : FiniteLaw Ψ where
  mass y := ∑ x, μ.mass x * (ν x).mass y
  nonneg y := sum_nonneg (fun x _ => mul_nonneg (μ.nonneg x) ((ν x).nonneg y))
  total := by
    rw [sum_comm]
    simp only [← mul_sum, total, mul_one]

theorem bind_expect (μ : FiniteLaw Ω) (ν : Ω → FiniteLaw Ψ) (f : Ψ → ℝ) :
    (μ.bind ν).expect f = μ.expect (fun x => (ν x).expect f) := by
  simp only [expect, bind, sum_mul, mul_sum]
  rw [sum_comm]
  apply sum_congr rfl
  intro x hx
  apply sum_congr rfl
  intro y hy
  ring

theorem mass_eq_expect_indicator (μ : FiniteLaw Ω) [DecidableEq Ω] (x : Ω) :
    μ.mass x = μ.expect (fun y => if y = x then 1 else 0) := by
  simp [expect]

end MatroidProphetSecretary.FiniteLaw
