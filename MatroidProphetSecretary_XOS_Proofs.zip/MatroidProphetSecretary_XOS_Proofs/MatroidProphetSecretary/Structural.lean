import MatroidProphetSecretary.Algebra
import MatroidProphetSecretary.FiniteOptimum
import MatroidProphetSecretary.FiniteProbability

noncomputable section

namespace MatroidProphetSecretary

open Finset

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

def exclusionThreshold (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) : ℝ :=
  deletionValue M v e - contractionValue M v e he

theorem exclusionThreshold_nonneg (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) : 0 ≤ exclusionThreshold M v e he :=
  sub_nonneg.mpr (contraction_le_deletion M v e he)

/-- Both identities (3.1) for the actual finite matroid optimum. -/
theorem deletion_contraction_identities (M : Matroid E) (v : E → ℝ) (e : E)
    (he : M.Indep ({e} : Set E)) :
    optimum M v - deletionValue M v e = posPart (v e - exclusionThreshold M v e he) ∧
    optimum M v - contractionValue M v e he = max (v e) (exclusionThreshold M v e he) := by
  rw [optimum_deletion_contraction M v e he]
  exact optimum_split_identities _ _ _ (contraction_le_deletion M v e he)

def expectedOptimum (μ : FiniteLaw Ω) (M : Matroid E) (values : Ω → E → ℝ) : ℝ :=
  μ.expect (fun w => optimum M (values w))

def deletionSurplus (μ : FiniteLaw Ω) (M : Matroid E) (values : Ω → E → ℝ) : ℝ :=
  ∑ e, μ.expect (fun w => optimum M (values w) - deletionValue M (values w) e)

def stableSurplus (μ : FiniteLaw Ω) (M : Matroid E) (values : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) : ℝ :=
  ∑ e, μ.expect (fun w => μ.expect (fun w' =>
    posPart (min (values w e) (values w' e) - exclusionThreshold M (values w) e (hnonloop e))))

theorem expectedOptimum_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (values : Ω → E → ℝ) :
    0 ≤ expectedOptimum μ M values :=
  μ.expect_nonneg (fun w => optimum_nonneg M (values w))

theorem deletionSurplus_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (values : Ω → E → ℝ) :
    0 ≤ deletionSurplus μ M values := by
  apply sum_nonneg
  intro e he
  exact μ.expect_nonneg (fun w => deletion_surplus_nonneg M (values w) e)

theorem deletionSurplus_le_expectedOptimum (μ : FiniteLaw Ω) (M : Matroid E)
    (values : Ω → E → ℝ) : deletionSurplus μ M values ≤ expectedOptimum μ M values := by
  have h := μ.expect_mono (fun w => total_deletion_surplus_le_optimum M (values w))
  dsimp [FiniteLaw.expect] at h
  simp_rw [mul_sum] at h
  rw [sum_comm] at h
  exact h

theorem stableSurplus_nonneg (μ : FiniteLaw Ω) (M : Matroid E) (values : Ω → E → ℝ)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) : 0 ≤ stableSurplus μ M values hnonloop := by
  apply sum_nonneg
  intro e he
  apply μ.expect_nonneg
  intro w
  apply μ.expect_nonneg
  intro w'
  exact posPart_nonneg _

theorem stableSurplus_le_deletionSurplus (μ : FiniteLaw Ω) (M : Matroid E)
    (values : Ω → E → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    stableSurplus μ M values hnonloop ≤ deletionSurplus μ M values := by
  apply sum_le_sum
  intro e he
  apply μ.expect_mono
  intro w
  rw [(deletion_contraction_identities M (values w) e (hnonloop e)).1,
    ← μ.expect_const (posPart (values w e - exclusionThreshold M (values w) e (hnonloop e)))]
  apply μ.expect_mono
  intro w'
  exact max_le_max (sub_le_sub_right (min_le_left _ _) _) le_rfl

/-- The first chain of bounds in (3.3), for arbitrary finite value laws. -/
theorem basic_surplus_bounds (μ : FiniteLaw Ω) (M : Matroid E)
    (values : Ω → E → ℝ) (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    0 ≤ stableSurplus μ M values hnonloop ∧
    stableSurplus μ M values hnonloop ≤ deletionSurplus μ M values ∧
    deletionSurplus μ M values ≤ expectedOptimum μ M values :=
  ⟨stableSurplus_nonneg μ M values hnonloop,
    stableSurplus_le_deletionSurplus μ M values hnonloop,
    deletionSurplus_le_expectedOptimum μ M values⟩

/-- Taking expectations in the pointwise cap decomposition of Lemma 7. -/
theorem expected_cap_decomposition (μ : FiniteLaw Ω) (M : Matroid E)
    (values : Ω → E → ℝ) (cap : E → ℝ) :
    expectedOptimum μ M values ≤ expectedOptimum μ M (fun w e => min (values w e) (cap e)) +
      ∑ e, μ.expect (fun w => posPart (values w e - cap e)) := by
  have h := μ.expect_mono (fun w => optimum_cap_decomposition M (values w) cap)
  rw [μ.expect_add] at h
  have hid : μ.expect (fun w => ∑ e, max (values w e - cap e) 0) =
      ∑ e, μ.expect (fun w => posPart (values w e - cap e)) := by
    dsimp [FiniteLaw.expect, posPart]
    simp_rw [mul_sum]
    rw [sum_comm]
  rw [hid] at h
  exact h

end MatroidProphetSecretary
