import MatroidProphetSecretary.ConditionalSampling
import MatroidProphetSecretary.LayerInclusion
import MatroidProphetSecretary.ValueActivity
import MatroidProphetSecretary.BlockResampling

/-! Greedy selection among active labels only depends on their active values. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def orderedBefore (reverse : Bool) (v : E → ℝ) (e f : E) : Prop :=
  if reverse = true then priorityBefore v f e else priorityBefore v e f

theorem orderedBefore_congr (reverse : Bool) {v w : E → ℝ} (e f : E)
    (he : v e = w e) (hf : v f = w f) : orderedBefore reverse v e f ↔ orderedBefore reverse w e f := by
  simp only [orderedBefore, priorityBefore, he, hf]

theorem selected_event_masked (reverse : Bool) (M : Matroid E) (v : E → ℝ)
    (e : E) (b : E → Bool) :
    (b e = true ∧ nonspanEvent M e (orderedBefore reverse (maskedValue v b) e) b) ↔
      (b e = true ∧ nonspanEvent M e (orderedBefore reverse v e) b) := by
  by_cases he : b e = true
  · have hset : activeBlock M e (orderedBefore reverse (maskedValue v b) e) b =
        activeBlock M e (orderedBefore reverse v e) b := by
      ext f
      by_cases hf : b f = true
      · have hi := orderedBefore_congr reverse e f
          (show maskedValue v b e = v e by simp [maskedValue, he])
          (show maskedValue v b f = v f by simp [maskedValue, hf])
        simp only [activeBlock, Set.mem_setOf_eq, hi]
      · simp [activeBlock, hf]
    simp only [nonspanEvent, hset]
  · simp [he]

variable {V : E → Type*} [∀ e, Fintype (V e)]

def optionValues (value : ∀ e, V e → ℝ) (x : ∀ e, Option (V e)) (e : E) : ℝ :=
  (x e).elim 0 (value e)

def optionActivity (x : ∀ e, Option (V e)) (e : E) : Bool := (x e).isSome

def optionSelectedIndicator (reverse : Bool) (M : Matroid E) (value : ∀ e, V e → ℝ)
    (e : E) (x : ∀ e, Option (V e)) : ℝ :=
  if optionActivity x e = true ∧
    nonspanEvent M e (orderedBefore reverse (optionValues value x) e) (optionActivity x) then 1 else 0

theorem option_activity_mask (b : E → Bool) (x : ∀ e, V e) :
    optionActivity (fun e => activeOption (b e) (x e)) = b := by
  funext e
  cases hb : b e <;> simp [optionActivity, activeOption, hb]

theorem option_values_mask (value : ∀ e, V e → ℝ) (b : E → Bool) (x : ∀ e, V e) :
    optionValues value (fun e => activeOption (b e) (x e)) = maskedValue (coordinateValues value x) b := by
  funext e
  cases hb : b e <;> simp [optionValues, activeOption, maskedValue, coordinateValues, hb]

theorem option_selected_mask (reverse : Bool) (M : Matroid E) (value : ∀ e, V e → ℝ)
    (e : E) (b : E → Bool) (x : ∀ e, V e) :
    optionSelectedIndicator reverse M value e (fun e => activeOption (b e) (x e)) =
      if b e = true ∧ nonspanEvent M e (orderedBefore reverse (coordinateValues value x) e) b then 1 else 0 := by
  simp only [optionSelectedIndicator, option_activity_mask, option_values_mask, selected_event_masked]

theorem conditional_selected_representation (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (z : ℝ) (e : E) (reverse : Bool) :
    (FiniteLaw.product (fun i => (laws i).conditionOrSelf (fun x => z < value i x))).expect
      (fun x => selectedProbability (activityLaws laws value z) M e
        (orderedBefore reverse (coordinateValues value x) e)) =
      (FiniteLaw.product laws).expect (fun x => if valueActivity value z x e = true ∧
        nonspanEvent M e (orderedBefore reverse (coordinateValues value x) e) (valueActivity value z x)
        then 1 else 0) := by
  have h := FiniteLaw.product_conditional_sampling laws (fun i x => z < value i x)
    (optionSelectedIndicator reverse M value e)
  rw [FiniteLaw.expect_comm] at h
  have hbits : (fun i => bernoulliLaw ((laws i).prob (fun x => z < value i x))
      ((laws i).prob_nonneg _) ((laws i).prob_le_one _)) = activityLaws laws value z :=
    (activityLaws_eq_bernoulli laws value z).symm
  rw [hbits] at h
  simp_rw [option_selected_mask] at h
  change _ = _ at h
  convert h using 1
  congr 1
  funext x
  have hx : (fun i => if z < value i (x i) then some (x i) else none) =
      (fun i => activeOption (valueActivity value z x i) (x i)) := by
    funext i
    simp [activeOption, valueActivity]
  rw [hx, option_selected_mask]

end MatroidProphetSecretary
