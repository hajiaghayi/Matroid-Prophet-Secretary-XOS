import MatroidProphetSecretary.BernoulliGenerator

/-! Differentiation of a Bernoulli expectation along a one-sided differentiable path. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem bernoulliEval_hasDerivWithinAt (a : ℝ → E → ℝ) (a' : E → ℝ)
    (f : (E → Bool) → ℝ) (S : Set ℝ) (q : ℝ)
    (ha : ∀ e, HasDerivWithinAt (fun t => a t e) (a' e) S q) :
    HasDerivWithinAt (fun t => bernoulliEval (a t) f)
      (∑ e, a' e * bernoulliEval (a q) (replaceDifference e f)) S q := by
  have hweight (e : E) (b : Bool) : HasDerivWithinAt (fun t => bernoulliWeight (a t e) b)
      ((if b = true then 1 else -1) * a' e) S q := by
    cases b
    · simpa only [bernoulliWeight, Bool.false_eq_true, if_false, neg_one_mul] using (ha e).const_sub 1
    · simpa only [bernoulliWeight, if_true, one_mul] using ha e
  have hworld (x : E → Bool) :
      HasDerivWithinAt (fun t => bernoulliMass (a t) x * f x)
        ((∑ e, bernoulliExcept (a q) e x * ((if x e = true then 1 else -1) * a' e)) * f x) S q := by
    simpa only [bernoulliMass, bernoulliExcept, smul_eq_mul] using
      (HasDerivWithinAt.finset_prod (u := univ) (fun e _ => hweight e (x e))).mul_const (f x)
  have hsum := HasDerivWithinAt.sum (u := univ) (fun x _ => hworld x)
  have heq : (∑ x, (∑ e, bernoulliExcept (a q) e x *
      ((if x e = true then 1 else -1) * a' e)) * f x) =
      ∑ e, a' e * bernoulliEval (a q) (replaceDifference e f) := by
    simp_rw [sum_mul]
    rw [sum_comm]
    apply sum_congr rfl
    intro e he
    rw [← bernoulli_generator_column, mul_sum]
    apply sum_congr rfl
    intro x hx
    ring
  rw [heq] at hsum
  exact hsum

end MatroidProphetSecretary
