import MatroidProphetSecretary.SharedValueTapes
import MatroidProphetSecretary.ScreenedLiveKernel

/-! One private value shared across all counterfactual clock slots, with an exact marked kernel. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {V E C P : Type*} [Fintype V] [Fintype E] [DecidableEq E]
  [Fintype C] [DecidableEq C] [Fintype P]

def referencePrivateTapeLaw (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (probe : FiniteLaw P) : FiniteLaw (V × (C → P × Option (E → Option V))) :=
  FiniteLaw.sharedValueTapes prior (fun v _ => probe.pair (conditionalScreenedCandidate prior references e q hq hdom v))

def referencePrivateDecision (live : (E → Option V) → Prop) (pass : P → Prop)
    (c : C) (tape : V × (C → P × Option (E → Option V))) : Option (E → Option V) :=
  attenuateOption pass ((tape.2 c).1,liveCandidate live (tape.2 c).2)

theorem referencePrivateTape_slot_law (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (probe : FiniteLaw P) (c : C) :
    (referencePrivateTapeLaw (C := C) prior references e q hq hdom probe).map (fun tape => tape.2 c) =
      probe.pair (screenedCandidateLaw prior references e q hq hdom) := by
  rw [referencePrivateTapeLaw,FiniteLaw.sharedValueTapes_slot_law,FiniteLaw.pair_bind_right,
    conditionalScreenedCandidate_mixture]

theorem referencePrivateDecision_law (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (probe : FiniteLaw P) (c : C) (live : (E → Option V) → Prop) (pass : P → Prop) :
    (referencePrivateTapeLaw (C := C) prior references e q hq hdom probe).map
      (referencePrivateDecision live pass c) =
    (probe.pair (screenedLiveLaw prior references e q hq hdom live)).map (attenuateOption pass) := by
  apply FiniteLaw.ext_expect
  intro f
  rw [FiniteLaw.map_expect,FiniteLaw.map_expect]
  have hslot := congrArg (fun law => law.expect (fun data : P × Option (E → Option V) =>
      f (attenuateOption pass (data.1,liveCandidate live data.2))))
    (referencePrivateTape_slot_law prior references e q hq hdom probe c)
  dsimp only at hslot
  rw [FiniteLaw.map_expect] at hslot
  unfold referencePrivateDecision
  rw [hslot]
  simp only [FiniteLaw.pair_expect,screenedLiveLaw,FiniteLaw.map_expect]

theorem reference_private_tape_kernel (prior : FiniteLaw V) (references : E → FiniteLaw (Option V)) (e : E)
    (q : ℝ) (hq : 0 < q) (hdom : ∀ v, (references e).mass (some v) ≤ q*prior.mass v)
    (probe : FiniteLaw P) (c : C) (live : (E → Option V) → Prop)
    (hpositive : ∀ y, live y → y e ≠ none) (pass : P → Prop) (B : (E → Option V) → Prop) :
    (referencePrivateTapeLaw (C := C) prior references e q hq hdom probe).prob
      (fun tape => ∃ y, referencePrivateDecision live pass c tape = some y ∧ B y) =
      (1/q)*probe.prob pass*(FiniteLaw.product references).prob (fun y => live y ∧ B y) := by
  have hmap := congrArg (fun law => law.prob (fun x => ∃ y, x = some y ∧ B y))
    (referencePrivateDecision_law prior references e q hq hdom probe c live pass)
  dsimp only at hmap
  simp only [FiniteLaw.map_prob] at hmap
  have h := attenuateOption_mark_probability probe
    (screenedLiveLaw prior references e q hq hdom live) pass B
  rw [screenedLiveLaw_mark_probability prior references e q hq hdom live hpositive B] at h
  have ht := hmap.trans h
  convert ht using 1
  ring

end MatroidProphetSecretary
