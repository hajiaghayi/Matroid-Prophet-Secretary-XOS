import MatroidProphetSecretary.ColoopOracle
import MatroidProphetSecretary.GreedyBasisOracle
import MatroidProphetSecretary.RankMarginals

/-! The entire common-layer oracle computation, with a deterministic query bound. -/

namespace MatroidProphetSecretary

open Finset
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [LinearOrder E]

def restrictedOracle (oracle : Finset E → Bool) (R I : Finset E) : Bool :=
  oracle I && decide (I ⊆ R)

theorem restrictedOracle_spec (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R I : Finset E) :
    restrictedOracle oracle R I = true ↔ (M ↾ (R : Set E)).Indep (I : Set E) := by
  simp only [restrictedOracle,Bool.and_eq_true,decide_eq_true_eq,horacle,Matroid.restrict_indep_iff]
  rfl

def layerBasis (oracle : Finset E → Bool) (R : Finset E) : Finset E :=
  oracleGreedy oracle (R.sort (· ≤ ·)) ∅

theorem layerBasis_isBasis (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R : Finset E)
    (hR : (R : Set E) ⊆ M.E) : M.IsBasis (layerBasis oracle R : Set E) (R : Set E) := by
  simpa only [sort_toFinset] using oracleGreedy_isBasis M oracle horacle (R.sort (· ≤ ·))
    (fun e he => hR (by simpa using he))

def layerColoops (oracle : Finset E → Bool) (R : Finset E) : Finset E × ℕ :=
  coloopOracle (restrictedOracle oracle R) R (layerBasis oracle R)

theorem layerColoops_correct (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R : Finset E)
    (hR : (R : Set E) ⊆ M.E) :
    (layerColoops oracle R).1 = R.filter (M ↾ (R : Set E)).IsColoop :=
  coloopOracle_correct (M ↾ (R : Set E)) _ (restrictedOracle_spec M oracle horacle R) R _
    rfl ((layerBasis_isBasis M oracle horacle R hR).isBase_restrict)

theorem layerBasis_rank (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R : Finset E)
    (hR : (R : Set E) ⊆ M.E) :
    (layerBasis oracle R).card = realRank M (R : Set E) := by
  rw [realRank_eq_ncard (layerBasis_isBasis M oracle horacle R hR),Set.ncard_coe_Finset]

def layerClosure (oracle : Finset E → Bool) (R U B : Finset E) (e : E) : Bool :=
  if e ∈ R then !decide (e ∈ U) else !(oracle (insert e B))

theorem layerClosure_correct (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R : Finset E)
    (hR : (R : Set E) ⊆ M.E) (e : E) (heE : e ∈ M.E) :
    layerClosure oracle R (layerColoops oracle R).1 (layerBasis oracle R) e = true ↔
      e ∈ M.closure ((R : Set E) \ {e}) := by
  rw [layerClosure,layerColoops_correct M oracle horacle R hR]
  by_cases heR : e ∈ R
  · simp only [heR,if_true,Bool.not_eq_true',decide_eq_false_iff_not,mem_filter,true_and]
    have hc := (M ↾ (R : Set E)).isColoop_iff_not_mem_closure_compl (show e ∈ (M ↾ (R : Set E)).E from heR)
    rw [Matroid.restrict_ground_eq,M.restrict_closure_eq Set.diff_subset hR] at hc
    simpa only [Set.mem_inter_iff,Finset.mem_coe,heR,and_true,not_not] using not_congr hc
  · simp only [heR,if_false,Bool.not_eq_true']
    have hB := layerBasis_isBasis M oracle horacle R hR
    have heB : e ∉ layerBasis oracle R := fun he => heR (hB.subset he)
    have hc := hB.indep.not_mem_closure_iff_of_not_mem heB heE
    rw [hB.closure_eq_closure] at hc
    have hdiff : (R : Set E) \ {e} = R := Set.diff_singleton_eq_self heR
    rw [hdiff]
    have ho := horacle (insert e (layerBasis oracle R))
    simp only [coe_insert] at ho
    rw [← hc] at ho
    cases h : oracle (insert e (layerBasis oracle R)) <;> simp_all

def layerOracleQueries (oracle : Finset E → Bool) (R : Finset E) : ℕ :=
  oracleGreedyQueries (R.sort (· ≤ ·)) + (layerColoops oracle R).2 + (univ \ R).card

theorem layerOracle_query_bound (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E)) (R : Finset E)
    (hR : (R : Set E) ⊆ M.E) :
    layerOracleQueries oracle R ≤ 2*Fintype.card E + 2*Nat.clog 2 (Fintype.card E)*Fintype.card E := by
  have hB := layerBasis_isBasis M oracle horacle R hR
  have h := coloopOracle_query_bound (M ↾ (R : Set E)) _
    (restrictedOracle_spec M oracle horacle R) R _ rfl hB.isBase_restrict
  change (layerColoops oracle R).2 ≤ _ at h
  have hbcard := card_le_univ (layerBasis oracle R)
  have hcard := card_le_univ R
  have hdcard : (R \ layerBasis oracle R).card ≤ R.card := card_le_card sdiff_subset
  have hlog := Nat.clog_mono_right 2 hbcard
  have hmul : 2*Nat.clog 2 (layerBasis oracle R).card*(layerBasis oracle R).card ≤
      2*Nat.clog 2 (Fintype.card E)*Fintype.card E := by gcongr
  simp only [layerOracleQueries,oracleGreedyQueries_eq,length_sort,card_sdiff (subset_univ R),card_univ]
  omega

end MatroidProphetSecretary
