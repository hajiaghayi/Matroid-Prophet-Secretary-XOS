import MatroidProphetSecretary.BernoulliRankBound
import MatroidProphetSecretary.NonspanProbability

/-! Lemma 8: the Bernoulli nonspanning rank inequality, with boundary probabilities. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def bernoulliLaws (p : E → ℝ) (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) : E → FiniteLaw Bool :=
  fun e => bernoulliLaw (p e) (hp0 e) (hp1 e)

theorem bernoulliEval_eq_expect (p : E → ℝ) (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1)
    (f : (E → Bool) → ℝ) :
    bernoulliEval p f = (FiniteLaw.product (bernoulliLaws p hp0 hp1)).expect f := rfl

theorem nonspan_bitSet_iff (M : Matroid E) (hground : ∀ e, e ∈ M.E) (e : E) (x : E → Bool) :
    e ∉ M.closure (bitSet x) ↔ x e = false ∧ nonspanEvent M e (fun _ => True) x := by
  have hfalse (hx : x e = false) : bitSet x = activeBlock M e (fun _ => True) x := by
    ext f
    by_cases hfe : f = e
    · subst f
      simp [bitSet, activeBlock, hx]
    · simp [bitSet, activeBlock, hfe, hground f]
  cases hx : x e
  · simp only [hfalse hx, nonspanEvent, true_and]
  · have he : e ∈ M.closure (bitSet x) :=
      M.mem_closure_of_mem hx (fun f _ => hground f)
    simp [he]

theorem bernoulli_rank_marginal (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (e : E) :
    bernoulliEval p (insertDifference e (rankObservable M)) =
      (1 - p e) * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True) := by
  let laws := bernoulliLaws p hp0 hp1
  have hevent : bernoulliEval p (insertDifference e (rankObservable M)) =
      (FiniteLaw.product laws).prob (fun x => x e = false ∧ nonspanEvent M e (fun _ => True) x) := by
    rw [bernoulliEval_eq_expect p hp0 hp1]
    apply sum_congr rfl
    intro x hx
    congr 1
    rw [rank_insertDifference M hground]
    have hi := nonspan_bitSet_iff M hground e x
    by_cases hc : e ∈ M.closure (bitSet x)
    · have hn : ¬(x e = false ∧ nonspanEvent M e (fun _ => True) x) := by
        rw [← hi]
        exact fun hn => hn hc
      simp [hc, hn]
    · have hh := hi.mp hc
      simp [hc, hh]
  rw [hevent]
  have hind := FiniteLaw.product_prob_and_of_disjoint laws (fun f => f = e)
    (fun x => x e = false) (nonspanEvent M e (fun _ => True))
    (fun x y hxy => by dsimp only; rw [hxy e rfl]) (by
      intro x y hxy
      have hid : activeBlock M e (fun _ => True) x = activeBlock M e (fun _ => True) y := by
        ext f
        by_cases hfe : f = e
        · simp [activeBlock, hfe]
        · simp [activeBlock, hfe, hxy f hfe]
      simp only [nonspanEvent, hid])
  rw [hind, FiniteLaw.product_prob_coordinate]
  rfl

/-- The nonspanning inequality from Lemma 8 of the paper, for a finite matroid. -/
theorem rank_nonspan_inequality (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (C : Finset E) (hC : M.IsBase (C : Set E)) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (s : ℝ) (hs : 0 ≤ s) :
    let rho := fun e => nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True)
    (∑ e, p e * rho e) ≤ (∑ e, (p e)^2 * rho e) + realRank M M.E * Real.exp (-s) +
      s * ∑ e ∈ C, (1 - p e) * rho e := by
  dsimp only
  have h := bernoulli_rank_missing_mass M hground C hC p hp0 hp1 s hs
  simp_rw [bernoulli_rank_marginal M hground p hp0 hp1] at h
  have halg :
      (∑ e, p e * ((1 - p e) * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True))) =
      (∑ e, p e * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True)) -
      ∑ e, (p e)^2 * nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True) := by
    rw [← sum_sub_distrib]
    apply sum_congr rfl
    intro e he
    ring
  rw [halg] at h
  linarith

end MatroidProphetSecretary
