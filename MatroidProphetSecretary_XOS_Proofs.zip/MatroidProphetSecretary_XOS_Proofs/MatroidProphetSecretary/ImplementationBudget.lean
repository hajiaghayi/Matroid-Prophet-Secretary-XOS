import MatroidProphetSecretary.PoissonTableEncoding
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Tactic

/-! The concrete truncation and dyadic grid choices pay the complete finite-precision error budget. -/

noncomputable section

namespace MatroidProphetSecretary

def implementationTruncation (N : ℕ) (ρ : ℝ) : ℕ := Nat.clog 2 ⌈8*(N:ℝ)/ρ⌉₊

def categoricalDrawBudget (N K m T : ℕ) : ℕ := N*K*m*(N+2)+N^2*(1+T)+2*N+N*T

def categoricalSizeBudget (N support T : ℕ) : ℕ := N*support+N+T+3

def implementationGridBits (N draws categories dyadic : ℕ) (ρ : ℝ) : ℕ :=
  max dyadic (Nat.clog 2 ⌈2*(4*(N:ℝ)^2+draws*categories)/ρ⌉₊)

theorem implementationTruncation_budget (N : ℕ) (ρ : ℝ) (hρ : 0 < ρ) :
    4*N/(2:ℝ)^(implementationTruncation N ρ) ≤ ρ/2 := by
  have hc : 8*(N:ℝ)/ρ ≤ (⌈8*(N:ℝ)/ρ⌉₊:ℝ) := Nat.le_ceil _
  have hp : (⌈8*(N:ℝ)/ρ⌉₊:ℝ) ≤ (2:ℝ)^(implementationTruncation N ρ) := by
    unfold implementationTruncation
    exact_mod_cast Nat.le_pow_clog (by omega : 1 < 2) ⌈8*(N:ℝ)/ρ⌉₊
  have h := hc.trans hp
  have hm := (div_le_iff₀ hρ).mp h
  apply (div_le_iff₀ (by positivity : (0:ℝ) < 2^(implementationTruncation N ρ))).mpr
  nlinarith only [hm]

theorem implementationGrid_budget (N draws categories dyadic : ℕ) (ρ : ℝ) (hρ : 0 < ρ) :
    (4*(N:ℝ)^2+draws*categories)/(2:ℝ)^(implementationGridBits N draws categories dyadic ρ) ≤ ρ/2 := by
  let A : ℝ := 4*(N:ℝ)^2+draws*categories
  have hc : 2*A/ρ ≤ (⌈2*A/ρ⌉₊:ℝ) := Nat.le_ceil _
  have hp : (⌈2*A/ρ⌉₊:ℝ) ≤ (2:ℝ)^(implementationGridBits N draws categories dyadic ρ) := by
    have h := Nat.le_pow_clog (by omega : 1 < 2) ⌈2*A/ρ⌉₊
    have hm : 2^(Nat.clog 2 ⌈2*A/ρ⌉₊) ≤ 2^(implementationGridBits N draws categories dyadic ρ) :=
      Nat.pow_le_pow_right (by omega) (le_max_right _ _)
    exact_mod_cast h.trans hm
  have h := (div_le_iff₀ hρ).mp (hc.trans hp)
  apply (div_le_iff₀ (by positivity : (0:ℝ) < 2^(implementationGridBits N draws categories dyadic ρ))).mpr
  change A ≤ _
  calc
    A = (2*A)/2 := by ring
    _ ≤ ((2:ℝ)^(implementationGridBits N draws categories dyadic ρ)*ρ)/2 :=
      div_le_div_of_nonneg_right h (by norm_num)
    _ = _ := by ring

theorem implementation_total_error_budget (N draws categories dyadic : ℕ) (ρ : ℝ) (hρ : 0 < ρ) :
    4*(N:ℝ)^2/(2:ℝ)^(implementationGridBits N draws categories dyadic ρ) +
    4*N/(2:ℝ)^(implementationTruncation N ρ) +
    draws*categories/(2:ℝ)^(implementationGridBits N draws categories dyadic ρ) ≤ ρ := by
  have hg := implementationGrid_budget N draws categories dyadic ρ hρ
  have ht := implementationTruncation_budget N ρ hρ
  rw [add_div] at hg
  linarith

theorem implementationGrid_dyadic (N draws categories dyadic : ℕ) (ρ : ℝ) :
    ∃ z : ℕ, (2:ℝ)^(implementationGridBits N draws categories dyadic ρ) * (1/(2:ℝ)^dyadic) = z := by
  let bits := implementationGridBits N draws categories dyadic ρ
  have hd : dyadic ≤ bits := le_max_left _ _
  refine ⟨2^(bits-dyadic),?_⟩
  change (2:ℝ)^bits*(1/(2:ℝ)^dyadic) = _
  rw [mul_one_div,div_eq_mul_inv,← pow_sub₀ (2:ℝ) (by norm_num : (2:ℝ) ≠ 0) hd]
  norm_cast

end MatroidProphetSecretary
