import MatroidProphetSecretary.BisectionGeometry

/-! Certificate provenance of the saved and opposite bisection endpoints. -/

namespace MatroidProphetSecretary

theorem bisectionRun_lower_property (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket)
    (P : ℝ → Prop) (hstart : P b.lower)
    (hquery : ∀ i < n, answers i = true → P (bisectionRun answers i b).midpoint) :
    P (bisectionRun answers n b).lower := by
  induction n with
  | zero => exact hstart
  | succ n ih =>
    cases ha : answers n
    · simp only [bisectionRun, ha, bisectBracket, Bool.false_eq_true, if_false]
      exact ih (fun i hi => hquery i (Nat.lt_succ_of_lt hi))
    · simp only [bisectionRun, ha, bisectBracket, if_true]
      exact hquery n (Nat.lt_succ_self n) ha

theorem bisectionRun_upper_property (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket)
    (P : ℝ → Prop) (hstart : P b.upper)
    (hquery : ∀ i < n, answers i = false → P (bisectionRun answers i b).midpoint) :
    P (bisectionRun answers n b).upper := by
  induction n with
  | zero => exact hstart
  | succ n ih =>
    cases ha : answers n
    · simp only [bisectionRun, ha, bisectBracket, Bool.false_eq_true, if_false]
      exact hquery n (Nat.lt_succ_self n) ha
    · simp only [bisectionRun, ha, bisectBracket, if_true]
      exact ih (fun i hi => hquery i (Nat.lt_succ_of_lt hi))

theorem bisectionRun_lower_provenance (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket) :
    (bisectionRun answers n b).lower = b.lower ∨
      ∃ i < n, answers i = true ∧ (bisectionRun answers n b).lower = (bisectionRun answers i b).midpoint := by
  induction n with
  | zero => exact Or.inl rfl
  | succ n ih =>
    cases ha : answers n
    · simp only [bisectionRun, ha, bisectBracket, Bool.false_eq_true, if_false]
      rcases ih with h | ⟨i,hi,hai,hpoint⟩
      · exact Or.inl h
      · exact Or.inr ⟨i,Nat.lt_succ_of_lt hi,hai,hpoint⟩
    · exact Or.inr ⟨n,Nat.lt_succ_self n,ha,by simp [bisectionRun, bisectBracket, ha]⟩

theorem bisectionRun_upper_provenance (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket) :
    (bisectionRun answers n b).upper = b.upper ∨
      ∃ i < n, answers i = false ∧ (bisectionRun answers n b).upper = (bisectionRun answers i b).midpoint := by
  induction n with
  | zero => exact Or.inl rfl
  | succ n ih =>
    cases ha : answers n
    · exact Or.inr ⟨n,Nat.lt_succ_self n,ha,by simp [bisectionRun, bisectBracket, ha]⟩
    · simp only [bisectionRun, ha, bisectBracket, if_true]
      rcases ih with h | ⟨i,hi,hai,hpoint⟩
      · exact Or.inl h
      · exact Or.inr ⟨i,Nat.lt_succ_of_lt hi,hai,hpoint⟩

theorem bisectionRun_lower_preserves_potential (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket)
    (hb : b.lower ≤ b.upper) (g : ℝ → ℝ)
    (hquery : ∀ i < n, answers i = true → g b.lower ≤ g (bisectionRun answers i b).midpoint) :
    g b.lower ≤ g (bisectionRun answers n b).lower :=
  bisectionRun_lower_property answers n b (fun q => g b.lower ≤ g q) le_rfl hquery

theorem bisectionRun_upper_preserves_potential (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket)
    (hb : b.lower ≤ b.upper) (g : ℝ → ℝ)
    (hquery : ∀ i < n, answers i = false → g b.upper ≤ g (bisectionRun answers i b).midpoint) :
    g b.upper ≤ g (bisectionRun answers n b).upper :=
  bisectionRun_upper_property answers n b (fun q => g b.upper ≤ g q) le_rfl hquery

end MatroidProphetSecretary
