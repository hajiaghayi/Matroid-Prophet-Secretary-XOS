import MatroidProphetSecretary.GridAcceptedAbsence
import MatroidProphetSecretary.AcceptedCoordinateLaw

/-! Exact transition intensities of the complete private-clock process, conditional on its accepted path. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

abbrev GridPrivateTape (N L : ℕ) (V : Type*) :=
  V × (Fin L → (Fin L → Bool × (Fin N → Option V)) × Option (Fin N → Option V))

structure PrivateGridConfig (N L : ℕ) (V : Type*) [Fintype V] where
  labels_pos : 0 < N
  clocks_pos : 0 < L
  prior : Fin N → FiniteLaw V
  reference : Fin N → FiniteLaw (Option V)
  q : ℝ
  q_pos : 0 < q
  domination : ∀ e v, (reference e).mass (some v) ≤ q*(prior e).mass v
  step_le : (1/(L:ℝ))*(1/q) ≤ 1
  cut : ℕ
  live : StampedHistory (Fin N) (Fin N → Option V) → Fin N → (Fin N → Option V) → Prop
  positive : ∀ history e y, live history e y → y e ≠ none

namespace PrivateGridConfig

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def tapes (e : Fin N) : FiniteLaw (GridPrivateTape N L V) :=
  earlyPrivateTapeLaw (cfg.prior e) cfg.reference e cfg.q cfg.q_pos (cfg.domination e)
    L ((1/(L:ℝ))*(1/cfg.q))
    (mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)) cfg.step_le

def laws (e : Fin N) : FiniteLaw (Fin L × GridPrivateTape N L V) :=
  letI : Nonempty (Fin L) := ⟨⟨0,cfg.clocks_pos⟩⟩
  (FiniteLaw.uniform (Fin L)).pair (cfg.tapes e)

def decision := gridPrivateDecision cfg.labels_pos cfg.clocks_pos cfg.cut cfg.live

def pathEvent (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) :=
  privatePathEvent (gridLabel N cfg.labels_pos)
    (markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision)) [] path n

def profile (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) :=
  gridHistoryProfile cfg.live (path n) (gridLabel N cfg.labels_pos n)

def dose (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) :=
  gridLiveDose (FiniteLaw.product cfg.reference) ((1/(L:ℝ))*(1/cfg.q)) (cfg.profile path n)

def survival (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) :=
  phaseSurvival (cfg.dose path n) cfg.cut (gridClock N L cfg.clocks_pos n).val

theorem profile_positive (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n i : ℕ) (y : Fin N → Option V) (hy : cfg.profile path n i y) :
    y (gridLabel N cfg.labels_pos n) ≠ none := cfg.positive _ _ _ hy

theorem coordinate_condition (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N) (hp : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n))
    (habsent : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ path n) :
    ((FiniteLaw.product cfg.laws).conditionOrSelf (cfg.pathEvent path n)).map
      (fun x => x (gridLabel N cfg.labels_pos n)) =
    (cfg.laws (gridLabel N cfg.labels_pos n)).conditionOrSelf
      (FiniteLaw.oneArrivalAbsent (fun c => c.val < (gridClock N L cfg.clocks_pos n).val)
        (phasePrivateDecision cfg.cut (cfg.profile path n))) := by
  have h := markedPath_absent_coordinate_law cfg.laws (gridLabel N cfg.labels_pos)
    (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision) [] path n hp _ habsent
  unfold pathEvent
  rw [h]
  apply FiniteLaw.conditionOrSelf_congr
  exact grid_private_past_absence_iff cfg.labels_pos cfg.clocks_pos cfg.laws cfg.cut cfg.live path n hn hp

theorem survival_probability (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) :
    (cfg.laws (gridLabel N cfg.labels_pos n)).prob
      (FiniteLaw.oneArrivalAbsent (fun c => c.val < (gridClock N L cfg.clocks_pos n).val)
        (phasePrivateDecision cfg.cut (cfg.profile path n))) = cfg.survival path n := by
  exact phase_private_survival (cfg.prior _) cfg.reference _ cfg.q cfg.q_pos (cfg.domination _)
    L cfg.clocks_pos cfg.step_le cfg.cut (cfg.profile path n) (cfg.profile_positive path n)
    _ (gridClock N L cfg.clocks_pos n).isLt.le

theorem survival_positive (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N) (hp : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n))
    (habsent : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ path n) : 0 < cfg.survival path n := by
  have hs := privatePath_start_of_positive cfg.laws (gridLabel N cfg.labels_pos)
    (markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision)) [] path n hp
  have hc := privatePath_coordinate_positive cfg.laws (gridLabel N cfg.labels_pos)
    (markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision)) [] path hs n hp
    (gridLabel N cfg.labels_pos n)
  have he (x : Fin L × GridPrivateTape N L V) :=
    (absent_coordinate_event_iff cfg.laws (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos)
      (stampDecision cfg.decision) [] path n hp _ habsent x).trans
    (grid_private_past_absence_iff cfg.labels_pos cfg.clocks_pos cfg.laws cfg.cut cfg.live path n hn hp x)
  rw [FiniteLaw.prob_congr _ he] at hc
  change 0 < (cfg.laws (gridLabel N cfg.labels_pos n)).prob
    (FiniteLaw.oneArrivalAbsent (fun c => c.val < (gridClock N L cfg.clocks_pos n).val)
      (phasePrivateDecision cfg.cut (cfg.profile path n))) at hc
  rw [cfg.survival_probability path n] at hc
  exact hc

theorem accepted_path_intensity (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N) (hp : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n))
    (habsent : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ path n)
    (B : (Fin N → Option V) → Prop) :
    ((FiniteLaw.product cfg.laws).conditionOrSelf (cfg.pathEvent path n)).prob
      (fun x => (x (gridLabel N cfg.labels_pos n)).1 = gridClock N L cfg.clocks_pos n ∧
        ∃ y, cfg.decision n (path n) (x (gridLabel N cfg.labels_pos n)).2 = some y ∧ B y) =
      (1/(L:ℝ))*(1/cfg.q)*
        (if (gridClock N L cfg.clocks_pos n).val < cfg.cut
          then gridSurvival (cfg.dose path n) (gridClock N L cfg.clocks_pos n).val else 1)*
        (FiniteLaw.product cfg.reference).prob (fun y => cfg.profile path n (gridClock N L cfg.clocks_pos n).val y ∧ B y) /
        cfg.survival path n := by
  have hc := congrArg (fun law => law.prob (fun x : Fin L × GridPrivateTape N L V =>
      x.1 = gridClock N L cfg.clocks_pos n ∧ ∃ y, cfg.decision n (path n) x.2 = some y ∧ B y))
    (cfg.coordinate_condition path n hn hp habsent)
  dsimp only at hc
  rw [FiniteLaw.map_prob] at hc
  rw [hc]
  exact phase_private_conditional_intensity (cfg.prior _) cfg.reference _ cfg.q cfg.q_pos (cfg.domination _)
    L cfg.clocks_pos cfg.step_le cfg.cut (cfg.profile path n) (cfg.profile_positive path n)
    (gridClock N L cfg.clocks_pos n) B (cfg.survival_positive path n hn hp habsent)

end PrivateGridConfig
end MatroidProphetSecretary
