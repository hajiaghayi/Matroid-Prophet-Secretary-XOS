import MatroidProphetSecretary.CappedLayerBound
import MatroidProphetSecretary.IntegratedMissingMass

/-! The capped-surplus lemma and threshold-surplus corollary for independent finite priors. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

/-- Lemma 9, with all structural inequalities derived from the finite independent instance. -/
theorem finite_capped_surplus (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (b : ℝ) (hb : 0 ≤ b) (s : ℝ) (hs : 0 ≤ s) :
    let μ := FiniteLaw.product laws
    let v := coordinateValues value
    remainingCapSurplus μ M v hnonloop b ≤ stableSurplus μ M v hnonloop +
      b * priceOptimum μ M v hnonloop * Real.exp (-s) +
        s * (priceGap μ M v hnonloop + capDeficit μ M v hnonloop b) := by
  dsimp only
  let μ := FiniteLaw.product laws
  let v := coordinateValues value
  let c := fun e => b * contractionPrice μ M v hnonloop e
  have hv' : ∀ w e, 0 ≤ v w e := fun w e => hv e (w e)
  have hc : ∀ e, 0 ≤ c e := fun e => mul_nonneg hb (contractionPrice_nonneg μ M v hnonloop e)
  have hground : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  obtain ⟨B, hB, hopt⟩ := optimum_attained_base M (contractionPrice μ M v hnonloop)
    (contractionPrice_nonneg μ M v hnonloop)
  have hoptc : optimum M c = weight c B := by
    rw [optimum_smul M _ b hb, hopt]
    simp [weight, c, mul_sum]
  have hH := stableLayerExpectation_integrable μ M v hv'
  have hR := positiveRankLayer_integrable M c hc
  have hM := μ.integrable_expect _ (fun w => capMissingLayer_integrable M (v w) c (hv' w) B hnonloop)
  have hHR : Integrable (fun z => stableLayerExpectation μ M v z +
      Real.exp (-s) * positiveRankLayer M c z) := hH.add (hR.const_mul _)
  have h := integral_mono (cappedColoopExpectation_integrable μ M v c hv' hc)
    (hHR.add (hM.const_mul s))
    (fun z => capped_layer_bound laws M hground value c B hB hoptc z s hs)
  simp only [Pi.add_apply] at h
  rw [← remainingCapSurplus_eq_integral μ M v hv' hnonloop b hb,
    integral_add hHR (hM.const_mul s), integral_add hH (hR.const_mul _),
    integral_const_mul, integral_const_mul] at h
  have hHint : (∫ z, stableLayerExpectation μ M v z) = stableSurplus μ M v hnonloop :=
    (stableSurplus_eq_integral_tail_coloop μ M v hv' hnonloop).symm
  have hRint : (∫ z, positiveRankLayer M c z) = b * priceOptimum μ M v hnonloop := by
    rw [← optimum_eq_integral_rank M c hc, optimum_smul M _ b hb]
    rfl
  rw [hHint, hRint] at h
  have hmissing := price_missing_mass_bound μ M v hv' hnonloop B hB hopt b hb
  have hm := mul_le_mul_of_nonneg_left hmissing hs
  dsimp only [c] at h
  nlinarith

/-- Corollary 10, for the mean exclusion thresholds of the actual finite instance. -/
theorem finite_threshold_surplus (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value))
    (b : ℝ) (hb : 0 < b) (hb1 : b ≤ 1) (s : ℝ) (hs : 0 < s) :
    let μ := FiniteLaw.product laws
    let v := coordinateValues value
    let F := expectedOptimum μ M v
    1 - b + b / (b + s) * (deletionSurplus μ M v / F - (1 - b) -
      stableSurplus μ M v hnonloop / F - b * Real.exp (-s)) ≤
      thresholdSurplus μ v (meanThreshold μ M v hnonloop) b / F := by
  dsimp only
  let μ := FiniteLaw.product laws
  let v := coordinateValues value
  have hv' : ∀ w e, 0 ≤ v w e := fun w e => hv e (w e)
  have h := threshold_surplus_of_decomposition
    (expectedOptimum μ M v) (deletionSurplus μ M v) (stableSurplus μ M v hnonloop)
    (priceOptimum μ M v hnonloop) (priceGap μ M v hnonloop) (capDeficit μ M v hnonloop b)
    (thresholdSurplus μ v (contractionPrice μ M v hnonloop) b) (remainingCapSurplus μ M v hnonloop b)
    b s (Real.exp (-s)) hF hb hb1 hs (priceGap_nonneg μ M v hv' hnonloop)
    (capDeficit_nonneg μ M v hnonloop b hb.le) (Real.exp_pos _).le
    (optimum_contractionPrice_le_expectedOptimum μ M v hv' hnonloop)
    (price_surplus_lower μ M v hnonloop b) (deletion_surplus_split_at_prices μ M v hnonloop b)
    (finite_capped_surplus laws M value hv hnonloop b hb.le s hs.le)
  exact h.trans (div_le_div_of_nonneg_right
    (thresholdSurplus_antitone μ v (meanThreshold_le_contractionPrice μ M v hnonloop) b hb.le) hF.le)

end MatroidProphetSecretary
