import MatroidProphetSecretary.Algebra
import Mathlib.Algebra.Order.BigOperators.Ring.Finset

/-! Turning simultaneous mean accuracy into the threshold bounds (5.2) and (5.3). -/

noncomputable section

namespace MatroidProphetSecretary

def upperMeanEstimate (estimate ε V N : ℝ) : ℝ := (estimate + ε*V/N)/(1-ε)

theorem upperMeanEstimate_bounds (estimate mean ε V N : ℝ)
    (hε : ε < 1) (haccuracy : |estimate-mean| ≤ ε*mean + ε*V/N) :
    mean ≤ upperMeanEstimate estimate ε V N ∧
      upperMeanEstimate estimate ε V N ≤ (1+ε)/(1-ε)*mean + 2*ε*V/(N*(1-ε)) := by
  have hden : 0 < 1-ε := sub_pos.mpr hε
  obtain ⟨hl,hu⟩ := abs_le.mp haccuracy
  constructor
  · apply (le_div_iff₀ hden).mpr
    linarith
  · unfold upperMeanEstimate
    have hr : (1+ε)/(1-ε)*mean + 2*ε*V/(N*(1-ε)) =
        ((1+ε)*mean + 2*ε*V/N)/(1-ε) := by
      simp only [div_eq_mul_inv, mul_inv_rev]
      ring
    rw [hr, div_le_div_iff_of_pos_right hden]
    simp only [div_eq_mul_inv] at hu ⊢
    nlinarith

theorem threshold_estimate_bounds (estimate mean a ε V N : ℝ)
    (ha : 0 ≤ a) (hε : ε < 1) (haccuracy : |estimate-mean| ≤ ε*mean + ε*V/N) :
    a*mean ≤ a*upperMeanEstimate estimate ε V N ∧
      a*upperMeanEstimate estimate ε V N - (a*(1+ε)/(1-ε))*mean ≤
        2*a*ε*V/(N*(1-ε)) := by
  have h := upperMeanEstimate_bounds estimate mean ε V N hε haccuracy
  refine ⟨mul_le_mul_of_nonneg_left h.1 ha, ?_⟩
  have hh := mul_le_mul_of_nonneg_left h.2 ha
  calc
    _ ≤ a*((1+ε)/(1-ε)*mean + 2*ε*V/(N*(1-ε))) - (a*(1+ε)/(1-ε))*mean :=
      sub_le_sub_right hh _
    _ = _ := by simp only [div_eq_mul_inv, mul_inv_rev]; ring

theorem thresholdFactor_gap (a ε : ℝ) (ha0 : 0 ≤ a) (ha : a < 1-ε)
    (hε0 : 0 < ε) (hε1 : ε < 1) :
    0 ≤ a*(1+ε)/(1-ε) - a ∧ a*(1+ε)/(1-ε) - a < 2*ε := by
  have hd : 0 < 1-ε := sub_pos.mpr hε1
  have heq : a*(1+ε)/(1-ε) - a = 2*a*ε/(1-ε) := by field_simp; ring
  rw [heq]
  exact ⟨div_nonneg (by positivity) hd.le, (div_lt_iff₀ hd).mpr (by nlinarith)⟩

theorem threshold_estimate_total_excess {E : Type*} [Fintype E]
    (estimate mean : E → ℝ) (a ε V F : ℝ) (N : ℕ)
    (hN0 : 0 < N) (hN : Fintype.card E ≤ N) (ha0 : 0 ≤ a) (ha : a < 1-ε)
    (hε0 : 0 < ε) (hε1 : ε < 1) (hV : 0 < V) (hVF : V ≤ F)
    (haccuracy : ∀ e, |estimate e - mean e| ≤ ε*mean e + ε*V/N) :
    (∑ e, posPart (a*upperMeanEstimate (estimate e) ε V N -
      (a*(1+ε)/(1-ε))*mean e)) < 2*ε*F := by
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN0
  have hd : 0 < 1-ε := sub_pos.mpr hε1
  have hc : 0 ≤ 2*a*ε*V/((N:ℝ)*(1-ε)) := by positivity
  have hp (e : E) : posPart (a*upperMeanEstimate (estimate e) ε V N -
      (a*(1+ε)/(1-ε))*mean e) ≤ 2*a*ε*V/((N:ℝ)*(1-ε)) :=
    max_le (threshold_estimate_bounds (estimate e) (mean e) a ε V N ha0 hε1 (haccuracy e)).2 hc
  calc
    _ ≤ ∑ _ : E, 2*a*ε*V/((N:ℝ)*(1-ε)) := Finset.sum_le_sum (fun e _ => hp e)
    _ = (Fintype.card E : ℝ)*(2*a*ε*V/((N:ℝ)*(1-ε))) := by simp
    _ ≤ (N:ℝ)*(2*a*ε*V/((N:ℝ)*(1-ε))) :=
      mul_le_mul_of_nonneg_right (by exact_mod_cast hN) hc
    _ = 2*a*ε*V/(1-ε) := by field_simp; ring
    _ < 2*ε*V := (div_lt_iff₀ hd).mpr (by nlinarith [mul_pos hε0 hV])
    _ ≤ 2*ε*F := mul_le_mul_of_nonneg_left hVF (by positivity)

end MatroidProphetSecretary
