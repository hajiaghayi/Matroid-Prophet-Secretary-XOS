import MatroidProphetSecretary.AveragedRankBound
import MatroidProphetSecretary.CapMissingLayers
import MatroidProphetSecretary.CappedColoopLayers
import MatroidProphetSecretary.ValueMissingMass

/-! The capped-surplus inequality at each value layer of an independent finite prior. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

theorem capped_layer_bound_pos (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (c : E → ℝ)
    (B : Finset E) (hB : M.IsBase (B : Set E)) (hopt : optimum M c = weight c B)
    (z : ℝ) (hz : 0 < z) (s : ℝ) (hs : 0 ≤ s) :
    cappedColoopExpectation (FiniteLaw.product laws) M (coordinateValues value) c z ≤
      stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z +
        Real.exp (-s) * positiveRankLayer M c z +
        s * (FiniteLaw.product laws).expect (fun w => capMissingLayer M (coordinateValues value w) c B z) := by
  let p := coordinateTail laws value z
  let rho := fun e => otherNonspanProbability laws M value e z
  let T := valueLayer M c z
  let I := (B : Set E) ∩ T
  have hI : M.IsBasis I T := optimal_basis_inter_layer hB hopt z
  have h := restricted_nonspan_inequality M hground T I hI p
    (fun e => (laws e).prob_nonneg _) (fun e => (laws e).prob_le_one _) s hs
  dsimp only at h
  rw [← activityLaws_eq_bernoulli laws value z] at h
  simp only [activity_nonspan] at h
  have hTset : T.toFinset = Finset.univ.filter (fun e => z < c e) := by
    ext e
    simp [T, valueLayer, hground e]
  have hIset : I.toFinset = B.filter (fun e => z < c e) := by
    ext e
    simp [I, T, valueLayer, hground e, and_assoc]
  have hleft : cappedColoopExpectation (FiniteLaw.product laws) M (coordinateValues value) c z =
      ∑ e ∈ T.toFinset, p e * rho e := by
    unfold cappedColoopExpectation
    simp_rw [expected_coloop_eq_tail_nonspan laws M value _ (hground _) z,
      positiveTail_eq_coordinateTail laws value z hz]
    rw [hTset, sum_filter]
    apply sum_congr rfl
    intro e he
    by_cases hec : z < c e <;> simp [positiveLayer, hz, hec, p, rho]
  have hstable : stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z =
      ∑ e, (p e)^2 * rho e := by
    unfold stableLayerExpectation
    simp_rw [expected_coloop_eq_tail_nonspan laws M value _ (hground _) z,
      positiveTail_eq_coordinateTail laws value z hz]
    apply sum_congr rfl
    intro e he
    dsimp [p, rho]
    ring
  have hmissing : (FiniteLaw.product laws).expect (fun w =>
      capMissingLayer M (coordinateValues value w) c B z) =
      ∑ e ∈ I.toFinset, (1 - p e) * rho e := by
    unfold capMissingLayer
    rw [FiniteLaw.expect_finset_sum, hIset, sum_filter]
    simp_rw [FiniteLaw.expect_const_mul, expected_one_sub_closure laws M hground value z hz]
    apply sum_congr rfl
    intro e he
    by_cases hec : z < c e <;> simp [positiveLayer, hz, hec, p, rho]
  have hsq : (∑ e ∈ T.toFinset, (p e)^2 * rho e) ≤ ∑ e, (p e)^2 * rho e := by
    apply sum_le_sum_of_subset_of_nonneg (subset_univ _)
    intro e he hne
    exact mul_nonneg (sq_nonneg _) ((FiniteLaw.product laws).prob_nonneg _)
  rw [hleft, hstable, hmissing]
  simp only [positiveRankLayer, hz, if_true]
  dsimp only [T, realRank] at h
  dsimp only [T, rho] at hsq ⊢
  simp only [← Set.toFinite_toFinset] at h hsq ⊢
  simpa only [mul_comm] using h.trans (add_le_add_right (add_le_add_right hsq _) _)

theorem capped_layer_bound (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (c : E → ℝ)
    (B : Finset E) (hB : M.IsBase (B : Set E)) (hopt : optimum M c = weight c B)
    (z s : ℝ) (hs : 0 ≤ s) :
    cappedColoopExpectation (FiniteLaw.product laws) M (coordinateValues value) c z ≤
      stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z +
        Real.exp (-s) * positiveRankLayer M c z +
        s * (FiniteLaw.product laws).expect (fun w => capMissingLayer M (coordinateValues value w) c B z) := by
  by_cases hz : 0 < z
  · exact capped_layer_bound_pos laws M hground value c B hB hopt z hz s hs
  · simp [cappedColoopExpectation, stableLayerExpectation, capMissingLayer,
      positiveLayer, coloopLayer, positiveTailProbability, positiveRankLayer, hz,
      FiniteLaw.expect_const]

end MatroidProphetSecretary
