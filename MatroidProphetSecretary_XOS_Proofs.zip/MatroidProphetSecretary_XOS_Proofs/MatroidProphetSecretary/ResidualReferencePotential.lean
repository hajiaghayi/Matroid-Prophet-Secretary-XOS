import MatroidProphetSecretary.ResidualOptimumTransport
import MatroidProphetSecretary.ResidualValueLaw

/-! Child reference potentials use the actual untouched priors on the remaining labels. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def RationalPriors.remaining {n k : ℕ} (prior : RationalPriors (n+1) k) (e : Fin (n+1)) : RationalPriors n k where
  value i := prior.value (remainingLabel e i)
  value_nonneg i := prior.value_nonneg (remainingLabel e i)
  probability i := prior.probability (remainingLabel e i)
  probability_nonneg i := prior.probability_nonneg (remainingLabel e i)
  probability_sum i := prior.probability_sum (remainingLabel e i)

theorem reference_remaining_delete {n k : ℕ} (prior : RationalPriors (n+1) k)
    (M : Matroid (Fin (n+1))) (e : Fin (n+1)) (q : ℝ) :
    referenceExpectedOptimum (prior.remaining e).law (remainingDelete M e)
        (fun i v => ((prior.remaining e).value i v : ℝ)) q =
      (FiniteLaw.product (referenceInstanceLaws prior.law (fun i v => (prior.value i v : ℝ)) q)).expect
        (fun y => deletionValue M (coordinateValues (referenceInstanceValues (fun i v => (prior.value i v : ℝ))) y) e) := by
  let observed := fun i v => (prior.value i v : ℝ)
  let laws := referenceInstanceLaws prior.law observed q
  let values := coordinateValues (referenceInstanceValues observed)
  have hpoint (v : Option (Fin (Fintype.card (Fin k)))) (rest : Fin n → Option (Fin (Fintype.card (Fin k)))) :
      deletionValue M (values (joinArrivalValues e v rest)) e =
        optimum (remainingDelete M e) (fun i => referenceInstanceValues observed (remainingLabel e i) (rest i)) := by
    rw [← remainingDelete_optimum]
    apply congrArg (optimum (remainingDelete M e))
    funext i
    change referenceInstanceValues observed (remainingLabel e i) (joinArrivalValues e v rest (remainingLabel e i)) = _
    rw [joinArrivalValues_remaining]
  have h := first_arrival_value_decomposition laws e (fun y => deletionValue M (values y) e)
  simp_rw [hpoint,FiniteLaw.expect_const] at h
  exact h.symm

theorem reference_remaining_contract {n k : ℕ} (prior : RationalPriors (n+1) k)
    (M : Matroid (Fin (n+1))) (e : Fin (n+1)) (he : M.Indep ({e} : Set (Fin (n+1)))) (q : ℝ) :
    referenceExpectedOptimum (prior.remaining e).law (remainingContract M e)
        (fun i v => ((prior.remaining e).value i v : ℝ)) q =
      (FiniteLaw.product (referenceInstanceLaws prior.law (fun i v => (prior.value i v : ℝ)) q)).expect
        (fun y => contractionValue M (coordinateValues (referenceInstanceValues (fun i v => (prior.value i v : ℝ))) y) e he) := by
  let observed := fun i v => (prior.value i v : ℝ)
  let laws := referenceInstanceLaws prior.law observed q
  let values := coordinateValues (referenceInstanceValues observed)
  have hpoint (v : Option (Fin (Fintype.card (Fin k)))) (rest : Fin n → Option (Fin (Fintype.card (Fin k)))) :
      contractionValue M (values (joinArrivalValues e v rest)) e he =
        optimum (remainingContract M e) (fun i => referenceInstanceValues observed (remainingLabel e i) (rest i)) := by
    rw [← remainingContract_optimum M e he]
    apply congrArg (optimum (remainingContract M e))
    funext i
    change referenceInstanceValues observed (remainingLabel e i) (joinArrivalValues e v rest (remainingLabel e i)) = _
    rw [joinArrivalValues_remaining]
  have h := first_arrival_value_decomposition laws e (fun y => contractionValue M (values y) e he)
  simp_rw [hpoint,FiniteLaw.expect_const] at h
  exact h.symm

end MatroidProphetSecretary
