import MatroidProphetSecretary.PoissonIntegerTable

/-! An explicit coupling keeps Poisson counts unchanged below the truncation threshold. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def poissonBelowMass (T : ℕ) : ℝ := ∑ n : Fin (T+1), ProbabilityTheory.poissonPMFReal 2 n

theorem poissonBelowMass_pos (T : ℕ) : 0 < poissonBelowMass T := by
  exact sum_pos (fun n _ => ProbabilityTheory.poissonPMFReal_pos (by norm_num)) univ_nonempty

theorem poisson_tail_hasSum (T : ℕ) :
    HasSum (fun n : ℕ => if T < n then ProbabilityTheory.poissonPMFReal 2 n else 0) (1-poissonBelowMass T) := by
  let p := fun n => ProbabilityTheory.poissonPMFReal 2 n
  let head := fun n : ℕ => if n ≤ T then p n else 0
  have hh : HasSum head (∑ n ∈ range (T+1), head n) := hasSum_sum_of_ne_finset_zero (by
    intro n hn
    simp only [mem_range,not_lt] at hn
    simp [head,show ¬ n ≤ T by omega])
  have he : (∑ n ∈ range (T+1), head n) = poissonBelowMass T := by
    rw [poissonBelowMass,Fin.sum_univ_eq_sum_range]
    apply sum_congr rfl
    intro n hn
    simp only [head,if_pos (Nat.le_of_lt_succ (mem_range.mp hn))]
    rfl
  rw [he] at hh
  have hs := (ProbabilityTheory.poissonPMFRealSum 2).sub hh
  convert hs using 1
  funext n
  by_cases hn : n ≤ T
  · simp [head,hn,not_lt.mpr hn,p]
  · simp [head,hn,lt_of_not_ge hn,p]

def poissonTruncationJoint (T : ℕ) (z : ℕ) (n : Fin (T+1)) : ℝ :=
  if T < z then ProbabilityTheory.poissonPMFReal 2 z*(truncatedPoissonTwo T).mass n
  else if z = n.val then ProbabilityTheory.poissonPMFReal 2 z else 0

theorem poissonTruncationJoint_nonneg (T z : ℕ) (n : Fin (T+1)) :
    0 ≤ poissonTruncationJoint T z n := by
  unfold poissonTruncationJoint
  split_ifs
  · exact mul_nonneg ProbabilityTheory.poissonPMFReal_nonneg ((truncatedPoissonTwo T).nonneg n)
  · exact ProbabilityTheory.poissonPMFReal_nonneg
  · rfl

theorem poissonTruncationJoint_left (T z : ℕ) :
    (∑ n : Fin (T+1), poissonTruncationJoint T z n) = ProbabilityTheory.poissonPMFReal 2 z := by
  by_cases hz : T < z
  · simp only [poissonTruncationJoint,hz,if_true,← mul_sum,(truncatedPoissonTwo T).total,mul_one]
  · let j : Fin (T+1) := ⟨z,by omega⟩
    have he (n : Fin (T+1)) : z = n.val ↔ n = j := by
      constructor
      · intro h; exact Fin.ext h.symm
      · rintro rfl; rfl
    simp only [poissonTruncationJoint,hz,if_false,he]
    simp

theorem poissonTruncationJoint_split (T z : ℕ) (n : Fin (T+1)) :
    poissonTruncationJoint T z n =
      (if z = n.val then ProbabilityTheory.poissonPMFReal 2 n else 0) +
      (if T < z then ProbabilityTheory.poissonPMFReal 2 z else 0)*(truncatedPoissonTwo T).mass n := by
  by_cases hz : T < z
  · have hn : z ≠ n.val := by have h := n.isLt; omega
    simp [poissonTruncationJoint,hz,hn]
  · by_cases hn : z = n.val
    · subst z; simp [poissonTruncationJoint,hz]
    · simp [poissonTruncationJoint,hz,hn]

theorem poissonTruncationJoint_right (T : ℕ) (n : Fin (T+1)) :
    HasSum (fun z => poissonTruncationJoint T z n) ((truncatedPoissonTwo T).mass n) := by
  have h := (hasSum_ite_eq n.val (ProbabilityTheory.poissonPMFReal 2 n)).add
    ((poisson_tail_hasSum T).mul_right ((truncatedPoissonTwo T).mass n))
  have he : ProbabilityTheory.poissonPMFReal 2 n +
      (1-poissonBelowMass T)*(truncatedPoissonTwo T).mass n = (truncatedPoissonTwo T).mass n := by
    rw [truncatedPoissonTwo_conditional_mass]
    change _ + (1-poissonBelowMass T)*(_/poissonBelowMass T) = _/poissonBelowMass T
    field_simp [ne_of_gt (poissonBelowMass_pos T)]
    <;> ring
  rw [he] at h
  simpa only [← poissonTruncationJoint_split] using h

theorem poissonTruncationJoint_total (T : ℕ) :
    HasSum (fun z => ∑ n : Fin (T+1), poissonTruncationJoint T z n) 1 := by
  simpa only [poissonTruncationJoint_left] using ProbabilityTheory.poissonPMFRealSum 2

theorem poissonTruncationJoint_error (T : ℕ) :
    (∑' z : ℕ, ∑ n : Fin (T+1), if z ≠ n.val then poissonTruncationJoint T z n else 0) ≤ 4/(2:ℝ)^T := by
  have he (z : ℕ) : (∑ n : Fin (T+1), if z ≠ n.val then poissonTruncationJoint T z n else 0) =
      if T < z then ProbabilityTheory.poissonPMFReal 2 z else 0 := by
    by_cases hz : T < z
    · have hn (n : Fin (T+1)) : z ≠ n.val := by have h := n.isLt; omega
      simp [poissonTruncationJoint,hz,hn,← mul_sum,(truncatedPoissonTwo T).total]
    · simp only [poissonTruncationJoint,hz,if_false]
      apply sum_eq_zero
      intro n hn
      split_ifs <;> simp_all
  simp_rw [he]
  exact poisson_two_tail_bound T

end MatroidProphetSecretary
