import MatroidProphetSecretary.FirstActiveSampler
import MatroidProphetSecretary.FiniteMixtures

/-! The nonempty-layer sampler of Section 5.1 as a categorical draw followed by independent bits. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E J : Type*} [Fintype E] [LinearOrder E] [Fintype J]

def nonemptyLayerVolume (width : J → ℝ) (laws : J → E → FiniteLaw Bool) : ℝ :=
  ∑ j, width j * (FiniteLaw.product (laws j)).prob (fun x => ∃ e, x e = true)

def firstLayerWeight (width : J → ℝ) (laws : J → E → FiniteLaw Bool) (jb : J × E) : ℝ :=
  width jb.1 * (FiniteLaw.product (laws jb.1)).prob (firstActiveEvent jb.2)

theorem firstLayerWeight_sum (width : J → ℝ) (laws : J → E → FiniteLaw Bool) :
    (∑ jb, firstLayerWeight width laws jb) = nonemptyLayerVolume width laws := by
  rw [Fintype.sum_prod_type]
  simp only [firstLayerWeight, ← mul_sum, firstActive_probabilities_sum]
  rfl

theorem firstLayerWeight_nonneg (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (jb : J × E) : 0 ≤ firstLayerWeight width laws jb :=
  mul_nonneg (hw jb.1) ((FiniteLaw.product (laws jb.1)).prob_nonneg _)

theorem firstLayerWeight_formula (width : J → ℝ) (laws : J → E → FiniteLaw Bool) (j : J) (b : E) :
    firstLayerWeight width laws (j,b) = width j * (laws j b).mass true *
      ∏ i, if i < b then (laws j i).mass false else 1 := by
  rw [firstLayerWeight, firstActive_probability]
  ring

def nonemptyLayerSampler (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws) : FiniteLaw (J × (E → Bool)) :=
  (FiniteLaw.ofWeights (firstLayerWeight width laws) (firstLayerWeight_nonneg width laws hw)
    (by rw [firstLayerWeight_sum]; exact hV)).bind
    (fun jb => (FiniteLaw.product (laws jb.1)).map (fun x => (jb.1, firstActiveSample jb.2 x)))

theorem nonemptyLayerSampler_expect (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws)
    (f : J × (E → Bool) → ℝ) :
    nonemptyLayerVolume width laws * (nonemptyLayerSampler width laws hw hV).expect f =
      ∑ j, width j * (FiniteLaw.product (laws j)).expect
        (fun x => if ∃ e, x e = true then f (j,x) else 0) := by
  unfold nonemptyLayerSampler
  rw [FiniteLaw.bind_expect]
  simp_rw [FiniteLaw.map_expect]
  have h := FiniteLaw.ofWeights_expect (firstLayerWeight width laws)
    (firstLayerWeight_nonneg width laws hw) (by rw [firstLayerWeight_sum]; exact hV)
    (fun jb => (FiniteLaw.product (laws jb.1)).expect (fun x => f (jb.1, firstActiveSample jb.2 x)))
  simp only [firstLayerWeight_sum] at h
  rw [h, Fintype.sum_prod_type]
  apply sum_congr rfl
  intro j hj
  simp only [firstLayerWeight, mul_assoc, ← mul_sum]
  rw [firstActive_mixture_expect (laws j) (fun x => f (j,x))]

theorem nonemptyLayerSampler_mass (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws)
    (j : J) (x : E → Bool) :
    nonemptyLayerVolume width laws * (nonemptyLayerSampler width laws hw hV).mass (j,x) =
      if ∃ e, x e = true then width j * (FiniteLaw.product (laws j)).mass x else 0 := by
  have h := nonemptyLayerSampler_expect width laws hw hV (fun y => if y = (j,x) then 1 else 0)
  rw [← FiniteLaw.mass_eq_expect_indicator] at h
  have hterm (k : J) (y : E → Bool) :
      (if ∃ e, y e = true then if (k,y) = (j,x) then (1 : ℝ) else 0 else 0) =
        if k = j then if y = x then (if ∃ e, x e = true then 1 else 0) else 0 else 0 := by
    by_cases hk : k = j <;> by_cases hy : y = x <;> simp [hk, hy, Prod.mk.injEq]
  simp_rw [hterm] at h
  simpa [FiniteLaw.expect, mul_ite] using h

theorem nonemptyLayerSampler_support (width : J → ℝ) (laws : J → E → FiniteLaw Bool)
    (hw : ∀ j, 0 ≤ width j) (hV : 0 < nonemptyLayerVolume width laws)
    (j : J) (x : E → Bool) (hx : (nonemptyLayerSampler width laws hw hV).mass (j,x) ≠ 0) :
    ∃ e, x e = true := by
  by_contra hempty
  have h := nonemptyLayerSampler_mass width laws hw hV j x
  rw [if_neg hempty] at h
  exact hx ((mul_eq_zero.mp h).resolve_left hV.ne')

end MatroidProphetSecretary
