import MatroidProphetSecretary.FiniteRandomPolicy
import MatroidProphetSecretary.PolicyFeasibility

/-! A deterministic state machine is an online policy when its state is replayed from revealed observations. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {N : ℕ} {S : Type*}

def replayPolicyState (initial : S) (step : S → Fin N → ℝ → S × Bool) (history : List (Observation N)) : S :=
  history.foldl (fun state observation => (step state observation.label observation.value).1) initial

def replayedPolicy (initial : S) (step : S → Fin N → ℝ → S × Bool) : OnlinePolicy N 0 :=
  fun _ history e v => (step (replayPolicyState initial step history) e v).2

theorem replayPolicyState_append (initial : S) (step : S → Fin N → ℝ → S × Bool)
    (history : List (Observation N)) (observation : Observation N) :
    replayPolicyState initial step (history++[observation]) =
      (step (replayPolicyState initial step history) observation.label observation.value).1 := by
  simp [replayPolicyState,List.foldl_append]

theorem replayedPolicy_run_state (initial : S) (step : S → Fin N → ℝ → S × Bool)
    (seed : Fin (2^0)) (values : Fin N → ℝ) (order : List (Fin N)) (history : List (Observation N)) :
    replayPolicyState initial step (runPolicy (replayedPolicy initial step) seed values order history) =
      order.foldl (fun state e => (step state e (values e)).1) (replayPolicyState initial step history) := by
  induction order generalizing history with
  | nil => rfl
  | cons e rest ih =>
    simp only [runPolicy,List.foldl_cons,ih,replayPolicyState_append]

theorem replayedPolicy_run_invariant (initial : S) (step : S → Fin N → ℝ → S × Bool)
    (Good : S → Prop) (labels : S → Finset (Fin N))
    (hstep : ∀ state, Good state → ∀ e v, Good (step state e v).1 ∧
      labels (step state e v).1 = if (step state e v).2 = true then insert e (labels state) else labels state)
    (seed : Fin (2^0)) (values : Fin N → ℝ) (order : List (Fin N)) (history : List (Observation N))
    (hh : Good (replayPolicyState initial step history))
    (hl : acceptedSet history = labels (replayPolicyState initial step history)) :
    Good (replayPolicyState initial step (runPolicy (replayedPolicy initial step) seed values order history)) ∧
      acceptedSet (runPolicy (replayedPolicy initial step) seed values order history) =
        labels (replayPolicyState initial step (runPolicy (replayedPolicy initial step) seed values order history)) := by
  induction order generalizing history with
  | nil => exact ⟨hh,hl⟩
  | cons e rest ih =>
    have hs := hstep _ hh e (values e)
    apply ih
    · simpa only [replayPolicyState_append] using hs.1
    · rw [acceptedSet_append_observation,replayPolicyState_append,hs.2,hl]
      rfl

theorem replayedPolicy_feasible (M : Matroid (Fin N)) (initial : S) (step : S → Fin N → ℝ → S × Bool)
    (Good : S → Prop) (labels : S → Finset (Fin N)) (hinit : Good initial) (hempty : labels initial = ∅)
    (hstep : ∀ state, Good state → ∀ e v, Good (step state e v).1 ∧
      labels (step state e v).1 = if (step state e v).2 = true then insert e (labels state) else labels state)
    (hfeasible : ∀ state, Good state → M.Indep (labels state : Set (Fin N))) :
    PolicyFeasible M (replayedPolicy initial step) := by
  intro seed values order
  have hi : Good (replayPolicyState initial step []) := hinit
  have he : acceptedSet [] = labels (replayPolicyState initial step []) := by
    simpa [acceptedSet,replayPolicyState] using hempty.symm
  have h := replayedPolicy_run_invariant initial step Good labels hstep seed values
    ((List.finRange N).map order) [] hi he
  rw [completedHistory,h.2]
  exact hfeasible _ h.1

end MatroidProphetSecretary
