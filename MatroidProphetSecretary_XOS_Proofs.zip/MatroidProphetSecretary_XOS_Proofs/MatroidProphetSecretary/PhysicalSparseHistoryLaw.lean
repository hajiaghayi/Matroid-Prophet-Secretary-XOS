import MatroidProphetSecretary.PhysicalSparseReward

/-! The sparse round and the exchange kernel agree on every accepted-history observable. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open Finset
open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def eulerHistoryUpdate (clock : Fin L) (history : StampedHistory (Fin N) (Fin N → Option V))
    (event : Option (Fin N × (Fin N → Option V))) : StampedHistory (Fin N) (Fin N → Option V) :=
  updateGridHistory history (event.map (fun pair => (pair.1,(clock,pair.2))))

theorem historyKernel_history_loss (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (G : StampedHistory (Fin N) (Fin N → Option V) → ℝ) :
    (cfg.historyKernel n history).expect (fun mark => G history-G (updateGridHistory history mark)) =
      ((1/(L:ℝ))*cfg.historyRate history n)*(FiniteLaw.product cfg.reference).expect
        (fun y => if gridLabel N cfg.labels_pos n ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y
          then G history-G (eulerHistoryUpdate (gridClock N L cfg.clocks_pos n) history (some (gridLabel N cfg.labels_pos n,y)))
          else 0) := by
  by_cases hseen : gridLabel N cfg.labels_pos n ∈ recordLabels history
  · rw [cfg.historyKernel_seen n hn history hseen,FiniteLaw.pointMass_expect]
    have hvalid := cfg.reachable_history_valid M base hbase value hlive history n hn.le hp
    have hnot (y : Fin N → Option V) :
        gridLabel N cfg.labels_pos n ∉ virtualLive M base hbase value (recordReplay M base hbase value history) y := by
      intro hmem
      exact hvalid.fresh M base hbase value history _ y hmem hseen
    simp [hnot,updateGridHistory,appendOptional]
  · rw [cfg.historyKernel_expect_zero history n hn hp hseen _ (by simp [updateGridHistory,appendOptional])]
    simp only [hlive,eulerHistoryUpdate]
    congr 1

theorem physical_sparse_history_expect (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1)
    (hsingle : (1/(L:ℝ))*((1/cfg.q)/omega) < 1)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (clock.val*N) = history))
    (G : StampedHistory (Fin N) (Fin N → Option V) → ℝ) :
    (cfg.sparsePhysicalRound hsmall omega homega homega1 hlower (clock.val*N) history hbudget).expect
      (fun x => G (FiniteLaw.stateAfter updateGridHistory N history x)) =
    (cfg.eulerStep M base hbase value hsmall omega homega homega1 hlower hbudget history clock).expect
      (fun event => G (eulerHistoryUpdate clock history event)) := by
  rw [sparsePhysicalRound,FiniteLaw.sparseRound_terminal_expect_loss cfg.finiteHistoryKernel updateGridHistory
    (fun _ => rfl) ((1/(L:ℝ))*((1/cfg.q)/omega))
    (cfg.finiteHistoryKernel_acceptance_bound hsmall omega homega homega1 hlower) N (clock.val*N) history hbudget
    G,eulerStep,virtualStepLaw,FiniteLaw.optionalLaw_expect_loss]
  change G history-∑ e : Fin N, (cfg.finiteHistoryKernel (clock.val*N+e.val) history).expect
    (fun mark => G history-G (updateGridHistory history mark)) =
    G history-∑ event, virtualStepWeight (FiniteLaw.product cfg.reference) M base hbase value
      (recordReplay M base hbase value history) (1/(L:ℝ)) (cfg.eulerRate history clock) event*
      (G history-G (eulerHistoryUpdate clock history (some event)))
  congr 1
  rw [Fintype.sum_prod_type]
  apply sum_congr rfl
  intro e he
  have hn : clock.val*N+e.val < L*N := gridSlot_lt N L clock e
  have hpast := cfg.quiet_interval_reachable history (clock.val*N) e.val hn.le hp hsmall omega homega homega1 hlower hsingle
  simp only [finiteHistoryKernel,if_pos hn]
  rw [cfg.historyKernel_history_loss M base hbase value hlive history _ hn hpast G]
  have hlabel : gridLabel N cfg.labels_pos (clock.val*N+e.val) = e := gridLabel_slot N L cfg.labels_pos clock e
  have hclock : gridClock N L cfg.clocks_pos (clock.val*N+e.val) = clock := gridClock_slot N L cfg.clocks_pos clock e
  rw [hlabel,hclock]
  simp only [FiniteLaw.expect,mul_sum,eulerRate,gridSlot]
  apply sum_congr rfl
  intro y hy
  unfold virtualStepWeight
  dsimp only [eulerRate,gridSlot]
  split_ifs <;> ring

end MatroidProphetSecretary.PrivateGridConfig
