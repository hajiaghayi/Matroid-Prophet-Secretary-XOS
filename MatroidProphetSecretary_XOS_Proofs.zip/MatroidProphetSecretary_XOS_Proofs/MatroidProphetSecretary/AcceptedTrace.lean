import MatroidProphetSecretary.FiniteTraceLaw
import MatroidProphetSecretary.PhysicalRecordFeasibility

/-! The accepted records and the finite marked trace contain the same information. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def appendOptional {A : Type*} (history : List A) : Option A → List A
  | none => history
  | some a => history ++ [a]

theorem appendOptional_injective {A : Type*} (history : List A) : Function.Injective (appendOptional history) := by
  intro x y he
  cases x with
  | none =>
    cases y with
    | none => rfl
    | some y =>
      have hlen := congrArg List.length he
      simp [appendOptional] at hlen
  | some x =>
    cases y with
    | none =>
      have hlen := congrArg List.length he
      simp [appendOptional] at hlen
    | some y =>
      have h := List.append_cancel_left he
      simpa using h

theorem traceEvent_iff_scanPath {R W S : Type*} [Fintype R] [Fintype W]
    (trace : R → ℕ → W) (update : S → W → S) (s : S)
    (hinj : ∀ state, Function.Injective (update state)) (x : ℕ → W) (n : ℕ) (raw : R) :
    FiniteLaw.traceEvent trace x n raw ↔
      ∀ i ≤ n, FiniteLaw.scanState update s (trace raw) i = FiniteLaw.scanState update s x i := by
  constructor
  · intro h i hi
    induction i with
    | zero => rfl
    | succ i ih => rw [FiniteLaw.scanState,FiniteLaw.scanState,ih (by omega),h i (by omega)]
  · intro h i hi
    have he := h (i+1) (by omega)
    simp only [FiniteLaw.scanState] at he
    rw [h i hi.le] at he
    exact hinj _ he

abbrev GridMark (N L : ℕ) (V : Type*) := Fin N × (Fin L × (Fin N → Option V))

def gridMarkRecord {N L : ℕ} {V : Type*} (mark : GridMark N L V) : Fin N × (ℕ × (Fin N → Option V)) :=
  (mark.1,(gridSlot mark.2.1 mark.1,mark.2.2))

theorem gridMarkRecord_injective {N L : ℕ} {V : Type*} : Function.Injective (gridMarkRecord (N := N) (L := L) (V := V)) := by
  rintro ⟨e,c,y⟩ ⟨f,d,z⟩ he
  have hef : e = f := congrArg Prod.fst he
  have hyz : y = z := congrArg (fun r => r.2.2) he
  subst f
  subst z
  have hs : gridSlot c e = gridSlot d e := congrArg (fun r => r.2.1) he
  have hN : 0 < N := Nat.zero_lt_of_lt e.isLt
  have hc : c = d := by
    apply Fin.ext
    unfold gridSlot at hs
    exact Nat.eq_of_mul_eq_mul_right hN (Nat.add_right_cancel hs)
  subst d
  rfl

def updateGridHistory {N L : ℕ} {V : Type*} (history : StampedHistory (Fin N) (Fin N → Option V))
    (mark : Option (GridMark N L V)) : StampedHistory (Fin N) (Fin N → Option V) :=
  appendOptional history (mark.map gridMarkRecord)

theorem updateGridHistory_injective {N L : ℕ} {V : Type*}
    (history : StampedHistory (Fin N) (Fin N → Option V)) :
    Function.Injective (updateGridHistory (L := L) history) := by
  intro x y he
  have hm := appendOptional_injective history he
  exact Option.map_injective gridMarkRecord_injective hm

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def trace (tapes : Fin N → Fin L × GridPrivateTape N L V) (i : ℕ) : Option (GridMark N L V) :=
  if (tapes (gridLabel N cfg.labels_pos i)).1 = gridClock N L cfg.clocks_pos i then
    (cfg.decision i (cfg.run tapes i) (tapes (gridLabel N cfg.labels_pos i)).2).map
      (fun y => (gridLabel N cfg.labels_pos i,(gridClock N L cfg.clocks_pos i,y)))
  else none

theorem trace_update (tapes : Fin N → Fin L × GridPrivateTape N L V) (n : ℕ) (hn : n < L*N) :
    updateGridHistory (cfg.run tapes n) (cfg.trace tapes n) = cfg.run tapes (n+1) := by
  have hslot := gridSlot_clock_label N L cfg.labels_pos cfg.clocks_pos n hn
  change updateGridHistory (cfg.run tapes n) (cfg.trace tapes n) =
    markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision) n
      (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n))
  unfold trace markedStep stampDecision updateGridHistory
  split_ifs
  · cases hd : cfg.decision n (cfg.run tapes n) (tapes (gridLabel N cfg.labels_pos n)).2 <;>
      simp [appendOptional,gridMarkRecord,hslot]
  · rfl

theorem trace_scan (tapes : Fin N → Fin L × GridPrivateTape N L V) (n : ℕ) (hn : n ≤ L*N) :
    FiniteLaw.scanState updateGridHistory [] (cfg.trace tapes) n = cfg.run tapes n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [FiniteLaw.scanState,ih (by omega)]
    exact cfg.trace_update tapes n (by omega)

theorem trace_pathEvent_iff (x : ℕ → Option (GridMark N L V)) (n : ℕ) (hn : n ≤ L*N)
    (tapes : Fin N → Fin L × GridPrivateTape N L V) :
    FiniteLaw.traceEvent cfg.trace x n tapes ↔
      cfg.pathEvent (FiniteLaw.scanState updateGridHistory [] x) n tapes := by
  rw [traceEvent_iff_scanPath cfg.trace updateGridHistory [] updateGridHistory_injective x n tapes]
  unfold pathEvent privatePathEvent
  apply forall_congr'
  intro i
  apply forall_congr'
  intro hi
  rw [cfg.trace_scan tapes i (hi.trans hn)]
  rfl

end PrivateGridConfig
end MatroidProphetSecretary
