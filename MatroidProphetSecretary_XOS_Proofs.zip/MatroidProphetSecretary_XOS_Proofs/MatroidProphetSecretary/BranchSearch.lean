import MatroidProphetSecretary.FeedbackBisection
import MatroidProphetSecretary.BisectionStationarity

/-! Correctness of the two adaptive search branches, including the actual saved batch. -/

noncomputable section

namespace MatroidProphetSecretary

variable {B : Type*}

def positiveBranch (test : ℝ → B → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (n : ℕ) : SearchRecord B :=
  savedLowerRecord (feedbackAnswers test batches b) batches b initial n

def negativeBranch (test : ℝ → B → Bool) (batches : ℕ → B) (b : SearchBracket)
    (initial : SearchRecord B) (n : ℕ) : SearchRecord B :=
  savedUpperRecord (feedbackAnswers (fun q x => !(test q x)) batches b) batches b initial n

theorem positiveBranch_correct (test : ℝ → B → Bool) (batches : ℕ → B)
    (b : SearchBracket) (initial : SearchRecord B) (n : ℕ)
    (hb : b.lower ≤ b.upper) (hinitpoint : initial.point = b.lower)
    (C D g : ℝ → ℝ) (Good : SearchRecord B → Prop) (ε δ L : ℝ) (hε : 0 ≤ ε)
    (hupper : b.upper = 1+4*δ) (hinitgood : Good initial) (hinit : test initial.point initial.batch = true)
    (hcert : ∀ q ∈ Set.Icc b.lower b.upper, ∀ x, Good ⟨q,x⟩ →
      if test q x then 0 < C q else C q ≤ 15*ε)
    (hquery : ∀ i < n, Good ⟨(feedbackBracket test batches i b).midpoint,batches i⟩)
    (hCD : ∀ q ∈ Set.Icc b.lower b.upper, C q ≤ D q)
    (hLip : ∀ x ∈ Set.Icc b.lower b.upper, ∀ y ∈ Set.Icc b.lower b.upper, |C x-C y| ≤ L*|x-y|)
    (hpotential : ∀ q ∈ Set.Icc b.lower b.upper, 0 < C q → g b.lower ≤ g q)
    (hwidth : (feedbackBracket test batches n b).upper - (feedbackBracket test batches n b).lower < δ)
    (hloss : L*((feedbackBracket test batches n b).upper - (feedbackBracket test batches n b).lower) ≤ 4*ε) :
    let r := positiveBranch test batches b initial n
    Good r ∧ r.point ∈ Set.Icc b.lower b.upper ∧ g initial.point ≤ g r.point ∧
      (|r.point-1| < 3*δ → -20*ε ≤ D r.point ∧ C r.point ≤ 20*ε) := by
  dsimp only [positiveBranch]
  let answers := feedbackAnswers test batches b
  have hn := bisectionRun_nested answers n b hb
  have hstart : 0 < C b.lower := by
    have h := hcert initial.point (by simpa only [hinitpoint] using (show b.lower ∈ Set.Icc b.lower b.upper from ⟨le_rfl,hb⟩)) initial.batch hinitgood
    simp only [hinit,if_true] at h
    simpa only [hinitpoint] using h
  have hmid (i : ℕ) : (bisectionRun answers i b).midpoint ∈ Set.Icc b.lower b.upper := by
    have hh := bisectionRun_nested answers i b hb
    have hm := midpoint_mem_bracket _ hh.2.1
    exact ⟨hh.1.trans hm.1,hm.2.trans hh.2.2⟩
  have hgood (i : ℕ) (hi : i < n) : Good ⟨(bisectionRun answers i b).midpoint,batches i⟩ := by
    simpa only [feedbackBracket_eq_run] using hquery i hi
  have hc (i : ℕ) (hi : i < n) :
      if answers i then 0 < C (bisectionRun answers i b).midpoint
      else C (bisectionRun answers i b).midpoint ≤ 15*ε := by
    dsimp only [answers]
    rw [feedbackAnswers_eq_test]
    exact hcert _ (hmid i) _ (hgood i hi)
  have hs := bisection_positive_stationarity answers n b hb C D ε δ L hε hupper hstart hc hCD hLip
    (by simpa only [feedbackBracket_eq_run] using hwidth)
    (by simpa only [feedbackBracket_eq_run] using hloss)
  have hp := savedLowerRecord_point answers batches b initial hinitpoint n
  change Good (savedLowerRecord answers batches b initial n) ∧ _
  refine ⟨savedLowerRecord_property answers batches b initial Good hinitgood n (fun i hi _ => hgood i hi), ?_⟩
  change (savedLowerRecord answers batches b initial n).point ∈ _ ∧ _
  rw [hp,hinitpoint]
  refine ⟨⟨hn.1,hn.2.1.trans hn.2.2⟩,?_,?_⟩
  · apply bisectionRun_lower_preserves_potential answers n b hb g
    intro i hi hai
    apply hpotential _ (hmid i)
    simpa only [hai,if_true] using hc i hi
  · intro interior
    have hu := hs.2 interior
    constructor <;> linarith [hs.1]

theorem negativeBranch_correct (test : ℝ → B → Bool) (batches : ℕ → B)
    (b : SearchBracket) (initial : SearchRecord B) (n : ℕ)
    (hb : b.lower ≤ b.upper) (hinitpoint : initial.point = b.upper)
    (C D g : ℝ → ℝ) (Good : SearchRecord B → Prop) (ε δ L : ℝ) (hε : 0 ≤ ε)
    (hlower : b.lower = 1-4*δ) (hinitgood : Good initial) (hinit : test initial.point initial.batch = true)
    (hcert : ∀ q ∈ Set.Icc b.lower b.upper, ∀ x, Good ⟨q,x⟩ →
      if test q x then D q < 0 else -15*ε ≤ D q)
    (hquery : ∀ i < n, Good ⟨(feedbackBracket (fun q x => !(test q x)) batches i b).midpoint,batches i⟩)
    (hCD : ∀ q ∈ Set.Icc b.lower b.upper, C q ≤ D q)
    (hLip : ∀ x ∈ Set.Icc b.lower b.upper, ∀ y ∈ Set.Icc b.lower b.upper, |D x-D y| ≤ L*|x-y|)
    (hpotential : ∀ q ∈ Set.Icc b.lower b.upper, D q < 0 → g b.upper ≤ g q)
    (hwidth : (feedbackBracket (fun q x => !(test q x)) batches n b).upper -
      (feedbackBracket (fun q x => !(test q x)) batches n b).lower < δ)
    (hloss : L*((feedbackBracket (fun q x => !(test q x)) batches n b).upper -
      (feedbackBracket (fun q x => !(test q x)) batches n b).lower) ≤ 4*ε) :
    let r := negativeBranch test batches b initial n
    Good r ∧ r.point ∈ Set.Icc b.lower b.upper ∧ g initial.point ≤ g r.point ∧
      (|r.point-1| < 3*δ → -20*ε ≤ D r.point ∧ C r.point ≤ 20*ε) := by
  dsimp only [negativeBranch]
  let flipped := fun q x => !(test q x)
  let answers := feedbackAnswers flipped batches b
  have hn := bisectionRun_nested answers n b hb
  have hstart : D b.upper < 0 := by
    have h := hcert initial.point (by simpa only [hinitpoint] using (show b.upper ∈ Set.Icc b.lower b.upper from ⟨hb,le_rfl⟩)) initial.batch hinitgood
    simp only [hinit,if_true] at h
    simpa only [hinitpoint] using h
  have hmid (i : ℕ) : (bisectionRun answers i b).midpoint ∈ Set.Icc b.lower b.upper := by
    have hh := bisectionRun_nested answers i b hb
    have hm := midpoint_mem_bracket _ hh.2.1
    exact ⟨hh.1.trans hm.1,hm.2.trans hh.2.2⟩
  have hgood (i : ℕ) (hi : i < n) : Good ⟨(bisectionRun answers i b).midpoint,batches i⟩ := by
    simpa only [feedbackBracket_eq_run] using hquery i hi
  have hc (i : ℕ) (hi : i < n) :
      if answers i then -15*ε ≤ D (bisectionRun answers i b).midpoint
      else D (bisectionRun answers i b).midpoint < 0 := by
    have h := hcert _ (hmid i) _ (hgood i hi)
    have ha : answers i = !(test (bisectionRun answers i b).midpoint (batches i)) :=
      feedbackAnswers_eq_test flipped batches b i
    rw [ha]
    cases ht : test (bisectionRun answers i b).midpoint (batches i) <;>
      simp only [ht,Bool.not_false,Bool.not_true,Bool.false_eq_true,if_true,if_false] at h ⊢ <;> exact h
  have hs := bisection_negative_stationarity answers n b hb C D ε δ L hε hlower hstart hc hCD hLip
    (by simpa only [feedbackBracket_eq_run] using hwidth)
    (by simpa only [feedbackBracket_eq_run] using hloss)
  have hp := savedUpperRecord_point answers batches b initial hinitpoint n
  change Good (savedUpperRecord answers batches b initial n) ∧ _
  refine ⟨savedUpperRecord_property answers batches b initial Good hinitgood n (fun i hi _ => hgood i hi), ?_⟩
  change (savedUpperRecord answers batches b initial n).point ∈ _ ∧ _
  rw [hp,hinitpoint]
  refine ⟨⟨hn.1.trans hn.2.1,hn.2.2⟩,?_,?_⟩
  · apply bisectionRun_upper_preserves_potential answers n b hb g
    intro i hi hai
    apply hpotential _ (hmid i)
    simpa only [hai,Bool.false_eq_true,if_false] using hc i hi
  · intro interior
    have hl := hs.2 interior
    constructor <;> linarith [hs.1]

end MatroidProphetSecretary
