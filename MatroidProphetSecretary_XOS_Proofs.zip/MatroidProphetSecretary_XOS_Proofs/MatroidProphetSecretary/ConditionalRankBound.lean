import MatroidProphetSecretary.ConditionalMinor
import MatroidProphetSecretary.RankInequality

/-! Applying the rank inequality after conditioning on the outside active set. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

def conditionalMissing (M : Matroid E) (O T : Set E) (p : E → ℝ) (e : E) : ℝ :=
  bernoulliEval p (fun x => if e ∈ M.closure ((bitSet x ∩ T) ∪ O) then 0 else 1)

theorem conditionalMissing_nonneg (M : Matroid E) (O T : Set E) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (e : E) :
    0 ≤ conditionalMissing M O T p e := by
  unfold conditionalMissing
  rw [bernoulliEval_eq_expect p hp0 hp1]
  apply FiniteLaw.expect_nonneg
  intro x
  split_ifs <;> norm_num

theorem conditionalMinor_expected_marginal (M : Matroid E) (O T : Set E)
    (hT : T ⊆ M.E) (hd : Disjoint T O) (p : E → ℝ) (e : E) :
    bernoulliEval p (insertDifference e (rankObservable (conditionalMinor M O T))) =
      if e ∈ T then conditionalMissing M O T p e else 0 := by
  by_cases heT : e ∈ T
  · rw [if_pos heT]
    apply sum_congr rfl
    intro x hx
    congr 1
    rw [conditionalMinor_marginal M O T hT hd]
    by_cases hc : e ∈ M.closure ((bitSet x ∩ T) ∪ O) <;> simp [heT, hc]
  · rw [if_neg heT]
    unfold bernoulliEval
    simp_rw [conditionalMinor_marginal M O T hT hd, if_neg (not_and_of_not_left _ heT)]
    simp

theorem conditional_rank_missing_mass (M : Matroid E) (O T I : Set E)
    (hI : M.IsBasis I T) (hd : Disjoint T O) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (s : ℝ) (hs : 0 ≤ s) :
    (∑ e ∈ T.toFinset, p e * conditionalMissing M O T p e) ≤
      realRank M T * Real.exp (-s) + s * ∑ e ∈ I.toFinset, conditionalMissing M O T p e := by
  obtain ⟨C, hC, hCI⟩ := conditionalMinor_has_base_in M O T I hI hd
  have h := bernoulli_rank_missing_mass_general (conditionalMinor M O T) C hC p hp0 hp1 s hs
  simp_rw [conditionalMinor_expected_marginal M O T hI.subset_ground hd] at h
  have hleft : (∑ e, p e * (if e ∈ T then conditionalMissing M O T p e else 0)) =
      ∑ e ∈ T.toFinset, p e * conditionalMissing M O T p e := by
    simp only [mul_ite, mul_zero, ← sum_filter]
    apply sum_congr (by ext e; simp)
    intro e he
    rfl
  have hright : (∑ e ∈ C, if e ∈ T then conditionalMissing M O T p e else 0) =
      ∑ e ∈ C, conditionalMissing M O T p e := by
    apply sum_congr rfl
    intro e he
    exact if_pos (hI.subset (hCI he))
  rw [hleft, hright] at h
  have hsum : (∑ e ∈ C, conditionalMissing M O T p e) ≤
      ∑ e ∈ I.toFinset, conditionalMissing M O T p e := by
    apply sum_le_sum_of_subset_of_nonneg
    · intro e he
      exact Set.mem_toFinset.mpr (hCI he)
    · intro e he hne
      exact conditionalMissing_nonneg M O T p hp0 hp1 e
  have hrank := conditionalMinor_rank_le M O T hI.subset_ground
  exact h.trans (add_le_add
    (mul_le_mul_of_nonneg_right hrank (Real.exp_pos _).le)
    (mul_le_mul_of_nonneg_left hsum hs))

end MatroidProphetSecretary
