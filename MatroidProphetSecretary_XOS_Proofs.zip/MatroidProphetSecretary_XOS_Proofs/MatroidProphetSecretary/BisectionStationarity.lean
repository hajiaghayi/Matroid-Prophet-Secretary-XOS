import MatroidProphetSecretary.BisectionCertificates

/-! Endpoint provenance, continuity, and the guarded-region conclusion of bisection. -/

namespace MatroidProphetSecretary

theorem bisection_positive_stationarity (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket)
    (hb : b.lower ≤ b.upper) (C D : ℝ → ℝ) (ε δ L : ℝ) (hε : 0 ≤ ε)
    (hupper : b.upper = 1+4*δ)
    (hstart : 0 < C b.lower)
    (hquery : ∀ i < n, if answers i then 0 < C (bisectionRun answers i b).midpoint
      else C (bisectionRun answers i b).midpoint ≤ 15*ε)
    (hCD : ∀ q ∈ Set.Icc b.lower b.upper, C q ≤ D q)
    (hLip : ∀ x ∈ Set.Icc b.lower b.upper, ∀ y ∈ Set.Icc b.lower b.upper,
      |C x-C y| ≤ L*|x-y|)
    (hwidth : (bisectionRun answers n b).upper - (bisectionRun answers n b).lower < δ)
    (hloss : L*((bisectionRun answers n b).upper - (bisectionRun answers n b).lower) ≤ 4*ε) :
    0 < D (bisectionRun answers n b).lower ∧
      (|(bisectionRun answers n b).lower-1| < 3*δ →
        C (bisectionRun answers n b).lower ≤ 19*ε) := by
  have hn := bisectionRun_nested answers n b hb
  have hlo : (bisectionRun answers n b).lower ∈ Set.Icc b.lower b.upper :=
    ⟨hn.1,hn.2.1.trans hn.2.2⟩
  have hhi : (bisectionRun answers n b).upper ∈ Set.Icc b.lower b.upper :=
    ⟨hn.1.trans hn.2.1,hn.2.2⟩
  have hC : 0 < C (bisectionRun answers n b).lower :=
    bisectionRun_lower_property answers n b (fun q => 0 < C q) hstart (by
      intro i hi hai
      simpa only [hai, if_true] using hquery i hi)
  refine ⟨hC.trans_le (hCD _ hlo),?_⟩
  intro hinterior
  rcases bisectionRun_upper_provenance answers n b with h | ⟨i,hi,hai,hpoint⟩
  · rw [h,hupper] at hwidth
    have hx := (abs_lt.mp hinterior).2
    linarith
  · have hother : C (bisectionRun answers n b).upper ≤ 15*ε := by
      rw [hpoint]
      simpa only [hai, Bool.false_eq_true, if_false] using hquery i hi
    have h := hLip _ hlo _ hhi
    rw [abs_of_nonpos (sub_nonpos.mpr hn.2.1)] at h
    have h' := (abs_le.mp h).2
    linarith

theorem bisection_negative_stationarity (answers : ℕ → Bool) (n : ℕ) (b : SearchBracket)
    (hb : b.lower ≤ b.upper) (C D : ℝ → ℝ) (ε δ L : ℝ) (hε : 0 ≤ ε)
    (hlower : b.lower = 1-4*δ)
    (hstart : D b.upper < 0)
    (hquery : ∀ i < n, if answers i then -15*ε ≤ D (bisectionRun answers i b).midpoint
      else D (bisectionRun answers i b).midpoint < 0)
    (hCD : ∀ q ∈ Set.Icc b.lower b.upper, C q ≤ D q)
    (hLip : ∀ x ∈ Set.Icc b.lower b.upper, ∀ y ∈ Set.Icc b.lower b.upper,
      |D x-D y| ≤ L*|x-y|)
    (hwidth : (bisectionRun answers n b).upper - (bisectionRun answers n b).lower < δ)
    (hloss : L*((bisectionRun answers n b).upper - (bisectionRun answers n b).lower) ≤ 4*ε) :
    C (bisectionRun answers n b).upper < 0 ∧
      (|(bisectionRun answers n b).upper-1| < 3*δ →
        -19*ε ≤ D (bisectionRun answers n b).upper) := by
  have hn := bisectionRun_nested answers n b hb
  have hlo : (bisectionRun answers n b).lower ∈ Set.Icc b.lower b.upper :=
    ⟨hn.1,hn.2.1.trans hn.2.2⟩
  have hhi : (bisectionRun answers n b).upper ∈ Set.Icc b.lower b.upper :=
    ⟨hn.1.trans hn.2.1,hn.2.2⟩
  have hD : D (bisectionRun answers n b).upper < 0 :=
    bisectionRun_upper_property answers n b (fun q => D q < 0) hstart (by
      intro i hi hai
      simpa only [hai, Bool.false_eq_true, if_false] using hquery i hi)
  refine ⟨(hCD _ hhi).trans_lt hD,?_⟩
  intro hinterior
  rcases bisectionRun_lower_provenance answers n b with h | ⟨i,hi,hai,hpoint⟩
  · rw [h,hlower] at hwidth
    have hx := (abs_lt.mp hinterior).1
    linarith
  · have hother : -15*ε ≤ D (bisectionRun answers n b).lower := by
      rw [hpoint]
      simpa only [hai, if_true] using hquery i hi
    have h := hLip _ hlo _ hhi
    rw [abs_of_nonpos (sub_nonpos.mpr hn.2.1)] at h
    have h' := (abs_le.mp h).2
    linarith

end MatroidProphetSecretary
