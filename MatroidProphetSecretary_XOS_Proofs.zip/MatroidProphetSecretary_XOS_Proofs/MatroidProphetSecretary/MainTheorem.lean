import MatroidProphetSecretary.GeneralCompetitiveness

/-!
The mathematical competitiveness assertion of Theorem 1, with the numerical ratio expanded.

The policy uses only the arrival history and the current observation. Its accepted set is
independent for every value vector and every arrival permutation. Arrival order is uniform
and independent of the values through `orderAveragedReward`. The expected offline optimum
is finite by the integrability assumption. Runtime and encoding bounds are outside this theorem.
-/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory ProbabilityTheory

theorem matroid_prophet_secretary {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hind : iIndepFun X μ) (hv : ∀ ω e, 0 ≤ X e ω)
    (hint : Integrable (fun ω => optimum M (fun e => X e ω)) μ) :
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      Measurable (fun ω => orderAveragedReward policy (fun e => X e ω)) ∧
      Integrable (fun ω => orderAveragedReward policy (fun e => X e ω)) μ ∧
      (1-1/Real.exp 1+(1:ℝ)/10000000)*(∫ ω, optimum M (fun e => X e ω) ∂μ) ≤
        ∫ ω, orderAveragedReward policy (fun e => X e ω) ∂μ := by
  simpa only [targetRatio,epsilonZero] using
    matroid_prophet_secretary_competitive μ M X hX hind hv hint

end MatroidProphetSecretary
