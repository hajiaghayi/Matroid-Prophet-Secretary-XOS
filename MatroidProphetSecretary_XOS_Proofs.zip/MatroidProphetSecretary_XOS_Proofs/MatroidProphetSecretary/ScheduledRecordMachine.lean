import MatroidProphetSecretary.PhysicalArrivalCompression
import MatroidProphetSecretary.ObservedValueTapes
import MatroidProphetSecretary.EulerExposureGeometry
import MatroidProphetSecretary.ReplayedPolicy

/-! A private-clock state machine that consults only the current revealed value and the accepted-record replay. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

def nextScheduleBound (schedule : ClockSchedule N L) (j : ℕ) : ℕ :=
  if hj : j < N then (schedule.val.orderEmbOfFin schedule.property ⟨j,hj⟩).val*N else L*N

theorem scheduled_slot_before_next (schedule : ClockSchedule N L) (j : ℕ) (hj : j < N) (e : Fin N) :
    gridSlot (schedule.val.orderEmbOfFin schedule.property ⟨j,hj⟩) e < nextScheduleBound schedule (j+1) := by
  unfold nextScheduleBound
  split_ifs with hnext
  · have hc := (schedule.val.orderEmbOfFin schedule.property).strictMono
      (show (⟨j,hj⟩ : Fin N) < ⟨j+1,hnext⟩ from Nat.lt_succ_self j)
    have hm := Nat.mul_le_mul_right N (show (schedule.val.orderEmbOfFin schedule.property ⟨j,hj⟩).val+1 ≤
      (schedule.val.orderEmbOfFin schedule.property ⟨j+1,hnext⟩).val from hc)
    rw [Nat.add_mul,Nat.one_mul] at hm
    unfold gridSlot
    omega
  · exact gridSlot_lt N L _ e

theorem nextScheduleBound_step (schedule : ClockSchedule N L) (j : ℕ) :
    nextScheduleBound schedule j ≤ nextScheduleBound schedule (j+1) := by
  by_cases hj : j < N
  · have he : 0 < N := Nat.zero_lt_of_lt hj
    have h := scheduled_slot_before_next schedule j hj (⟨0,he⟩ : Fin N)
    simpa only [nextScheduleBound,dif_pos hj,gridSlot,Nat.add_zero] using h.le
  · simp [nextScheduleBound,hj,show ¬ j+1 < N by omega]

namespace PrivateGridConfig

variable (cfg : PrivateGridConfig N L V)

theorem arrivalDecision_live (clock : Fin L) (e : Fin N)
    (history : StampedHistory (Fin N) (Fin N → Option V))
    (hfix : recordsBefore (gridSlot clock e) history = history)
    (tape : GridPrivateTape N L V) (y : Fin N → Option V)
    (hd : cfg.decision (gridSlot clock e) history tape = some y) : cfg.live history e y := by
  have hd' : phasePrivateDecision cfg.cut (gridHistoryProfile cfg.live history e) clock tape = some y := by
    simpa only [decision,gridPrivateDecision,gridLabel_slot N L cfg.labels_pos,gridClock_slot N L cfg.clocks_pos] using hd
  have hy := (phasePrivateDecision_some cfg.cut (gridHistoryProfile cfg.live history e) clock tape y hd').2
  change cfg.live (recordsBefore (gridSlot clock e) history) e y at hy
  rwa [hfix] at hy

theorem arrivalUpdate_valid (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (clock : Fin L) (e : Fin N) (history : StampedHistory (Fin N) (Fin N → Option V))
    (hvalid : ValidExchangeRecords M base hbase value history)
    (hfix : recordsBefore (gridSlot clock e) history = history) (tape : GridPrivateTape N L V) :
    ValidExchangeRecords M base hbase value (cfg.arrivalUpdate clock e history tape) := by
  unfold arrivalUpdate
  cases hd : cfg.decision (gridSlot clock e) history tape with
  | none => exact hvalid
  | some y =>
    apply ValidExchangeRecords.snoc hvalid
    exact (hlive history e y).mp (cfg.arrivalDecision_live clock e history hfix tape y hd)

theorem arrivalUpdate_labels (clock : Fin L) (e : Fin N)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (tape : GridPrivateTape N L V) :
    recordLabels (cfg.arrivalUpdate clock e history tape) =
      if (cfg.decision (gridSlot clock e) history tape).isSome = true then insert e (recordLabels history) else recordLabels history := by
  unfold arrivalUpdate
  cases hd : cfg.decision (gridSlot clock e) history tape <;>
    simp [updateGridHistory,appendOptional,recordLabels,gridMarkRecord,Finset.insert_eq,Finset.union_comm]

theorem arrivalUpdate_bounded (clock : Fin L) (e : Fin N)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (tape : GridPrivateTape N L V)
    (bound : ℕ) (hh : recordsBefore bound history = history) (hb : gridSlot clock e < bound) :
    recordsBefore bound (cfg.arrivalUpdate clock e history tape) = cfg.arrivalUpdate clock e history tape := by
  unfold arrivalUpdate
  cases hd : cfg.decision (gridSlot clock e) history tape with
  | none => exact hh
  | some y =>
    change recordsBefore bound (history++[(e,(gridSlot clock e,y))]) = _
    simpa only [recordsBefore,List.filter_append,List.filter_cons,hb,decide_true,Bool.true_eq,if_true,List.filter_nil] using
      congrArg (fun records => records++[(e,(gridSlot clock e,y))]) hh

def scheduledPolicyStep (observed : Fin N → V → ℝ) (schedule : ClockSchedule N L)
    (tables : ValueTapeTables N L observed) (state : BlockState N V) (e : Fin N) (v : ℝ) : BlockState N V × Bool :=
  if hj : state.1 < N then
    let clock := schedule.val.orderEmbOfFin schedule.property ⟨state.1,hj⟩
    match readValueTape observed tables e v with
    | none => ((state.1+1,state.2),false)
    | some tape => ((state.1+1,cfg.arrivalUpdate clock e state.2 tape),
        (cfg.decision (gridSlot clock e) state.2 tape).isSome)
  else ((state.1+1,state.2),false)

def ScheduledStateGood (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (schedule : ClockSchedule N L) (state : BlockState N V) : Prop :=
  ValidExchangeRecords M base hbase value state.2 ∧ recordsBefore (nextScheduleBound schedule state.1) state.2 = state.2

theorem scheduledPolicyStep_good (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (observed : Fin N → V → ℝ) (schedule : ClockSchedule N L) (tables : ValueTapeTables N L observed)
    (state : BlockState N V) (hs : ScheduledStateGood M base hbase value schedule state) (e : Fin N) (v : ℝ) :
    ScheduledStateGood M base hbase value schedule (cfg.scheduledPolicyStep observed schedule tables state e v).1 ∧
      recordLabels (cfg.scheduledPolicyStep observed schedule tables state e v).1.2 =
        if (cfg.scheduledPolicyStep observed schedule tables state e v).2 = true then insert e (recordLabels state.2) else recordLabels state.2 := by
  have hnext := recordsBefore_self_mono state.2 (nextScheduleBound schedule state.1)
    (nextScheduleBound schedule (state.1+1)) (nextScheduleBound_step schedule state.1) hs.2
  unfold scheduledPolicyStep
  by_cases hj : state.1 < N
  · simp only [dif_pos hj]
    cases ht : readValueTape observed tables e v with
    | none => exact ⟨⟨hs.1,hnext⟩,rfl⟩
    | some tape =>
      let clock := schedule.val.orderEmbOfFin schedule.property ⟨state.1,hj⟩
      have hb : nextScheduleBound schedule state.1 ≤ gridSlot clock e := by
        simp only [nextScheduleBound,dif_pos hj,gridSlot,clock]
        omega
      have hfix := recordsBefore_self_mono state.2 _ _ hb hs.2
      exact ⟨⟨cfg.arrivalUpdate_valid M base hbase value hlive clock e state.2 hs.1 hfix tape,
        cfg.arrivalUpdate_bounded clock e state.2 tape _ hnext (scheduled_slot_before_next schedule state.1 hj e)⟩,
        cfg.arrivalUpdate_labels clock e state.2 tape⟩
  · simp only [dif_neg hj,Bool.false_eq_true,if_false]
    exact ⟨⟨hs.1,hnext⟩,True.intro⟩

def privateClockPolicy (observed : Fin N → V → ℝ) : FiniteRandomPolicy N (ClockSchedule N L × ValueTapeTables N L observed) :=
  fun seed history e v => replayedPolicy (0,[]) (cfg.scheduledPolicyStep observed seed.1 seed.2) 0 history e v

theorem privateClockPolicy_feasible (M : Matroid (Fin N)) (base : (Fin N → Option V) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (observed : Fin N → V → ℝ) (seed : ClockSchedule N L × ValueTapeTables N L observed) :
    PolicyFeasible M (fixedPolicy (cfg.privateClockPolicy observed) seed) := by
  apply replayedPolicy_feasible M (0,[]) (cfg.scheduledPolicyStep observed seed.1 seed.2)
    (ScheduledStateGood M base hbase value seed.1) (fun s => recordLabels s.2)
  · exact ⟨ValidExchangeRecords.nil,rfl⟩
  · rfl
  · exact cfg.scheduledPolicyStep_good M base hbase value hlive observed seed.1 seed.2
  · intro state hs
    exact hs.1.feasible (FiniteLaw.product cfg.reference) M base hbase value state.2

end PrivateGridConfig
end MatroidProphetSecretary
