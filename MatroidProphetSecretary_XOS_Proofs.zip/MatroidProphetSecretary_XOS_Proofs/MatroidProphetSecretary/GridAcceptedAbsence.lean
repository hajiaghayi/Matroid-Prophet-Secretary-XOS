import MatroidProphetSecretary.PrivateDecisionLocality
import MatroidProphetSecretary.FiniteAcceptedIntensity

/-! The full accepted-path conditioning event reduces to the single-label one-arrival event. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 512

theorem grid_past_absence_iff {N L : ℕ} {Ω A : Type*}
    (hN : 0 < N) (hL : 0 < L)
    (decision : ℕ → StampedHistory (Fin N) A → Ω → Option A)
    (path : ℕ → StampedHistory (Fin N) A) (n : ℕ) (hn : n < L*N)
    (D : Fin L → Ω → Option A)
    (hdecision : ∀ i < n, gridLabel N hN i = gridLabel N hN n → decision i (path i) = D (gridClock N L hL i))
    (x : Fin L × Ω) :
    pastMarkedAbsence (gridLabel N hN) (gridClock N L hL) (stampDecision decision) path n (gridLabel N hN n) x ↔
      FiniteLaw.oneArrivalAbsent (fun c => c.val < (gridClock N L hL n).val) D x := by
  constructor
  · intro h hbad
    let i := gridSlot x.1 (gridLabel N hN n)
    have hi : i < n := (grid_past_same_label hN hL n hn x.1).mpr hbad.1
    have he : gridLabel N hN i = gridLabel N hN n := gridLabel_slot N L hN _ _
    have hc : gridClock N L hL i = x.1 := gridClock_slot N L hL _ _
    apply h i hi he
    refine ⟨hc.symm,?_⟩
    simpa [stampDecision,hdecision i hi he,hc] using hbad.2
  · intro h i hi he ⟨hc,hd⟩
    have hslot : gridSlot (gridClock N L hL i) (gridLabel N hN n) = i := by
      rw [← he]
      exact gridSlot_clock_label N L hN hL i (hi.trans hn)
    have ht : (gridClock N L hL i).val < (gridClock N L hL n).val :=
      (grid_past_same_label hN hL n hn _).mp (by rw [hslot]; exact hi)
    apply h
    refine ⟨hc ▸ ht,?_⟩
    simpa [stampDecision,hdecision i hi he,← hc] using hd

theorem grid_private_past_absence_iff {N L : ℕ} {V : Type*} [Fintype V]
    (hN : 0 < N) (hL : 0 < L)
    (laws : Fin N → FiniteLaw (Fin L ×
      (V × (Fin L → (Fin L → Bool × (Fin N → Option V)) × Option (Fin N → Option V)))))
    (cut : ℕ) (live : StampedHistory (Fin N) (Fin N → Option V) → Fin N → (Fin N → Option V) → Prop)
    (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ) (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent (gridLabel N hN)
        (markedStep (gridLabel N hN) (gridClock N L hL) (stampDecision (gridPrivateDecision hN hL cut live))) [] path n))
    (x : Fin L × (V × (Fin L → (Fin L → Bool × (Fin N → Option V)) × Option (Fin N → Option V)))) :
    pastMarkedAbsence (gridLabel N hN) (gridClock N L hL)
      (stampDecision (gridPrivateDecision hN hL cut live)) path n (gridLabel N hN n) x ↔
      FiniteLaw.oneArrivalAbsent (fun c => c.val < (gridClock N L hL n).val)
        (phasePrivateDecision cut (gridHistoryProfile live (path n) (gridLabel N hN n))) x := by
  apply grid_past_absence_iff hN hL _ path n hn
  intro i hi he
  rw [gridPrivateDecision_on_path hN hL laws cut live path n hp i hi.le (hi.trans hn)]
  unfold gridPrivateDecision
  rw [he]

end MatroidProphetSecretary
