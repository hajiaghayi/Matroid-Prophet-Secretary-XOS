import MatroidProphetSecretary.SelectionMarginals
import MatroidProphetSecretary.IntegratedOverlap
import MatroidProphetSecretary.CappedColoopLayers

/-! Lemma 5: stable surplus and overlap for independent finite nonnegative priors. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E Ω : Type*} [Fintype E] [LinearOrder E] [Fintype Ω]

def deletionLayerExpectation (μ : FiniteLaw Ω) (M : Matroid E) (v : Ω → E → ℝ) (z : ℝ) : ℝ :=
  ∑ e, μ.expect (fun x => coloopLayer M (v x) e z)

theorem deletionLayerExpectation_integrable (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ x e, 0 ≤ v x e) : Integrable (deletionLayerExpectation μ M v) :=
  integrable_finset_sum univ (fun e _ => μ.integrable_expect _
    (fun x => coloopLayer_integrable M (v x) (hv x) e))

theorem stableLayerExpectation_bounds (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (z : ℝ) :
    0 ≤ stableLayerExpectation μ M v z ∧
      stableLayerExpectation μ M v z ≤ deletionLayerExpectation μ M v z := by
  have hp0 (e : E) : 0 ≤ positiveTailProbability μ v e z := by
    apply μ.expect_nonneg
    intro x
    unfold positiveLayer
    split_ifs <;> norm_num
  have hp1 (e : E) : positiveTailProbability μ v e z ≤ 1 := by
    have h := μ.expect_mono (fun x => show positiveLayer (v x e) z ≤ 1 by
      unfold positiveLayer
      split_ifs <;> norm_num)
    simpa only [FiniteLaw.expect_const] using h
  have hc0 (e : E) : 0 ≤ μ.expect (fun x => coloopLayer M (v x) e z) := by
    apply μ.expect_nonneg
    intro x
    unfold coloopLayer
    split_ifs <;> norm_num
  constructor
  · exact sum_nonneg (fun e _ => mul_nonneg (hp0 e) (hc0 e))
  · exact sum_le_sum (fun e _ => mul_le_of_le_one_left (hc0 e) (hp1 e))

variable {V : E → Type*} [∀ e, Fintype (V e)]

theorem stableLayer_le_marginal_product (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (z : ℝ) :
    stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z ≤
      ∑ e, orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) false e z *
        orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) true e z := by
  apply sum_le_sum
  intro e he
  rw [expected_coloop_eq_tail_nonspan laws M value e (hground e)]
  have h := selection_marginal_product laws M value z e
  nlinarith only [h]

theorem reverse_marginal_sq_sum_le (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (z : ℝ) :
    (∑ e, (orderedMarginal (FiniteLaw.product laws) M (coordinateValues value) true e z)^2) ≤
      (FiniteLaw.product laws).expect (fun x => positiveRankLayer M (coordinateValues value x) z) -
        deletionLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z +
        stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z := by
  rw [← orderedMarginal_sum (FiniteLaw.product laws) M hground (coordinateValues value) true z]
  unfold deletionLayerExpectation stableLayerExpectation
  rw [← sum_sub_distrib, ← sum_add_distrib]
  apply sum_le_sum
  intro e he
  rw [expected_coloop_eq_tail_nonspan laws M value e (hground e)]
  have h := selection_marginal_variance laws M value z e
  nlinarith only [h]

theorem finite_strong_overlap (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    (stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop)^2 ≤
      overlap (FiniteLaw.product laws) (coordinateValues value)
        (fun x => canonicalBasis M (coordinateValues value x)) *
      (expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) -
        deletionSurplus (FiniteLaw.product laws) M (coordinateValues value) +
        stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop) ∧
    overlap (FiniteLaw.product laws) (coordinateValues value)
        (fun x => canonicalBasis M (coordinateValues value x)) *
      (expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) -
        deletionSurplus (FiniteLaw.product laws) M (coordinateValues value) +
        stableSurplus (FiniteLaw.product laws) M (coordinateValues value) hnonloop) ≤
      expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) *
        overlap (FiniteLaw.product laws) (coordinateValues value)
          (fun x => canonicalBasis M (coordinateValues value x)) := by
  let μ := FiniteLaw.product laws
  let v := coordinateValues value
  have hground : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  have hv' : ∀ x e, 0 ≤ v x e := fun x e => hv e (x e)
  have h := integral_overlap_from_layer_bounds
    (orderedMarginal μ M v false) (orderedMarginal μ M v true)
    (fun z => μ.expect (fun x => positiveRankLayer M (v x) z))
    (deletionLayerExpectation μ M v) (stableLayerExpectation μ M v)
    (orderedMarginal_sq_integrable μ M hground v hv' false)
    (orderedMarginal_sq_integrable μ M hground v hv' true)
    (orderedMarginal_mul_integrable μ M hground v hv' false true)
    (μ.integrable_expect _ (fun x => positiveRankLayer_integrable M (v x) (hv' x)))
    (deletionLayerExpectation_integrable μ M v hv')
    (stableLayerExpectation_integrable μ M v hv')
    (fun z => (stableLayerExpectation_bounds μ M v z).1)
    (stableLayer_le_marginal_product laws M hground value)
    (reverse_marginal_sq_sum_le laws M hground value)
    (fun z => (stableLayerExpectation_bounds μ M v z).2)
  have hF : (∫ z, μ.expect (fun x => positiveRankLayer M (v x) z)) = expectedOptimum μ M v :=
    (expectedOptimum_eq_integral_expected_rank μ M v hv').symm
  have hD : (∫ z, deletionLayerExpectation μ M v z) = deletionSurplus μ M v :=
    (deletionSurplus_eq_integral_coloop_count μ M v hv').symm
  have hH : (∫ z, stableLayerExpectation μ M v z) = stableSurplus μ M v hnonloop :=
    (stableSurplus_eq_integral_tail_coloop μ M v hv' hnonloop).symm
  have hQ : (∫ z, ∑ e, (orderedMarginal μ M v false e z)^2) =
      overlap μ v (fun x => canonicalBasis M (v x)) := by
    simp only [orderedMarginal_forward μ M hground v, overlap]
  rwa [hF, hD, hH, hQ] at h

end MatroidProphetSecretary
