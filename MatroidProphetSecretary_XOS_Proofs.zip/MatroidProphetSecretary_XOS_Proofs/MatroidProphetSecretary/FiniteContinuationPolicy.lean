import MatroidProphetSecretary.ScheduledPolicyReward
import MatroidProphetSecretary.SortedPhysicalContinuation
import MatroidProphetSecretary.PolicyBitImplementation

/-! Proposition 11 for finite priors: the continuation is an online policy with a bounded fair-bit seed. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

local instance {N : ℕ} {V : Type*} [Fintype V] (observed : Fin N → V → ℝ) (e : Fin N) :
    DecidableEq (ObservedValue observed e) := fun a b => Classical.propDecidable (a = b)

theorem finite_continuation_policy {N k : ℕ} (hN : 0 < N) (prior : RationalPriors N k)
    (reference : Fin N → FiniteLaw (Option (Fin k)))
    (M : Matroid (Fin N)) (base : (Fin N → Option (Fin k)) → Finset (Fin N))
    (hbase : ∀ y, M.IsBase (base y : Set (Fin N))) (value : (Fin N → Option (Fin k)) → Fin N → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hzero : ∀ y e, y e = none → value y e = 0)
    (hvalue : ∀ y e v, y e = some v → value y e = (prior.value e v : ℝ))
    (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (hF : 0 < expectedOptimum (FiniteLaw.product reference) M value) {q c : ℝ}
    (hq : q ∈ interval) (hdom : ∀ e v, (reference e).mass (some v) ≤ q*(prior.law e).mass v)
    (hc : c < phi q (overlap (FiniteLaw.product reference) value base/expectedOptimum (FiniteLaw.product reference) M value)) :
    ∃ (K : ℕ) (policy : OnlinePolicy N K), PolicyFeasible M policy ∧
      c*expectedOptimum (FiniteLaw.product reference) M value < expectedPolicyReward prior policy := by
  let F := expectedOptimum (FiniteLaw.product reference) M value
  let d := (c+phi q (overlap (FiniteLaw.product reference) value base/F))/2
  have hcd : c < d := by dsimp [d,F]; linarith only [hc]
  have hd : d < phi q (overlap (FiniteLaw.product reference) value base/F) := by dsimp [d]; linarith only [hc]
  obtain ⟨L,cfg,hNL,hprior,href,hqeq,hlive,hgain⟩ :=
    exists_sorted_physical_continuation hN prior.law reference M base hbase value hv hzero hopt hF hq hdom hd
  let observed := fun e v => (prior.value e v : ℝ)
  let policy := cfg.privateClockPolicy observed
  let μ := cfg.clockSeedLaw hNL observed
  have hreward := cfg.sortedExpectedReward_policy hNL M prior hprior base hbase value hvalue hlive
  have hloss : 0 < (d-c)*F/2 := div_pos (mul_pos (sub_pos.mpr hcd) hF) (by norm_num)
  obtain ⟨K,implemented,hfeasible,himplemented⟩ := finite_random_policy_bit_implementation M prior policy μ
    (cfg.privateClockPolicy_feasible M base hbase value hlive observed) ((d-c)*F/2) hloss
  refine ⟨K,implemented,hfeasible,?_⟩
  change μ.expect (fun seed => expectedPolicyReward prior (fixedPolicy policy seed)) - (d-c)*F/2 ≤
    expectedPolicyReward prior implemented at himplemented
  change cfg.sortedExpectedReward hNL value = μ.expect (fun seed => expectedPolicyReward prior (fixedPolicy policy seed)) at hreward
  rw [← hreward] at himplemented
  change d*F < cfg.sortedExpectedReward hNL value at hgain
  change c*F < expectedPolicyReward prior implemented
  nlinarith only [himplemented,hgain,hloss]

end MatroidProphetSecretary
