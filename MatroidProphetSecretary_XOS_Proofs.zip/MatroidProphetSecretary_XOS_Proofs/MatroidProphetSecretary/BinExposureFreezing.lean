import MatroidProphetSecretary.PhysicalBinExposure

/-! The late-phase exposure statistic is a function of the accepted early history alone. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V]

theorem binEarlyExposure_bounds (μ : FiniteLaw (Fin N → Option V)) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ) (p : ℝ) (hp : 0 ≤ p) (cut : ℕ)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (e : Fin N) :
    0 ≤ binEarlyExposure μ M base hbase value p cut history e ∧
      binEarlyExposure μ M base hbase value p cut history e ≤ p*cut := by
  unfold binEarlyExposure
  constructor
  · exact mul_nonneg hp (sum_nonneg (fun _ _ => μ.prob_nonneg _))
  · apply mul_le_mul_of_nonneg_left _ hp
    calc
      _ ≤ ∑ _i ∈ range cut, (1:ℝ) := sum_le_sum (fun _ _ => μ.prob_le_one _)
      _ = _ := by simp

theorem binEarlyExposure_frozen (μ : FiniteLaw (Fin N → Option V)) (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ) (p : ℝ) (cut : ℕ)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (e : Fin N) :
    binEarlyExposure μ M base hbase value p cut (recordsBefore (cut*N) history) e =
      binEarlyExposure μ M base hbase value p cut history e := by
  unfold binEarlyExposure
  congr 1
  apply sum_congr rfl
  intro i hi
  rw [recordsBefore_nested _ _ _ (Nat.mul_le_mul_right N (mem_range.mp hi).le)]

namespace PrivateGridConfig

variable (cfg : PrivateGridConfig N L V)

theorem eulerRate_early (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L)
    (hclock : clock.val < cfg.cut) (e : Fin N) : cfg.eulerRate history clock e = 1/cfg.q := by
  simp only [eulerRate,historyRate,gridClock_slot N L cfg.clocks_pos clock e,if_pos hclock]

theorem bin_start_rate_lower (M : Matroid (Fin N))
    (base : (Fin N → Option V) → Finset (Fin N)) (hbase : ∀ y, M.IsBase (base y : Set (Fin N)))
    (value : (Fin N → Option V) → Fin N → ℝ)
    (hlive : ∀ history e y, cfg.live history e y ↔
      e ∈ virtualLive M base hbase value (recordReplay M base hbase value history) y)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (clock : Fin L)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes (clock.val*N) = history))
    (hcut : cfg.cut ≤ clock.val)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) < 1) (e : Fin N) :
    (1/cfg.q)*(1+binEarlyExposure (FiniteLaw.product cfg.reference) M base hbase value
      ((1/(L:ℝ))*(1/cfg.q)) cfg.cut history e-((1/(L:ℝ))*(1/cfg.q))) ≤
      cfg.eulerRate history clock e := by
  have hN : (1:ℝ) ≤ N := by exact_mod_cast cfg.labels_pos
  have hnonneg : 0 ≤ (1/(L:ℝ))*((1/cfg.q)/omega) :=
    mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)
  have hsingle : (1/(L:ℝ))*((1/cfg.q)/omega) < 1 := by nlinarith
  have hpast := cfg.quiet_interval_reachable history (clock.val*N) e.val (gridSlot_lt N L clock e).le
    hp hsmall omega homega homega1 hlower hsingle
  exact cfg.eulerRate_exposure_lower M base hbase value hlive history clock e hpast hcut hsmall omega homega hlower

end PrivateGridConfig
end MatroidProphetSecretary
