import MatroidProphetSecretary.Structural
import MatroidProphetSecretary.Parameters
import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Fintype.Perm
import Mathlib.Data.List.FinRange

/-!
An explicit online model. `FiniteCompetitiveness.lean` proves
`FiniteCompetitivenessClaim` in this model.
The target includes independent finite rational priors, a uniformly random
arrival permutation, a bounded fair-bit tape, and a policy that sees only
its tape, the past observations and decisions, and the current label/value.
-/

noncomputable section

namespace MatroidProphetSecretary

structure Observation (N : ℕ) where
  label : Fin N
  value : ℝ
  accepted : Bool

abbrev OnlinePolicy (N K : ℕ) :=
  Fin (2 ^ K) → List (Observation N) → Fin N → ℝ → Bool

def runPolicy {N K : ℕ} (policy : OnlinePolicy N K) (seed : Fin (2 ^ K))
    (values : Fin N → ℝ) : List (Fin N) → List (Observation N) → List (Observation N)
  | [], history => history
  | e :: rest, history =>
      let take := policy seed history e (values e)
      runPolicy policy seed values rest (history ++ [⟨e, values e, take⟩])

def acceptedSet {N : ℕ} (history : List (Observation N)) : Finset (Fin N) :=
  ((history.filter (fun x => x.accepted)).map (fun x => x.label)).toFinset

def completedHistory {N K : ℕ} (policy : OnlinePolicy N K) (seed : Fin (2 ^ K))
    (values : Fin N → ℝ) (order : Equiv.Perm (Fin N)) : List (Observation N) :=
  runPolicy policy seed values ((List.finRange N).map order) []

def PolicyFeasible {N K : ℕ} (M : Matroid (Fin N)) (policy : OnlinePolicy N K) : Prop :=
  ∀ seed values order, M.Indep (acceptedSet (completedHistory policy seed values order) : Set (Fin N))

structure RationalPriors (N k : ℕ) where
  value : Fin N → Fin k → ℚ
  value_nonneg : ∀ e v, 0 ≤ value e v
  probability : Fin N → Fin k → ℚ
  probability_nonneg : ∀ e v, 0 ≤ probability e v
  probability_sum : ∀ e, ∑ v, probability e v = 1

def RationalPriors.law {N k : ℕ} (prior : RationalPriors N k) (e : Fin N) : FiniteLaw (Fin k) where
  mass v := prior.probability e v
  nonneg v := by exact_mod_cast prior.probability_nonneg e v
  total := by exact_mod_cast prior.probability_sum e

def RationalPriors.realization {N k : ℕ} (prior : RationalPriors N k)
    (sample : Fin N → Fin k) (e : Fin N) : ℝ := prior.value e (sample e)

def expectedProphet {N k : ℕ} (M : Matroid (Fin N)) (prior : RationalPriors N k) : ℝ :=
  (FiniteLaw.product prior.law).expect (fun sample => optimum M (prior.realization sample))

def expectedPolicyReward {N k K : ℕ} (prior : RationalPriors N k)
    (policy : OnlinePolicy N K) : ℝ :=
  (FiniteLaw.product prior.law).expect (fun sample =>
    (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
      (FiniteLaw.uniform (Fin (2 ^ K))).expect (fun seed =>
        weight (prior.realization sample)
          (acceptedSet (completedHistory policy seed (prior.realization sample) order)))))

/-- The finite-prior competitiveness claim, proved in `FiniteCompetitiveness.lean`. -/
def FiniteCompetitivenessClaim : Prop :=
  ∀ (N k : ℕ), 0 < k → ∀ (M : Matroid (Fin N)) (prior : RationalPriors N k),
    ∃ (K : ℕ) (policy : OnlinePolicy N K),
      PolicyFeasible M policy ∧ targetRatio * expectedProphet M prior ≤ expectedPolicyReward prior policy

end MatroidProphetSecretary
