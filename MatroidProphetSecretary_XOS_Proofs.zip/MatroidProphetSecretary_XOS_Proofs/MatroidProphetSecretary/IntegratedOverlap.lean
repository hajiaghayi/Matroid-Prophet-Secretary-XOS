import MatroidProphetSecretary.FiniteIntegrals
import Mathlib.Algebra.QuadraticDiscriminant

/-! Cauchy--Schwarz for finite families of layer marginals, and its overlap consequence. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory

variable {E : Type*} [Fintype E]

theorem integral_sum_mul_sq_le (a b : E → ℝ → ℝ)
    (ha : ∀ e, Integrable (fun z => (a e z)^2))
    (hb : ∀ e, Integrable (fun z => (b e z)^2))
    (hab : ∀ e, Integrable (fun z => a e z * b e z)) :
    (∫ z, ∑ e, a e z * b e z)^2 ≤
      (∫ z, ∑ e, (a e z)^2) * (∫ z, ∑ e, (b e z)^2) := by
  have hA := integrable_finset_sum univ (fun e _ => ha e)
  have hB := integrable_finset_sum univ (fun e _ => hb e)
  have hC := integrable_finset_sum univ (fun e _ => hab e)
  have hpoly : ∀ t : ℝ, 0 ≤ (∫ z, ∑ e, (a e z)^2) * (t * t) +
      (-2 * (∫ z, ∑ e, a e z * b e z)) * t + (∫ z, ∑ e, (b e z)^2) := by
    intro t
    have h := integral_nonneg (μ := volume) (fun z : ℝ => sum_nonneg
      (fun e (_ : e ∈ (univ : Finset E)) => sq_nonneg (t * a e z - b e z)))
    have hid : (fun z => ∑ e, (t * a e z - b e z)^2) =
        (fun z => t^2 * (∑ e, (a e z)^2) - (2*t) * (∑ e, a e z * b e z) +
          ∑ e, (b e z)^2) := by
      funext z
      simp only [mul_sum, ← sum_sub_distrib, ← sum_add_distrib]
      apply sum_congr rfl
      intro e he
      ring
    have hsub := (hA.const_mul (t^2)).sub (hC.const_mul (2*t))
    simp only [Pi.sub_apply] at hsub
    rw [hid, integral_add (f := fun z => t^2 * (∑ e, (a e z)^2) - (2*t) * (∑ e, a e z * b e z))
      hsub hB, integral_sub (hA.const_mul (t^2)) (hC.const_mul (2*t)),
      integral_const_mul, integral_const_mul] at h
    nlinarith only [h]
  have hd := discrim_le_zero hpoly
  simp only [discrim] at hd
  nlinarith only [hd]

theorem integral_overlap_from_layer_bounds (a b : E → ℝ → ℝ) (f d h : ℝ → ℝ)
    (ha : ∀ e, Integrable (fun z => (a e z)^2))
    (hb : ∀ e, Integrable (fun z => (b e z)^2))
    (hab : ∀ e, Integrable (fun z => a e z * b e z))
    (hf : Integrable f) (hd : Integrable d) (hh : Integrable h)
    (hh0 : ∀ z, 0 ≤ h z)
    (hcross : ∀ z, h z ≤ ∑ e, a e z * b e z)
    (hvariance : ∀ z, (∑ e, (b e z)^2) ≤ f z - d z + h z)
    (hstable : ∀ z, h z ≤ d z) :
    (∫ z, h z)^2 ≤ (∫ z, ∑ e, (a e z)^2) * ((∫ z, f z) - (∫ z, d z) + (∫ z, h z)) ∧
      (∫ z, ∑ e, (a e z)^2) * ((∫ z, f z) - (∫ z, d z) + (∫ z, h z)) ≤
        (∫ z, f z) * (∫ z, ∑ e, (a e z)^2) := by
  have hA0 : 0 ≤ ∫ z, ∑ e, (a e z)^2 :=
    integral_nonneg (fun z => sum_nonneg (fun e _ => sq_nonneg _))
  have hH0 : 0 ≤ ∫ z, h z := integral_nonneg hh0
  have hHC := integral_mono hh (integrable_finset_sum univ (fun e _ => hab e)) hcross
  have hBF := integral_mono (integrable_finset_sum univ (fun e _ => hb e)) ((hf.sub hd).add hh) hvariance
  have hsub := hf.sub hd
  simp only [Pi.sub_apply] at hsub
  simp only [Pi.add_apply, Pi.sub_apply] at hBF
  rw [integral_add (f := fun z => f z - d z) hsub hh, integral_sub hf hd] at hBF
  have hHD := integral_mono hh hd hstable
  have hCS := integral_sum_mul_sq_le a b ha hb hab
  constructor
  · have hs : (∫ z, h z)^2 ≤ (∫ z, ∑ e, a e z * b e z)^2 := by
      nlinarith only [hH0, hHC]
    exact hs.trans (hCS.trans (mul_le_mul_of_nonneg_left hBF hA0))
  · have hm := mul_le_mul_of_nonneg_left (show
      (∫ z, f z) - (∫ z, d z) + (∫ z, h z) ≤ (∫ z, f z) by linarith only [hHD]) hA0
    simpa only [mul_comm] using hm

end MatroidProphetSecretary
