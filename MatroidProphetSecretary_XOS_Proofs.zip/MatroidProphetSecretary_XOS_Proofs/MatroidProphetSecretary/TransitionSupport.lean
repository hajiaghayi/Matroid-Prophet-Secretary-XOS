import MatroidProphetSecretary.SupportedAdaptiveDrift

/-! Equality of transition expectations also transfers their supported invariants. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {A B S : Type*} [Fintype A] [Fintype B]

theorem transition_support_transfer (μ : FiniteLaw A) (ν : FiniteLaw B)
    (f : A → S) (g : B → S) (Good : S → Prop)
    (hgood : ∀ x, μ.mass x ≠ 0 → Good (f x))
    (heq : ∀ F : S → ℝ, μ.expect (fun x => F (f x)) = ν.expect (fun y => F (g y)))
    (y : B) (hy : ν.mass y ≠ 0) : Good (g y) := by
  by_contra hbad
  have hzero : μ.expect (fun x => if Good (f x) then (0:ℝ) else 1) = 0 := by
    calc
      _ = μ.expect (fun _ => 0) := expect_congr_support μ (fun x hx => by simp [hgood x hx])
      _ = 0 := expect_const μ 0
  rw [heq (fun state => if Good state then (0:ℝ) else 1)] at hzero
  have hsingle : ν.mass y*(if Good (g y) then (0:ℝ) else 1) ≤
      ν.expect (fun x => if Good (g x) then (0:ℝ) else 1) := by
    apply single_le_sum _ (mem_univ y)
    intro x hx
    apply mul_nonneg (ν.nonneg x)
    split_ifs <;> norm_num
  simp only [if_neg hbad,mul_one,hzero] at hsingle
  exact hy (le_antisymm hsingle (ν.nonneg y))

end MatroidProphetSecretary.FiniteLaw
