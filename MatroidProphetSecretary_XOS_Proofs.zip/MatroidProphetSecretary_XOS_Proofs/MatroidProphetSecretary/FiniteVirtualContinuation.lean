import MatroidProphetSecretary.VirtualExposure

/-! An explicit two-phase finite virtual continuation and its complete expected reward bound.
Connecting this finite virtual law to the paper's physical-arrival algorithm is a separate obligation. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

structure FiniteContinuationConfig (N : ℕ) where
  earlyStep : ℝ
  lateStep : ℝ
  rate : ℝ
  omega : ℝ
  earlySteps : ℕ
  lateSteps : ℕ
  earlyStep_nonneg : 0 ≤ earlyStep
  lateStep_nonneg : 0 ≤ lateStep
  rate_nonneg : 0 ≤ rate
  omega_pos : 0 < omega
  early_decay : earlyStep*rate ≤ 1
  late_decay : lateStep*(rate/omega) ≤ 1
  early_mass : earlyStep*rate*N ≤ 1
  late_mass : lateStep*(rate/omega)*N ≤ 1
  exposure_budget : omega*(1+earlyStep*rate*earlySteps) ≤ 1

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

def continuationEarlyBatch (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M) : FiniteLaw (Option (E × W)) :=
  virtualStepLaw μ M base hbase value s cfg.earlyStep (fun _ => cfg.rate) cfg.rate
    cfg.earlyStep_nonneg cfg.rate_nonneg (fun _ => cfg.rate_nonneg) (fun _ => le_rfl) cfg.early_mass

def continuationMultiplier (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M)
    (x : Fin cfg.earlySteps → Option (E × W)) (e : E) : ℝ :=
  1+virtualEarlyExposure μ M base hbase value cfg.earlyStep cfg.rate cfg.earlySteps s x e

theorem continuationMultiplier_nonneg (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M)
    (x : Fin cfg.earlySteps → Option (E × W)) (e : E) :
    0 ≤ continuationMultiplier μ M base hbase value cfg s x e :=
  add_nonneg zero_le_one (virtualEarlyExposure_bounds μ M base hbase value cfg.earlyStep cfg.rate
    cfg.earlyStep_nonneg cfg.rate_nonneg cfg.earlySteps s x e).1

def continuationLateBatch (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M)
    (x : Fin cfg.earlySteps → Option (E × W)) (state : VirtualState M) : FiniteLaw (Option (E × W)) :=
  virtualStepLaw μ M base hbase value state cfg.lateStep
    (fun e => cfg.rate*continuationMultiplier μ M base hbase value cfg s x e) (cfg.rate/cfg.omega)
    cfg.lateStep_nonneg (div_nonneg cfg.rate_nonneg cfg.omega_pos.le)
    (fun e => mul_nonneg cfg.rate_nonneg (continuationMultiplier_nonneg μ M base hbase value cfg s x e))
    (fun e => virtual_exposure_rate_upper μ M base hbase value cfg.earlyStep cfg.rate cfg.omega
      cfg.earlyStep_nonneg cfg.rate_nonneg cfg.omega_pos cfg.earlySteps cfg.exposure_budget s x e)
    cfg.late_mass

def finiteContinuationLaw (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M) :
    FiniteLaw ((Fin cfg.earlySteps → Option (E × W)) × (Fin cfg.lateSteps → Option (E × W))) :=
  FiniteLaw.dependentPair
    (FiniteLaw.adaptiveBatches (continuationEarlyBatch μ M base hbase value cfg)
      (virtualUpdate M base hbase value) cfg.earlySteps s)
    (fun x => FiniteLaw.adaptiveBatches (continuationLateBatch μ M base hbase value cfg s x)
      (virtualUpdate M base hbase value) cfg.lateSteps
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x))

def finiteContinuationReward (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M)
    (x : (Fin cfg.earlySteps → Option (E × W)) × (Fin cfg.lateSteps → Option (E × W))) : ℝ :=
  FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value) cfg.earlySteps s x.1 +
  FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value) cfg.lateSteps
    (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x.1) x.2

def FiniteContinuationConfig.alpha {N : ℕ} (cfg : FiniteContinuationConfig N) : ℝ :=
  (1-cfg.earlyStep*cfg.rate)^cfg.earlySteps

def FiniteContinuationConfig.lateFactor {N : ℕ} (cfg : FiniteContinuationConfig N) : ℝ :=
  cfg.omega*(1-(1-cfg.lateStep*(cfg.rate/cfg.omega))^cfg.lateSteps)

theorem FiniteContinuationConfig.lateFactor_nonneg {N : ℕ} (cfg : FiniteContinuationConfig N) :
    0 ≤ cfg.lateFactor := by
  apply mul_nonneg cfg.omega_pos.le
  apply sub_nonneg.mpr
  exact pow_le_one₀ (sub_nonneg.mpr cfg.late_decay)
    (sub_le_self _ (mul_nonneg cfg.lateStep_nonneg (div_nonneg cfg.rate_nonneg cfg.omega_pos.le)))

theorem finite_virtual_continuation_reward (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (cfg : FiniteContinuationConfig (Fintype.card E)) (s : VirtualState M) :
    (1-cfg.alpha)*virtualTotalLiveValue μ M base hbase value s +
      cfg.lateFactor*(cfg.alpha*virtualTotalLiveValue μ M base hbase value s +
        cfg.alpha*(1-cfg.alpha)*virtualCurrentOverlap μ M base hbase value s) ≤
    (finiteContinuationLaw μ M base hbase value cfg s).expect (finiteContinuationReward M base hbase value cfg s) := by
  apply FiniteLaw.two_stage_reward_bound
    (FiniteLaw.adaptiveBatches (continuationEarlyBatch μ M base hbase value cfg)
      (virtualUpdate M base hbase value) cfg.earlySteps s)
    (fun x => FiniteLaw.adaptiveBatches (continuationLateBatch μ M base hbase value cfg s x)
      (virtualUpdate M base hbase value) cfg.lateSteps
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x))
    (FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value) cfg.earlySteps s)
    (fun x => FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value) cfg.lateSteps
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x))
    (fun x => virtualTotalLiveValue μ M base hbase value
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x))
    (virtualExposureValue μ M base hbase value cfg.earlyStep cfg.rate cfg.earlySteps s)
    _ _ _ _ cfg.lateFactor_nonneg
  · exact virtualProcess_early_reward μ M base hbase value hv cfg.earlyStep cfg.rate
      cfg.earlyStep_nonneg cfg.rate_nonneg cfg.early_decay cfg.early_mass cfg.earlySteps s
  · exact virtualProcess_total_value_persistence μ M base hbase value hv cfg.earlyStep cfg.rate
      cfg.earlyStep_nonneg cfg.rate_nonneg cfg.early_decay (fun _ _ => cfg.rate)
      (fun _ _ => cfg.rate_nonneg) (fun _ _ => le_rfl) cfg.early_mass cfg.earlySteps s
  · rw [virtualExposureValue_expect]
    exact virtualProcess_overlap_accumulation μ M base hbase value hv cfg.earlyStep cfg.rate
      cfg.earlyStep_nonneg cfg.rate_nonneg cfg.early_decay cfg.early_mass cfg.earlySteps s
  · intro x
    have h := virtualProcess_late_reward μ M base hbase value hv
      (continuationMultiplier μ M base hbase value cfg s x)
      (continuationMultiplier_nonneg μ M base hbase value cfg s x)
      cfg.lateStep cfg.rate cfg.omega cfg.lateStep_nonneg cfg.rate_nonneg cfg.omega_pos cfg.late_decay cfg.late_mass
      (fun _ e => cfg.rate*continuationMultiplier μ M base hbase value cfg s x e)
      (fun _ e => mul_nonneg cfg.rate_nonneg (continuationMultiplier_nonneg μ M base hbase value cfg s x e))
      (fun _ e => virtual_exposure_rate_upper μ M base hbase value cfg.earlyStep cfg.rate cfg.omega
        cfg.earlyStep_nonneg cfg.rate_nonneg cfg.omega_pos cfg.earlySteps cfg.exposure_budget s x e)
      (fun _ _ => le_rfl) cfg.lateSteps
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x)
    change cfg.lateFactor*virtualWeightedLiveValue μ M base hbase value
      (fun e => 1+virtualEarlyExposure μ M base hbase value cfg.earlyStep cfg.rate cfg.earlySteps s x e)
      (FiniteLaw.stateAfter (virtualUpdate M base hbase value) cfg.earlySteps s x) ≤ _ at h
    rw [virtual_exposure_weighted_value] at h
    exact h

end MatroidProphetSecretary
