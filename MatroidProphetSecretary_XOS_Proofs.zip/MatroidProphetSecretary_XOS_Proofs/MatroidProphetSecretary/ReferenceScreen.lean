import Mathlib.Data.Real.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace MatroidProphetSecretary

/-- Difference of adjacent scaled tails is a valid screened atom.
This proves the domination needed for Algorithm 1's first step. -/
theorem reference_atom_domination (q p r : ℝ) (hq : 0 ≤ q) (hpr : r ≤ p) :
    0 ≤ min 1 (q * p) - min 1 (q * r) ∧
    min 1 (q * p) - min 1 (q * r) ≤ q * (p - r) := by
  have hmul : q * r ≤ q * p := mul_le_mul_of_nonneg_left hpr hq
  constructor
  · exact sub_nonneg.mpr (min_le_min_left 1 hmul)
  · by_cases hp : q * p ≤ 1
    · have hr : q * r ≤ 1 := hmul.trans hp
      rw [min_eq_right hp, min_eq_right hr]
      nlinarith
    · have hp' : 1 ≤ q * p := le_of_not_ge hp
      rw [min_eq_left hp']
      by_cases hr : q * r ≤ 1
      · rw [min_eq_right hr]
        nlinarith
      · rw [min_eq_left (le_of_not_ge hr)]
        nlinarith

theorem reference_screen_probability (q mass referenceMass : ℝ)
    (hq : 0 < q) (hmass : 0 < mass)
    (hreference : 0 ≤ referenceMass) (hbound : referenceMass ≤ q * mass) :
    0 ≤ referenceMass / (q * mass) ∧ referenceMass / (q * mass) ≤ 1 := by
  constructor
  · exact div_nonneg hreference (mul_pos hq hmass).le
  · exact (div_le_one (mul_pos hq hmass)).mpr hbound

theorem screened_atom_identity (q mass referenceMass : ℝ)
    (hq : 0 < q) (hmass : 0 < mass) :
    mass * (referenceMass / (q * mass)) = (1 / q) * referenceMass := by
  field_simp
  <;> ring

end MatroidProphetSecretary
