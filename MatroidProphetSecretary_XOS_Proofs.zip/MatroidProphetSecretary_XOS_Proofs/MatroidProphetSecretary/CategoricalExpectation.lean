import MatroidProphetSecretary.CategoricalSupport

/-! The ordered categorical coupling bounds expected costs under actual uniform finite seeds. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

theorem finiteRandomVariableLaw_expect {Ω A : Type*} [MeasurableSpace Ω]
    [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → A) (hX : Measurable X) (f : A → ℝ) :
    (finiteRandomVariableLaw μ X hX).expect f = ∫ ω, f (X ω) ∂μ := by
  letI : IsProbabilityMeasure (μ.map X) := isProbabilityMeasure_map hX.aemeasurable
  rw [finiteRandomVariableLaw,FiniteLaw.ofMeasure_expect]
  exact integral_map hX.aemeasurable (measurable_of_countable f).aestronglyMeasurable

theorem finiteRandomVariable_integrable {Ω A : Type*} [MeasurableSpace Ω]
    [Fintype A] [MeasurableSpace A] [MeasurableSingletonClass A]
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Ω → A) (hX : Measurable X) (f : A → ℝ) :
    Integrable (fun ω => f (X ω)) μ := by
  letI : IsProbabilityMeasure (μ.map X) := isProbabilityMeasure_map hX.aemeasurable
  exact (Integrable.of_finite (f := f) (μ := μ.map X)).comp_aemeasurable hX.aemeasurable

def categoricalFinDraw {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) (u : ℝ) : Fin k :=
  ⟨categoricalDraw μ u,by
    have h := inverseCDF_le_length (categoricalBoundaries μ) u
    rw [categoricalBoundaries_length] at h
    change categoricalDraw μ u ≤ k-1 at h
    omega⟩

theorem categoricalFinDraw_measurable {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) :
    Measurable (categoricalFinDraw μ hk) := by
  let f : ℕ → Fin k := fun j => ⟨min j (k-1),lt_of_le_of_lt (min_le_right _ _) (by omega)⟩
  have hm := (measurable_of_countable f).comp (inverseCDF_measurable (categoricalBoundaries μ))
  convert hm using 1
  funext u
  apply Fin.ext
  have h := inverseCDF_le_length (categoricalBoundaries μ) u
  rw [categoricalBoundaries_length] at h
  exact (min_eq_left h).symm

theorem categoricalFinDraw_law {k : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k) :
    finiteRandomVariableLaw unitUniform (categoricalFinDraw μ hk) (categoricalFinDraw_measurable μ hk) = μ := by
  apply FiniteLaw.ext_mass
  funext i
  change (unitUniform.map (categoricalFinDraw μ hk)).real {i} = μ.mass i
  rw [measureReal_def,Measure.map_apply (categoricalFinDraw_measurable μ hk) (measurableSet_singleton i)]
  have he : categoricalFinDraw μ hk ⁻¹' {i} = {u | categoricalDraw μ u = i.val} := by
    ext u
    exact Fin.ext_iff
  rw [he]
  change ((volume.restrict (Set.Ico (0:ℝ) 1)) {u | categoricalDraw μ u = i.val}).toReal = μ.mass i
  rw [categoricalDraw_mass,ENNReal.toReal_ofReal (μ.nonneg i)]

theorem categorical_grid_expect_le {k G : ℕ} (μ : FiniteLaw (Fin k)) (hk : 0 < k)
    (hG : 0 < G) (f : Fin k → ℝ) (hf : Monotone f) :
    (@FiniteLaw.uniform (Fin G) _ ⟨⟨0,hG⟩⟩).expect
      (fun j => f (categoricalFinDraw μ hk ((j.val:ℝ)/G))) ≤ μ.expect f := by
  rw [← uniformGridIndex_finiteLaw G hG,finiteRandomVariableLaw_expect]
  conv_rhs => rw [← categoricalFinDraw_law μ hk,finiteRandomVariableLaw_expect]
  apply integral_mono_ae
    (finiteRandomVariable_integrable unitUniform (uniformGridIndex G hG) (uniformGridIndex_measurable G hG)
      (fun j : Fin G => f (categoricalFinDraw μ hk ((j.val:ℝ)/G))))
    (finiteRandomVariable_integrable unitUniform (categoricalFinDraw μ hk) (categoricalFinDraw_measurable μ hk) f)
  filter_upwards [ae_restrict_mem measurableSet_Ico] with u hu
  apply hf
  change categoricalDraw μ (((uniformGridIndex G hG u).val:ℝ)/G) ≤ categoricalDraw μ u
  rw [uniformGridIndex_down G hG u hu]
  exact (categorical_grid_coupling μ G hG).2 u hu.1

end MatroidProphetSecretary
