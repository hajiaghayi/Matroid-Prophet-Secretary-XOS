import MatroidProphetSecretary.FiniteKernelApproximation

/-! Total mass distance is twice the deficit of one probability law below another. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]

theorem massDistance_eq_shortfall (μ ν : FiniteLaw Ω) :
    massDistance μ ν = 2*∑ x, max (ν.mass x-μ.mass x) 0 := by
  have hp (x : Ω) : |μ.mass x-ν.mass x| = μ.mass x-ν.mass x+2*max (ν.mass x-μ.mass x) 0 := by
    rcases le_total (μ.mass x) (ν.mass x) with h | h
    · rw [abs_of_nonpos (sub_nonpos.mpr h),max_eq_left (sub_nonneg.mpr h)]; ring
    · rw [abs_of_nonneg (sub_nonneg.mpr h),max_eq_right (sub_nonpos.mpr h)]; ring
  unfold massDistance
  simp_rw [hp]
  rw [sum_add_distrib,sum_sub_distrib,μ.total,ν.total]
  simp [mul_sum]

theorem massDistance_le_shortfall_bound (μ ν : FiniteLaw Ω) (event : Ω → Prop)
    (err : ℝ) (herr : 0 ≤ err)
    (houtside : ∀ x, ¬ event x → ν.mass x ≤ μ.mass x)
    (hinside : ∀ x, event x → (1-err)*ν.mass x ≤ μ.mass x) :
    massDistance μ ν ≤ 2*err*ν.prob event := by
  rw [massDistance_eq_shortfall]
  have hp (x : Ω) : max (ν.mass x-μ.mass x) 0 ≤ err*ν.mass x*(if event x then 1 else 0) := by
    by_cases hx : event x
    · rw [if_pos hx,mul_one]
      apply max_le
      · nlinarith only [hinside x hx]
      · exact mul_nonneg herr (ν.nonneg x)
    · rw [if_neg hx,mul_zero,max_eq_right (sub_nonpos.mpr (houtside x hx))]
  have hsum := sum_le_sum (s := univ) (fun x _ => hp x)
  have he : (∑ x, err*ν.mass x*(if event x then 1 else 0)) = err*ν.prob event := by
    simp only [prob,expect,mul_sum,mul_assoc]
  rw [he] at hsum
  nlinarith only [hsum]

theorem map_mass_of_injective (μ : FiniteLaw Ω) (f : Ω → Ψ) (hf : Function.Injective f) (x : Ω) :
    (μ.map f).mass (f x) = μ.mass x := by
  unfold map
  simp only [hf.eq_iff]
  simp

theorem map_mass_eq_zero_of_not_range (μ : FiniteLaw Ω) (f : Ω → Ψ) (y : Ψ)
    (hy : y ∉ Set.range f) : (μ.map f).mass y = 0 := by
  have hne : ∀ x, f x ≠ y := fun x h => hy ⟨x,h⟩
  simp [map,hne]

end MatroidProphetSecretary.FiniteLaw
