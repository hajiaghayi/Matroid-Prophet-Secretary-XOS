import MatroidProphetSecretary.FiniteAcceptedIntensity
import MatroidProphetSecretary.ClockCollisions

/-! The conditional private tape of an absent label is exactly its law conditioned on past nonacceptance. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem FiniteLaw.conditionOrSelf_congr {Ω : Type*} [Fintype Ω] (μ : FiniteLaw Ω)
    (P Q : Ω → Prop) [DecidablePred P] [DecidablePred Q] (h : ∀ x, P x ↔ Q x) :
    μ.conditionOrSelf P = μ.conditionOrSelf Q := by
  have he : P = Q := funext (fun x => propext (h x))
  subst Q
  apply FiniteLaw.conditionOrSelf_irrel

theorem privatePath_start_of_positive {E Ω S : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]
    (laws : E → FiniteLaw Ω) (label : ℕ → E) (step : ℕ → S → Ω → S)
    (initial : S) (path : ℕ → S) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n)) :
    path 0 = initial := by
  obtain ⟨tapes,hpath⟩ := FiniteLaw.exists_of_prob_pos _ _ hp
  exact (hpath 0 (Nat.zero_le n)).symm

theorem privatePath_conditional_coordinate_law {E Ω S : Type*}
    [Fintype E] [DecidableEq E] [Fintype Ω]
    (laws : E → FiniteLaw Ω) (label : ℕ → E) (step : ℕ → S → Ω → S)
    (initial : S) (path : ℕ → S) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob (privatePathEvent label step initial path n)) (e : E) :
    ((FiniteLaw.product laws).conditionOrSelf (privatePathEvent label step initial path n)).map (fun x => x e) =
      (laws e).conditionOrSelf (privateCoordinateEvent label step path n e) := by
  apply FiniteLaw.ext_expect
  intro f
  rw [FiniteLaw.map_expect]
  rw [privatePath_conditional_expect laws label step initial path
    (privatePath_start_of_positive laws label step initial path n hp) n hp (fun x => f (x e))]
  exact FiniteLaw.product_expect_single_coordinate _ e f

theorem markedPath_absent_coordinate_law {E T Ω A : Type*}
    [Fintype E] [DecidableEq E] [Fintype T] [Fintype Ω]
    (laws : E → FiniteLaw (T × Ω)) (label : ℕ → E) (time : ℕ → T)
    (decision : ℕ → List (E × A) → Ω → Option A)
    (initial : List (E × A)) (path : ℕ → List (E × A)) (n : ℕ)
    (hp : 0 < (FiniteLaw.product laws).prob
      (privatePathEvent label (markedStep label time decision) initial path n))
    (e : E) (habsent : ∀ mark, (e,mark) ∉ path n) :
    ((FiniteLaw.product laws).conditionOrSelf
      (privatePathEvent label (markedStep label time decision) initial path n)).map (fun x => x e) =
      (laws e).conditionOrSelf (pastMarkedAbsence label time decision path n e) := by
  rw [privatePath_conditional_coordinate_law laws label (markedStep label time decision) initial path n hp e]
  apply FiniteLaw.conditionOrSelf_congr
  exact absent_coordinate_event_iff laws label time decision initial path n hp e habsent

end MatroidProphetSecretary
