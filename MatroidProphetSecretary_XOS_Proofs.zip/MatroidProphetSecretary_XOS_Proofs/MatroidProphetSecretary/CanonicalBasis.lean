import MatroidProphetSecretary.GreedyCharacterization

/-! A fixed value-and-label priority order and its canonical optimal basis. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

def priorityBefore (v : E → ℝ) (e f : E) : Prop := v e < v f ∨ v e = v f ∧ e < f

theorem priorityBefore_irrefl (v : E → ℝ) (e : E) : ¬ priorityBefore v e e := by
  simp [priorityBefore]

theorem priorityBefore_trans (v : E → ℝ) {e f g : E}
    (hef : priorityBefore v e f) (hfg : priorityBefore v f g) : priorityBefore v e g := by
  rcases hef with hef | ⟨hef, hef'⟩ <;> rcases hfg with hfg | ⟨hfg, hfg'⟩
  · exact Or.inl (hef.trans hfg)
  · exact Or.inl (hef.trans_eq hfg)
  · exact Or.inl (hef.trans_lt hfg)
  · exact Or.inr ⟨hef.trans hfg, hef'.trans hfg'⟩

theorem priorityBefore_trichotomy (v : E → ℝ) (e f : E) :
    priorityBefore v e f ∨ e = f ∨ priorityBefore v f e := by
  rcases lt_trichotomy (v e) (v f) with h | h | h
  · exact Or.inl (Or.inl h)
  · rcases lt_trichotomy e f with hef | hef | hef
    · exact Or.inl (Or.inr ⟨h, hef⟩)
    · exact Or.inr (Or.inl hef)
    · exact Or.inr (Or.inr (Or.inr ⟨h.symm, hef⟩))
  · exact Or.inr (Or.inr (Or.inl h))

def canonicalPriority (v : E → ℝ) (e : E) : ℝ :=
  ((univ.filter (fun f => priorityBefore v f e)).card : ℝ) + 1

theorem canonicalPriority_pos (v : E → ℝ) (e : E) : 0 < canonicalPriority v e := by
  unfold canonicalPriority
  positivity

theorem canonicalPriority_strict (v : E → ℝ) {e f : E} (hef : priorityBefore v e f) :
    canonicalPriority v e < canonicalPriority v f := by
  have hsub : univ.filter (fun g => priorityBefore v g e) ⊆
      univ.filter (fun g => priorityBefore v g f) := by
    intro g hg
    exact mem_filter.mpr ⟨mem_univ _, priorityBefore_trans v (mem_filter.mp hg).2 hef⟩
  have hne : univ.filter (fun g => priorityBefore v g e) ≠
      univ.filter (fun g => priorityBefore v g f) := by
    intro heq
    have hmem : e ∈ univ.filter (fun g => priorityBefore v g f) := mem_filter.mpr ⟨mem_univ _, hef⟩
    rw [← heq] at hmem
    exact priorityBefore_irrefl v e (mem_filter.mp hmem).2
  have hc := card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨hsub, hne⟩)
  unfold canonicalPriority
  exact add_lt_add_right (Nat.cast_lt.mpr hc) 1

theorem canonicalPriority_injective (v : E → ℝ) : Function.Injective (canonicalPriority v) := by
  intro e f heq
  rcases priorityBefore_trichotomy v e f with h | h | h
  · exact ((canonicalPriority_strict v h).ne heq).elim
  · exact h
  · exact ((canonicalPriority_strict v h).ne heq.symm).elim

theorem canonicalPriority_refines (v : E → ℝ) (e f : E)
    (h : canonicalPriority v e ≤ canonicalPriority v f) : v e ≤ v f := by
  by_contra hv
  have hh := canonicalPriority_strict v (Or.inl (lt_of_not_ge hv) : priorityBefore v f e)
  exact (not_lt_of_ge h) hh

theorem canonicalPriority_lt_iff (v : E → ℝ) (e f : E) :
    canonicalPriority v e < canonicalPriority v f ↔ priorityBefore v e f := by
  constructor
  · intro h
    rcases priorityBefore_trichotomy v e f with h' | rfl | h'
    · exact h'
    · exact (lt_irrefl _ h).elim
    · exact (lt_asymm h (canonicalPriority_strict v h')).elim
  · exact canonicalPriority_strict v

def canonicalBasis (M : Matroid E) (v : E → ℝ) : Finset E :=
  optimalBasis M (canonicalPriority v) (fun e => (canonicalPriority_pos v e).le)

theorem canonicalBasis_isBase (M : Matroid E) (v : E → ℝ) :
    M.IsBase (canonicalBasis M v : Set E) := optimalBasis_isBase M _ _

theorem canonicalBasis_weight (M : Matroid E) (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) :
    weight v (canonicalBasis M v) = optimum M v := by
  exact (priority_refinement_optimal hv (canonicalBasis_isBase M v)
    (optimalBasis_weight M (canonicalPriority v) _).symm (canonicalPriority_refines v)).symm

/-- Greedy membership in the fixed value-and-label order. -/
theorem canonicalBasis_mem_iff (M : Matroid E) (v : E → ℝ) (e : E) (he : e ∈ M.E) :
    e ∈ canonicalBasis M v ↔
      e ∉ M.closure {f | f ∈ M.E ∧ priorityBefore v e f} := by
  have h := optimal_basis_mem_iff_not_span_higher (canonicalBasis_isBase M v)
    (optimalBasis_weight M (canonicalPriority v) _).symm (canonicalPriority_injective v) e he
  simpa only [valueLayer, canonicalPriority_lt_iff] using h

end MatroidProphetSecretary
