import Mathlib.Data.List.Range

/-! Folding a state machine along consecutive indices advances its counter exactly once per input. -/

namespace MatroidProphetSecretary

theorem range_fold_counter {S : Type*} (step : ℕ × S → ℕ → ℕ × S) (update : ℕ → S → S)
    (hstep : ∀ j s, step (j,s) j = (j+1,update j s)) (initial : S) (n : ℕ) :
    (List.range n).foldl step (0,initial) = (n,(List.range n).foldl (fun s j => update j s) initial) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    rw [List.range_succ,List.foldl_append,List.foldl_append]
    simp only [List.foldl_cons,List.foldl_nil,ih,hstep]

end MatroidProphetSecretary
