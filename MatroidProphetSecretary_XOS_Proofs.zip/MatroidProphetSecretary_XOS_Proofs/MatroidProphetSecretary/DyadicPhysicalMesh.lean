import MatroidProphetSecretary.VirtualContinuationLimit

/-! Uniform clock grids aligned with the paper's dyadic switching time. -/

noncomputable section

namespace MatroidProphetSecretary

open Filter
open scoped Topology

def physicalMeshSize (n : ℕ) : ℕ := 2048*n
def physicalMeshCut (n : ℕ) : ℕ := 2047*n
def physicalMeshStep (lam : ℝ) (n : ℕ) : ℝ := (1/(physicalMeshSize n:ℝ))*lam
def physicalMeshAlpha (lam : ℝ) (n : ℕ) : ℝ := (1-physicalMeshStep lam n)^(physicalMeshCut n)
def physicalMeshSurvival (lam : ℝ) (n : ℕ) : ℝ := physicalMeshAlpha lam n-delta*lam
def physicalMeshLate (lam omega : ℝ) (n : ℕ) : ℝ :=
  omega*(1-(1-(1/(physicalMeshSize n:ℝ))*(lam/omega))^n)
def physicalMeshFactor (lam omega z : ℝ) (n : ℕ) : ℝ :=
  1-physicalMeshAlpha lam n+
    physicalMeshLate lam omega n*((1-physicalMeshStep lam n)*physicalMeshAlpha lam n+
      physicalMeshAlpha lam n*(1-physicalMeshAlpha lam n)*z)

theorem physicalMesh_remainder (n : ℕ) : physicalMeshSize n-physicalMeshCut n = n := by
  unfold physicalMeshSize physicalMeshCut
  omega

theorem physicalMesh_cut_le (n : ℕ) : physicalMeshCut n ≤ physicalMeshSize n := by
  unfold physicalMeshSize physicalMeshCut
  omega

theorem physicalMesh_step_eq (lam : ℝ) (n : ℕ) : physicalMeshStep lam n = (1/2048)/(n:ℝ)*lam := by
  simp only [physicalMeshStep,physicalMeshSize,Nat.cast_mul,Nat.cast_ofNat,mul_inv_rev,one_div]
  ring

theorem physicalMesh_step_tendsto (lam : ℝ) : Tendsto (physicalMeshStep lam) atTop (𝓝 0) := by
  convert (tendsto_const_div_atTop_nhds_zero_nat (1/2048)).mul_const lam using 1
  · funext n
    exact physicalMesh_step_eq lam n
  · ring

theorem physicalMesh_alpha_tendsto (lam : ℝ) :
    Tendsto (physicalMeshAlpha lam) atTop (𝓝 (Real.exp (-(1-delta)*lam))) := by
  have h := (mesh_decay_tendsto (1/2048) lam).pow 2047
  convert h using 1
  · funext n
    rw [physicalMeshAlpha,physicalMesh_step_eq,← pow_mul]
    congr 1
    unfold physicalMeshCut
    omega
  · rw [← Real.exp_nat_mul]
    congr 1
    norm_num [delta]
    ring

theorem physicalMesh_survival_eq (lam : ℝ) (n : ℕ) (hn : 0 < n) :
    physicalMeshSurvival lam n = (1-(1/(physicalMeshSize n:ℝ))*lam)^(physicalMeshCut n)-
      (physicalMeshSize n-physicalMeshCut n:ℕ)*((1/(physicalMeshSize n:ℝ))*lam) := by
  rw [physicalMesh_remainder]
  unfold physicalMeshSurvival physicalMeshAlpha physicalMeshStep
  congr 1
  have hn' : (n:ℝ) ≠ 0 := by exact_mod_cast hn.ne'
  simp only [physicalMeshSize,Nat.cast_mul,Nat.cast_ofNat,delta]
  field_simp
  <;> ring

theorem physicalMesh_survival_tendsto (lam : ℝ) :
    Tendsto (physicalMeshSurvival lam) atTop (𝓝 (Real.exp (-(1-delta)*lam)-delta*lam)) :=
  (physicalMesh_alpha_tendsto lam).sub_const (delta*lam)

theorem physicalMesh_late_tendsto (lam omega : ℝ) :
    Tendsto (physicalMeshLate lam omega) atTop (𝓝 (omega*(1-Real.exp (-delta*(lam/omega))))) := by
  have hone : Tendsto (fun _ : ℕ => (1:ℝ)) atTop (𝓝 1) := tendsto_const_nhds
  have h := (hone.sub (mesh_decay_tendsto (1/2048) (lam/omega))).const_mul omega
  convert h using 1
  · funext n
    unfold physicalMeshLate
    rw [← physicalMesh_step_eq]
    rfl

theorem physicalMesh_factor_tendsto (lam omega z : ℝ) :
    Tendsto (physicalMeshFactor lam omega z) atTop (𝓝 (limitingContinuationFactor (1-delta) delta lam omega z)) := by
  have ha := physicalMesh_alpha_tendsto lam
  have hp := physicalMesh_step_tendsto lam
  have hb := physicalMesh_late_tendsto lam omega
  have hone : Tendsto (fun _ : ℕ => (1:ℝ)) atTop (𝓝 1) := tendsto_const_nhds
  have h := (hone.sub ha).add
    (hb.mul (((hone.sub hp).mul ha).add ((ha.mul (hone.sub ha)).mul_const z)))
  convert h using 1
  unfold limitingContinuationFactor
  ring

theorem physicalMesh_error_tendsto (C : ℝ) :
    Tendsto (fun n : ℕ => C/(physicalMeshSize n:ℝ)) atTop (𝓝 0) := by
  convert tendsto_const_div_atTop_nhds_zero_nat (C/2048) using 1
  funext n
  simp only [physicalMeshSize,Nat.cast_mul,Nat.cast_ofNat,mul_inv_rev,div_eq_mul_inv]
  ring

theorem physicalMesh_factor_with_error_tendsto (lam omega z C : ℝ) :
    Tendsto (fun n => physicalMeshFactor lam omega z n-C/(physicalMeshSize n:ℝ)) atTop
      (𝓝 (limitingContinuationFactor (1-delta) delta lam omega z)) := by
  simpa only [sub_zero] using (physicalMesh_factor_tendsto lam omega z).sub (physicalMesh_error_tendsto C)

end MatroidProphetSecretary
