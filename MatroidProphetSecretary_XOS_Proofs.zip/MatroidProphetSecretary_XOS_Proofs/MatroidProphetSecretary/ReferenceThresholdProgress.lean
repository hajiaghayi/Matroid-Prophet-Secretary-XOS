import MatroidProphetSecretary.SavedThresholdStatistics
import MatroidProphetSecretary.AlignedReferenceStatistics
import MatroidProphetSecretary.LocalThresholdBounds
import MatroidProphetSecretary.ReferenceSurplusTransfer
import MatroidProphetSecretary.Problem
import MatroidProphetSecretary.FiniteOrderInstances

/-! The small-stability action with the saved batch pays the selected reference potential. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

theorem reference_threshold_epoch_progress {N k B : ℕ} (hN : 0 < N) (hB : 0 < B) (hNB : N ≤ B)
    (prior : RationalPriors N k) (M : Matroid (Fin N)) (hnonloop : ∀ e, M.Indep ({e} : Set (Fin N)))
    (G : ValueHeightGrid (referenceInstanceValues (fun e v => (prior.value e v : ℝ))))
    {q : ℝ} (hq : q ∈ interval) {m : ℕ} (x : Fin m → (Fin G.last × (Fin N → Bool)))
    (hF : 0 < referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)
    (hgood : ¬ samplerBatchBad (referenceInstanceLaws prior.law (fun e v => (prior.value e v : ℝ)) q)
      (referenceInstanceValues (fun e v => (prior.value e v : ℝ))) G M hnonloop B epsilon x)
    (hDlo : stationaryRatio q-20*epsilon ≤ referenceDeletion prior.law M (fun e v => (prior.value e v : ℝ)) q/
      referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q)
    (hDhi : referenceDeletion prior.law M (fun e v => (prior.value e v : ℝ)) q/
        referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ stationaryRatio q+
      referenceStable prior.law M (fun e v => (prior.value e v : ℝ)) hnonloop q/
        referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q+20*epsilon)
    (hH : referenceStable prior.law M (fun e v => (prior.value e v : ℝ)) hnonloop q/
      referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ hPlus) :
    letI : Nonempty (Fin N) := ⟨⟨0,hN⟩⟩
    discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤
      (FiniteLaw.uniform (Fin N)).expect (fun e => (prior.law e).expect (fun v =>
        thresholdEpochValue (FiniteLaw.product (alignedReferenceLaws prior.law (fun e v => (prior.value e v : ℝ)) q)) M
          (optionalCoordinateValues (fun e v => (prior.value e v : ℝ))) hnonloop (discount q)
          (referenceSavedThreshold prior.law (fun e v => (prior.value e v : ℝ)) G M q B x) e (prior.value e v))) := by
  letI : Nonempty (Fin N) := ⟨⟨0,hN⟩⟩
  let observed := fun e v => (prior.value e v : ℝ)
  let reference := alignedReferenceLaws prior.law observed q
  let value := optionalCoordinateValues observed
  let μ := FiniteLaw.product reference
  let mean := meanThreshold μ M value hnonloop
  let p := referenceSavedThreshold prior.law observed G M q B x
  have hobs (e : Fin N) (v : Fin k) : 0 ≤ observed e v := by
    change (0:ℝ) ≤ (prior.value e v:ℝ)
    exact_mod_cast prior.value_nonneg e v
  have hF' : 0 < expectedOptimum μ M value := by rw [aligned_reference_optimum]; exact hF
  have hDlo' : stationaryRatio q-20*epsilon ≤ deletionSurplus μ M value/expectedOptimum μ M value := by
    rw [aligned_reference_deletion,aligned_reference_optimum]
    exact hDlo
  have hDhi' : deletionSurplus μ M value/expectedOptimum μ M value ≤ stationaryRatio q+
      stableSurplus μ M value hnonloop/expectedOptimum μ M value+20*epsilon := by
    rw [aligned_reference_deletion,aligned_reference_optimum,aligned_reference_stable]
    exact hDhi
  have hH' : stableSurplus μ M value hnonloop/expectedOptimum μ M value ≤ hPlus := by
    rw [aligned_reference_stable,aligned_reference_optimum]
    exact hH
  have hsur := finite_small_stability_surplus reference M (fun e => optionalValue (observed e))
    (fun e v => by cases v with | none => exact le_rfl | some v => exact hobs e v) hnonloop hq hF' hDlo' hDhi' hH'
  have hbounds := referenceSavedThreshold_bounds prior.law observed hobs G M hnonloop hq B hB
    (by simpa only [Fintype.card_fin] using hNB) x
  rw [fin_order_decidableEq] at hbounds
  have hbounds := hbounds hF hgood
  have hmeans : mean = meanThreshold (FiniteLaw.product (referenceInstanceLaws prior.law observed q)) M
      (coordinateValues (referenceInstanceValues observed)) hnonloop := by
    funext e
    exact aligned_reference_mean prior.law M observed hnonloop q e
  have hprice (e : Fin N) : discount q*mean e ≤ p e := by rw [hmeans]; exact hbounds.1 e
  have hp (e : Fin N) : 0 ≤ p e :=
    (mul_nonneg (discount_pos hq).le (meanThreshold_nonneg μ M value hnonloop e)).trans (hprice e)
  have herr : (∑ e, posPart (p e-thresholdFactor q*mean e)) < 2*epsilon*expectedOptimum μ M value := by
    rw [hmeans,aligned_reference_optimum]
    exact hbounds.2
  have hvalues : value = (fun y e => referenceValue (observed e) (y e)) := by
    funext y e
    change optionalValue (observed e) (y e) = referenceValue (observed e) (y e)
    cases y e <;> rfl
  change thresholdFactor q*q*deletionSurplus μ M value+2*epsilon*expectedOptimum μ M value <
    thresholdSurplus μ value (meanThreshold μ M value hnonloop) (thresholdFactor q) at hsur
  rw [hvalues] at hsur
  have herr' := herr
  dsimp only [mean] at herr'
  rw [hvalues] at herr'
  have hpay := reference_threshold_surplus_pays prior.law reference observed M hnonloop q (discount q) (thresholdFactor q) epsilon p
    (q_pos hq) (by linarith [(threshold_factor_bounds hq).1]) hp
    (aligned_reference_atom_domination prior.law observed q (q_pos hq).le) hsur herr'
  rw [← hvalues] at hpay
  have hstep := threshold_epoch_expected_progress prior.law observed μ M value hnonloop (discount q) p hprice
  have hnonneg : 0 ≤ ((∑ e, (prior.law e).expect (fun v => posPart (observed e v-p e)))-
      discount q*deletionSurplus μ M value)/(Fintype.card (Fin N):ℝ) :=
    div_nonneg (sub_nonneg.mpr hpay.le) (Nat.cast_nonneg _)
  have hfinal := (le_add_of_nonneg_right hnonneg).trans hstep
  rw [aligned_reference_optimum] at hfinal
  exact hfinal

end MatroidProphetSecretary
