import MatroidProphetSecretary.LayerIntegral
import Mathlib.Data.Finset.Sort
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Basic

/-! Finite height partitions containing every atom value. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

structure HeightGrid {A : Type*} (v : A → ℝ) where
  last : ℕ
  level : ℕ → ℝ
  monotone : Monotone level
  zero : level 0 = 0
  contains : ∀ a, ∃ k ≤ last, level k = v a

variable {A : Type*} {v : A → ℝ}

theorem HeightGrid.nonneg (G : HeightGrid v) (k : ℕ) : 0 ≤ G.level k := by
  rw [← G.zero]
  exact G.monotone (Nat.zero_le k)

theorem HeightGrid.value_le_top (G : HeightGrid v) (a : A) : v a ≤ G.level G.last := by
  obtain ⟨k, hk, hv⟩ := G.contains a
  rw [← hv]
  exact G.monotone hk

theorem HeightGrid.width_nonneg (G : HeightGrid v) (k : ℕ) : 0 ≤ G.level (k+1) - G.level k :=
  sub_nonneg.mpr (G.monotone (Nat.le_succ k))

theorem HeightGrid.tail_constant (G : HeightGrid v) (a : A) (k : ℕ) (z : ℝ)
    (hz : z ∈ Set.Ioo (G.level k) (G.level (k+1))) : z < v a ↔ G.level k < v a := by
  obtain ⟨i, hi, hv⟩ := G.contains a
  rw [← hv]
  constructor
  · exact fun h => hz.1.trans h
  · intro h
    have hki : k < i := by
      by_contra hn
      exact (not_lt_of_ge (G.monotone (Nat.le_of_not_gt hn))) h
    exact hz.2.trans_le (G.monotone (Nat.succ_le_of_lt hki))

theorem HeightGrid.integral_eq_sum (G : HeightGrid v) (f : ℝ → ℝ) (hf : Integrable f)
    (c : ℕ → ℝ) (hzero : ∀ z, z ≤ 0 ∨ G.level G.last ≤ z → f z = 0)
    (hbin : ∀ k < G.last, ∀ z ∈ Set.Ioo (G.level k) (G.level (k+1)), f z = c k) :
    (∫ z, f z) = ∑ k ∈ range G.last, (G.level (k+1) - G.level k) * c k := by
  have hs : Function.support f ⊆ Set.Ioc (G.level 0) (G.level G.last) := by
    intro z hz
    rw [G.zero]
    constructor
    · by_contra hn
      exact hz (hzero z (Or.inl (le_of_not_gt hn)))
    · by_contra hn
      exact hz (hzero z (Or.inr (le_of_lt (lt_of_not_ge hn))))
  rw [← intervalIntegral.integral_eq_integral_of_support_subset hs,
    ← intervalIntegral.sum_integral_adjacent_intervals
      (a := G.level) (n := G.last) (fun k hk => hf.intervalIntegrable)]
  apply sum_congr rfl
  intro k hk
  rw [intervalIntegral.integral_of_le (G.monotone (Nat.le_succ k)), integral_Ioc_eq_integral_Ioo]
  rw [setIntegral_congr_fun measurableSet_Ioo (hbin k (mem_range.mp hk))]
  rw [setIntegral_const]
  simp [Real.volume_real_Ioo_of_le (G.monotone (Nat.le_succ k)), smul_eq_mul]

theorem heightGrid_exists [Fintype A] (v : A → ℝ) (hv : ∀ a, 0 ≤ v a) :
    Nonempty (HeightGrid v) := by
  let S : Finset ℝ := insert 0 (univ.image v)
  have hS : 0 < S.card := card_pos.mpr ⟨0, mem_insert_self _ _⟩
  let top := S.card - 1
  have ht : top < S.card := Nat.sub_lt hS (by decide)
  let idx (k : ℕ) : Fin S.card := ⟨min k top, lt_of_le_of_lt (min_le_right _ _) ht⟩
  let level (k : ℕ) : ℝ := S.orderEmbOfFin rfl (idx k)
  have hmono : Monotone level := by
    intro k l hkl
    apply (S.orderEmbOfFin rfl).monotone
    exact min_le_min_right top hkl
  have hlevmem (k : ℕ) : level k ∈ S := S.orderEmbOfFin_mem rfl (idx k)
  have hlevnonneg (k : ℕ) : 0 ≤ level k := by
    rcases mem_insert.mp (hlevmem k) with h | h
    · exact le_of_eq h.symm
    · obtain ⟨a, ha, hav⟩ := mem_image.mp h
      exact hav ▸ hv a
  have hcontains (y : ℝ) (hy : y ∈ S) : ∃ k ≤ top, level k = y := by
    let i := (S.orderIsoOfFin rfl).symm ⟨y,hy⟩
    have hi : i.val ≤ top := Nat.le_sub_one_of_lt i.isLt
    refine ⟨i.val, hi, ?_⟩
    have heq : idx i.val = i := Fin.ext (min_eq_left hi)
    simp only [level, heq, ← coe_orderIsoOfFin_apply, i, OrderIso.apply_symm_apply]
  have hzero : level 0 = 0 := by
    obtain ⟨k, hk, hzero⟩ := hcontains 0 (mem_insert_self _ _)
    exact le_antisymm (hzero ▸ hmono (Nat.zero_le k)) (hlevnonneg 0)
  refine ⟨⟨top, level, hmono, hzero, ?_⟩⟩
  intro a
  exact hcontains (v a) (mem_insert_of_mem (mem_image.mpr ⟨a, mem_univ _, rfl⟩))

end MatroidProphetSecretary
