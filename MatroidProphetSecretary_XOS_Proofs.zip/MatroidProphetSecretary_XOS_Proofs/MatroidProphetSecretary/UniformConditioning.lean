import MatroidProphetSecretary.ClockEncoding
import MatroidProphetSecretary.FiniteConditioning

/-! Conditioning a finite uniform law is exactly the uniform law on the satisfying subtype. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω] [Nonempty Ω]

theorem uniform_probability_card (P : Ω → Prop) :
    (uniform Ω).prob P = (Fintype.card {x // P x}:ℝ)/Fintype.card Ω := by
  simp only [prob,expect,uniform,← mul_sum]
  rw [← sum_filter]
  simp only [sum_const,nsmul_eq_mul,mul_one]
  rw [← Fintype.card_subtype P]
  ring

theorem uniform_condition_expect (P : Ω → Prop) [Nonempty {x // P x}] (f : Ω → ℝ) :
    ((uniform Ω).conditionOrSelf P).expect f = (uniform {x // P x}).expect (fun x => f x.val) := by
  have hΩ : (0:ℝ) < Fintype.card Ω := by exact_mod_cast Fintype.card_pos
  have hP : (0:ℝ) < Fintype.card {x // P x} := by exact_mod_cast Fintype.card_pos
  have hp : 0 < (uniform Ω).prob P := by rw [uniform_probability_card]; exact div_pos hP hΩ
  apply mul_left_cancel₀ hp.ne'
  rw [conditionOrSelf_weighted_expect,uniform_probability_card]
  have hs : (∑ x, if P x then f x else 0) = ∑ x : {x // P x}, f x.val := by
    rw [← sum_filter]
    exact sum_subtype _ (by simp) f
  simp only [expect,uniform,← mul_sum]
  rw [hs]
  field_simp
  <;> ring

theorem uniform_condition_subtype (P : Ω → Prop) [Nonempty {x // P x}] :
    (uniform Ω).conditionOrSelf P = (uniform {x // P x}).map Subtype.val := by
  apply ext_expect
  intro f
  rw [map_expect]
  exact uniform_condition_expect P f

end MatroidProphetSecretary.FiniteLaw
