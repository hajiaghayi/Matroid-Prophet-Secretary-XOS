import MatroidProphetSecretary.RankMarginals

/-! The deterministic rank inequality used to bound integrated missing mass. -/

noncomputable section

namespace MatroidProphetSecretary

open Set
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem indep_ncard_le_realRank {M : Matroid E} {I S : Set E}
    (hI : M.Indep I) (hIS : I ⊆ S) (hS : S ⊆ M.E) :
    (I.ncard : ℝ) ≤ realRank M S := by
  obtain ⟨J, hJ, hIJ⟩ := hI.subset_isBasis_of_subset hIS hS
  rw [realRank_eq_ncard hJ]
  exact_mod_cast Set.ncard_le_ncard hIJ

theorem indep_outside_basis_union {M : Matroid E} {B T J K : Set E}
    (hB : M.Indep B) (hBT : M.IsBasis (B ∩ T) T)
    (hJ : M.Indep J) (hJT : J ⊆ T) (hK : K ⊆ B \ T) : M.Indep (K ∪ J) := by
  have hKT : (M ／ T).Indep K := hBT.contract_indep_iff.mpr ⟨hB.subset
    (union_subset (hK.trans diff_subset) inter_subset_left),
    Set.disjoint_left.mpr (fun e heT heK => (hK heK).2 heT)⟩
  have hKJT : (M ／ J ／ T).Indep K := by
    rwa [Matroid.contract_contract, union_eq_self_of_subset_left hJT]
  exact (hJ.contract_indep_iff.mp hKJT.of_contract).2

theorem rank_ge_inter_add_outside_closure {M : Matroid E} {B T S : Set E}
    (hB : M.Indep B) (hBT : M.IsBasis (B ∩ T) T) (hS : S ⊆ M.E) :
    realRank M (S ∩ T) + (((B \ T) ∩ M.closure S).ncard : ℝ) ≤ realRank M S := by
  obtain ⟨J, hJ⟩ := M.exists_isBasis (S ∩ T) (inter_subset_left.trans hS)
  let K := (B \ T) ∩ M.closure S
  have hK : K ⊆ B \ T := inter_subset_left
  have hJKT : M.Indep (K ∪ J) := indep_outside_basis_union hB hBT hJ.indep
    (hJ.subset.trans inter_subset_right) hK
  have hss : K ∪ J ⊆ M.closure S := by
    apply union_subset inter_subset_right
    exact (hJ.subset.trans inter_subset_left).trans (M.subset_closure S hS)
  have hbound := indep_ncard_le_realRank hJKT hss (M.closure_subset_ground S)
  have hdj : Disjoint K J := Set.disjoint_left.mpr (fun e heK heJ =>
    (hK heK).2 (hJ.subset heJ).2)
  rw [realRank_closure, Set.ncard_union_eq hdj, Nat.cast_add, ← realRank_eq_ncard hJ] at hbound
  dsimp [K] at hbound
  linarith

/-- Equation (3.11), for actual finite matroid rank and closure. -/
theorem cap_rank_deficit {M : Matroid E} {B T S : Set E}
    (hB : M.Indep B) (hBT : M.IsBasis (B ∩ T) T) (hS : S ⊆ M.E) :
    realRank M T - ((B ∩ T ∩ M.closure S).ncard : ℝ) ≤
      realRank M T - realRank M (S ∩ T) + realRank M S - ((B ∩ M.closure S).ncard : ℝ) := by
  have hbound := rank_ge_inter_add_outside_closure hB hBT hS
  have hdj : Disjoint (B ∩ T ∩ M.closure S) ((B \ T) ∩ M.closure S) :=
    Set.disjoint_left.mpr (fun e he1 he2 => he2.1.2 he1.1.2)
  have hunion : (B ∩ T ∩ M.closure S) ∪ ((B \ T) ∩ M.closure S) = B ∩ M.closure S := by
    ext e
    simp only [mem_union, mem_inter_iff, mem_diff]
    tauto
  have hcard := Set.ncard_union_eq hdj
  rw [hunion] at hcard
  have hc : ((B ∩ M.closure S).ncard : ℝ) =
      ((B ∩ T ∩ M.closure S).ncard : ℝ) + (((B \ T) ∩ M.closure S).ncard : ℝ) := by
    exact_mod_cast hcard
  linarith

end MatroidProphetSecretary
