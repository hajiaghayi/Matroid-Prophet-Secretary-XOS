import MatroidProphetSecretary.StableLayers
import MatroidProphetSecretary.SurplusDecomposition
import MatroidProphetSecretary.FiniteIntegrals

/-! Layer formulas for the capped surplus and the stable-surplus integrand. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E Ω : Type*} [Fintype E] [DecidableEq E] [Fintype Ω]

def cappedColoopExpectation (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (c : E → ℝ) (z : ℝ) : ℝ :=
  ∑ e, μ.expect (fun w => coloopLayer M (v w) e z) * positiveLayer (c e) z

def stableLayerExpectation (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (z : ℝ) : ℝ :=
  ∑ e, positiveTailProbability μ v e z * μ.expect (fun w => coloopLayer M (v w) e z)

theorem cappedColoopExpectation_integrable (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (c : E → ℝ) (hv : ∀ w e, 0 ≤ v w e) (hc : ∀ e, 0 ≤ c e) :
    Integrable (cappedColoopExpectation μ M v c) := by
  apply integrable_finset_sum
  intro e he
  have h := μ.integrable_expect _
    (fun w => coloop_mul_positiveLayer_integrable M (v w) (hv w) e (c e) (hc e))
  simpa only [FiniteLaw.expect_mul_const] using h

theorem capped_surplus_eq_integral (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (c : E → ℝ) (hv : ∀ w e, 0 ≤ v w e) (hc : ∀ e, 0 ≤ c e)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    (∑ e, μ.expect (fun w => posPart (min (v w e) (c e) - exclusionThreshold M (v w) e (hnonloop e)))) =
      ∫ z, cappedColoopExpectation μ M v c z := by
  have hpoint (e : E) : Integrable (fun z => μ.expect (fun w =>
      coloopLayer M (v w) e z * positiveLayer (c e) z)) :=
    μ.integrable_expect _ (fun w => coloop_mul_positiveLayer_integrable M (v w) (hv w) e (c e) (hc e))
  unfold cappedColoopExpectation
  simp_rw [← μ.expect_mul_const]
  rw [integral_finset_sum univ (fun e _ => hpoint e)]
  apply sum_congr rfl
  intro e he
  rw [μ.integral_expect _ (fun w =>
    coloop_mul_positiveLayer_integrable M (v w) (hv w) e (c e) (hc e))]
  congr 1
  funext w
  exact stable_pair_eq_integral M (v w) (hv w) e (hnonloop e) (c e) (hc e)

theorem stableLayerExpectation_integrable (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e) : Integrable (stableLayerExpectation μ M v) := by
  apply integrable_finset_sum
  intro e he
  have h := expected_stableLayer_integrable μ M v hv e
  have heq (z : ℝ) :
      μ.expect (fun w => μ.expect (fun w' => coloopLayer M (v w) e z * positiveLayer (v w' e) z)) =
      positiveTailProbability μ v e z * μ.expect (fun w => coloopLayer M (v w) e z) := by
    simp_rw [μ.expect_const_mul]
    rw [μ.expect_mul_const]
    exact mul_comm _ _
  simpa only [heq] using h

theorem remainingCapSurplus_eq_integral (μ : FiniteLaw Ω) (M : Matroid E)
    (v : Ω → E → ℝ) (hv : ∀ w e, 0 ≤ v w e) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (b : ℝ) (hb : 0 ≤ b) :
    remainingCapSurplus μ M v hnonloop b = ∫ z, cappedColoopExpectation μ M v
      (fun e => b * contractionPrice μ M v hnonloop e) z :=
  capped_surplus_eq_integral μ M v _ hv
    (fun e => mul_nonneg hb (contractionPrice_nonneg μ M v hnonloop e)) hnonloop

end MatroidProphetSecretary
