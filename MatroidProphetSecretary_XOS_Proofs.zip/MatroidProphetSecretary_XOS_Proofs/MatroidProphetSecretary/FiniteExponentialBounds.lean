import MatroidProphetSecretary.ProductMoments
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Complex.ExponentialBounds

/-! Finite exponential-moment bounds used for the sampler's concentration guarantee. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem exp_mul_unit_interval_le_chord (t w : ℝ) (hw0 : 0 ≤ w) (hw1 : w ≤ 1) :
    Real.exp (t*w) ≤ 1 + w * (Real.exp t - 1) := by
  have h := convexOn_exp.2 (Set.mem_univ 0) (Set.mem_univ t)
    (sub_nonneg.mpr hw1) hw0 (show 1-w+w=1 by ring)
  simp only [smul_eq_mul, mul_zero, zero_add, Real.exp_zero, mul_one] at h
  rw [mul_comm w t] at h
  nlinarith

namespace FiniteLaw

variable {Ω : Type*} [Fintype Ω]

theorem prob_le_exp_moment (μ : FiniteLaw Ω) (f : Ω → ℝ) (a : ℝ) :
    μ.prob (fun x => a ≤ f x) ≤ Real.exp (-a) * μ.expect (fun x => Real.exp (f x)) := by
  have hp (x : Ω) : (if a ≤ f x then (1 : ℝ) else 0) ≤ Real.exp (-a) * Real.exp (f x) := by
    rw [← Real.exp_add]
    by_cases hx : a ≤ f x
    · rw [if_pos hx]
      simpa using Real.exp_le_exp.mpr (show 0 ≤ -a+f x by linarith)
    · simp [hx, Real.exp_nonneg]
  have h := μ.expect_mono hp
  rw [μ.expect_const_mul] at h
  exact h

theorem unit_interval_exp_moment (μ : FiniteLaw Ω) (W : Ω → ℝ)
    (hW0 : ∀ x, 0 ≤ W x) (hW1 : ∀ x, W x ≤ 1) (t : ℝ) :
    μ.expect (fun x => Real.exp (t * W x)) ≤ Real.exp (μ.expect W * (Real.exp t - 1)) := by
  calc
    μ.expect (fun x => Real.exp (t * W x)) ≤ μ.expect (fun x => 1 + W x * (Real.exp t - 1)) :=
      μ.expect_mono (fun x => exp_mul_unit_interval_le_chord t (W x) (hW0 x) (hW1 x))
    _ = 1 + μ.expect W * (Real.exp t - 1) := by rw [μ.expect_add, μ.expect_const, μ.expect_mul_const]
    _ ≤ Real.exp (μ.expect W * (Real.exp t - 1)) := by
      simpa [add_comm] using Real.add_one_le_exp (μ.expect W * (Real.exp t - 1))

theorem unit_interval_centered_exp_moment (μ : FiniteLaw Ω) (W : Ω → ℝ)
    (hW0 : ∀ x, 0 ≤ W x) (hW1 : ∀ x, W x ≤ 1) (t : ℝ) (ht : |t| ≤ 1) :
    μ.expect (fun x => Real.exp (t * (W x - μ.expect W))) ≤ Real.exp (μ.expect W * t^2) := by
  have hmean := μ.expect_nonneg hW0
  have he : Real.exp t - 1 - t ≤ t^2 := (abs_le.mp (Real.abs_exp_sub_one_sub_id_le ht)).2
  calc
    μ.expect (fun x => Real.exp (t * (W x - μ.expect W))) =
        Real.exp (-t * μ.expect W) * μ.expect (fun x => Real.exp (t * W x)) := by
      rw [← μ.expect_const_mul]
      congr 1
      funext x
      rw [← Real.exp_add]
      congr 1
      ring
    _ ≤ Real.exp (-t * μ.expect W) * Real.exp (μ.expect W * (Real.exp t - 1)) :=
      mul_le_mul_of_nonneg_left (unit_interval_exp_moment μ W hW0 hW1 t) (Real.exp_nonneg _)
    _ = Real.exp (μ.expect W * (Real.exp t - 1 - t)) := by rw [← Real.exp_add]; congr 1; ring
    _ ≤ Real.exp (μ.expect W * t^2) := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left he hmean)

theorem product_centered_exp_moment {ι : Type*} [Fintype ι] [DecidableEq ι]
    {A : ι → Type*} [∀ i, Fintype (A i)] (laws : ∀ i, FiniteLaw (A i)) (W : ∀ i, A i → ℝ)
    (hW0 : ∀ i x, 0 ≤ W i x) (hW1 : ∀ i x, W i x ≤ 1) (t : ℝ) (ht : |t| ≤ 1) :
    (product laws).expect (fun x => Real.exp (t * ∑ i, (W i (x i) - (laws i).expect (W i)))) ≤
      Real.exp ((∑ i, (laws i).expect (W i)) * t^2) := by
  simp_rw [mul_sum, Real.exp_sum]
  rw [product_expect_prod laws (fun i x => Real.exp (t * (W i x - (laws i).expect (W i))))]
  calc
    (∏ i, (laws i).expect (fun x => Real.exp (t * (W i x - (laws i).expect (W i))))) ≤
        ∏ i, Real.exp ((laws i).expect (W i) * t^2) := by
      apply prod_le_prod
      · intro i hi
        exact (laws i).expect_nonneg (fun x => Real.exp_nonneg _)
      · intro i hi
        exact unit_interval_centered_exp_moment (laws i) (W i) (hW0 i) (hW1 i) t ht
    _ = Real.exp ((∑ i, (laws i).expect (W i)) * t^2) := by rw [← Real.exp_sum, sum_mul]

end FiniteLaw

end MatroidProphetSecretary
