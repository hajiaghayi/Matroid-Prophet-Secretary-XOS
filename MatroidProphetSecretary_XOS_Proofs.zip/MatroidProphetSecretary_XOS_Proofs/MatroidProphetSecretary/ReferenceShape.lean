import MatroidProphetSecretary.ReferenceInstance

/-! Monotonicity, concavity, and scaling of the actual finite reference optimum. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

theorem referenceExpectedOptimum_zero (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) :
    referenceExpectedOptimum laws M value 0 = 0 := by
  rw [referenceExpectedOptimum_integral laws M hground value hv 0 le_rfl]
  simp only [referenceLayerRank_zero, ite_self, integral_zero]

theorem referenceExpectedOptimum_one (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) :
    referenceExpectedOptimum laws M value 1 = expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  rw [referenceExpectedOptimum_integral laws M hground value hv 1 zero_le_one,
    expectedOptimum_eq_integral_expected_rank (FiniteLaw.product laws) M (coordinateValues value)
      (fun x e => hv e (x e))]
  congr 1
  funext z
  by_cases hz : 0 < z
  · simp only [positiveRankLayer, hz, if_true]
    change referenceLayerRank M (coordinateTail laws value z) 1 =
      (FiniteLaw.product laws).expect (fun x => realRank M (valueLayer M (coordinateValues value x) z))
    rw [value_expected_rank laws M hground value z]
    unfold referenceLayerRank
    congr 1
    funext e
    simp only [scaledTail, one_mul]
    exact min_eq_right ((laws e).prob_le_one (fun x => z < value e x))
  · simp [positiveRankLayer, hz]

theorem referenceExpectedOptimum_monotone (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) :
    MonotoneOn (referenceExpectedOptimum laws M value) (Set.Ici 0) := by
  intro q hq r hr hqr
  rw [referenceExpectedOptimum_integral laws M hground value hv q hq,
    referenceExpectedOptimum_integral laws M hground value hv r hr]
  apply integral_mono
    (referenceExpectedOptimum_integrable_layers laws M hground value hv q hq)
    (referenceExpectedOptimum_integrable_layers laws M hground value hv r hr)
  intro z
  by_cases hz : 0 < z
  · simp only [hz, if_true]
    exact referenceLayerRank_monotone M hground (coordinateTail laws value z)
      (fun e => (laws e).prob_nonneg _) hq hr hqr
  · simp [hz]

theorem referenceExpectedOptimum_concave (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x) :
    ConcaveOn ℝ (Set.Ici 0) (referenceExpectedOptimum laws M value) := by
  refine ⟨convex_Ici 0, ?_⟩
  intro q hq r hr a b ha hb hab
  have hc : 0 ≤ a*q + b*r := add_nonneg (mul_nonneg ha hq) (mul_nonneg hb hr)
  have hqint := referenceExpectedOptimum_integrable_layers laws M hground value hv q hq
  have hrint := referenceExpectedOptimum_integrable_layers laws M hground value hv r hr
  have hcint := referenceExpectedOptimum_integrable_layers laws M hground value hv (a*q+b*r) hc
  have hpoint (z : ℝ) :
      a * (if 0 < z then referenceLayerRank M (coordinateTail laws value z) q else 0) +
        b * (if 0 < z then referenceLayerRank M (coordinateTail laws value z) r else 0) ≤
      if 0 < z then referenceLayerRank M (coordinateTail laws value z) (a*q+b*r) else 0 := by
    by_cases hz : 0 < z
    · simp only [hz, if_true]
      exact (referenceLayerRank_concave M hground (coordinateTail laws value z)
        (fun e => (laws e).prob_nonneg _)).2 hq hr ha hb hab
    · simp [hz]
  have h := integral_mono ((hqint.const_mul a).add (hrint.const_mul b)) hcint hpoint
  simp only [Pi.add_apply] at h
  rw [integral_add (hqint.const_mul a) (hrint.const_mul b), integral_const_mul, integral_const_mul,
    ← referenceExpectedOptimum_integral laws M hground value hv q hq,
    ← referenceExpectedOptimum_integral laws M hground value hv r hr,
    ← referenceExpectedOptimum_integral laws M hground value hv (a*q+b*r) hc] at h
  exact h

theorem referenceExpectedOptimum_scaling (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 ≤ q) :
    min 1 q * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) ≤
        referenceExpectedOptimum laws M value q ∧
      referenceExpectedOptimum laws M value q ≤
        max 1 q * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  have h := concave_zero_scaling _ (referenceExpectedOptimum_concave laws M hground value hv)
    (referenceExpectedOptimum_monotone laws M hground value hv)
    (referenceExpectedOptimum_zero laws M hground value hv) q hq
  rwa [referenceExpectedOptimum_one laws M hground value hv] at h

end MatroidProphetSecretary
