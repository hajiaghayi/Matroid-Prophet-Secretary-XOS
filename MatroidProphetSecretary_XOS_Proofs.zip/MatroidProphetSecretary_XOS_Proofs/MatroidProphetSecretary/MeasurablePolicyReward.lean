import MatroidProphetSecretary.TransformedObservationPolicy
import MatroidProphetSecretary.FinitePriorObservables
import Mathlib.MeasureTheory.Integral.Bochner.Basic

/-! Feasible policies driven by finite observations have measurable, optimum-dominated actual rewards. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

def orderAveragedReward {N : ℕ} (policy : OnlinePolicy N 0) (values : Fin N → ℝ) : ℝ :=
  (FiniteLaw.uniform (Equiv.Perm (Fin N))).expect (fun order =>
    weight values (acceptedSet (completedHistory policy 0 values order)))

theorem orderAveragedReward_bounds {N : ℕ} (M : Matroid (Fin N)) (policy : OnlinePolicy N 0)
    (hf : PolicyFeasible M policy) (values : Fin N → ℝ) (hv : ∀ e, 0 ≤ values e) :
    0 ≤ orderAveragedReward policy values ∧ orderAveragedReward policy values ≤ optimum M values := by
  constructor
  · exact FiniteLaw.expect_nonneg _ (fun order => sum_nonneg (fun e _ => hv e))
  · have h := FiniteLaw.expect_mono (FiniteLaw.uniform (Equiv.Perm (Fin N)))
      (fun order => weight_le_optimumOver (fun I : Finset (Fin N) => M.Indep (I : Set (Fin N)))
        (by simpa using M.empty_indep) values (hf 0 values order))
    simpa only [FiniteLaw.expect_const] using h

theorem measurable_weight_finite_choice {Ω S : Type*} [MeasurableSpace Ω] [MeasurableSpace S]
    [Countable S] [MeasurableSingletonClass S] {N : ℕ}
    (X : Fin N → Ω → ℝ) (hX : ∀ e, Measurable (X e)) (Y : Ω → S) (hY : Measurable Y)
    (chosen : S → Finset (Fin N)) : Measurable (fun ω => weight (fun e => X e ω) (chosen (Y ω))) := by
  have heq : (fun ω => weight (fun e => X e ω) (chosen (Y ω))) =
      fun ω => ∑ e : Fin N, X e ω * (if e ∈ chosen (Y ω) then (1:ℝ) else 0) := by
    funext ω
    simp [weight,mul_ite,Finset.sum_ite,Finset.filter_mem_eq_inter]
  rw [heq]
  apply Finset.measurable_sum
  intro e he
  exact (hX e).mul ((measurable_of_countable (fun s => if e ∈ chosen s then (1:ℝ) else 0)).comp hY)

theorem measurable_finite_observation_reward {Ω : Type*} [MeasurableSpace Ω] {N k : ℕ}
    (X : Fin N → Ω → ℝ) (hX : ∀ e, Measurable (X e))
    (observe : Fin N → ℝ → Fin k) (ho : ∀ e, Measurable (observe e))
    (value : Fin N → Fin k → ℝ) (policy : OnlinePolicy N 0) :
    Measurable (fun ω => orderAveragedReward
      (transformedPolicy (fun e v => value e (observe e v)) policy) (fun e => X e ω)) := by
  unfold orderAveragedReward FiniteLaw.expect
  apply Finset.measurable_sum
  intro order horder
  apply measurable_const.mul
  simp only [completed_transformedPolicy_accepted]
  exact measurable_weight_finite_choice X hX (fun ω e => observe e (X e ω))
    (measurable_pi_lambda _ (fun e => (ho e).comp (hX e)))
    (fun x => acceptedSet (completedHistory policy 0 (coordinateValues value x) order))

theorem integrable_finite_observation_reward {Ω : Type*} [MeasurableSpace Ω] {N k : ℕ}
    (μ : Measure Ω) (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hv : ∀ ω e, 0 ≤ X e ω)
    (hint : Integrable (fun ω => optimum M (fun e => X e ω)) μ)
    (observe : Fin N → ℝ → Fin k) (ho : ∀ e, Measurable (observe e))
    (value : Fin N → Fin k → ℝ) (policy : OnlinePolicy N 0) (hf : PolicyFeasible M policy) :
    Integrable (fun ω => orderAveragedReward
      (transformedPolicy (fun e v => value e (observe e v)) policy) (fun e => X e ω)) μ := by
  apply hint.mono' (measurable_finite_observation_reward X hX observe ho value policy).aestronglyMeasurable
  exact Filter.Eventually.of_forall (fun ω => by
    have h := orderAveragedReward_bounds M (transformedPolicy (fun e v => value e (observe e v)) policy)
      (transformedPolicy_feasible M (fun e v => value e (observe e v)) policy hf) (fun e => X e ω) (hv ω)
    rw [Real.norm_eq_abs,abs_of_nonneg h.1]
    exact h.2)

end MatroidProphetSecretary
