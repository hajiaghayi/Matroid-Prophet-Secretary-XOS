import MatroidProphetSecretary.ContractionPrices
import Mathlib.Data.Matroid.Rank.ENat

/-! Optimal bases span every strict weight layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [Fintype E] [DecidableEq E]

def valueLayer (M : Matroid E) (v : E → ℝ) (z : ℝ) : Set E :=
  {e | e ∈ M.E ∧ z < v e}

theorem optimal_exchange_value_le {M : Matroid E} {v : E → ℝ} {B : Finset E}
    (hopt : optimum M v = weight v B) {e b : E} (heB : e ∉ B) (hbB : b ∈ B)
    (hnew : M.Indep ((insert e (B.erase b) : Finset E) : Set E)) : v e ≤ v b := by
  have hnewle : weight v (insert e (B.erase b)) ≤ optimum M v :=
    weight_le_optimumOver _ _ v hnew
  have heErase : e ∉ B.erase b := fun h => heB (mem_of_mem_erase h)
  have hsum : weight v B = v b + weight v (B.erase b) := by
    simpa [weight] using (add_sum_erase B v hbB).symm
  rw [hopt, hsum] at hnewle
  simp only [weight, sum_insert heErase] at hnewle
  exact (add_le_add_iff_right _).mp hnewle

theorem optimal_basis_superlevel_isBasis {M : Matroid E} {v : E → ℝ} {B : Finset E}
    (hB : M.IsBase (B : Set E)) (hopt : optimum M v = weight v B) (z : ℝ) :
    M.IsBasis ((B.filter (fun e => z < v e) : Finset E) : Set E) (valueLayer M v z) := by
  classical
  let I := B.filter (fun e => z < v e)
  have hI : M.Indep (I : Set E) := hB.indep.subset (filter_subset _ B)
  apply hI.isBasis_of_subset_of_subset_closure
  · intro e he
    obtain ⟨heB, hev⟩ := mem_filter.mp he
    exact ⟨hB.subset_ground heB, hev⟩
  · intro e he
    obtain ⟨heE, hev⟩ := he
    by_cases heB : e ∈ B
    · exact M.mem_closure_of_mem (mem_filter.mpr ⟨heB, hev⟩) hI.subset_ground
    · let Γ := M.fundCircuit e (B : Set E)
      have hΓ : M.IsCircuit Γ := hB.fundCircuit_isCircuit heE heB
      have heΓ : e ∈ Γ := M.mem_fundCircuit e (B : Set E)
      have hΓI : Γ \ {e} ⊆ (I : Set E) := by
        intro b hb
        have hbB : b ∈ B := by
          rcases M.fundCircuit_subset_insert e (B : Set E) hb.1 with h | h
          · exact (hb.2 h).elim
          · exact h
        have heb : e ≠ b := (show b ≠ e from hb.2).symm
        have hi := (hB.indep.mem_fundCircuit_iff (by rw [hB.closure_eq]; exact heE) heB).mp hb.1
        have hinew : M.Indep ((insert e (B.erase b) : Finset E) : Set E) := by
          simpa [Finset.coe_insert, Finset.coe_erase, Set.insert_diff_singleton_comm heb] using hi
        exact mem_filter.mpr ⟨hbB, hev.trans_le (optimal_exchange_value_le hopt heB hbB hinew)⟩
      exact M.closure_subset_closure hΓI (hΓ.mem_closure_diff_singleton_of_mem heΓ)

theorem optimal_basis_layer_rank {M : Matroid E} {v : E → ℝ} {B : Finset E}
    (hB : M.IsBase (B : Set E)) (hopt : optimum M v = weight v B) (z : ℝ) :
    M.eRk (valueLayer M v z) = (B.filter (fun e => z < v e)).card := by
  rw [(optimal_basis_superlevel_isBasis hB hopt z).eRk_eq_encard]
  exact Set.encard_coe_eq_coe_finsetCard _

end MatroidProphetSecretary
