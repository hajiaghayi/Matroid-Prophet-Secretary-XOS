import MatroidProphetSecretary.PhysicalGridIntensity

/-! Early cancellation and late exposure bounds for the complete accepted-history process. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

open scoped Classical

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem profile_current (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N) (hp : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n)) :
    cfg.profile path n (gridClock N L cfg.clocks_pos n).val = cfg.live (path n) (gridLabel N cfg.labels_pos n) := by
  unfold profile gridHistoryProfile
  have hslot := gridSlot_clock_label N L cfg.labels_pos cfg.clocks_pos n hn
  unfold gridSlot at hslot
  rw [hslot,accepted_path_reconstruction cfg.laws (gridLabel N cfg.labels_pos)
    (gridClock N L cfg.clocks_pos) cfg.decision path n hp le_rfl]

theorem accepted_path_early_intensity (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N) (hp : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n))
    (habsent : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ path n)
    (hearly : (gridClock N L cfg.clocks_pos n).val < cfg.cut)
    (B : (Fin N → Option V) → Prop) :
    ((FiniteLaw.product cfg.laws).conditionOrSelf (cfg.pathEvent path n)).prob
      (fun x => (x (gridLabel N cfg.labels_pos n)).1 = gridClock N L cfg.clocks_pos n ∧
        ∃ y, cfg.decision n (path n) (x (gridLabel N cfg.labels_pos n)).2 = some y ∧ B y) =
      (1/(L:ℝ))*(1/cfg.q)*(FiniteLaw.product cfg.reference).prob
        (fun y => cfg.live (path n) (gridLabel N cfg.labels_pos n) y ∧ B y) := by
  rw [cfg.accepted_path_intensity path n hn hp habsent B,if_pos hearly,
    cfg.profile_current path n hn hp]
  have hs : cfg.survival path n = gridSurvival (cfg.dose path n) (gridClock N L cfg.clocks_pos n).val :=
    phaseSurvival_early _ _ _ hearly.le
  have hpos := cfg.survival_positive path n hn hp habsent
  rw [hs] at hpos ⊢
  apply (div_eq_iff hpos.ne').mpr
  ring

theorem accepted_path_late_intensity (path : ℕ → StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N) (hp : 0 < (FiniteLaw.product cfg.laws).prob (cfg.pathEvent path n))
    (habsent : ∀ mark, (gridLabel N cfg.labels_pos n,mark) ∉ path n)
    (hlate : cfg.cut ≤ (gridClock N L cfg.clocks_pos n).val)
    (B : (Fin N → Option V) → Prop) :
    ((FiniteLaw.product cfg.laws).conditionOrSelf (cfg.pathEvent path n)).prob
      (fun x => (x (gridLabel N cfg.labels_pos n)).1 = gridClock N L cfg.clocks_pos n ∧
        ∃ y, cfg.decision n (path n) (x (gridLabel N cfg.labels_pos n)).2 = some y ∧ B y) =
      (1/(L:ℝ))*((1/cfg.q)/cfg.survival path n)*(FiniteLaw.product cfg.reference).prob
        (fun y => cfg.live (path n) (gridLabel N cfg.labels_pos n) y ∧ B y) := by
  rw [cfg.accepted_path_intensity path n hn hp habsent B,if_neg (not_lt.mpr hlate),mul_one,
    cfg.profile_current path n hn hp]
  ring

theorem dose_bounds (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n i : ℕ) :
    0 ≤ cfg.dose path n i ∧ cfg.dose path n i ≤ (1/(L:ℝ))*(1/cfg.q) := by
  have hp : 0 ≤ (1/(L:ℝ))*(1/cfg.q) :=
    mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)
  constructor
  · exact mul_nonneg hp ((FiniteLaw.product cfg.reference).prob_nonneg _)
  · exact mul_le_of_le_one_right hp ((FiniteLaw.product cfg.reference).prob_le_one _)

theorem late_survival_lower (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hlate : cfg.cut ≤ (gridClock N L cfg.clocks_pos n).val) :
    (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)) ≤ cfg.survival path n := by
  let c := (gridClock N L cfg.clocks_pos n).val
  let p := (1/(L:ℝ))*(1/cfg.q)
  have hp : 0 ≤ p := mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (one_div_nonneg.mpr cfg.q_pos.le)
  have hh := (phaseSurvival_bounds (cfg.dose path n) p cfg.step_le
    (fun i => (cfg.dose_bounds path n i).1) (fun i => (cfg.dose_bounds path n i).2) cfg.cut (c-cfg.cut)).1
  have he : cfg.cut+(c-cfg.cut) = c := Nat.add_sub_of_le hlate
  rw [he] at hh
  have hle : ((c-cfg.cut:ℕ):ℝ) ≤ (L-cfg.cut:ℕ) := by
    exact_mod_cast Nat.sub_le_sub_right (gridClock N L cfg.clocks_pos n).isLt.le cfg.cut
  exact (sub_le_sub_left (mul_le_mul_of_nonneg_right hle hp) _).trans hh

theorem late_rate_bounds (path : ℕ → StampedHistory (Fin N) (Fin N → Option V)) (n : ℕ)
    (hlate : cfg.cut ≤ (gridClock N L cfg.clocks_pos n).val)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q))) :
    (1/cfg.q)*(1+accumulatedExposure (cfg.dose path n) cfg.cut) ≤ (1/cfg.q)/cfg.survival path n ∧
      (1/cfg.q)/cfg.survival path n ≤ (1/cfg.q)/omega := by
  have h := phaseSurvival_rate_bounds (cfg.dose path n)
    (fun i => (cfg.dose_bounds path n i).1) (fun i => ((cfg.dose_bounds path n i).2).trans_lt hsmall)
    cfg.cut ((gridClock N L cfg.clocks_pos n).val-cfg.cut) (1/cfg.q) omega
    (one_div_nonneg.mpr cfg.q_pos.le) homega
  rw [Nat.add_sub_of_le hlate] at h
  exact h (hlower.trans (cfg.late_survival_lower path n hlate))

end MatroidProphetSecretary.PrivateGridConfig
