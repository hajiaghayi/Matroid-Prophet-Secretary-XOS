import MatroidProphetSecretary.NonspanProbability

/-! The fixed-layer forward/reverse comparison with independent latent priorities. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]

theorem nonspanProbability_congr (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E)
    {p q : E → Prop} (hpq : ∀ f, f ≠ e → (p f ↔ q f)) :
    nonspanProbability laws M e p = nonspanProbability laws M e q := by
  have hsets : ∀ x, activeBlock M e p x = activeBlock M e q x := by
    intro x
    ext f
    by_cases hfe : f = e
    · simp [activeBlock, hfe]
    · simp [activeBlock, hfe, hpq f hfe]
  unfold nonspanProbability FiniteLaw.prob
  congr 1
  funext x
  have hi : nonspanEvent M e p x ↔ nonspanEvent M e q x := by
    unfold nonspanEvent
    rw [hsets x]
  by_cases hp : nonspanEvent M e p x
  · simp [hp, hi.mp hp]
  · have hq : ¬nonspanEvent M e q x := fun h => hp (hi.mpr h)
    simp [hp, hq]

theorem priorityBefore_asymm (v : E → ℝ) {e f : E} (hef : priorityBefore v e f) :
    ¬ priorityBefore v f e := fun hfe => priorityBefore_irrefl v e (priorityBefore_trans v hef hfe)

theorem nonspan_forward_reverse_product (laws : E → FiniteLaw Bool) (M : Matroid E)
    (e : E) (v : E → ℝ) :
    nonspanProbability laws M e (fun _ => True) ≤
      nonspanProbability laws M e (priorityBefore v e) *
        nonspanProbability laws M e (fun f => priorityBefore v f e) := by
  have h := nonspanProbability_le_partition_product laws M e (priorityBefore v e)
  have hcomp : nonspanProbability laws M e (fun f => ¬ priorityBefore v e f) =
      nonspanProbability laws M e (fun f => priorityBefore v f e) := by
    apply nonspanProbability_congr
    intro f hfe
    constructor
    · intro hnot
      rcases priorityBefore_trichotomy v e f with h | h | h
      · exact (hnot h).elim
      · exact (hfe h.symm).elim
      · exact h
    · exact priorityBefore_asymm v
  rwa [hcomp] at h

variable {V : E → Type*} [∀ e, Fintype (V e)] [∀ e, LinearOrder (V e)]

/-- The product-association step in Lemma 5, including the nonspanning comparison.
The order of the other coordinates is reversed, as in the paper. -/
theorem independent_latent_priority_bound
    (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (e : E) (value : ∀ e, V e → ℝ)
    (hown : Monotone (value e)) (hothers : ∀ f, f ≠ e → Antitone (value f)) :
    nonspanProbability activity M e (fun _ => True) ≤
      (FiniteLaw.product latent).expect (fun x =>
        nonspanProbability activity M e (priorityBefore (fun f => value f (x f)) e)) *
      (FiniteLaw.product latent).expect (fun x =>
        nonspanProbability activity M e (fun f => priorityBefore (fun g => value g (x g)) f e)) := by
  let F := fun x : ∀ f, V f =>
    nonspanProbability activity M e (priorityBefore (fun f => value f (x f)) e)
  let G := fun x : ∀ f, V f =>
    nonspanProbability activity M e (fun f => priorityBefore (fun g => value g (x g)) f e)
  have hF : Monotone F := by
    intro x y hxy
    exact forward_nonspan_mono activity M e (hown (hxy e)) (fun f hfe => hothers f hfe (hxy f))
  have hG : Antitone G := by
    intro x y hxy
    exact reverse_nonspan_antitone activity M e (hown (hxy e)) (fun f hfe => hothers f hfe (hxy f))
  have hassoc := FiniteLaw.product_reversed_association latent F G
    (fun x => (nonspanProbability_bounds activity M e _).1)
    (fun x => (nonspanProbability_bounds activity M e _).2) hF hG
  have hlower := (FiniteLaw.product latent).expect_mono (fun x =>
    nonspan_forward_reverse_product activity M e (fun f => value f (x f)))
  rw [FiniteLaw.expect_const] at hlower
  exact hlower.trans hassoc

end MatroidProphetSecretary
