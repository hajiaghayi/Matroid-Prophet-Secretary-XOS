import MatroidProphetSecretary.VirtualMortality

/-! Expected surviving value in the constructed finite virtual exchange process. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem virtualLiveValue_indicator (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (s : VirtualState M) (e : E) :
    virtualLiveValue μ M base hbase value s e =
      μ.expect (fun y => value y e * virtualLiveIndicator M base hbase value s y e) := by
  unfold virtualLiveValue
  congr 1
  funext y
  unfold virtualLiveIndicator
  split_ifs <;> simp

theorem virtualStep_value_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) (e : E) :
    (1-dt*R)*virtualLiveValue μ M base hbase value s e ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (fun event => virtualLiveValue μ M base hbase value (virtualUpdate M base hbase value s event) e) := by
  let law := virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall
  simp_rw [virtualLiveValue_indicator]
  rw [FiniteLaw.expect_comm]
  rw [← FiniteLaw.expect_const_mul]
  apply μ.expect_mono
  intro y
  rw [FiniteLaw.expect_const_mul]
  have h := mul_le_mul_of_nonneg_left
    (virtualStep_indicator_persistence μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall y e) (hv y e)
  convert h using 1 <;> ring

def virtualTotalLiveValue (μ : FiniteLaw W) (M : Matroid E) (base : W → Finset E)
    (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) (s : VirtualState M) : ℝ :=
  ∑ e, virtualLiveValue μ M base hbase value s e

theorem virtualStep_total_value_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (s : VirtualState M) (dt : ℝ) (rate : E → ℝ)
    (R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hrate0 : ∀ e, 0 ≤ rate e)
    (hrate1 : ∀ e, rate e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1) :
    (1-dt*R)*virtualTotalLiveValue μ M base hbase value s ≤
      (virtualStepLaw μ M base hbase value s dt rate R hdt hR hrate0 hrate1 hsmall).expect
        (fun event => virtualTotalLiveValue μ M base hbase value (virtualUpdate M base hbase value s event)) := by
  simp only [virtualTotalLiveValue,mul_sum,FiniteLaw.expect_finset_sum]
  exact sum_le_sum (fun e _ => virtualStep_value_persistence μ M base hbase value hv s dt rate R hdt hR hrate0 hrate1 hsmall e)

theorem virtualProcess_total_value_persistence (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (dt R : ℝ) (hdt : 0 ≤ dt) (hR : 0 ≤ R) (hdtR : dt*R ≤ 1)
    (rate : VirtualState M → E → ℝ) (hrate0 : ∀ s e, 0 ≤ rate s e)
    (hrate1 : ∀ s e, rate s e ≤ R) (hsmall : dt*R*Fintype.card E ≤ 1)
    (n : ℕ) (s : VirtualState M) :
    (1-dt*R)^n*virtualTotalLiveValue μ M base hbase value s ≤
      (FiniteLaw.adaptiveBatches
        (fun state => virtualStepLaw μ M base hbase value state dt (rate state) R hdt hR (hrate0 state) (hrate1 state) hsmall)
        (virtualUpdate M base hbase value) n s).expect
        (fun x => virtualTotalLiveValue μ M base hbase value
          (FiniteLaw.stateAfter (virtualUpdate M base hbase value) n s x)) := by
  exact FiniteLaw.adaptive_terminal_lower _ _ _ (1-dt*R) (sub_nonneg.mpr hdtR)
    (fun state => virtualStep_total_value_persistence μ M base hbase value hv state dt (rate state) R
      hdt hR (hrate0 state) (hrate1 state) hsmall) n s

theorem virtualProcess_early_reward (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (dt lam : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (hdtlam : dt*lam ≤ 1)
    (hsmall : dt*lam*Fintype.card E ≤ 1) (n : ℕ) (s : VirtualState M) :
    (1-(1-dt*lam)^n)*virtualTotalLiveValue μ M base hbase value s ≤
      (FiniteLaw.adaptiveBatches
        (fun state => virtualStepLaw μ M base hbase value state dt (fun _ => lam) lam hdt hlam
          (fun _ => hlam) (fun _ => le_rfl) hsmall)
        (virtualUpdate M base hbase value) n s).expect
        (FiniteLaw.trajectoryReward (virtualUpdate M base hbase value) (virtualCredit M base hbase value) n s) := by
  apply FiniteLaw.adaptive_reward_lower _ _ _ (virtualTotalLiveValue μ M base hbase value)
    (1-dt*lam) (sub_nonneg.mpr hdtlam) (sub_le_self _ (mul_nonneg hdt hlam))
  · intro state
    exact virtualStep_total_value_persistence μ M base hbase value hv state dt (fun _ => lam) lam
      hdt hlam (fun _ => hlam) (fun _ => le_rfl) hsmall
  · intro state
    rw [virtualStep_expected_credit]
    simp only [sub_sub_cancel,virtualTotalLiveValue,← mul_sum]
    exact le_of_eq (by ring)

end MatroidProphetSecretary
