import MatroidProphetSecretary.XOSHardness
import Mathlib.Data.Fintype.Perm
import MatroidProphetSecretary.FinitePairs

/-! Explicit uniform arrival order. We even allow a policy to know the entire
arrival permutation before any values arrive; this only strengthens the upper bound. -/

noncomputable section
set_option maxHeartbeats 1000000
namespace MatroidProphetSecretary.XOS
open Finset
open scoped Classical

def reindexLabels {n L : ℕ} (σ : Equiv.Perm (Fin n)) : Sample n L ≃ Sample n L where
  toFun x t := x (σ t)
  invFun x t := x (σ.symm t)
  left_inv x := by funext t; simp
  right_inv x := by funext t; simp

theorem feasible_reindex {n L : ℕ} (σ : Equiv.Perm (Fin n)) (S : Allocation n L)
    (hS : Feasible S) : Feasible (fun t => S (σ t)) := by
  intro i j hij
  exact hS (fun h => hij (σ.injective h))

theorem welfare_reindex {n L : ℕ} (σ : Equiv.Perm (Fin n))
    (x : Sample n L) (S : Allocation n L) :
    welfare (fun t => x (σ t)) (fun t => S (σ t)) = welfare x S :=
  Equiv.sum_comp σ (fun t => value (x t) (S t))

theorem prophet_reindex_le {n L : ℕ} (σ : Equiv.Perm (Fin n)) (x : Sample n L) :
    prophet (fun t => x (σ t)) ≤ prophet x := by
  apply Finset.sup_le
  intro S hS
  have hfeas : Feasible S := by simpa using hS
  have h := welfare_le_prophet x (fun t => S (σ.symm t)) (feasible_reindex σ.symm S hfeas)
  have heq := welfare_reindex σ x (fun t => S (σ.symm t))
  simpa only [Equiv.symm_apply_apply] using heq.trans_le h

/-- Reordering buyers preserves the actual offline allocation optimum pointwise. -/
theorem prophet_permutation_invariant {n L : ℕ} (σ : Equiv.Perm (Fin n)) (x : Sample n L) :
    prophet (fun t => x (σ t)) = prophet x := by
  apply le_antisymm (prophet_reindex_le σ x)
  simpa only [Equiv.apply_symm_apply] using prophet_reindex_le σ.symm (fun t => x (σ t))

theorem labels_permutation_invariant {n L : ℕ} [NeZero L]
    (σ : Equiv.Perm (Fin n)) (f : Sample n L → ℝ) :
    (labelsLaw n L).expect (fun x => f (fun t => x (σ t))) = (labelsLaw n L).expect f := by
  rw [labelsLaw,uniform_product]
  unfold FiniteLaw.expect FiniteLaw.uniform
  exact (reindexLabels σ).sum_comp (fun x => (1 / (Fintype.card (Sample n L) : ℝ)) * f x)

abbrev PolicyFamily (n L : ℕ) := Equiv.Perm (Fin n) → OnlineRule n L

/-- Labels are drawn for buyers independently, and the independent arrival permutation is uniform. -/
def secretaryReward {n L : ℕ} [NeZero L] (μ : FiniteLaw (PolicyFamily n L)) : ℝ :=
  (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect (fun σ =>
    μ.expect (fun p => (labelsLaw n L).expect (fun x =>
      (welfare (fun t => x (σ t)) ((p σ).val (fun t => x (σ t))) : ℝ))))

theorem secretaryReward_eq {n L : ℕ} [NeZero L] (μ : FiniteLaw (PolicyFamily n L)) :
    secretaryReward μ = (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect (fun σ =>
      μ.expect (fun p => expectedReward (p σ).val)) := by
  unfold secretaryReward
  apply congrArg (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect
  funext σ
  apply congrArg μ.expect
  funext p
  exact labels_permutation_invariant σ (fun x => (welfare x ((p σ).val x) : ℝ))

theorem secretaryReward_upper {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L)
    (μ : FiniteLaw (PolicyFamily n L)) :
    secretaryReward μ ≤ (Fintype.card (Goods n L) : ℝ) *
      (coverageRatio n + (n : ℝ)^3 / L) := by
  rw [secretaryReward_eq]
  have h := (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect_mono (fun σ =>
    μ.expect_mono (fun p => expectedReward_upper hnL (p σ).val (p σ).property))
  simpa using h

theorem secretary_ratio_bound {n L : ℕ} [NeZero n] [NeZero L] (hnL : n ≤ L)
    (hd : 0 < 1 - (n : ℝ)^2 / L) (μ : FiniteLaw (PolicyFamily n L)) :
    secretaryReward μ / expectedProphet n L ≤ finiteRatio n L := by
  let ν : FiniteLaw (OnlineRule n L) :=
    ((FiniteLaw.uniform (Equiv.Perm (Fin n))).pair μ).map (fun z => z.2 z.1)
  have heq : randomizedReward ν = secretaryReward μ := by
    rw [randomizedReward,FiniteLaw.map_expect,FiniteLaw.pair_expect,secretaryReward_eq]
  rw [← heq]
  exact randomized_ratio_bound hnL hd ν

/-- The hardness theorem in the explicit prophet-secretary arrival model. -/
theorem xos_prophet_secretary_hardness (ξ : ℝ) (hξ : 0 < ξ) :
    ∃ n L : ℕ, ∃ hn : NeZero n, ∃ hL : NeZero L,
      letI : NeZero n := hn
      letI : NeZero L := hL
      2 ≤ n ∧ n ≤ L ∧
      0 < expectedProphet n L ∧
      (∀ a : Fin L, ∀ S : Finset (Goods n L),
        (∀ c ∈ allowed a, ∑ x ∈ S, coefficient c x ≤ (value a S : ℝ)) ∧
        ∃ c ∈ allowed a, (value a S : ℝ) = ∑ x ∈ S, coefficient c x) ∧
      ∀ μ : FiniteLaw (PolicyFamily n L),
        secretaryReward μ / expectedProphet n L < 1 - 1 / Real.exp 1 + ξ := by
  obtain ⟨n,L,hn2,hnL,hd,hr⟩ := exists_hard_parameters ξ hξ
  haveI hn : NeZero n := ⟨by omega⟩
  haveI hL : NeZero L := ⟨by omega⟩
  refine ⟨n,L,hn,hL,hn2,hnL,expectedProphet_pos hd,?_,?_⟩
  · intro a
    exact (value_is_XOS hnL a).2
  · intro μ
    exact (secretary_ratio_bound hnL hd μ).trans_lt hr

end MatroidProphetSecretary.XOS
