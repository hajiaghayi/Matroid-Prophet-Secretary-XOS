import MatroidProphetSecretary.ReferenceDifferentiation
import MatroidProphetSecretary.ReferenceSurplusLayers
import MatroidProphetSecretary.ReferenceShape

/-! The derivative sandwich of Lemma 3 for the actual finite reference distributions. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

theorem referenceLayerD_integrable (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 ≤ q) :
    Integrable (fun z => if 0 < z then referenceLayerD M (coordinateTail laws value z) q else 0) := by
  have h := integrable_finset_sum univ (fun e _ =>
    (FiniteLaw.product (referenceInstanceLaws laws value q)).integrable_expect _
      (fun x => coloopLayer_integrable M (coordinateValues (referenceInstanceValues value) x)
        (fun f => referencePriorValue_nonneg (value f) (hv f) (x f)) e))
  simpa only [referenceInstance_deletion_layer laws M hground value q hq] using h

theorem referenceLayerH_integrable (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 ≤ q) :
    Integrable (fun z => if 0 < z then referenceLayerH M (coordinateTail laws value z) q else 0) := by
  have h := stableLayerExpectation_integrable (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value))
    (fun x e => referencePriorValue_nonneg (value e) (hv e) (x e))
  rw [← funext (referenceInstance_stable_layer laws M hground value q hq)]
  exact h

theorem finite_reference_derivative_bounds (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) (hq : 0 < q) :
    deletionSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) -
      stableSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) hnonloop ≤
      q * referenceOptimumSlope false laws M value q ∧
    q * referenceOptimumSlope false laws M value q ≤ q * referenceOptimumSlope true laws M value q ∧
    q * referenceOptimumSlope true laws M value q ≤
      deletionSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) := by
  have hground : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  let D := fun z => if 0 < z then referenceLayerD M (coordinateTail laws value z) q else 0
  let H := fun z => if 0 < z then referenceLayerH M (coordinateTail laws value z) q else 0
  let R := fun z => if 0 < z then referenceLayerSlope false M (coordinateTail laws value z) q else 0
  let L := fun z => if 0 < z then referenceLayerSlope true M (coordinateTail laws value z) q else 0
  have hD : Integrable D := referenceLayerD_integrable laws M hground value hv q hq.le
  have hH : Integrable H := referenceLayerH_integrable laws M hground value hv q hq.le
  have hR : Integrable R := referenceLayerSlope_integrable false laws M hground value hv q hq
  have hL : Integrable L := referenceLayerSlope_integrable true laws M hground value hv q hq
  have hp (z : ℝ) : D z - H z ≤ q * R z ∧ q * R z ≤ q * L z ∧ q * L z ≤ D z := by
    by_cases hz : 0 < z
    · simpa only [D, H, R, L, hz, if_true, referenceLayerSlope, Bool.false_eq_true, if_false] using
        referenceLayer_derivative_bounds M hground (coordinateTail laws value z)
          (fun e => (laws e).prob_nonneg _) q hq.le
    · simp [D, H, R, L, hz]
  have h1 := integral_mono (hD.sub hH) (hR.const_mul q) (fun z => (hp z).1)
  have h2 := integral_mono (hR.const_mul q) (hL.const_mul q) (fun z => (hp z).2.1)
  have h3 := integral_mono (hL.const_mul q) hD (fun z => (hp z).2.2)
  simp only [Pi.sub_apply] at h1
  rw [integral_sub hD hH, integral_const_mul] at h1
  rw [integral_const_mul, integral_const_mul] at h2
  rw [integral_const_mul] at h3
  rw [referenceInstance_deletion_integral laws M hground value hv q hq.le,
    referenceInstance_stable_integral laws M value hv hnonloop q hq.le,
    referenceOptimumSlope_integral false laws M hground value hv q hq,
    referenceOptimumSlope_integral true laws M hground value hv q hq]
  exact ⟨h1, h2, h3⟩

end MatroidProphetSecretary
