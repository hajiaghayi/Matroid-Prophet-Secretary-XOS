import MatroidProphetSecretary.StableLayerVariation
import MatroidProphetSecretary.LayerMassIntegral
import MatroidProphetSecretary.ReferencePotential

/-! The finite-prior Lipschitz bounds for D, H, and C in Lemma 17. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem integrated_layer_variation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (L : (E → ℝ) → ℝ → ℝ) (C q r : ℝ) (hC : 0 ≤ C)
    (hIq : Integrable (fun z => if 0 < z then L (coordinateTail laws value z) q else 0))
    (hIr : Integrable (fun z => if 0 < z then L (coordinateTail laws value z) r else 0))
    (hvar : ∀ p, (∀ e, 0 ≤ p e) → |L p r - L p q| ≤ C*|r-q| * (∑ e, p e)) :
    |(∫ z, if 0 < z then L (coordinateTail laws value z) r else 0) -
      (∫ z, if 0 < z then L (coordinateTail laws value z) q else 0)| ≤
      C*|r-q| * (Fintype.card E : ℝ)*expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  have h := integral_variation_bound _ _
    (fun z => ∑ e, positiveTailProbability (FiniteLaw.product laws) (coordinateValues value) e z)
    hIr hIq (total_tail_integrable (FiniteLaw.product laws) (coordinateValues value)) (C*|r-q|) (by
      intro z
      by_cases hz : 0 < z
      · simp only [if_pos hz, positiveTail_eq_coordinateTail laws value z hz]
        exact hvar _ (fun e => (laws e).prob_nonneg _)
      · simp [hz, positiveTailProbability, positiveLayer])
  refine h.trans ?_
  have hmass := integral_total_tail_le (FiniteLaw.product laws) (coordinateValues value)
    (fun x e => hv e (x e)) M hnonloop
  simpa only [mul_assoc] using mul_le_mul_of_nonneg_left hmass (mul_nonneg hC (abs_nonneg _))

theorem referenceDeletion_lipschitz (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q r : ℝ) (hq : 0 ≤ q) (hr : 0 ≤ r) :
    |referenceDeletion laws M value r - referenceDeletion laws M value q| ≤
      (Fintype.card E : ℝ)^2 * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) * |r-q| := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  unfold referenceDeletion
  rw [referenceInstance_deletion_integral laws M hg value hv r hr,
    referenceInstance_deletion_integral laws M hg value hv q hq]
  have h := integrated_layer_variation laws value hv M hnonloop (referenceLayerD M) (Fintype.card E) q r
    (Nat.cast_nonneg _) (referenceLayerD_integrable laws M hg value hv q hq)
    (referenceLayerD_integrable laws M hg value hv r hr)
    (fun p hp => referenceLayerD_variation M hg p hp q r hq hr)
  convert h using 1 <;> ring

theorem referenceStable_lipschitz (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q r : ℝ) (hq : 0 ≤ q) (hr : 0 ≤ r) :
    |referenceStable laws M value hnonloop r - referenceStable laws M value hnonloop q| ≤
      2*(Fintype.card E : ℝ)^2 * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) * |r-q| := by
  have hg : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  unfold referenceStable
  rw [referenceInstance_stable_integral laws M value hv hnonloop r hr,
    referenceInstance_stable_integral laws M value hv hnonloop q hq]
  have h := integrated_layer_variation laws value hv M hnonloop (referenceLayerH M) ((Fintype.card E : ℝ)+1) q r
    (by positivity) (referenceLayerH_integrable laws M hg value hv q hq)
    (referenceLayerH_integrable laws M hg value hv r hr)
    (fun p hp => referenceLayerH_variation M hg p hp q r hq hr)
  refine h.trans ?_
  have hn : (Fintype.card E : ℝ) ≤ (Fintype.card E : ℝ)*(Fintype.card E : ℝ) := by
    exact_mod_cast Nat.le_mul_self (Fintype.card E)
  have hF : 0 ≤ expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) :=
    FiniteLaw.expect_nonneg _ (fun x => optimum_nonneg M _)
  have hc : ((Fintype.card E : ℝ)+1)*(Fintype.card E : ℝ) ≤ 2*(Fintype.card E : ℝ)^2 := by nlinarith
  have hh := mul_le_mul_of_nonneg_right hc (mul_nonneg hF (abs_nonneg (r-q)))
  nlinarith only [hh]

theorem referenceUnstable_lipschitz (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q r : ℝ) (hq : 0 ≤ q) (hr : 0 ≤ r) :
    |(referenceDeletion laws M value r - referenceStable laws M value hnonloop r) -
      (referenceDeletion laws M value q - referenceStable laws M value hnonloop q)| ≤
      3*(Fintype.card E : ℝ)^2 * expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) * |r-q| := by
  have hD := referenceDeletion_lipschitz laws M value hv hnonloop q r hq hr
  have hH := referenceStable_lipschitz laws M value hv hnonloop q r hq hr
  have h := abs_sub_le (referenceDeletion laws M value r - referenceStable laws M value hnonloop r)
    (referenceDeletion laws M value q - referenceStable laws M value hnonloop r)
    (referenceDeletion laws M value q - referenceStable laws M value hnonloop q)
  have he1 : (referenceDeletion laws M value r - referenceStable laws M value hnonloop r) -
      (referenceDeletion laws M value q - referenceStable laws M value hnonloop r) =
      referenceDeletion laws M value r - referenceDeletion laws M value q := by ring
  have he2 : (referenceDeletion laws M value q - referenceStable laws M value hnonloop r) -
      (referenceDeletion laws M value q - referenceStable laws M value hnonloop q) =
      -(referenceStable laws M value hnonloop r - referenceStable laws M value hnonloop q) := by ring
  rw [he1, he2, abs_neg] at h
  linarith

end MatroidProphetSecretary
