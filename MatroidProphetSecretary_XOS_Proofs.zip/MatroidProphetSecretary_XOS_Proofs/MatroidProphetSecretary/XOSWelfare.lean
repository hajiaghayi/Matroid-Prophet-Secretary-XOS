import MatroidProphetSecretary.XOSProbability

/-! Actual disjoint allocations, the offline optimum, and online information constraints. -/

noncomputable section
namespace MatroidProphetSecretary.XOS
open Finset
open scoped Classical

abbrev Sample (n L : ℕ) := Fin n → Fin L
abbrev Allocation (n L : ℕ) := Fin n → Finset (Goods n L)
abbrev Rule (n L : ℕ) := Sample n L → Allocation n L

def Feasible {n L : ℕ} (S : Allocation n L) : Prop :=
  Pairwise (fun i j => Disjoint (S i) (S j))

/-- The irrevocable bundle at time `t` depends only on labels seen through `t`. -/
def Causal {n L : ℕ} (rule : Rule n L) : Prop :=
  ∀ x y t, (∀ i, i ≤ t → x i = y i) → rule x t = rule y t

def Legal {n L : ℕ} (rule : Rule n L) : Prop :=
  Causal rule ∧ ∀ x, Feasible (rule x)

abbrev OnlineRule (n L : ℕ) := {rule : Rule n L // Legal rule}

theorem empty_rule_legal (n L : ℕ) : Legal (fun (_ : Sample n L) (_ : Fin n) => ∅) := by
  constructor
  · intro _ _ _ _; rfl
  · intro _ i j _; exact disjoint_empty_left _

instance onlineRule_nonempty (n L : ℕ) : Nonempty (OnlineRule n L) :=
  ⟨⟨fun _ _ => ∅,empty_rule_legal n L⟩⟩

def welfare {n L : ℕ} (x : Sample n L) (S : Allocation n L) : ℕ :=
  ∑ t, value (x t) (S t)

def prophet {n L : ℕ} (x : Sample n L) : ℕ :=
  (univ.filter (fun S : Allocation n L => Feasible S)).sup (welfare x)

theorem welfare_le_prophet {n L : ℕ} (x : Sample n L) (S : Allocation n L)
    (hS : Feasible S) : welfare x S ≤ prophet x :=
  Finset.le_sup (by simp [hS])

theorem disjoint_sum_card_le {A I : Type*} [Fintype A] [Fintype I]
    (S : I → Finset A) (hS : Pairwise (fun i j => Disjoint (S i) (S j))) :
    ∑ i, (S i).card ≤ Fintype.card A := by
  rw [← card_biUnion (fun i _ j _ hij => hS hij)]
  exact card_le_univ _

theorem welfare_le_goods {n L : ℕ} (x : Sample n L) (S : Allocation n L)
    (hS : Feasible S) : welfare x S ≤ Fintype.card (Goods n L) := by
  exact (sum_le_sum (fun t _ => value_le_card (x t) (S t))).trans
    (disjoint_sum_card_le S hS)

theorem prophet_le_goods {n L : ℕ} (x : Sample n L) :
    prophet x ≤ Fintype.card (Goods n L) := by
  apply Finset.sup_le
  intro S hS
  exact welfare_le_goods x S (by simpa using hS)

/-- Distinct realized labels themselves specify a partition allocating every item. -/
theorem prophet_of_injective {n L : ℕ} (x : Sample n L) (hx : Function.Injective x) :
    prophet x = Fintype.card (Goods n L) := by
  let s : Index n L := ⟨x,hx⟩
  let S : Allocation n L := fun t => part n s t
  have hS : Feasible S := by
    intro i j hij
    apply disjoint_left.mpr
    intro a hai haj
    exact hij ((mem_part s i a).mp hai |>.symm.trans ((mem_part s j a).mp haj))
  have hvalue (t : Fin n) : value (x t) (S t) = (S t).card := by
    apply le_antisymm (value_le_card _ _)
    simpa [S] using clause_le_value (x t) (S t) (s,t) rfl
  have hcover : univ.biUnion S = univ := by
    ext a
    simp only [mem_biUnion, mem_univ, true_and, iff_true]
    exact ⟨a s,by simp [S]⟩
  have hw : welfare x S = Fintype.card (Goods n L) := by
    simp only [welfare,hvalue]
    rw [← card_biUnion (fun i _ j _ hij => hS hij),hcover,card_univ]
  exact (prophet_le_goods x).antisymm (hw ▸ welfare_le_prophet x S hS)

def expectedProphet (n L : ℕ) [NeZero L] : ℝ :=
  (labelsLaw n L).expect (fun x => (prophet x : ℝ))

def expectedReward {n L : ℕ} [NeZero L] (rule : Rule n L) : ℝ :=
  (labelsLaw n L).expect (fun x => (welfare x (rule x) : ℝ))

theorem expectedProphet_lower {n L : ℕ} [NeZero L] :
    (Fintype.card (Goods n L) : ℝ) * (1 - (n : ℝ)^2 / L) ≤ expectedProphet n L := by
  let μ := labelsLaw n L
  have h := μ.expect_mono (f := fun x => (Fintype.card (Goods n L) : ℝ) *
    (if Function.Injective x then 1 else 0)) (g := fun x => (prophet x : ℝ)) (by
      intro x
      by_cases hx : Function.Injective x
      · simp [hx,prophet_of_injective x hx]
      · simp [hx])
  rw [μ.expect_const_mul] at h
  have hcomp := prob_not μ (fun x => ¬Function.Injective x)
  simp only [not_not] at hcomp
  change _ * μ.prob (fun x => Function.Injective x) ≤ _ at h
  rw [hcomp] at h
  have hb := label_collision_bound (n := n) (L := L)
  exact (mul_le_mul_of_nonneg_left (sub_le_sub_left hb 1) (by positivity)).trans h

end MatroidProphetSecretary.XOS
