import MatroidProphetSecretary.ClockEncoding
import MatroidProphetSecretary.Problem
import Mathlib.GroupTheory.Perm.Fin

/-! A uniform arrival order is a uniform first label followed by an independent uniform remaining order. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def remainingLabel {n : ℕ} (e : Fin (n+1)) (i : Fin n) : Fin (n+1) := Equiv.swap 0 e i.succ

theorem remainingLabel_injective {n : ℕ} (e : Fin (n+1)) : Function.Injective (remainingLabel e) :=
  (Equiv.swap 0 e).injective.comp (Fin.succ_injective n)

theorem remainingLabel_ne {n : ℕ} (e : Fin (n+1)) (i : Fin n) : remainingLabel e i ≠ e := by
  intro he
  have h := congrArg (Equiv.swap 0 e) he
  simp only [remainingLabel,Equiv.swap_apply_self,Equiv.swap_apply_right] at h
  exact Fin.succ_ne_zero i h

theorem arrival_order_uncons {n : ℕ} (e : Fin (n+1)) (order : Equiv.Perm (Fin n)) :
    (List.finRange (n+1)).map (Equiv.Perm.decomposeFin.symm (e,order)) =
      e :: (List.finRange n).map (fun i => remainingLabel e (order i)) := by
  rw [List.finRange_succ_eq_map,List.map_cons,List.map_map,Equiv.Perm.decomposeFin_symm_apply_zero]
  apply congrArg (List.cons e)
  apply List.map_congr_left
  intro i hi
  exact Equiv.Perm.decomposeFin_symm_apply_succ order e i

theorem uniform_arrival_decomposition (n : ℕ) (f : Equiv.Perm (Fin (n+1)) → ℝ) :
    (FiniteLaw.uniform (Equiv.Perm (Fin (n+1)))).expect f =
      (FiniteLaw.uniform (Fin (n+1))).expect (fun e =>
        (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect (fun order => f (Equiv.Perm.decomposeFin.symm (e,order)))) := by
  have h := FiniteLaw.uniform_expect_equiv (Equiv.Perm.decomposeFin (n := n)).symm f
  rw [FiniteLaw.uniform_pair,FiniteLaw.pair_expect] at h
  exact h.symm

theorem completedHistory_uncons {n K : ℕ} (policy : OnlinePolicy (n+1) K) (seed : Fin (2^K))
    (value : Fin (n+1) → ℝ) (e : Fin (n+1)) (order : Equiv.Perm (Fin n)) :
    completedHistory policy seed value (Equiv.Perm.decomposeFin.symm (e,order)) =
      runPolicy policy seed value ((List.finRange n).map (fun i => remainingLabel e (order i)))
        [⟨e,value e,policy seed [] e (value e)⟩] := by
  unfold completedHistory
  rw [arrival_order_uncons]
  rfl

end MatroidProphetSecretary
