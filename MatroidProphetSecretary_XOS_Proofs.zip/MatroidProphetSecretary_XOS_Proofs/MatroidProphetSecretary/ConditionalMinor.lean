import MatroidProphetSecretary.GroundExtension

/-! The outside-active-set contraction used in the capped-surplus proof. -/

noncomputable section

namespace MatroidProphetSecretary

open Set
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

def conditionalMinor (M : Matroid E) (O T : Set E) : Matroid E := (M ／ O) ↾ T

theorem realRank_restrict (M : Matroid E) (T S : Set E) :
    realRank (M ↾ T) S = realRank M (S ∩ T) := by
  unfold realRank
  rw [M.restrict_eRk_eq']

theorem conditionalMinor_rank_le (M : Matroid E) (O T : Set E) (hT : T ⊆ M.E) :
    realRank (conditionalMinor M O T) (conditionalMinor M O T).E ≤ realRank M T := by
  obtain ⟨B, hB⟩ := (conditionalMinor M O T).exists_isBase
  rw [realRank_eq_ncard hB.isBasis_ground]
  exact indep_ncard_le_realRank hB.indep.of_restrict.of_contract hB.subset_ground hT

theorem conditionalMinor_has_base_in (M : Matroid E) (O T I : Set E)
    (hI : M.IsBasis I T) (hd : Disjoint T O) :
    ∃ C : Finset E, (conditionalMinor M O T).IsBase (C : Set E) ∧ (C : Set E) ⊆ I := by
  let N := conditionalMinor M O T
  have hTO : T ⊆ (M ／ O).E := by
    intro e he
    exact ⟨hI.subset_ground he, Set.disjoint_left.mp hd he⟩
  have hspan : T ⊆ N.closure I := by
    dsimp [N, conditionalMinor]
    rw [Matroid.restrict_closure_eq _ hI.subset hTO, Matroid.contract_closure_eq]
    intro e he
    refine ⟨⟨?_, Set.disjoint_left.mp hd he⟩, he⟩
    exact M.closure_subset_closure subset_union_left (hI.subset_closure he)
  obtain ⟨J, hJ⟩ := N.exists_isBasis I hI.subset
  have hJB : N.IsBase J := hJ.indep.isBase_of_ground_subset_closure (by
    rw [hJ.closure_eq_closure]
    exact hspan)
  refine ⟨J.toFinset, ?_, ?_⟩
  · simpa using hJB
  · simpa using hJ.subset

theorem conditionalMinor_marginal (M : Matroid E) (O T : Set E)
    (hT : T ⊆ M.E) (hd : Disjoint T O) (e : E) (x : E → Bool) :
    insertDifference e (rankObservable (conditionalMinor M O T)) x =
      if e ∈ T ∧ e ∉ M.closure ((bitSet x ∩ T) ∪ O) then 1 else 0 := by
  simp only [insertDifference, rankObservable, bitSet_update, conditionalMinor,
    realRank_restrict]
  by_cases heT : e ∈ T
  · have heO : e ∉ O := Set.disjoint_left.mp hd heT
    have heground : e ∈ (M ／ O).E := ⟨hT heT, heO⟩
    have hS : bitSet x ∩ T ⊆ (M ／ O).E := by
      intro f hf
      exact ⟨hT hf.2, Set.disjoint_left.mp hd hf.2⟩
    rw [Set.insert_inter_of_mem heT, realRank_insert (M ／ O) _ hS e heground,
      Matroid.contract_closure_eq]
    simp only [mem_diff, heO, not_false_eq_true, and_true, heT, true_and]
    split_ifs <;> ring
  · rw [Set.insert_inter_of_not_mem heT]
    simp [heT]

end MatroidProphetSecretary
