import MatroidProphetSecretary.FiniteCountSampler
import Mathlib.Algebra.Order.Floor.Semiring

/-! Explicit downward rounding of atom masses, with the remainder assigned to one atom. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω : Type*} [Fintype Ω]

def floorCounts (μ : FiniteLaw Ω) (N : ℕ) (x : Ω) : ℕ := ⌊(N:ℝ)*μ.mass x⌋₊

theorem floorCounts_total_le (μ : FiniteLaw Ω) (N : ℕ) : ∑ x, floorCounts μ N x ≤ N := by
  have h := sum_le_sum (s := (univ : Finset Ω)) (fun x _ =>
    Nat.floor_le (mul_nonneg (Nat.cast_nonneg N) (μ.nonneg x)))
  simp only [← mul_sum,μ.total,mul_one] at h
  exact_mod_cast h

def roundedCounts (μ : FiniteLaw Ω) (N : ℕ) (default : Ω) (x : Ω) : ℕ :=
  floorCounts μ N x + if x = default then N-∑ y, floorCounts μ N y else 0

theorem roundedCounts_total (μ : FiniteLaw Ω) (N : ℕ) (default : Ω) :
    ∑ x, roundedCounts μ N default x = N := by
  simp only [roundedCounts,sum_add_distrib,sum_ite_eq',mem_univ,if_true]
  exact Nat.add_sub_of_le (floorCounts_total_le μ N)

def roundedLaw (μ : FiniteLaw Ω) (N : ℕ) (hN : 0 < N) (default : Ω) : FiniteLaw Ω :=
  countSampleLaw (roundedCounts μ N default) N hN (roundedCounts_total μ N default)

theorem floor_atom_bounds (μ : FiniteLaw Ω) (N : ℕ) (hN : 0 < N) (x : Ω) :
    0 ≤ μ.mass x-(floorCounts μ N x : ℝ)/N ∧
      μ.mass x-(floorCounts μ N x : ℝ)/N ≤ 1/N := by
  have hN' : (0 : ℝ) < N := by exact_mod_cast hN
  have hl := Nat.floor_le (mul_nonneg hN'.le (μ.nonneg x))
  have hu := Nat.lt_floor_add_one ((N:ℝ)*μ.mass x)
  constructor
  · apply sub_nonneg.mpr
    apply (div_le_iff₀ hN').mpr
    simpa only [floorCounts,mul_comm] using hl
  · have he : μ.mass x-(floorCounts μ N x : ℝ)/N = ((N:ℝ)*μ.mass x-floorCounts μ N x)/N := by
      field_simp
      <;> ring
    rw [he]
    apply (div_le_div_iff_of_pos_right hN').mpr
    dsimp only [floorCounts]
    linarith

theorem roundedLaw_ge_floor (μ : FiniteLaw Ω) (N : ℕ) (hN : 0 < N) (default x : Ω) :
    (floorCounts μ N x : ℝ)/N ≤ (roundedLaw μ N hN default).mass x := by
  rw [roundedLaw,countSampleLaw_mass]
  apply div_le_div_of_nonneg_right _ (Nat.cast_nonneg N)
  exact_mod_cast (Nat.le_add_right (floorCounts μ N x)
    (if x = default then N-∑ y, floorCounts μ N y else 0))

theorem roundedLaw_massDistance (μ : FiniteLaw Ω) (N : ℕ) (hN : 0 < N) (default : Ω) :
    massDistance μ (roundedLaw μ N hN default) ≤ 2*Fintype.card Ω/N := by
  let ν := roundedLaw μ N hN default
  let low := fun x => (floorCounts μ N x : ℝ)/N
  have hpoint (x : Ω) : |μ.mass x-ν.mass x| ≤ (μ.mass x-low x)+(ν.mass x-low x) := by
    have hμ := (floor_atom_bounds μ N hN x).1
    have hν := roundedLaw_ge_floor μ N hN default x
    rw [abs_le]
    constructor <;> dsimp [ν,low] at * <;> linarith
  have htotal : (∑ x, ((μ.mass x-low x)+(ν.mass x-low x))) = 2*∑ x, (μ.mass x-low x) := by
    simp only [sum_add_distrib,sum_sub_distrib,μ.total,ν.total]
    ring
  have herr : (∑ x, (μ.mass x-low x)) ≤ (Fintype.card Ω:ℝ)/N := by
    have h := sum_le_sum (s := (univ : Finset Ω)) (fun x _ => (floor_atom_bounds μ N hN x).2)
    simpa only [sum_const,card_univ,nsmul_eq_mul,mul_one_div] using h
  calc
    _ ≤ ∑ x, ((μ.mass x-low x)+(ν.mass x-low x)) := sum_le_sum (fun x _ => hpoint x)
    _ = 2*∑ x, (μ.mass x-low x) := htotal
    _ ≤ 2*((Fintype.card Ω:ℝ)/N) := mul_le_mul_of_nonneg_left herr (by norm_num)
    _ = 2*Fintype.card Ω/N := by ring

end MatroidProphetSecretary.FiniteLaw
