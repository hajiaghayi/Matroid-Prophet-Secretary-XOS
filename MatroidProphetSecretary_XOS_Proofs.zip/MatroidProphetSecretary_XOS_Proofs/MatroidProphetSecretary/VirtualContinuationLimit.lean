import MatroidProphetSecretary.ContinuationMesh
import MatroidProphetSecretary.ControllerParameters

/-! Arbitrarily accurate finite virtual continuations with the paper's factor phi. -/

noncomputable section

namespace MatroidProphetSecretary

theorem exponential_exposure_budget (x omega : ℝ) (hx : 0 ≤ x)
    (homega : omega ≤ Real.exp (-x)) : omega*(1+x) ≤ 1 := by
  calc
    omega*(1+x) ≤ Real.exp (-x)*(1+x) := mul_le_mul_of_nonneg_right homega (by linarith)
    _ ≤ Real.exp (-x)*Real.exp x := mul_le_mul_of_nonneg_left
      (by linarith [Real.add_one_le_exp x]) (Real.exp_pos _).le
    _ = 1 := by rw [← Real.exp_add]; simp

theorem paper_exposure_budget {q : ℝ} (hq : q ∈ interval) :
    omega q*(1+(1-delta)*(1/q)) ≤ 1 := by
  apply exponential_exposure_budget
  · exact mul_nonneg (by norm_num [delta]) (one_div_pos.mpr (q_pos hq)).le
  · have he : Real.exp (-((1-delta)*(1/q))) = alpha q := by
      unfold alpha
      congr 1
      ring
    rw [he]
    exact sub_le_self _ (delta_div_q_bounds hq).1.le

theorem limiting_factor_eq_phi (q z : ℝ) :
    limitingContinuationFactor (1-delta) delta (1/q) (omega q) z = phi q z := by
  have he : Real.exp (-(1-delta)*(1/q)) = alpha q := by
    unfold alpha
    congr 1
    ring
  have hl : Real.exp (-delta*((1/q)/omega q)) = Real.exp (-(delta/q)/omega q) := by
    congr 1
    ring
  simp only [limitingContinuationFactor,he,hl,phi]
  ring

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem exists_finite_virtual_reward_above (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (hF : 0 < expectedOptimum μ M value) {q c : ℝ} (hq : q ∈ interval)
    (hc : c < phi q (overlap μ value base / expectedOptimum μ M value)) :
    ∃ cfg : FiniteContinuationConfig (Fintype.card E),
      c * expectedOptimum μ M value <
        (finiteContinuationLaw μ M base hbase value cfg (initialVirtualState M)).expect
          (finiteContinuationReward M base hbase value cfg (initialVirtualState M)) := by
  have hlim : c < limitingContinuationFactor (1-delta) delta (1/q) (omega q)
      (overlap μ value base / expectedOptimum μ M value) := by rwa [limiting_factor_eq_phi]
  obtain ⟨n,hn,hearly,hlate,hfactor⟩ := exists_mesh_factor_lower (Fintype.card E)
    (1-delta) delta (1/q) (omega q) (overlap μ value base / expectedOptimum μ M value) c hlim
  let cfg := meshContinuationConfig (Fintype.card E) (1-delta) delta (1/q) (omega q)
    (by norm_num [delta]) (by norm_num [delta]) (one_div_pos.mpr (q_pos hq)).le
    (lt_trans (by norm_num) (omega_positive hq)) (paper_exposure_budget hq) n hn hearly hlate
  refine ⟨cfg,?_⟩
  exact (mul_lt_mul_of_pos_right hfactor hF).trans_le
    (finite_virtual_reward_factor μ M base hbase value hv hopt hF cfg)

theorem finite_virtual_reward_with_loss (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (hF : 0 < expectedOptimum μ M value) {q loss : ℝ} (hq : q ∈ interval) (hloss : 0 < loss) :
    ∃ cfg : FiniteContinuationConfig (Fintype.card E),
      (phi q (overlap μ value base / expectedOptimum μ M value)-loss) * expectedOptimum μ M value <
        (finiteContinuationLaw μ M base hbase value cfg (initialVirtualState M)).expect
          (finiteContinuationReward M base hbase value cfg (initialVirtualState M)) :=
  exists_finite_virtual_reward_above μ M base hbase value hv hopt hF hq (sub_lt_self _ hloss)

end MatroidProphetSecretary
