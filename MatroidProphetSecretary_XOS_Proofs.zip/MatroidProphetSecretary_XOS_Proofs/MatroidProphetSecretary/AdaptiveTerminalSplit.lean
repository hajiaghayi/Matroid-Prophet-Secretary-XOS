import MatroidProphetSecretary.SupportedKernelTransfer

/-! Splitting a finite adaptive run into consecutive phases. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

variable {S W : Type*} [Fintype W]

theorem adaptive_terminal_add (batch : S → FiniteLaw W) (update : S → W → S)
    (n m : ℕ) (s : S) (F : S → ℝ) :
    (adaptiveBatches batch update (n+m) s).expect (fun x => F (stateAfter update (n+m) s x)) =
      (adaptiveBatches batch update n s).expect (fun x =>
        (adaptiveBatches batch update m (stateAfter update n s x)).expect
          (fun y => F (stateAfter update m (stateAfter update n s x) y))) := by
  have h := timed_terminal_add (fun _ => batch) update n m 0 s F
  simpa only [timedBatches_constant] using h

end MatroidProphetSecretary.FiniteLaw
