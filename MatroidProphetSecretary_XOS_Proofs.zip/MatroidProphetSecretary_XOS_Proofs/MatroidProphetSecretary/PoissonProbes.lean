import MatroidProphetSecretary.FiniteAbsence
import MatroidProphetSecretary.ProductMoments
import Mathlib.Probability.Distributions.Poisson
import Mathlib.Tactic.Ring

/-! Exact pass probability of independently sampled probes with a Poisson probe count. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical NNReal

theorem poisson_weighted_power_hasSum (r : ℝ≥0) (s : ℝ) :
    HasSum (fun n : ℕ => ProbabilityTheory.poissonPMFReal r n * s^n) (Real.exp ((r:ℝ)*(s-1))) := by
  have hs := (NormedSpace.expSeries_div_hasSum_exp ℝ ((r:ℝ)*s)).mul_left (Real.exp (-(r:ℝ)))
  rw [← Real.exp_eq_exp_ℝ] at hs
  have hterm (n : ℕ) : ProbabilityTheory.poissonPMFReal r n * s^n =
      Real.exp (-(r:ℝ))*(((r:ℝ)*s)^n / (n.factorial:ℝ)) := by
    rw [ProbabilityTheory.poissonPMFReal,mul_pow]
    ring
  have hval : Real.exp ((r:ℝ)*(s-1)) = Real.exp (-(r:ℝ))*Real.exp ((r:ℝ)*s) := by
    rw [← Real.exp_add]
    congr 1
    ring
  simpa only [hterm,hval] using hs

theorem poisson_weighted_power (r : ℝ≥0) (s : ℝ) :
    (∑' n : ℕ, ProbabilityTheory.poissonPMFReal r n * s^n) = Real.exp ((r:ℝ)*(s-1)) :=
  (poisson_weighted_power_hasSum r s).tsum_eq

variable {Ω : Type*} [Fintype Ω]

def poissonProbePassProbability (r : ℝ≥0) (probe : FiniteLaw Ω) (bad : Ω → Prop) : ℝ :=
  ∑' n : ℕ, ProbabilityTheory.poissonPMFReal r n *
    (FiniteLaw.product (fun _ : Fin n => probe)).prob (fun x => ∀ i, ¬ bad (x i))

theorem iid_probe_pass_probability (probe : FiniteLaw Ω) (bad : Ω → Prop) (n : ℕ) :
    (FiniteLaw.product (fun _ : Fin n => probe)).prob (fun x => ∀ i, ¬ bad (x i)) = (1-probe.prob bad)^n := by
  have h := FiniteLaw.product_prob_coordinates (fun _ : Fin n => probe) (fun _ w => ¬ bad w)
  simp only [Finset.prod_const,Finset.card_univ,Fintype.card_fin] at h
  have hn : probe.prob (fun w => ¬ bad w) = 1-probe.prob bad := by
    convert FiniteLaw.prob_not probe bad using 1
  rw [hn] at h
  convert h using 1
  unfold FiniteLaw.prob
  congr 1
  funext x
  split_ifs <;> rfl

theorem poisson_probe_pass_probability (r : ℝ≥0) (probe : FiniteLaw Ω) (bad : Ω → Prop) :
    poissonProbePassProbability r probe bad = Real.exp (-(r:ℝ)*probe.prob bad) := by
  unfold poissonProbePassProbability
  simp_rw [iid_probe_pass_probability]
  rw [poisson_weighted_power]
  congr 1
  ring

theorem early_poisson_probe_pass (probe : FiniteLaw Ω) (bad : Ω → Prop) (Λ : ℝ)
    (hprobe : probe.prob bad = Λ/2) :
    poissonProbePassProbability 2 probe bad = Real.exp (-Λ) := by
  rw [poisson_probe_pass_probability,hprobe]
  congr 1
  norm_num <;> ring

end MatroidProphetSecretary
