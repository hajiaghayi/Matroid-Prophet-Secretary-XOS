import MatroidProphetSecretary.FiniteCompetitiveness
import MatroidProphetSecretary.FinitePriorObservables

/-! Competitiveness for rational value supports with arbitrary real marginal probabilities. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem finite_rational_prior_reference_one {N k : ℕ} (M : Matroid (Fin N)) (prior : RationalPriors N k) :
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      discount 1*expectedProphet M prior ≤ expectedPolicyReward prior policy := by
  obtain ⟨policy,hf,hr⟩ := reference_policy_exists N k M prior 1 (by norm_num [interval,delta])
  have hone := referenceExpectedOptimum_one_general prior.law M (fun e v => (prior.value e v : ℝ))
    (fun e v => by change (0:ℝ) ≤ (prior.value e v:ℝ); exact_mod_cast prior.value_nonneg e v)
  exact ⟨policy,hf,by simpa only [hone] using hr⟩

theorem finite_real_probability_competitive {N k : ℕ} (hk : 0 < k) (M : Matroid (Fin N))
    (value : Fin N → Fin k → ℚ) (hv : ∀ e v, 0 ≤ value e v) (laws : Fin N → FiniteLaw (Fin k))
    (c : ℝ) (hc : c < discount 1) :
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      c*expectedOptimum (FiniteLaw.product laws) M (coordinateValues (fun e v => (value e v : ℝ))) ≤
        finitePriorReward laws (fun e v => (value e v : ℝ)) policy := by
  let val := fun e v => (value e v : ℝ)
  let F := expectedOptimum (FiniteLaw.product laws) M (coordinateValues val)
  let B := inputValueBudget val
  let C := discount 1
  have hval (e : Fin N) (v : Fin k) : 0 ≤ val e v := by
    change (0:ℝ) ≤ (value e v:ℝ)
    exact_mod_cast hv e v
  have hF0 : 0 ≤ F := FiniteLaw.expect_nonneg _ (fun x => optimum_nonneg M _)
  have hB : 0 ≤ B := inputValueBudget_nonneg val hval
  have hC : 0 < C := by norm_num [C,discount,theta]
  by_cases hz : F = 0
  · refine ⟨rejectAllPolicy N,rejectAll_feasible M,?_⟩
    change c*F ≤ _
    rw [hz,mul_zero,finitePriorReward_reject]
  have hF : 0 < F := lt_of_le_of_ne hF0 (Ne.symm hz)
  let T := (1+C)*(N+1)*(B+1)
  have hT : 0 < T := by dsimp [T]; positivity
  let err := (C-c)*F/(2*T)
  have herr : 0 < err := div_pos (mul_pos (sub_pos.mpr hc) hF) (by positivity)
  have hscale : 2*T*err = (C-c)*F := by
    dsimp [err]
    field_simp
  obtain ⟨prior,hvalues,happrox⟩ := exists_rational_prior_approximation value hv laws ⟨0,hk⟩ err herr
  obtain ⟨policy,hfeasible,hreward⟩ := finite_rational_prior_reference_one M prior
  have hopt : expectedProphet M prior = expectedOptimum (FiniteLaw.product prior.law) M (coordinateValues val) := by
    have heq : prior.realization = fun x => coordinateValues val x := by
      funext x e
      change (prior.value e (x e) : ℝ) = _
      rw [hvalues]
      rfl
    unfold expectedProphet expectedOptimum
    rw [heq]
  have hrew : expectedPolicyReward prior policy = finitePriorReward prior.law val policy := by
    have h := finitePriorReward_of_rational prior policy
    rw [hvalues] at h
    exact h.symm
  rw [hopt,hrew] at hreward
  have herrs := finite_prior_observable_approximation laws prior.law val hval M policy err (fun e => (happrox e).le)
  have hbudget : (1+C)*(N:ℝ)*B ≤ T := by
    dsimp [T]
    gcongr <;> linarith
  have hbudget' : (1+C)*(N:ℝ)*err*B ≤ T*err := by
    nlinarith [mul_le_mul_of_nonneg_right hbudget herr.le]
  have hopt' := (abs_le.mp herrs.1).2
  have hrew' := (abs_le.mp herrs.2).1
  refine ⟨policy,hfeasible,?_⟩
  change c*F ≤ _
  change F-_ ≤ N*err*B at hopt'
  change -(N*err*B) ≤ _ at hrew'
  change C*_ ≤ _ at hreward
  nlinarith

theorem finite_real_probability_beta {N k : ℕ} (hk : 0 < k) (M : Matroid (Fin N))
    (value : Fin N → Fin k → ℚ) (hv : ∀ e v, 0 ≤ value e v) (laws : Fin N → FiniteLaw (Fin k)) :
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      beta*expectedOptimum (FiniteLaw.product laws) M (coordinateValues (fun e v => (value e v : ℝ))) ≤
        finitePriorReward laws (fun e v => (value e v : ℝ)) policy :=
  finite_real_probability_competitive hk M value hv laws beta (by norm_num [beta,discount,rho])

end MatroidProphetSecretary

