import MatroidProphetSecretary.LatentValueOrder
import MatroidProphetSecretary.ActiveGreedyRank
import MatroidProphetSecretary.BlockResampling

/-! The forward/reverse overlap and variance inequalities for an independent latent layer. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
    {V : E → Type*} [∀ e, Fintype (V e)]

def latentForward (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) : ℝ :=
  (FiniteLaw.product latent).expect (fun x =>
    selectedProbability activity M e (priorityBefore (fun f => value f (x f)) e))

def latentReverse (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) : ℝ :=
  (FiniteLaw.product latent).expect (fun x =>
    selectedProbability activity M e (fun f => priorityBefore (fun g => value g (x g)) f e))

theorem latentForward_factor (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) :
    latentForward activity latent M value e = activityProbability activity e *
      (FiniteLaw.product latent).expect (fun x =>
        nonspanProbability activity M e (priorityBefore (fun f => value f (x f)) e)) := by
  simp only [latentForward, selectedProbability_eq_factor, FiniteLaw.expect_const_mul]

theorem latentReverse_factor (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) :
    latentReverse activity latent M value e = activityProbability activity e *
      (FiniteLaw.product latent).expect (fun x =>
        nonspanProbability activity M e (fun f => priorityBefore (fun g => value g (x g)) f e)) := by
  simp only [latentReverse, selectedProbability_eq_factor, FiniteLaw.expect_const_mul]

theorem latentForward_bounds (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) :
    0 ≤ latentForward activity latent M value e ∧
      latentForward activity latent M value e ≤ activityProbability activity e := by
  constructor
  · exact (FiniteLaw.product latent).expect_nonneg (fun x =>
      (FiniteLaw.product activity).prob_nonneg _)
  · simpa only [FiniteLaw.expect_const] using
      (FiniteLaw.product latent).expect_mono (fun x => selectedProbability_le_activity activity M e _)

theorem latentReverse_bounds (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) :
    activityProbability activity e * nonspanProbability activity M e (fun _ => True) ≤
        latentReverse activity latent M value e ∧
      latentReverse activity latent M value e ≤ activityProbability activity e := by
  constructor
  · simpa only [FiniteLaw.expect_const] using
      (FiniteLaw.product latent).expect_mono (fun x => coloop_probability_le_selected activity M e
        (fun f => priorityBefore (fun g => value g (x g)) f e))
  · simpa only [FiniteLaw.expect_const] using
      (FiniteLaw.product latent).expect_mono (fun x => selectedProbability_le_activity activity M e
        (fun f => priorityBefore (fun g => value g (x g)) f e))

theorem latent_overlap_product (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) :
    (activityProbability activity e) ^ 2 * nonspanProbability activity M e (fun _ => True) ≤
      latentForward activity latent M value e * latentReverse activity latent M value e := by
  rw [latentForward_factor, latentReverse_factor]
  have h := mul_le_mul_of_nonneg_left (independent_latent_value_bound activity latent M e value)
    (sq_nonneg (activityProbability activity e))
  nlinarith only [h]

theorem latent_reverse_variance (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (value : ∀ e, V e → ℝ) (e : E) :
    activityProbability activity e * (1 - activityProbability activity e) *
        nonspanProbability activity M e (fun _ => True) ≤
      latentReverse activity latent M value e * (1 - latentReverse activity latent M value e) := by
  have hb := latentReverse_bounds activity latent M value e
  have hp0 : 0 ≤ activityProbability activity e := (FiniteLaw.product activity).prob_nonneg _
  have hp1 : activityProbability activity e ≤ 1 := (FiniteLaw.product activity).prob_le_one _
  have hr0 := (nonspanProbability_bounds activity M e (fun _ => True)).1
  have hx0 := (mul_nonneg hp0 hr0).trans hb.1
  have h := mul_le_mul hb.1 (sub_le_sub_left hb.2 1) (sub_nonneg.mpr hp1) hx0
  nlinarith only [h]

theorem latentForward_sum_eq_rank (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) :
    (∑ e, latentForward activity latent M value e) =
      (FiniteLaw.product activity).expect (fun x => realRank M (bitSet x)) := by
  unfold latentForward
  rw [← FiniteLaw.expect_finset_sum]
  simp_rw [selectedProbability_sum_eq_rank activity M hground]
  exact FiniteLaw.expect_const _ _

theorem latentReverse_sum_eq_rank (activity : E → FiniteLaw Bool) (latent : ∀ e, FiniteLaw (V e))
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) :
    (∑ e, latentReverse activity latent M value e) =
      (FiniteLaw.product activity).expect (fun x => realRank M (bitSet x)) := by
  unfold latentReverse
  rw [← FiniteLaw.expect_finset_sum]
  simp_rw [reverse_selectedProbability_sum_eq_rank activity M hground]
  exact FiniteLaw.expect_const _ _

end MatroidProphetSecretary
