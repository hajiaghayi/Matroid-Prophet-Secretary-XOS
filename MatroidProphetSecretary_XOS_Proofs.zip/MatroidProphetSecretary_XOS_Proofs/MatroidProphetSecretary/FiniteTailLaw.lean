import MatroidProphetSecretary.FiniteConditioning
import MatroidProphetSecretary.ReferenceScreen
import Mathlib.Algebra.BigOperators.Fin

/-! A reference law from adjacent saturated tails of a finite ordered prior. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem sum_fin_tail_differences (n : ℕ) (f : ℕ → ℝ) :
    (∑ i : Fin n, (f i.val - f (i.val + 1))) = f 0 - f n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Fin.sum_univ_castSucc]
    simp only [Fin.coe_castSucc, Fin.val_last]
    rw [ih]
    ring

theorem sum_fin_tail_differences_from (n k : ℕ) (f : ℕ → ℝ) :
    (∑ i : Fin n, if k ≤ i.val then f i.val - f (i.val + 1) else 0) = f (min k n) - f n := by
  induction n generalizing k f with
  | zero => simp
  | succ n ih =>
    cases k with
    | zero => simpa using sum_fin_tail_differences (n+1) f
    | succ k =>
      rw [Fin.sum_univ_succ]
      simp only [Fin.val_zero, Nat.not_succ_le_zero, if_false, zero_add, Fin.val_succ, Nat.succ_le_succ_iff]
      rw [ih k (fun i => f (i+1))]
      simp [Nat.succ_eq_add_one, min_add_add_right]

def finiteIndexTail {n : ℕ} (μ : FiniteLaw (Fin n)) (k : ℕ) : ℝ := μ.prob (fun i => k ≤ i.val)

theorem finiteIndexTail_antitone {n : ℕ} (μ : FiniteLaw (Fin n)) : Antitone (finiteIndexTail μ) := by
  intro k l hkl
  apply FiniteLaw.prob_mono
  intro i hi
  exact hkl.trans hi

theorem finiteIndexTail_zero {n : ℕ} (μ : FiniteLaw (Fin n)) : finiteIndexTail μ 0 = 1 := by
  simp [finiteIndexTail, FiniteLaw.prob]

theorem finiteIndexTail_end {n : ℕ} (μ : FiniteLaw (Fin n)) : finiteIndexTail μ n = 0 := by
  have hn (i : Fin n) : ¬ n ≤ i.val := not_le_of_gt i.isLt
  simp [finiteIndexTail, FiniteLaw.prob, hn]

def scaledIndexTail {n : ℕ} (μ : FiniteLaw (Fin n)) (q : ℝ) (k : ℕ) : ℝ :=
  min 1 (q * finiteIndexTail μ k)

theorem scaledIndexTail_antitone {n : ℕ} (μ : FiniteLaw (Fin n)) (q : ℝ) (hq : 0 ≤ q) :
    Antitone (scaledIndexTail μ q) := fun _ _ h => min_le_min_left 1
      (mul_le_mul_of_nonneg_left (finiteIndexTail_antitone μ h) hq)

theorem scaledIndexTail_end {n : ℕ} (μ : FiniteLaw (Fin n)) (q : ℝ) : scaledIndexTail μ q n = 0 := by
  simp [scaledIndexTail, finiteIndexTail_end]

def finiteReferenceLaw {n : ℕ} (μ : FiniteLaw (Fin n)) (q : ℝ) (hq : 0 ≤ q) : FiniteLaw (Option (Fin n)) where
  mass x := match x with
    | none => 1 - scaledIndexTail μ q 0
    | some i => scaledIndexTail μ q i.val - scaledIndexTail μ q (i.val + 1)
  nonneg x := by
    cases x with
    | none => exact sub_nonneg.mpr (min_le_left _ _)
    | some i => exact sub_nonneg.mpr (scaledIndexTail_antitone μ q hq (Nat.le_succ _))
  total := by
    rw [Fintype.sum_option]
    rw [sum_fin_tail_differences]
    rw [scaledIndexTail_end]
    ring

theorem finiteReferenceLaw_index_tail {n : ℕ} (μ : FiniteLaw (Fin n)) (q : ℝ) (hq : 0 ≤ q)
    (k : ℕ) (hk : k ≤ n) :
    (finiteReferenceLaw μ q hq).prob (fun x => ∃ i, x = some i ∧ k ≤ i.val) = scaledIndexTail μ q k := by
  simp only [FiniteLaw.prob, FiniteLaw.expect, Fintype.sum_option, finiteReferenceLaw,
    false_and, exists_false, if_false, mul_zero, zero_add,
    Option.some.injEq, exists_eq_left', exists_eq_right]
  have hid : (∑ i : Fin n, (scaledIndexTail μ q i.val - scaledIndexTail μ q (i.val + 1)) *
      if k ≤ i.val then 1 else 0) =
      ∑ i : Fin n, if k ≤ i.val then scaledIndexTail μ q i.val - scaledIndexTail μ q (i.val + 1) else 0 := by
    apply sum_congr rfl
    intro i hi
    split_ifs <;> simp
  rw [hid, sum_fin_tail_differences_from, min_eq_left hk, scaledIndexTail_end, sub_zero]
  simp

end MatroidProphetSecretary
