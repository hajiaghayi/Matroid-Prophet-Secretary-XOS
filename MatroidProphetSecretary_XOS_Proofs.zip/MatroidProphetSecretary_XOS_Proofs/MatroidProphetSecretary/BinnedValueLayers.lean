import MatroidProphetSecretary.HeightGrid
import MatroidProphetSecretary.ValueActivity
import MatroidProphetSecretary.LayerEstimators

/-! Exact finite bin sums for statistics of independently sampled value layers. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

abbrev ValueHeightGrid (value : ∀ e, V e → ℝ) :=
  HeightGrid (fun a : Σ e, V e => value a.1 a.2)

def positiveActivityExpectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (φ : (E → ℝ) → (E → Bool) → ℝ) (z : ℝ) : ℝ :=
  if 0 < z then (FiniteLaw.product (activityLaws laws value z)).expect
    (φ (coordinateTail laws value z)) else 0

theorem valueActivity_grid_constant (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value)
    (k : ℕ) (z : ℝ) (hz : z ∈ Set.Ioo (G.level k) (G.level (k+1))) (x : ∀ e, V e) :
    valueActivity value z x = valueActivity value (G.level k) x := by
  funext e
  simp only [valueActivity, G.tail_constant ⟨e, x e⟩ k z hz]

theorem activityLaws_grid_constant (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (k : ℕ) (z : ℝ)
    (hz : z ∈ Set.Ioo (G.level k) (G.level (k+1))) :
    activityLaws laws value z = activityLaws laws value (G.level k) := by
  funext e
  unfold activityLaws
  congr 1
  funext x
  simp only [G.tail_constant ⟨e,x⟩ k z hz]

theorem coordinateTail_grid_constant (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (k : ℕ) (z : ℝ)
    (hz : z ∈ Set.Ioo (G.level k) (G.level (k+1))) :
    coordinateTail laws value z = coordinateTail laws value (G.level k) := by
  funext e
  apply FiniteLaw.prob_congr
  intro x
  exact G.tail_constant ⟨e,x⟩ k z hz

theorem positiveActivityExpectation_top_zero (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value)
    (φ : (E → ℝ) → (E → Bool) → ℝ) (hφ : ∀ p, φ p (fun _ => false) = 0)
    (z : ℝ) (hz : G.level G.last ≤ z) : positiveActivityExpectation laws value φ z = 0 := by
  have he (e : E) (x : V e) : ¬ z < value e x :=
    not_lt_of_ge ((G.value_le_top ⟨e,x⟩).trans hz)
  have hempty (x : ∀ e, V e) : (fun e => decide (z < value e (x e))) = fun _ => false := by
    funext e
    exact decide_eq_false (he e (x e))
  unfold positiveActivityExpectation
  split_ifs
  · unfold activityLaws
    rw [FiniteLaw.product_map_expect]
    simp only [hempty, hφ, FiniteLaw.expect_const]
  · rfl

theorem positiveActivityExpectation_bins (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value)
    (φ : (E → ℝ) → (E → Bool) → ℝ) (hφ : ∀ p, φ p (fun _ => false) = 0)
    (hf : Integrable (positiveActivityExpectation laws value φ)) :
    (∫ z, positiveActivityExpectation laws value φ z) =
      ∑ j : Fin G.last, (G.level (j.val+1) - G.level j.val) *
        (FiniteLaw.product (activityLaws laws value (G.level j.val))).expect
          (φ (coordinateTail laws value (G.level j.val))) := by
  rw [Fin.sum_univ_eq_sum_range (fun k => (G.level (k+1) - G.level k) *
    (FiniteLaw.product (activityLaws laws value (G.level k))).expect
      (φ (coordinateTail laws value (G.level k))))]
  apply G.integral_eq_sum _ hf
  · intro z hz
    rcases hz with hz | hz
    · simp [positiveActivityExpectation, not_lt_of_ge hz]
    · exact positiveActivityExpectation_top_zero laws value G φ hφ z hz
  · intro k hk z hz
    have hzpos : 0 < z := (G.nonneg k).trans_lt hz.1
    simp only [positiveActivityExpectation, if_pos hzpos,
      activityLaws_grid_constant laws value G k z hz,
      coordinateTail_grid_constant laws value G k z hz]

def heightBinWidth (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) (j : Fin G.last) : ℝ :=
  G.level (j.val+1) - G.level j.val

def heightBinLaws (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (j : Fin G.last) : E → FiniteLaw Bool :=
  activityLaws laws value (G.level j.val)

theorem heightBinWidth_nonneg (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value)
    (j : Fin G.last) : 0 ≤ heightBinWidth value G j := G.width_nonneg j.val

theorem heightBin_activityProbability (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (G : ValueHeightGrid value) (j : Fin G.last) (e : E) :
    activityProbability (heightBinLaws laws value G j) e =
      coordinateTail laws value (G.level j.val) e := by
  unfold activityProbability heightBinLaws
  rw [FiniteLaw.product_prob_coordinate, activityLaws_true_mass]

end MatroidProphetSecretary
