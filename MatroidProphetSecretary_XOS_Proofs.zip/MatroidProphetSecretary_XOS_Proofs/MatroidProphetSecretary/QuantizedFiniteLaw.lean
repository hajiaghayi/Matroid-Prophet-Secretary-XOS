import MatroidProphetSecretary.FiniteMeasureLaw
import MatroidProphetSecretary.RationalValueQuantization
import MatroidProphetSecretary.FinitePriorObservables

/-! Independent rounded values induce the finite marginal laws required by the finite competitiveness theorem. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory ProbabilityTheory

def quantizedMarginal {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (n : ℕ) (e : Fin N) : FiniteLaw (Fin ((n+1)^2+1)) :=
  finiteRandomVariableLaw μ (fun ω => quantizeIndex n (X e ω)) ((measurable_quantizeIndex n).comp (hX e))

theorem quantized_independent_integral {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hind : iIndepFun X μ) (n : ℕ)
    (f : (Fin N → Fin ((n+1)^2+1)) → ℝ) :
    (∫ ω, f (fun e => quantizeIndex n (X e ω)) ∂μ) =
      (FiniteLaw.product (quantizedMarginal μ X hX n)).expect f := by
  exact independent_finite_integral μ (fun e ω => quantizeIndex n (X e ω))
    (fun e => (measurable_quantizeIndex n).comp (hX e))
    (hind.comp (fun _ => quantizeIndex n) (fun _ => measurable_quantizeIndex n)) f

theorem quantized_optimum_integral {Ω : Type*} [MeasurableSpace Ω] {N : ℕ}
    (μ : Measure Ω) [IsProbabilityMeasure μ] (M : Matroid (Fin N)) (X : Fin N → Ω → ℝ)
    (hX : ∀ e, Measurable (X e)) (hind : iIndepFun X μ) (n : ℕ) :
    (∫ ω, optimum M (fun e => rationalRound n (X e ω)) ∂μ) =
      expectedOptimum (FiniteLaw.product (quantizedMarginal μ X hX n)) M
        (coordinateValues (fun _ i => (quantizeValue n i : ℝ))) := by
  exact quantized_independent_integral μ X hX hind n
    (fun x => optimum M (coordinateValues (fun _ i => (quantizeValue n i : ℝ)) x))

end MatroidProphetSecretary
