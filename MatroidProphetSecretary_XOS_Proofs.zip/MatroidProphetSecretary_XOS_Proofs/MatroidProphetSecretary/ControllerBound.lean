import MatroidProphetSecretary.ControllerParameters

noncomputable section

namespace MatroidProphetSecretary

set_option maxHeartbeats 1000000

/-- The scalar continuation bound (9.5). The inputs are numerical
inequalities, not stochastic survival assumptions. -/
theorem controller_scalar_bound (A W x d l z : ℝ)
    (hAlo : 367 / 1000 < A) (hAhi : A < 369 / 1000)
    (hW : 183 / 500 < W) (hWx : W = A - x)
    (hx : 0 < x) (hxhi : x < 1 / 2000)
    (hd : 0 < d) (hl : 499 / 500 < l) (hl2 : l ^ 2 ≤ 251 / 250)
    (hxl : x = d * l) (hz : 0 ≤ z) :
    1 - A * Real.exp (-x) + (23 / 100) * d * z - (8 / 25) * d ^ 2 ≤
      1 - A + A * W * (1 - Real.exp (-x / W)) * (1 + (1 - A) * z) := by
  have hA : 0 < A := by linarith
  have hW0 : 0 < W := by linarith
  have hl0 : 0 < l := by linarith
  have hA1 : 0 < 1 - A := by linarith
  have hu0 : 0 ≤ x / W := (div_pos hx hW0).le
  have hu1 : x / W ≤ 1 := (div_le_one hW0).mpr (by linarith)
  have ht := exp_neg_quadratic_upper hu0 hu1
  have hneg : -(x / W) = -x / W := by ring
  rw [hneg] at ht
  set L := A * W * (1 - Real.exp (-x / W)) with hLdef
  set R := 1 - x / (2 * W) with hRdef
  have hL : A * x * R ≤ L := by
    have hh := mul_le_mul_of_nonneg_left
      (show x / W - (x / W) ^ 2 / 2 ≤ 1 - Real.exp (-x / W) by linarith)
      (mul_pos hA hW0).le
    have hid : A * W * (x / W - (x / W) ^ 2 / 2) = A * x * R := by
      dsimp [R]
      field_simp
      <;> ring
    rw [hid] at hh
    exact hh
  have hfrac : x / (2 * W) < 1 / 1464 := by
    apply (div_lt_iff₀ (by positivity : 0 < 2 * W)).mpr
    linarith
  have hR : 1463 / 1464 < R := by dsimp [R]; linarith
  have hR0 : 0 < R := lt_trans (by norm_num) hR
  have hAx : A * x < (369 / 1000) * (1 / 2000) :=
    mul_lt_mul hAhi hxhi.le hx (by norm_num)
  set C := (1 - A) / 2 + x / (2 * W) + (2 / 9) * A * x with hCdef
  have hC : C ≤ 159 / 500 := by
    dsimp [C]
    linarith
  have hcost : x ^ 2 * C ≤ (8 / 25) * d ^ 2 := by
    have hc := mul_le_mul_of_nonneg_right hC (sq_nonneg l)
    have hc' : l ^ 2 * C ≤ 8 / 25 := by nlinarith
    have hh := mul_le_mul_of_nonneg_right hc' (sq_nonneg d)
    rw [hxl]
    nlinarith
  have hlow := exp_neg_cubic_lower hx.le (by linarith : x ≤ 1)
  have hweighted := mul_le_mul_of_nonneg_left hlow hA.le
  have hidentity : A * (1 - x + x ^ 2 / 2 - (2 / 9) * x ^ 3 - 1) +
      A * x * R = -(x ^ 2 * C) := by
    dsimp [R, C]
    rw [hWx]
    have hAxne : A - x ≠ 0 := by rw [← hWx]; exact ne_of_gt hW0
    field_simp [hAxne]
    <;> ring
  clear_value L R C
  have hconstant : -(8 / 25) * d ^ 2 ≤ L + A * (Real.exp (-x) - 1) := by
    nlinarith only [hcost, hidentity, hweighted, hL]
  have hg0 : (499 / 500) * (367 / 1000) * (631 / 1000) * (1463 / 1464) ≤
      l * A * (1 - A) * R := by
    gcongr <;> linarith
  have hg : (23 / 100) * d ≤ L * (1 - A) := by
    have h1 := mul_le_mul_of_nonneg_right hL hA1.le
    have h2 : 23 / 100 ≤ l * A * (1 - A) * R := by linarith
    have h3 := mul_le_mul_of_nonneg_left h2 hd.le
    rw [hxl] at h1
    nlinarith only [h1, h3]
  have hgz := mul_le_mul_of_nonneg_right hg hz
  nlinarith only [hconstant, hgz]

theorem controller_uniform_bound {q z : ℝ} (hq : q ∈ interval) (hz : 0 ≤ z) :
    1 - Real.exp (-(1 / q)) + (23 / 100) * delta * z - (8 / 25) * delta ^ 2 ≤ phi q z := by
  have hl := inverse_q_bounds hq
  have hx := delta_div_q_bounds hq
  have ha := alpha_bounds hq
  have hlupper : 1 / q ≤ 512 / 511 :=
    (div_le_iff₀ (q_pos hq)).mpr (by linarith [(interval_bounds hq).1])
  have hl2 : (1 / q) ^ 2 ≤ 251 / 250 := by nlinarith
  have h := controller_scalar_bound (alpha q) (omega q) (delta / q) delta (1 / q) z
    ha.1 ha.2 (omega_positive hq) rfl hx.1 hx.2 (by norm_num [delta]) hl.1 hl2
    (by ring) hz
  have hid : alpha q * Real.exp (-(delta / q)) = Real.exp (-(1 / q)) := by
    unfold alpha
    rw [← Real.exp_add]
    congr 1
    ring
  rw [hid] at h
  exact h

theorem stability_parameter_condition {q : ℝ} (hq : q ∈ interval) :
    discount q < phi q (overlapCutoff q) := by
  have hz := overlap_cutoff_bound hq
  have h := controller_uniform_bound hq (by linarith : 0 ≤ overlapCutoff q)
  have hg := affine_gap_uniform hq
  simp only [one_div] at hg
  norm_num [delta] at h
  linarith

theorem guard_parameter_condition {q : ℝ} (hq : q ∈ interval)
    (hguard : 3 * delta ≤ |q - 1|) : discount q < phi q 0 := by
  have h := controller_uniform_bound hq (le_refl (0 : ℝ))
  have hg := affine_gap_quadratic hq
  simp only [one_div] at hg
  have hs : (3 * delta) ^ 2 ≤ (q - 1) ^ 2 := by
    have := sq_abs (q - 1)
    have hd : 0 < delta := by norm_num [delta]
    nlinarith
  dsimp [discount]
  norm_num [delta] at h hs
  linarith

end MatroidProphetSecretary
