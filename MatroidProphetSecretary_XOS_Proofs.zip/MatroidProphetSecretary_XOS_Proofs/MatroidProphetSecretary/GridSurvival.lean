import MatroidProphetSecretary.SurvivalSegments
import MatroidProphetSecretary.ProductMoments
import MatroidProphetSecretary.ConditionalSampling
import MatroidProphetSecretary.FiniteAbsence

/-! Finite probes realize the multiplicative survival needed by grid attenuation. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def gridSurvival (dose : ℕ → ℝ) (n : ℕ) : ℝ := ∏ i ∈ range n, (1-dose i)

theorem gridSurvival_zero (dose : ℕ → ℝ) : gridSurvival dose 0 = 1 := by
  simp [gridSurvival]

theorem gridSurvival_step (dose : ℕ → ℝ) (n : ℕ) :
    gridSurvival dose (n+1) = gridSurvival dose n*(1-dose n) := by
  simp [gridSurvival,prod_range_succ]

theorem gridSurvival_pos (dose : ℕ → ℝ) (hdose : ∀ i, dose i < 1) (n : ℕ) :
    0 < gridSurvival dose n := prod_pos (fun i _ => sub_pos.mpr (hdose i))

theorem gridSurvival_mass (dose : ℕ → ℝ) (n : ℕ) :
    (∑ i ∈ range n, gridSurvival dose i*dose i) = 1-gridSurvival dose n := by
  induction n with
  | zero => simp [gridSurvival_zero]
  | succ n ih => rw [sum_range_succ,ih,gridSurvival_step]; ring

theorem gridSurvival_lower (dose : ℕ → ℝ) (r : ℝ)
    (hr : r ≤ 1) (hdose : ∀ i, dose i ≤ r) (n : ℕ) :
    (1-r)^n ≤ gridSurvival dose n := by
  induction n with
  | zero => simp [gridSurvival_zero]
  | succ n ih =>
    rw [pow_succ,gridSurvival_step]
    exact mul_le_mul ih (sub_le_sub_left (hdose n) _) (sub_nonneg.mpr hr)
      ((pow_nonneg (sub_nonneg.mpr hr) n).trans ih)

theorem gridSurvival_exp_upper (dose : ℕ → ℝ) (hdose : ∀ i, dose i ≤ 1) (n : ℕ) :
    gridSurvival dose n ≤ Real.exp (-accumulatedExposure dose n) := by
  induction n with
  | zero => simp [gridSurvival,accumulatedExposure]
  | succ n ih =>
    rw [gridSurvival_step]
    have hfactor : 1-dose n ≤ Real.exp (-dose n) := by linarith [Real.add_one_le_exp (-dose n)]
    have h := mul_le_mul ih hfactor (sub_nonneg.mpr (hdose n)) (Real.exp_pos _).le
    convert h using 1
    simp only [accumulatedExposure,sum_range_succ,neg_add,Real.exp_add]

theorem gridSurvival_inverse_exposure (dose : ℕ → ℝ)
    (hdose0 : ∀ i, 0 ≤ dose i) (hdose1 : ∀ i, dose i < 1) (n : ℕ) :
    1+accumulatedExposure dose n ≤ 1/gridSurvival dose n := by
  have hlow := gridSurvival_pos dose hdose1 n
  have hu := gridSurvival_exp_upper dose (fun i => (hdose1 i).le) n
  have hd := one_div_le_one_div_of_le hlow hu
  rw [Real.exp_neg,div_inv_eq_mul,one_mul] at hd
  have he : 1+accumulatedExposure dose n ≤ Real.exp (accumulatedExposure dose n) := by
    linarith [Real.add_one_le_exp (accumulatedExposure dose n)]
  exact he.trans hd

theorem grid_early_intensity (dose : ℕ → ℝ) (hdose : ∀ i, dose i < 1)
    (n : ℕ) (lam k : ℝ) :
    lam*gridSurvival dose n*k / gridSurvival dose n = lam*k := by
  have hp := (gridSurvival_pos dose hdose n).ne'
  field_simp
  <;> ring

theorem grid_late_rate_bounds (dose : ℕ → ℝ)
    (hdose0 : ∀ i, 0 ≤ dose i) (hdose1 : ∀ i, dose i < 1)
    (n : ℕ) (lam integralK omega : ℝ) (hlam : 0 ≤ lam) (hK : 0 ≤ integralK)
    (homega : 0 < omega) (hlower : omega ≤ gridSurvival dose n-lam*integralK) :
    lam*(1+accumulatedExposure dose n) ≤ lam/(gridSurvival dose n-lam*integralK) ∧
      lam/(gridSurvival dose n-lam*integralK) ≤ lam/omega := by
  have hS := homega.trans_le hlower
  constructor
  · have h1 := mul_le_mul_of_nonneg_left (gridSurvival_inverse_exposure dose hdose0 hdose1 n) hlam
    have h2 := div_le_div_of_nonneg_left hlam hS
      (show gridSurvival dose n-lam*integralK ≤ gridSurvival dose n from sub_le_self _ (mul_nonneg hlam hK))
    rw [mul_one_div] at h1
    exact h1.trans h2
  · exact div_le_div_of_nonneg_left hlam homega hlower

variable {Ω I : Type*} [Fintype Ω] [Fintype I] [DecidableEq I]

def finiteProbeLaw (μ : FiniteLaw Ω) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1) : FiniteLaw (Bool × Ω) :=
  (bernoulliLaw p hp0 hp1).pair μ

def finiteProbePass (A : Ω → Prop) (x : Bool × Ω) : Prop := ¬ (x.1 = true ∧ A x.2)

theorem finiteProbePass_probability (μ : FiniteLaw Ω) (p : ℝ) (hp0 : 0 ≤ p) (hp1 : p ≤ 1)
    (A : Ω → Prop) :
    (finiteProbeLaw μ p hp0 hp1).prob (finiteProbePass A) = 1-p*μ.prob A := by
  unfold finiteProbePass finiteProbeLaw FiniteLaw.prob
  rw [FiniteLaw.pair_expect,bernoulliLaw_expect]
  simp only [Bool.false_eq_true,eq_self_iff_true,true_and,false_and,not_false_eq_true,if_true,FiniteLaw.expect_const]
  have hpoint : (fun w => if ¬ A w then (1 : ℝ) else 0) =
      (fun w => 1-(if A w then 1 else 0)) := by
    funext w
    by_cases hw : A w <;> simp [hw]
  rw [hpoint,FiniteLaw.expect_sub,FiniteLaw.expect_const]
  ring

theorem independent_finite_probes (laws : I → FiniteLaw Ω) (p : I → ℝ)
    (hp0 : ∀ i, 0 ≤ p i) (hp1 : ∀ i, p i ≤ 1) (A : I → Ω → Prop) :
    (FiniteLaw.product (fun i => finiteProbeLaw (laws i) (p i) (hp0 i) (hp1 i))).prob
      (fun x => ∀ i, finiteProbePass (A i) (x i)) =
      ∏ i, (1-p i*(laws i).prob (A i)) := by
  rw [FiniteLaw.product_prob_coordinates
    (fun i => finiteProbeLaw (laws i) (p i) (hp0 i) (hp1 i))
    (fun i x => finiteProbePass (A i) x)]
  apply prod_congr rfl
  intro i hi
  exact finiteProbePass_probability (laws i) (p i) (hp0 i) (hp1 i) (A i)

end MatroidProphetSecretary
