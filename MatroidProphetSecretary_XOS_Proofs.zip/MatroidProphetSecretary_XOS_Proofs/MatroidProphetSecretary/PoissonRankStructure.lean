import MatroidProphetSecretary.RankMarginals
import Mathlib.Data.Fintype.Powerset

/-! The block positive-semidefinite matrix underlying Poisson rank concavity. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Set
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def rankBlock (M : Matroid E) (S : Set E) (e f : E) : ℝ :=
  realRank M (insert e S) + realRank M (insert f S) -
    realRank M (insert e (insert f S)) - realRank M S

theorem rankBlock_eq_exchange_indicator (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (e f : E) (he : e ∈ M.E) (hf : f ∈ M.E) :
    rankBlock M S e f = if e ∈ M.closure (insert f S) ∧ e ∉ M.closure S then 1 else 0 := by
  unfold rankBlock
  rw [realRank_insert M S hS e he,
    realRank_insert M (insert f S) (insert_subset hf hS) e he]
  by_cases heS : e ∈ M.closure S
  · have heSf : e ∈ M.closure (insert f S) :=
      M.closure_subset_closure (subset_insert f S) heS
    simp only [heS, heSf, if_true, not_true_eq_false, and_false, if_false]
    ring
  · by_cases heSf : e ∈ M.closure (insert f S)
    · simp only [heS, heSf, if_true, not_false_eq_true, and_self, if_false]
      ring
    · simp only [heS, heSf, if_false, false_and]
      ring

theorem rankBlock_eq_parallel_indicator (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (e f : E) (he : e ∈ M.E) (hf : f ∈ M.E) :
    rankBlock M S e f =
      if e ∉ M.closure S ∧ f ∉ M.closure S ∧ M.closure (insert e S) = M.closure (insert f S)
      then 1 else 0 := by
  rw [rankBlock_eq_exchange_indicator M S hS e f he hf]
  have hiff : (e ∈ M.closure (insert f S) ∧ e ∉ M.closure S) ↔
      (e ∉ M.closure S ∧ f ∉ M.closure S ∧ M.closure (insert e S) = M.closure (insert f S)) := by
    constructor
    · intro h
      exact ⟨h.2, (M.closure_exchange h).2, M.closure_insert_congr h⟩
    · rintro ⟨heS, hfS, heq⟩
      refine ⟨?_, heS⟩
      rw [← heq]
      exact M.mem_closure_of_mem (mem_insert e S) (insert_subset he hS)
  simp only [hiff]

def rankFeature (M : Matroid E) (S C : Set E) (e : E) : ℝ :=
  if e ∉ M.closure S ∧ M.closure (insert e S) = C then 1 else 0

theorem rankBlock_eq_gram (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (e f : E) (he : e ∈ M.E) (hf : f ∈ M.E) :
    rankBlock M S e f = ∑ C : Set E, rankFeature M S C e * rankFeature M S C f := by
  rw [rankBlock_eq_parallel_indicator M S hS e f he hf]
  rw [sum_eq_single (M.closure (insert e S))]
  · by_cases heS : e ∈ M.closure S <;> by_cases hfS : f ∈ M.closure S <;>
      by_cases heq : M.closure (insert e S) = M.closure (insert f S) <;>
      simp [rankFeature, heS, hfS, heq, eq_comm]
  · intro C hC hne
    have hne' := hne.symm
    simp [rankFeature, hne']
  · simp

theorem gram_quadratic_nonneg {ι : Type*} [Fintype ι] (feature : ι → E → ℝ) (x : E → ℝ) :
    0 ≤ ∑ e, ∑ f, x e * x f * (∑ i, feature i e * feature i f) := by
  have hdist : (∑ e, ∑ f, x e * x f * (∑ i, feature i e * feature i f)) =
      ∑ e, ∑ f, ∑ i, (x e * feature i e) * (x f * feature i f) := by
    apply sum_congr rfl
    intro e he
    apply sum_congr rfl
    intro f hf
    rw [mul_sum]
    apply sum_congr rfl
    intro i hi
    ring
  have hs (e : E) : (∑ f, ∑ i, (x e * feature i e) * (x f * feature i f)) =
      ∑ i, ∑ f, (x e * feature i e) * (x f * feature i f) := sum_comm
  rw [hdist]
  simp_rw [hs]
  rw [sum_comm]
  apply sum_nonneg
  intro i hi
  rw [← sum_mul_sum]
  exact mul_self_nonneg _

/-- The negative Hessian's discrete rank matrix is positive semidefinite. -/
theorem rankBlock_quadratic_nonneg (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (hground : ∀ e, e ∈ M.E) (x : E → ℝ) :
    0 ≤ ∑ e, ∑ f, x e * x f * rankBlock M S e f := by
  simp_rw [rankBlock_eq_gram M S hS _ _ (hground _) (hground _)]
  exact gram_quadratic_nonneg (rankFeature M S) x

end MatroidProphetSecretary
