import MatroidProphetSecretary.BernoulliRankBound

/-! Extending a matroid by loops removes the ambient-ground convention from the rank bound. -/

noncomputable section

namespace MatroidProphetSecretary

open Set
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

theorem realRank_extend_ground (M : Matroid E) (S : Set E) :
    realRank (M ↾ univ) S = realRank M S := by
  unfold realRank
  rw [M.restrict_eRk_eq (subset_univ S)]

theorem rankObservable_extend_ground (M : Matroid E) :
    rankObservable (M ↾ univ) = rankObservable M := by
  funext x
  exact realRank_extend_ground M (bitSet x)

theorem base_extend_ground (M : Matroid E) {C : Set E} (hC : M.IsBase C) :
    (M ↾ univ).IsBase C := by
  apply Matroid.isBase_restrict_iff'.mpr
  rw [Matroid.isBasis'_iff_isBasis_inter_ground]
  simpa using hC.isBasis_ground

theorem bernoulli_rank_missing_mass_general (M : Matroid E)
    (C : Finset E) (hC : M.IsBase (C : Set E)) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (s : ℝ) (hs : 0 ≤ s) :
    (∑ e, p e * bernoulliEval p (insertDifference e (rankObservable M))) ≤
      realRank M M.E * Real.exp (-s) +
        s * ∑ e ∈ C, bernoulliEval p (insertDifference e (rankObservable M)) := by
  have h := bernoulli_rank_missing_mass (M ↾ univ) (fun _ => mem_univ _)
    C (base_extend_ground M hC) p hp0 hp1 s hs
  rw [rankObservable_extend_ground] at h
  have hr : realRank (M ↾ univ) (M ↾ univ).E = realRank M M.E := by
    rw [Matroid.restrict_ground_eq, realRank_extend_ground]
    unfold realRank
    rw [M.eRk_univ_eq, M.eRk_ground]
  rwa [hr] at h

end MatroidProphetSecretary
