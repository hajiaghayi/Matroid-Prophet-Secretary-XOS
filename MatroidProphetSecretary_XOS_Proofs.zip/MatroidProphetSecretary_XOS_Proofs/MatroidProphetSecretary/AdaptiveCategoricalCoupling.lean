import MatroidProphetSecretary.AdaptiveCoupling
import MatroidProphetSecretary.CategoricalFiniteCoupling

/-! The bounded categorical primitive couples an entire adaptive run, uniformly in its initial state. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem adaptive_categorical_coupling {S : Type*} {k : ℕ} (laws : S → FiniteLaw (Fin k))
    (hk : 0 < k) (G : ℕ) (hG : 0 < G) (update : S → Fin k → S) (steps : ℕ) (start : S) :
    ∃ joint : FiniteLaw (Fin steps → Fin k × Fin k),
      joint.map (fun x i => (x i).1) = FiniteLaw.adaptiveBatches laws update steps start ∧
      joint.map (fun x i => (x i).2) =
        FiniteLaw.adaptiveBatches (fun s => categoricalGridLaw (laws s) hk G hG) update steps start ∧
      joint.prob (fun x => (fun i => (x i).1) ≠ (fun i => (x i).2)) ≤ (steps:ℝ)*(k-1:ℕ)/G := by
  let right := fun s => categoricalGridLaw (laws s) hk G hG
  let pair := fun s => categoricalGridJoint (laws s) hk G hG
  let batch := FiniteLaw.coupledBatch laws right pair
  let joint := FiniteLaw.adaptiveBatches batch (FiniteLaw.coupledUpdate update) steps (start,start)
  refine ⟨joint,?_,?_,?_⟩
  · exact FiniteLaw.coupled_adaptive_left laws right pair update
      (fun s => categoricalGridJoint_left (laws s) hk G hG) steps (start,start)
  · exact FiniteLaw.coupled_adaptive_right laws right pair update
      (fun s => categoricalGridJoint_right (laws s) hk G hG) steps (start,start)
  · have h := FiniteLaw.coupled_adaptive_error laws right pair update ((k-1:ℕ)/(G:ℝ))
      (by positivity) (fun s => by
        convert categoricalGridJoint_error (laws s) hk G hG using 1 <;> congr 1) steps start
    convert h using 1
    · dsimp only [joint,batch]
      congr 1
    · ring

theorem adaptive_categorical_reward_loss {S : Type*} {k : ℕ} (laws : S → FiniteLaw (Fin k))
    (hk : 0 < k) (G : ℕ) (hG : 0 < G) (update : S → Fin k → S) (steps : ℕ) (start : S)
    (reward : (Fin steps → Fin k) → ℝ) (B : ℝ) (hB : 0 ≤ B)
    (hr0 : ∀ x, 0 ≤ reward x) (hrB : ∀ x, reward x ≤ B) :
    (FiniteLaw.adaptiveBatches laws update steps start).expect reward -
      (FiniteLaw.adaptiveBatches (fun s => categoricalGridLaw (laws s) hk G hG) update steps start).expect reward ≤
      B*((steps:ℝ)*(k-1:ℕ)/G) := by
  obtain ⟨joint,hleft,hright,herr⟩ := adaptive_categorical_coupling laws hk G hG update steps start
  have h := joint.coupling_welfare_loss (fun x => reward (fun i => (x i).1))
    (fun x => reward (fun i => (x i).2))
    (fun x => (fun i => (x i).1) ≠ (fun i => (x i).2)) B
    (fun x => hrB _) (fun x => hr0 _) (fun x hx => congrArg reward (not_not.mp hx))
  have hl := FiniteLaw.map_expect joint (fun x i => (x i).1) reward
  have hr := FiniteLaw.map_expect joint (fun x i => (x i).2) reward
  rw [hleft] at hl
  rw [hright] at hr
  rw [← hl,← hr] at h
  exact h.trans (mul_le_mul_of_nonneg_left herr hB)

end MatroidProphetSecretary
