import MatroidProphetSecretary.PhysicalMarkovLaw

/-! Conditional private randomness can be sampled in advance as a table indexed only by the observed value. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {A O : Type*} [Fintype A] [Fintype O]

def observedKernel (μ : FiniteLaw A) (observe : A → O) (o : O) : FiniteLaw A :=
  μ.conditionOrSelf (fun a => observe a = o)

def observedTableLaw (μ : FiniteLaw A) (observe : A → O) : FiniteLaw (O → A) :=
  product (observedKernel μ observe)

theorem observed_total_expectation (μ : FiniteLaw A) (observe : A → O) (f : O → A → ℝ) :
    (μ.map observe).expect (fun o => (observedKernel μ observe o).expect (f o)) =
      μ.expect (fun a => f (observe a) a) := by
  change (∑ o, (μ.map observe).mass o*(μ.conditionOrSelf (fun a => observe a = o)).expect (f o)) = _
  simp_rw [map_mass_probability,conditionOrSelf_weighted_expect]
  simp only [expect]
  rw [sum_comm]
  apply sum_congr rfl
  intro a ha
  simp [mul_ite,eq_comm]

theorem observed_table_expectation (μ : FiniteLaw A) (observe : A → O) (f : O → A → ℝ) :
    ((μ.map observe).pair (observedTableLaw μ observe)).expect (fun data => f data.1 (data.2 data.1)) =
      μ.expect (fun a => f (observe a) a) := by
  rw [pair_expect]
  simp only [observedTableLaw,product_expect_single_coordinate]
  exact observed_total_expectation μ observe f

theorem observed_table_law (μ : FiniteLaw A) (observe : A → O) :
    ((μ.map observe).pair (observedTableLaw μ observe)).map (fun data => data.2 data.1) = μ := by
  apply ext_expect
  intro f
  rw [map_expect]
  exact observed_table_expectation μ observe (fun _ => f)

theorem observed_table_consistency (μ : FiniteLaw A) (observe : A → O) (o : O) (table : O → A)
    (ho : (μ.map observe).mass o ≠ 0) (ht : (observedTableLaw μ observe).mass table ≠ 0) :
    observe (table o) = o := by
  have hp : 0 < μ.prob (fun a => observe a = o) := by
    have hm := (μ.map observe).nonneg o
    have hpos : 0 < (μ.map observe).mass o := lt_of_le_of_ne hm (Ne.symm ho)
    rw [map_mass_probability] at hpos
    convert hpos using 1
  exact conditionOrSelf_support μ (fun a => observe a = o) hp (table o)
    (product_support (observedKernel μ observe) table ht o)

variable {I : Type*} [Fintype I] [DecidableEq I]
variable {D K : I → Type*} [∀ i, Fintype (D i)] [∀ i, Fintype (K i)]

theorem product_observed_table_expectation (laws : ∀ i, FiniteLaw (D i)) (observe : ∀ i, D i → K i)
    (f : (∀ i, D i) → ℝ) :
    (product laws).expect f =
      (product (fun i => (laws i).map (observe i))).expect (fun values =>
        (product (fun i => observedTableLaw (laws i) (observe i))).expect
          (fun tables => f (fun i => tables i (values i)))) := by
  let source := fun i => ((laws i).map (observe i)).pair (observedTableLaw (laws i) (observe i))
  let evaluate := fun i (data : K i × (K i → D i)) => data.2 data.1
  have he : (fun i => (source i).map (evaluate i)) = laws := by
    funext i
    exact observed_table_law (laws i) (observe i)
  have h := product_map_expect source evaluate f
  rw [he] at h
  rw [h]
  exact product_pair_expect (fun i => (laws i).map (observe i))
    (fun i => observedTableLaw (laws i) (observe i)) (fun data => f (fun i => (data i).2 (data i).1))

end MatroidProphetSecretary.FiniteLaw
