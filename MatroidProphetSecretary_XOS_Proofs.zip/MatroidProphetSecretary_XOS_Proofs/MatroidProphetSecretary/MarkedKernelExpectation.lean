import MatroidProphetSecretary.PhysicalKernelProbabilities

/-! The explicit marked-event probabilities determine all zero-at-none reward expectations. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem FiniteLaw.marked_expectation {W A : Type*} [Fintype W] [Fintype A]
    (μ : FiniteLaw (Option W)) (ν : FiniteLaw A) (embed : A → W) (live : A → Prop) (c : ℝ)
    (hprob : ∀ B : W → Prop, μ.prob (fun outcome => ∃ w, outcome = some w ∧ B w) =
      c*ν.prob (fun y => live y ∧ B (embed y))) (f : Option W → ℝ) (hf : f none = 0) :
    μ.expect f = c*ν.expect (fun y => if live y then f (some (embed y)) else 0) := by
  have hs (w : W) : μ.mass (some w) = c*ν.prob (fun y => live y ∧ embed y = w) := by
    have h := hprob (fun z => z = w)
    simpa [FiniteLaw.prob,FiniteLaw.expect] using h
  rw [FiniteLaw.expect,Fintype.sum_option,hf,mul_zero,zero_add]
  simp_rw [hs]
  simp only [FiniteLaw.prob,FiniteLaw.expect,mul_sum,sum_mul]
  rw [sum_comm]
  apply sum_congr rfl
  intro y hy
  by_cases hl : live y <;> simp [hl,mul_ite,mul_assoc]

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem historyKernel_expect_zero (history : StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N)
    (hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history))
    (habsent : gridLabel N cfg.labels_pos n ∉ recordLabels history)
    (f : Option (GridMark N L V) → ℝ) (hf : f none = 0) :
    (cfg.historyKernel n history).expect f =
      ((1/(L:ℝ))*cfg.historyRate history n)*(FiniteLaw.product cfg.reference).expect
        (fun y => if cfg.live history (gridLabel N cfg.labels_pos n) y
          then f (some (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y))) else 0) := by
  exact FiniteLaw.marked_expectation (cfg.historyKernel n history) (FiniteLaw.product cfg.reference)
    (fun y => (gridLabel N cfg.labels_pos n,(gridClock N L cfg.clocks_pos n,y)))
    (cfg.live history (gridLabel N cfg.labels_pos n)) _
    (cfg.historyKernel_mark_probability history n hn hp habsent) f hf

end PrivateGridConfig
end MatroidProphetSecretary
