import MatroidProphetSecretary.ClockGridRounding

/-! Moving clock-derived prefix boundaries upward gives a uniform error for every fixed history. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

theorem inverseCDF_shift_discrepancy (bs cs : List ℝ) (d u : ℝ)
    (h : List.Forall₂ (fun b c => b ≤ c ∧ c ≤ b+d) bs cs)
    (hne : inverseCDF bs u ≠ inverseCDF cs u) : ∃ b ∈ bs, u ∈ Set.Ico b (b+d) := by
  induction h with
  | nil => exact False.elim (hne rfl)
  | @cons b c bs cs hbc htail ih =>
    by_cases hb : u < b
    · have hc : u < c := hb.trans_le hbc.1
      exact False.elim (hne (by simp [inverseCDF,hb,hc]))
    · by_cases hc : u < c
      · exact ⟨b,by simp,le_of_not_gt hb,hc.trans_le hbc.2⟩
      · have ht : inverseCDF bs u ≠ inverseCDF cs u := by
          intro he
          exact hne (by simp [inverseCDF,hb,hc,he])
        obtain ⟨a,ha,hu⟩ := ih ht
        exact ⟨a,by simp [ha],hu⟩

theorem inverseCDF_shift_error (bs cs : List ℝ) (d : ℝ) (hd : 0 ≤ d)
    (h : List.Forall₂ (fun b c => b ≤ c ∧ c ≤ b+d) bs cs) :
    volume {u : ℝ | inverseCDF bs u ≠ inverseCDF cs u} ≤ ENNReal.ofReal (bs.length*d) := by
  apply (measure_mono (show {u : ℝ | inverseCDF bs u ≠ inverseCDF cs u} ⊆
    {u : ℝ | ∃ b ∈ bs, u ∈ Set.Ico b (b+d)} from fun u hu => inverseCDF_shift_discrepancy bs cs d u h hu)).trans
  exact volume_boundary_intervals_le bs d hd

theorem probe_prefix_rounding_error (times : List ℝ) (ht : ∀ t ∈ times, 0 ≤ t)
    (q : ℝ) (hq : 1/2 ≤ q) (G : ℕ) (hG : 0 < G) :
    unitUniform {u | inverseCDF (times.map (fun t => t/(2*q))) u ≠
      inverseCDF (times.map (fun t => uniformGridUp G t/(2*q))) u} ≤ ENNReal.ofReal (times.length/G) := by
  have hq0 : 0 < 2*q := by linarith
  have hd : (0:ℝ) ≤ 1/G := by positivity
  have hp : List.Forall₂ (fun b c : ℝ => b ≤ c ∧ c ≤ b+1/G)
      (times.map (fun t => t/(2*q))) (times.map (fun t => uniformGridUp G t/(2*q))) := by
    induction times with
    | nil => exact .nil
    | cons t ts ih =>
      apply List.Forall₂.cons
      · have hb := uniformGridUp_bounds G hG t (ht t (by simp))
        refine ⟨div_le_div_of_nonneg_right hb.1.le hq0.le,?_⟩
        calc
          _ ≤ (t+1/G)/(2*q) := div_le_div_of_nonneg_right hb.2 hq0.le
          _ = t/(2*q)+(1/G)/(2*q) := add_div _ _ _
          _ ≤ t/(2*q)+1/G := add_le_add_left ((div_le_iff₀ hq0).mpr (by nlinarith)) _
      · exact ih (fun s hs => ht s (by simp [hs]))
  have h := inverseCDF_shift_error _ _ (1/G) hd hp
  apply (Measure.restrict_apply_le _ _).trans
  simpa only [List.length_map,mul_one_div] using h

end MatroidProphetSecretary
