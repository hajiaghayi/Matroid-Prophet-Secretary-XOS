import MatroidProphetSecretary.PhysicalKernelProbabilities
import MatroidProphetSecretary.SparseRoundApproximation

/-! Quantitative comparison of actual physical rounds with their one-event discretization. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem FiniteLaw.optional_acceptance_probability {W : Type*} [Fintype W] (μ : FiniteLaw (Option W)) :
    μ.prob (fun x => ∃ mark, x = some mark ∧ True) = 1-μ.mass none := by
  rw [FiniteLaw.mass_eq_expect_indicator]
  rw [← μ.expect_const 1,← FiniteLaw.expect_sub]
  unfold FiniteLaw.prob
  congr 1
  funext x
  cases x <;> simp

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

theorem historyKernel_acceptance_bound (history : StampedHistory (Fin N) (Fin N → Option V))
    (n : ℕ) (hn : n < L*N)
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q))) :
    1-(cfg.historyKernel n history).mass none ≤ (1/(L:ℝ))*((1/cfg.q)/omega) := by
  have hbound : 0 ≤ (1/(L:ℝ))*((1/cfg.q)/omega) :=
    mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)
  by_cases hp : 0 < (FiniteLaw.product cfg.laws).prob (fun tapes => cfg.run tapes n = history)
  · by_cases hseen : gridLabel N cfg.labels_pos n ∈ recordLabels history
    · rw [cfg.historyKernel_seen n hn history hseen]
      simpa [FiniteLaw.pointMass] using hbound
    · rw [← FiniteLaw.optional_acceptance_probability]
      have hk := cfg.historyKernel_mark_probability history n hn hp hseen (fun _ => True)
      have hr := cfg.historyRate_bounds history n hsmall omega homega homega1 hlower
      calc
        _ = (1/(L:ℝ))*cfg.historyRate history n*(FiniteLaw.product cfg.reference).prob
            (fun y => cfg.live history (gridLabel N cfg.labels_pos n) y ∧ True) := by
          convert hk using 1 <;> congr 4
        _ ≤ (1/(L:ℝ))*cfg.historyRate history n :=
          mul_le_of_le_one_right (mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) hr.1)
            ((FiniteLaw.product cfg.reference).prob_le_one _)
        _ ≤ _ := mul_le_mul_of_nonneg_left hr.2 (one_div_nonneg.mpr (Nat.cast_nonneg L))
  · simpa [historyKernel,hp,FiniteLaw.pointMass] using hbound

theorem finiteHistoryKernel_acceptance_bound
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (n : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V)) :
    1-(cfg.finiteHistoryKernel n history).mass none ≤ (1/(L:ℝ))*((1/cfg.q)/omega) := by
  by_cases hn : n < L*N
  · simp only [finiteHistoryKernel,if_pos hn]
    exact cfg.historyKernel_acceptance_bound history n hn hsmall omega homega homega1 hlower
  · have hbound : 0 ≤ (1/(L:ℝ))*((1/cfg.q)/omega) :=
      mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L)) (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)
    simpa [finiteHistoryKernel,hn,FiniteLaw.pointMass] using hbound

def sparsePhysicalRound
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (offset : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) :
    FiniteLaw (Fin N → Option (GridMark N L V)) :=
  FiniteLaw.sparseRoundTraceLaw cfg.finiteHistoryKernel ((1/(L:ℝ))*((1/cfg.q)/omega))
    (cfg.finiteHistoryKernel_acceptance_bound hsmall omega homega homega1 hlower) N offset history hbudget

theorem physical_round_approximation
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (offset : ℕ) (history : StampedHistory (Fin N) (Fin N → Option V))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) :
    FiniteLaw.massDistance (FiniteLaw.timedBatches cfg.finiteHistoryKernel updateGridHistory N offset history)
      (cfg.sparsePhysicalRound hsmall omega homega homega1 hlower offset history hbudget) ≤
      2*(N:ℝ)^2*((1/(L:ℝ))*((1/cfg.q)/omega))^2 := by
  apply FiniteLaw.sparse_round_massDistance
  · intro state
    rfl
  · exact mul_nonneg (one_div_nonneg.mpr (Nat.cast_nonneg L))
      (div_nonneg (one_div_nonneg.mpr cfg.q_pos.le) homega.le)

end PrivateGridConfig
end MatroidProphetSecretary
