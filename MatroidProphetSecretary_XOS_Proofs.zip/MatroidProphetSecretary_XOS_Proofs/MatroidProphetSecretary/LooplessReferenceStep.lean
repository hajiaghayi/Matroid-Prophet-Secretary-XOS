import MatroidProphetSecretary.ReferenceSearchAction
import MatroidProphetSecretary.ReferenceSearchExistence
import MatroidProphetSecretary.ResidualThresholdPolicy
import MatroidProphetSecretary.GeneralReferenceShape

/-! The complete loopless induction step: accurate search, selected action, and actual residual policies. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

set_option synthInstance.maxSize 2048
set_option maxRecDepth 2048

def ReferencePolicyClaim (N : ℕ) : Prop :=
  ∀ (k : ℕ) (M : Matroid (Fin N)) (prior : RationalPriors N k) (q : ℝ), q ∈ interval →
    ∃ policy : OnlinePolicy N 0, PolicyFeasible M policy ∧
      discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ expectedPolicyReward prior policy

theorem loopless_reference_policy_step {n k : ℕ} (ih : ReferencePolicyClaim n)
    (M : Matroid (Fin (n+1))) (prior : RationalPriors (n+1) k)
    (hnonloop : ∀ e, M.Indep ({e} : Set (Fin (n+1))))
    (hF : 0 < expectedProphet M prior) (q : ℝ) (hq : q ∈ interval) :
    ∃ policy : OnlinePolicy (n+1) 0, PolicyFeasible M policy ∧
      discount q*referenceExpectedOptimum prior.law M (fun e v => (prior.value e v : ℝ)) q ≤ expectedPolicyReward prior policy := by
  let observed := fun e v => (prior.value e v : ℝ)
  have hobs (e : Fin (n+1)) (v : Fin k) : 0 ≤ observed e v := by
    change (0:ℝ) ≤ (prior.value e v:ℝ)
    exact_mod_cast prior.value_nonneg e v
  have hF' : 0 < expectedOptimum (FiniteLaw.product prior.law) M (coordinateValues observed) := hF
  have hFq : 0 < referenceExpectedOptimum prior.law M observed q :=
    (mul_pos (by norm_num : (0:ℝ) < 1/2) hF').trans_le
      (referenceExpectedOptimum_lower_away_zero prior.law M
        (fun e => (hnonloop e).subset_ground (Set.mem_singleton e)) observed hobs (1/2) q
        (by norm_num) (by norm_num) (by linarith [(interval_bounds hq).1]))
  by_cases hguard : 3*delta ≤ |q-1|
  · obtain ⟨K,policy,hfeasible,hreward⟩ := reference_guard_policy (Nat.zero_lt_succ n) prior M hq hguard hFq
    obtain ⟨det,hd,hr⟩ := deterministic_policy_dominates prior M policy hfeasible
    exact ⟨det,hd,hreward.le.trans hr⟩
  have hinit : |q-1| < 3*delta := lt_of_not_ge hguard
  obtain ⟨G⟩ := heightGrid_exists
    (fun a : Σ e : Fin (n+1), ReferenceAtom (fun _ : Fin (n+1) => Fin k) e =>
      referenceInstanceValues observed a.1 a.2)
    (fun a => referencePriorValue_nonneg (observed a.1) (hobs a.1) a.2)
  have hex := exists_accurate_reference_search prior.law M observed hobs hnonloop G
  rw [fin_order_decidableEq] at hex
  obtain ⟨m,initial,batches,hgood⟩ := hex hF' (n+1) (Nat.zero_lt_succ n) (by simp) q hq
  let r := runReferenceSearch
    (fun q x => referencePositiveTest prior.law observed G M theta epsilon q x)
    (fun q x => referenceNegativeTest prior.law observed G M theta epsilon q x)
    batches ⟨q,initial⟩ delta (referenceSearchSteps (n+1) delta epsilon)
  have hs := finite_reference_selection_concrete prior.law M observed hobs hnonloop G
  rw [fin_order_decidableEq] at hs
  have hs := hs hF' (n+1) (Nat.zero_lt_succ n) (by simp) batches ⟨q,initial⟩ hinit hgood
  have hr : r.point ∈ interval := hs.2.1
  have hpay := reference_search_action_pays (Nat.zero_lt_succ n) (Nat.zero_lt_succ n) le_rfl
    prior M hnonloop G hF batches ⟨q,initial⟩ hinit hgood
  change ReferenceActionPays (B := n+1) (Nat.zero_lt_succ n) prior M hnonloop G
    (discount q*referenceExpectedOptimum prior.law M observed q) r.point r.batch at hpay
  unfold ReferenceActionPays at hpay
  split_ifs at hpay with ha
  · obtain ⟨K,policy,hfeasible,hreward⟩ := hpay
    obtain ⟨det,hd,hreward'⟩ := deterministic_policy_dominates prior M policy hfeasible
    exact ⟨det,hd,hreward.trans hreward'⟩
  · obtain ⟨policy,hfeasible,hreward⟩ := reference_threshold_policy_of_children (B := n+1)
      prior M hnonloop G r.point r.batch
      (fun e => ih k (remainingDelete M e) (prior.remaining e) r.point hr)
      (fun e => ih k (remainingContract M e) (prior.remaining e) r.point hr)
    exact ⟨policy,hfeasible,hpay.trans hreward⟩

end MatroidProphetSecretary
