import MatroidProphetSecretary.PoissonRankBound
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.SpecificLimits.Basic
import Mathlib.Tactic.FunProp

/-! The rank missing-mass inequality, including certain activation probabilities. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset Filter
open scoped Classical Topology

variable {E : Type*} [Fintype E] [DecidableEq E]

def bernoulliEval (p : E → ℝ) (f : (E → Bool) → ℝ) : ℝ :=
  ∑ x, (∏ e, if x e = true then p e else 1 - p e) * f x

theorem bernoulliEval_poisson (a : E → ℝ) (f : (E → Bool) → ℝ) :
    bernoulliEval (fun e => 1 - Real.exp (-a e)) f = poissonEval a f := by
  apply sum_congr rfl
  intro x hx
  congr 1
  apply prod_congr rfl
  intro e he
  cases x e <;> simp [poissonWeight]

@[fun_prop] theorem continuous_bernoulliEval (f : (E → Bool) → ℝ) :
    Continuous (fun p : E → ℝ => bernoulliEval p f) := by
  unfold bernoulliEval
  apply continuous_finset_sum
  intro x hx
  apply Continuous.mul _ continuous_const
  apply continuous_finset_prod
  intro e he
  by_cases hxe : x e = true
  · simp only [if_pos hxe]
    exact continuous_apply e
  · simp only [if_neg hxe]
    exact continuous_const.sub (continuous_apply e)

theorem bernoulli_rank_missing_mass_lt_one (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (C : Finset E) (hC : M.IsBase (C : Set E)) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e < 1) (s : ℝ) (hs : 0 ≤ s) :
    (∑ e, p e * bernoulliEval p (insertDifference e (rankObservable M))) ≤
      realRank M M.E * Real.exp (-s) +
        s * ∑ e ∈ C, bernoulliEval p (insertDifference e (rankObservable M)) := by
  let a : E → ℝ := fun e => -Real.log (1 - p e)
  have ha : ∀ e, 0 ≤ a e := by
    intro e
    apply neg_nonneg.mpr
    exact Real.log_nonpos (by linarith [hp1 e]) (by linarith [hp0 e])
  have heq : (fun e => 1 - Real.exp (-a e)) = p := by
    funext e
    dsimp [a]
    rw [neg_neg, Real.exp_log (by linarith [hp1 e])]
    ring
  have h := poisson_rank_missing_mass M hground C hC a ha s hs
  simp_rw [← bernoulliEval_poisson, heq] at h
  simpa only [← heq] using h

theorem bernoulli_rank_missing_mass (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (C : Finset E) (hC : M.IsBase (C : Set E)) (p : E → ℝ)
    (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (s : ℝ) (hs : 0 ≤ s) :
    (∑ e, p e * bernoulliEval p (insertDifference e (rankObservable M))) ≤
      realRank M M.E * Real.exp (-s) +
        s * ∑ e ∈ C, bernoulliEval p (insertDifference e (rankObservable M)) := by
  let F : ℝ → ℝ := fun t =>
    (∑ e, (t * p e) * bernoulliEval (fun i => t * p i) (insertDifference e (rankObservable M))) -
      (realRank M M.E * Real.exp (-s) +
        s * ∑ e ∈ C, bernoulliEval (fun i => t * p i) (insertDifference e (rankObservable M)))
  have hcont : Continuous F := by dsimp [F]; fun_prop
  have htend : Tendsto (fun n : ℕ => 1 - 1 / ((n : ℝ) + 1)) atTop (𝓝 (1 : ℝ)) := by
    convert tendsto_const_nhds.sub tendsto_one_div_add_atTop_nhds_zero_nat using 1 <;> simp
  have hlim : F 1 ≤ 0 := le_of_tendsto' (hcont.continuousAt.tendsto.comp htend) (fun n => by
    have hd : (0 : ℝ) < (n : ℝ) + 1 := by positivity
    have hdiv : 1 / ((n : ℝ) + 1) ≤ (1 : ℝ) := by
      apply (div_le_iff₀ hd).mpr
      norm_num
    have ht0 : (0 : ℝ) ≤ 1 - 1 / ((n : ℝ) + 1) := sub_nonneg.mpr hdiv
    have ht1 : (1 : ℝ) - 1 / ((n : ℝ) + 1) < 1 := by
      have hpos : (0 : ℝ) < 1 / ((n : ℝ) + 1) := div_pos zero_lt_one hd
      linarith
    apply sub_nonpos.mpr
    apply bernoulli_rank_missing_mass_lt_one M hground C hC _ _ _ s hs
    · intro e
      exact mul_nonneg ht0 (hp0 e)
    · intro e
      calc
        _ ≤ (1 - 1 / ((n : ℝ) + 1)) * 1 := mul_le_mul_of_nonneg_left (hp1 e) ht0
        _ < 1 := by simpa using ht1)
  simpa only [F, one_mul, sub_nonpos] using hlim

end MatroidProphetSecretary
