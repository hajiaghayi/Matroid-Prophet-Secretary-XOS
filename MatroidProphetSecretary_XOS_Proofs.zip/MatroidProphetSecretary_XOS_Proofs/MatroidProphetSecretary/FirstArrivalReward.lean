import MatroidProphetSecretary.FirstArrivalPolicy
import MatroidProphetSecretary.DeterministicPolicy

/-! The composed online policy realizes the uniform-first-arrival recurrence exactly. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

theorem weight_remaining_image {n : ℕ} (values : Fin (n+1) → ℝ) (e : Fin (n+1)) (I : Finset (Fin n)) :
    weight values (I.image (remainingLabel e)) = weight (fun i => values (remainingLabel e i)) I := by
  unfold weight
  exact sum_image (fun i _ j _ h => remainingLabel_injective e h)

theorem firstArrivalPolicy_reward {n : ℕ} (decision : Fin (n+1) → ℝ → Bool)
    (child : Fin (n+1) → Bool → OnlinePolicy n 0) (seed : Fin (2^0))
    (values : Fin (n+1) → ℝ) (e : Fin (n+1)) (order : Equiv.Perm (Fin n)) :
    weight values (acceptedSet (completedHistory (firstArrivalPolicy decision child) seed values
      (Equiv.Perm.decomposeFin.symm (e,order)))) =
      (if decision e (values e) then values e else 0) +
        weight (fun i => values (remainingLabel e i))
          (acceptedSet (completedHistory (child e (decision e (values e))) 0
            (fun i => values (remainingLabel e i)) order)) := by
  rw [completed_firstArrivalPolicy,acceptedSet_first_lift]
  have hnot (I : Finset (Fin n)) : e ∉ I.image (remainingLabel e) := by
    rintro he
    obtain ⟨i,hi,he⟩ := mem_image.mp he
    exact remainingLabel_ne e i he
  cases h : decision e (values e)
  · simp only [h,Bool.false_eq_true,if_false,zero_add,weight_remaining_image]
  · simp only [h,if_true,weight,sum_insert (hnot _)]
    exact congrArg (values e + ·) (weight_remaining_image values e _)

theorem realization_join_remaining {n k : ℕ} (prior : RationalPriors (n+1) k) (e : Fin (n+1))
    (v : Fin k) (rest : Fin n → Fin k) :
    (fun i => prior.realization (joinArrivalValues e v rest) (remainingLabel e i)) =
      (prior.remaining e).realization rest := by
  funext i
  change (prior.value (remainingLabel e i) (joinArrivalValues e v rest (remainingLabel e i)) : ℝ) = _
  rw [joinArrivalValues_remaining]
  rfl

theorem realization_join_current {n k : ℕ} (prior : RationalPriors (n+1) k) (e : Fin (n+1))
    (v : Fin k) (rest : Fin n → Fin k) :
    prior.realization (joinArrivalValues e v rest) e = (prior.value e v : ℝ) := by
  change (prior.value e (joinArrivalValues e v rest e) : ℝ) = _
  rw [joinArrivalValues_current]

theorem expected_firstArrivalPolicy {n k : ℕ} (prior : RationalPriors (n+1) k)
    (decision : Fin (n+1) → ℝ → Bool) (child : Fin (n+1) → Bool → OnlinePolicy n 0) :
    expectedPolicyReward prior (firstArrivalPolicy decision child) =
      (FiniteLaw.uniform (Fin (n+1))).expect (fun e => (prior.law e).expect (fun v =>
        (if decision e (prior.value e v) then (prior.value e v : ℝ) else 0) +
          expectedPolicyReward (prior.remaining e) (child e (decision e (prior.value e v))))) := by
  rw [expectedPolicyReward_zero_bits]
  simp_rw [uniform_arrival_decomposition,firstArrivalPolicy_reward]
  rw [FiniteLaw.expect_comm (FiniteLaw.product prior.law) (FiniteLaw.uniform (Fin (n+1)))]
  apply congrArg (FiniteLaw.expect (FiniteLaw.uniform (Fin (n+1))))
  funext e
  rw [first_arrival_value_decomposition prior.law e]
  simp only [realization_join_current,realization_join_remaining]
  apply congrArg (FiniteLaw.expect (prior.law e))
  funext v
  simp_rw [FiniteLaw.expect_add,FiniteLaw.expect_const]
  rw [expectedPolicyReward_zero_bits]
  rfl

theorem firstArrivalPolicy_reward_bound {n k : ℕ} (prior : RationalPriors (n+1) k)
    (decision : Fin (n+1) → ℝ → Bool) (child : Fin (n+1) → Bool → OnlinePolicy n 0)
    (potential : Fin (n+1) → Bool → ℝ)
    (hchild : ∀ e b, potential e b ≤ expectedPolicyReward (prior.remaining e) (child e b)) :
    (FiniteLaw.uniform (Fin (n+1))).expect (fun e => (prior.law e).expect (fun v =>
      (if decision e (prior.value e v) then (prior.value e v : ℝ) else 0) +
        potential e (decision e (prior.value e v)))) ≤
      expectedPolicyReward prior (firstArrivalPolicy decision child) := by
  rw [expected_firstArrivalPolicy]
  apply FiniteLaw.expect_mono
  intro e
  apply FiniteLaw.expect_mono
  intro v
  exact add_le_add_left (hchild e _) _

end MatroidProphetSecretary
