import MatroidProphetSecretary.ReferenceInstance
import MatroidProphetSecretary.CappedColoopLayers

/-! Deletion and stable surplus of the constructed reference laws have the proved layer formulas. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]
    {V : E → Type*} [∀ e, Fintype (V e)]

theorem bernoulli_replace_rank_eq_nonspan (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (p : E → ℝ) (hp0 : ∀ e, 0 ≤ p e) (hp1 : ∀ e, p e ≤ 1) (e : E) :
    bernoulliEval p (replaceDifference e (rankObservable M)) =
      nonspanProbability (bernoulliLaws p hp0 hp1) M e (fun _ => True) := by
  rw [bernoulliEval_eq_expect p hp0 hp1]
  unfold nonspanProbability FiniteLaw.prob
  congr 1
  funext x
  have hset : bitSet x \ {e} = activeBlock M e (fun _ => True) x := by
    ext f
    simp only [bitSet, activeBlock, Set.mem_diff, Set.mem_setOf_eq, Set.mem_singleton_iff,
      hground f, true_and]
    tauto
  rw [rank_replaceDifference M hground, hset]
  unfold nonspanEvent
  split_ifs <;> simp_all

theorem referenceInstance_nonspan (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 ≤ q)
    (z : ℝ) (hz : 0 ≤ z) (e : E) :
    otherNonspanProbability (referenceInstanceLaws laws value q) M (referenceInstanceValues value) e z =
      referenceLayerRho M (coordinateTail laws value z) q e := by
  have hp : coordinateTail (referenceInstanceLaws laws value q) (referenceInstanceValues value) z =
      fun f => scaledTail (coordinateTail laws value z f) q :=
    funext (referenceInstance_tail laws value q hq z hz)
  unfold referenceLayerRho
  rw [← hp, bernoulli_replace_rank_eq_nonspan M hground
    (coordinateTail (referenceInstanceLaws laws value q) (referenceInstanceValues value) z)
    (fun f => (referenceInstanceLaws laws value q f).prob_nonneg _)
    (fun f => (referenceInstanceLaws laws value q f).prob_le_one _),
    ← activityLaws_eq_bernoulli, activity_nonspan]

theorem referenceInstance_deletion_layer (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 ≤ q) (z : ℝ) :
    (∑ e, (FiniteLaw.product (referenceInstanceLaws laws value q)).expect (fun x =>
      coloopLayer M (coordinateValues (referenceInstanceValues value) x) e z)) =
      if 0 < z then referenceLayerD M (coordinateTail laws value z) q else 0 := by
  by_cases hz : 0 < z
  · rw [if_pos hz]
    apply sum_congr rfl
    intro e he
    rw [expected_coloop_eq_tail_nonspan _ M _ e (hground e),
      positiveTail_eq_coordinateTail _ _ z hz,
      referenceInstance_tail laws value q hq z hz.le,
      referenceInstance_nonspan laws M hground value q hq z hz.le]
  · simp [coloopLayer, hz]

theorem referenceInstance_stable_layer (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (q : ℝ) (hq : 0 ≤ q) (z : ℝ) :
    stableLayerExpectation (FiniteLaw.product (referenceInstanceLaws laws value q)) M
      (coordinateValues (referenceInstanceValues value)) z =
      if 0 < z then referenceLayerH M (coordinateTail laws value z) q else 0 := by
  by_cases hz : 0 < z
  · rw [if_pos hz]
    apply sum_congr rfl
    intro e he
    rw [expected_coloop_eq_tail_nonspan _ M _ e (hground e),
      positiveTail_eq_coordinateTail _ _ z hz,
      referenceInstance_tail laws value q hq z hz.le,
      referenceInstance_nonspan laws M hground value q hq z hz.le]
    ring
  · simp [stableLayerExpectation, positiveTailProbability, positiveLayer, hz]

theorem referenceInstance_deletion_integral (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (hground : ∀ e, e ∈ M.E) (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (q : ℝ) (hq : 0 ≤ q) :
    deletionSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) =
      ∫ z, if 0 < z then referenceLayerD M (coordinateTail laws value z) q else 0 := by
  rw [deletionSurplus_eq_integral_coloop_count _ M _
    (show ∀ x e, 0 ≤ coordinateValues (referenceInstanceValues value) x e from
      fun x e => referencePriorValue_nonneg (value e) (hv e) (x e))]
  simp only [referenceInstance_deletion_layer laws M hground value q hq]

theorem referenceInstance_stable_integral (laws : ∀ e, FiniteLaw (V e)) (M : Matroid E)
    (value : ∀ e, V e → ℝ) (hv : ∀ e x, 0 ≤ value e x)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) (q : ℝ) (hq : 0 ≤ q) :
    stableSurplus (FiniteLaw.product (referenceInstanceLaws laws value q)) M
        (coordinateValues (referenceInstanceValues value)) hnonloop =
      ∫ z, if 0 < z then referenceLayerH M (coordinateTail laws value z) q else 0 := by
  have hground : ∀ e, e ∈ M.E := fun e => (hnonloop e).subset_ground (Set.mem_singleton e)
  rw [stableSurplus_eq_integral_tail_coloop _ M _
    (show ∀ x e, 0 ≤ coordinateValues (referenceInstanceValues value) x e from
      fun x e => referencePriorValue_nonneg (value e) (hv e) (x e)) hnonloop]
  change (∫ z, stableLayerExpectation (FiniteLaw.product (referenceInstanceLaws laws value q)) M
    (coordinateValues (referenceInstanceValues value)) z) = _
  simp only [referenceInstance_stable_layer laws M hground value q hq]

end MatroidProphetSecretary
