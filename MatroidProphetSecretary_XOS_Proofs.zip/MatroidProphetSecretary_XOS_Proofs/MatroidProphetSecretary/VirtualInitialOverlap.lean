import MatroidProphetSecretary.FiniteVirtualContinuation

/-! The two-phase virtual bound starts from the actual F and Q of the reference bases. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E W : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem basisLayer_filter_positive (v : E → ℝ) (B : Finset E) (e : E) (z : ℝ) :
    basisLayer v (B.filter (fun f => 0 < v f)) e z = basisLayer v B e z := by
  by_cases hv : 0 < v e
  · simp [basisLayer,hv]
  · have hz : ¬ (0 < z ∧ z < v e) := fun h => hv (h.1.trans h.2)
    simp [basisLayer,positiveLayer,hv,hz]

theorem initialVirtualState_overlap (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ) :
    virtualCurrentOverlap μ M base hbase value (initialVirtualState M) = overlap μ value base := by
  simp only [virtualCurrentOverlap,overlap,basisMarginal,virtualLive,initialVirtualState,
    ExchangeHistory.liveSet,ExchangeHistory.replay,sdiff_empty,basisLayer_filter_positive]

theorem finite_virtual_continuation_initial (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (cfg : FiniteContinuationConfig (Fintype.card E)) :
    (1-cfg.alpha)*expectedOptimum μ M value +
      cfg.lateFactor*(cfg.alpha*expectedOptimum μ M value + cfg.alpha*(1-cfg.alpha)*overlap μ value base) ≤
    (finiteContinuationLaw μ M base hbase value cfg (initialVirtualState M)).expect
      (finiteContinuationReward M base hbase value cfg (initialVirtualState M)) := by
  have h := finite_virtual_continuation_reward μ M base hbase value hv cfg (initialVirtualState M)
  rwa [initialVirtualState_value μ M base hbase value hv hopt,initialVirtualState_overlap] at h

def finiteContinuationFactor {N : ℕ} (cfg : FiniteContinuationConfig N) (z : ℝ) : ℝ :=
  1-cfg.alpha + cfg.alpha*cfg.lateFactor*(1+(1-cfg.alpha)*z)

theorem finite_virtual_reward_factor (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E)) (value : W → E → ℝ)
    (hv : ∀ y e, 0 ≤ value y e) (hopt : ∀ y, weight (value y) (base y) = optimum M (value y))
    (hF : 0 < expectedOptimum μ M value) (cfg : FiniteContinuationConfig (Fintype.card E)) :
    finiteContinuationFactor cfg (overlap μ value base / expectedOptimum μ M value) * expectedOptimum μ M value ≤
    (finiteContinuationLaw μ M base hbase value cfg (initialVirtualState M)).expect
      (finiteContinuationReward M base hbase value cfg (initialVirtualState M)) := by
  have h := finite_virtual_continuation_initial μ M base hbase value hv hopt cfg
  convert h using 1
  unfold finiteContinuationFactor
  field_simp
  <;> ring

end MatroidProphetSecretary
