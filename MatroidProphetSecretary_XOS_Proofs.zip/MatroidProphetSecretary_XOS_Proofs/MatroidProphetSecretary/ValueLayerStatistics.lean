import MatroidProphetSecretary.BinnedValueLayers
import MatroidProphetSecretary.ExclusionLayers
import MatroidProphetSecretary.CappedColoopLayers
import MatroidProphetSecretary.ValueMissingMass

/-! Identifying the sampler statistics with the actual matroid surplus integrands. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem activity_expect_valueActivity (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (z : ℝ) (f : (E → Bool) → ℝ) :
    (FiniteLaw.product (activityLaws laws value z)).expect f =
      (FiniteLaw.product laws).expect (fun x => f (valueActivity value z x)) :=
  FiniteLaw.product_map_expect laws (fun e x => decide (z < value e x)) f

theorem rank_activity_expectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (z : ℝ) :
    positiveActivityExpectation laws value (fun _ x => realRank M (bitSet x)) z =
      (FiniteLaw.product laws).expect (fun x => positiveRankLayer M (coordinateValues value x) z) := by
  unfold positiveActivityExpectation
  by_cases hz : 0 < z
  · rw [if_pos hz, activity_expect_valueActivity]
    congr 1
    funext x
    simp only [positiveRankLayer, if_pos hz, bitSet_valueActivity M hground value z x, realRank]
  · simp [hz, positiveRankLayer]

theorem coloop_valueActivity (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (e : E) (z : ℝ) (hz : 0 < z) (x : ∀ e, V e) :
    activeColoopIndicator M e (valueActivity value z x) = coloopLayer M (coordinateValues value x) e z := by
  unfold activeColoopIndicator nonspanEvent
  rw [activeBlock_valueActivity laws]
  simp only [valueActivity, decide_eq_true_eq, coloopLayer, if_pos hz, hz, true_and,
    valueLayer, Set.mem_setOf_eq, hground e, coordinateValues]

theorem coloop_activity_expectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (z : ℝ) :
    positiveActivityExpectation laws value (fun _ => activeColoopCount M) z =
      ∑ e, (FiniteLaw.product laws).expect (fun x => coloopLayer M (coordinateValues value x) e z) := by
  unfold positiveActivityExpectation
  by_cases hz : 0 < z
  · rw [if_pos hz, activity_expect_valueActivity]
    simp only [activeColoopCount, FiniteLaw.expect_finset_sum, coloop_valueActivity laws value M hground _ z hz]
  · simp [hz, coloopLayer]

theorem stable_activity_expectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (z : ℝ) :
    positiveActivityExpectation laws value (fun p x => ∑ e, activeColoopIndicator M e x * p e) z =
      stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z := by
  unfold positiveActivityExpectation
  by_cases hz : 0 < z
  · rw [if_pos hz, activity_expect_valueActivity]
    simp only [FiniteLaw.expect_finset_sum, FiniteLaw.expect_mul_const, FiniteLaw.expect_const_mul,
      coloop_valueActivity laws value M hground _ z hz, stableLayerExpectation,
      positiveTail_eq_coordinateTail laws value z hz, mul_comm]
  · simp [hz, stableLayerExpectation, coloopLayer]

theorem unstable_activity_expectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (z : ℝ) :
    positiveActivityExpectation laws value (fun p => activeUnstableCount M p) z =
      (∑ e, (FiniteLaw.product laws).expect (fun x => coloopLayer M (coordinateValues value x) e z)) -
        stableLayerExpectation (FiniteLaw.product laws) M (coordinateValues value) z := by
  rw [← coloop_activity_expectation laws value M hground,
    ← stable_activity_expectation laws value M hground]
  unfold positiveActivityExpectation
  by_cases hz : 0 < z
  · simp only [if_pos hz]
    change (FiniteLaw.product (activityLaws laws value z)).expect
      (fun x => ∑ e, activeColoopIndicator M e x * (1 - coordinateTail laws value z e)) = _
    simp only [mul_sub, mul_one, sum_sub_distrib]
    simpa only [activeColoopCount] using
      (FiniteLaw.product (activityLaws laws value z)).expect_sub (activeColoopCount M)
        (fun x => ∑ e, activeColoopIndicator M e x * coordinateTail laws value z e)
  · simp [hz]

theorem closure_activity_expectation (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (M : Matroid E) (hground : ∀ e, e ∈ M.E) (e : E) (z : ℝ) :
    positiveActivityExpectation laws value (fun _ => activeOtherClosure M e) z =
      (FiniteLaw.product laws).expect (fun x => othersClosureLayer M (coordinateValues value x) e z) := by
  unfold positiveActivityExpectation
  by_cases hz : 0 < z
  · rw [if_pos hz, activity_expect_valueActivity]
    congr 1
    funext x
    simp only [activeOtherClosure, bitSet_valueActivity M hground value z x, othersClosureLayer, hz, true_and]
  · simp [hz, othersClosureLayer]

theorem rank_activity_integrable (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (M : Matroid E) (hground : ∀ e, e ∈ M.E) :
    Integrable (positiveActivityExpectation laws value (fun _ x => realRank M (bitSet x))) := by
  rw [funext (rank_activity_expectation laws value M hground)]
  exact (FiniteLaw.product laws).integrable_expect _
    (fun x => positiveRankLayer_integrable M (coordinateValues value x) (fun e => hv e (x e)))

theorem coloop_activity_integrable (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (M : Matroid E) (hground : ∀ e, e ∈ M.E) :
    Integrable (positiveActivityExpectation laws value (fun _ => activeColoopCount M)) := by
  rw [funext (coloop_activity_expectation laws value M hground)]
  exact integrable_finset_sum univ (fun e _ => (FiniteLaw.product laws).integrable_expect _
    (fun x => coloopLayer_integrable M (coordinateValues value x) (fun e => hv e (x e)) e))

theorem unstable_activity_integrable (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (M : Matroid E) (hground : ∀ e, e ∈ M.E) :
    Integrable (positiveActivityExpectation laws value (fun p => activeUnstableCount M p)) := by
  have hD := coloop_activity_integrable laws value hv M hground
  rw [funext (coloop_activity_expectation laws value M hground)] at hD
  rw [funext (unstable_activity_expectation laws value M hground)]
  exact hD.sub (stableLayerExpectation_integrable (FiniteLaw.product laws) M
    (coordinateValues value) (fun x e => hv e (x e)))

theorem closure_activity_integrable (laws : ∀ e, FiniteLaw (V e)) (value : ∀ e, V e → ℝ)
    (hv : ∀ e x, 0 ≤ value e x) (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (e : E) (he : M.Indep ({e} : Set E)) :
    Integrable (positiveActivityExpectation laws value (fun _ => activeOtherClosure M e)) := by
  rw [funext (closure_activity_expectation laws value M hground e)]
  exact (FiniteLaw.product laws).integrable_expect _
    (fun x => othersClosureLayer_integrable M (coordinateValues value x) (fun e => hv e (x e)) e he)

end MatroidProphetSecretary
