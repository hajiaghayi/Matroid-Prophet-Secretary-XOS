import MatroidProphetSecretary.MaskedSelection
import MatroidProphetSecretary.ActiveGreedyRank
import MatroidProphetSecretary.Overlap

/-! Actual forward and reverse selection layers and their integrability. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset MeasureTheory
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [LinearOrder E]

def orderedSelectionLayer (M : Matroid E) (v : E → ℝ) (reverse : Bool) (e : E) (z : ℝ) : ℝ :=
  if 0 < z ∧ z < v e ∧
    nonspanEvent M e (orderedBefore reverse v e) (fun f => decide (z < v f)) then 1 else 0

theorem orderedSelectionLayer_bounds (M : Matroid E) (v : E → ℝ) (reverse : Bool) (e : E) (z : ℝ) :
    0 ≤ orderedSelectionLayer M v reverse e z ∧ orderedSelectionLayer M v reverse e z ≤ 1 := by
  unfold orderedSelectionLayer
  split_ifs <;> norm_num

theorem orderedSelectionLayer_eq_coloop (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : E → ℝ) (reverse : Bool) (e : E) (z : ℝ) :
    orderedSelectionLayer M v reverse e z =
      coloopLayer (M ↾ {f | f = e ∨ orderedBefore reverse v e f}) v e z := by
  let T := {f | f = e ∨ orderedBefore reverse v e f}
  have hS : valueLayer (M ↾ T) v z \ {e} ⊆ T := fun f hf => hf.1.1
  have hset : valueLayer (M ↾ T) v z \ {e} =
      activeBlock M e (orderedBefore reverse v e) (fun f => decide (z < v f)) := by
    ext f
    simp only [valueLayer, Matroid.restrict_ground_eq, T, Set.mem_diff, Set.mem_setOf_eq,
      Set.mem_singleton_iff, activeBlock, decide_eq_true_eq, hground f, true_and]
    tauto
  change _ = coloopLayer (M ↾ T) v e z
  rw [coloopLayer, Matroid.restrict_closure_eq _ hS (fun f _ => hground f), hset]
  simp [orderedSelectionLayer, valueLayer, T, nonspanEvent]

theorem orderedSelectionLayer_integrable (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : E → ℝ) (hv : ∀ e, 0 ≤ v e) (reverse : Bool) (e : E) :
    Integrable (orderedSelectionLayer M v reverse e) := by
  rw [funext (orderedSelectionLayer_eq_coloop M hground v reverse e)]
  exact coloopLayer_integrable _ v hv e

theorem forwardSelectionLayer_eq_basisLayer (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : E → ℝ) (e : E) (z : ℝ) :
    orderedSelectionLayer M v false e z = basisLayer v (canonicalBasis M v) e z := by
  by_cases hz : 0 < z
  · by_cases he : z < v e
    · have hset : activeBlock M e (orderedBefore false v e) (fun f => decide (z < v f)) =
          {f | f ∈ M.E ∧ priorityBefore v e f} := by
        ext f
        have hp : priorityBefore v e f → z < v f := by
          rintro (h | ⟨h, _⟩)
          · exact he.trans h
          · exact he.trans_eq h
        have hn : priorityBefore v e f → f ≠ e := by
          intro h hfe
          subst f
          exact priorityBefore_irrefl v e h
        simp only [activeBlock, orderedBefore, Bool.false_eq_true, if_false, Set.mem_setOf_eq,
          decide_eq_true_eq]
        constructor
        · rintro ⟨hf, _, hf', _⟩
          exact ⟨hf, hf'⟩
        · rintro ⟨hf, hf'⟩
          exact ⟨hf, hn hf', hf', hp hf'⟩
      simp only [orderedSelectionLayer, hz, he, true_and, nonspanEvent, hset,
        basisLayer, positiveLayer, and_self, if_true,
        canonicalBasis_mem_iff M v e (hground e)]
    · simp [orderedSelectionLayer, basisLayer, positiveLayer, he]
  · simp [orderedSelectionLayer, basisLayer, positiveLayer, hz]

theorem reverseSelectionLayer_eq_forward (M : Matroid E) (v : E → ℝ) (e : E) (z : ℝ) :
    orderedSelectionLayer M v true e z =
      if 0 < z ∧ z < v e ∧ nonspanEvent M e
        (priorityBefore (fun i => -canonicalPriority v i) e) (fun f => decide (z < v f)) then 1 else 0 := by
  have hp : (priorityBefore (fun i => -canonicalPriority v i) e) = (fun f => priorityBefore v f e) :=
    funext (fun f => propext (reverse_priority_iff v e f))
  have hr : orderedBefore true v e = (fun f => priorityBefore v f e) := rfl
  simp only [orderedSelectionLayer, hr, hp]

theorem orderedSelectionLayer_sum (M : Matroid E) (hground : ∀ e, e ∈ M.E)
    (v : E → ℝ) (reverse : Bool) (z : ℝ) :
    (∑ e, orderedSelectionLayer M v reverse e z) = positiveRankLayer M v z := by
  by_cases hz : 0 < z
  · let b := fun f => decide (z < v f)
    let w := if reverse = true then (fun i => -canonicalPriority v i) else v
    have hp (e : E) : (orderedBefore reverse v e) = priorityBefore w e := by
      cases reverse
      · rfl
      · funext f
        exact propext (reverse_priority_iff v e f).symm
    have hset : bitSet b = valueLayer M v z := by
      ext e
      simp [bitSet, b, valueLayer, hground e]
    have heq (e : E) : orderedSelectionLayer M v reverse e z =
        if e ∈ activeGreedyBasis M w b then 1 else 0 := by
      simp only [activeGreedyBasis_mem_iff M hground w b e,
        orderedSelectionLayer, hz, true_and, hp, b, decide_eq_true_eq]
    simp_rw [heq]
    rw [positiveRankLayer, if_pos hz]
    change _ = realRank M (valueLayer M v z)
    rw [← hset, realRank_eq_ncard (activeGreedyBasis_isBasis M hground w b)]
    simp
  · simp [orderedSelectionLayer, positiveRankLayer, hz]

end MatroidProphetSecretary
