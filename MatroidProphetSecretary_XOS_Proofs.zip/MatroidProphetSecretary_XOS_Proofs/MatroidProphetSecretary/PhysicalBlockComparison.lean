import MatroidProphetSecretary.PhysicalRoundComparison

/-! The one-round physical approximation propagates over successive clock bins. -/

noncomputable section

namespace MatroidProphetSecretary.PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

abbrev BlockState (N : ℕ) (V : Type*) := ℕ × StampedHistory (Fin N) (Fin N → Option V)

def physicalBlockBatch (state : BlockState N V) : FiniteLaw (Fin N → Option (GridMark N L V)) :=
  FiniteLaw.timedBatches cfg.finiteHistoryKernel updateGridHistory N state.1 state.2

def physicalBlockUpdate (state : BlockState N V) (x : Fin N → Option (GridMark N L V)) : BlockState N V :=
  (state.1+N,FiniteLaw.stateAfter updateGridHistory N state.2 x)

def sparseBlockBatch
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1) (state : BlockState N V) :
    FiniteLaw (Fin N → Option (GridMark N L V)) :=
  cfg.sparsePhysicalRound hsmall omega homega homega1 hlower state.1 state.2 hbudget

theorem physical_blocks_approximation
    (hsmall : (1/(L:ℝ))*(1/cfg.q) < 1) (omega : ℝ) (homega : 0 < omega) (homega1 : omega ≤ 1)
    (hlower : omega ≤ (1-(1/(L:ℝ))*(1/cfg.q))^cfg.cut - (L-cfg.cut:ℕ)*((1/(L:ℝ))*(1/cfg.q)))
    (hbudget : (N:ℝ)*((1/(L:ℝ))*((1/cfg.q)/omega)) ≤ 1)
    (rounds : ℕ) (state : BlockState N V) (B : ℝ) (hB : 0 ≤ B)
    (f : (Fin rounds → Fin N → Option (GridMark N L V)) → ℝ) (hf : ∀ x, |f x| ≤ B) :
    |(FiniteLaw.adaptiveBatches cfg.physicalBlockBatch physicalBlockUpdate rounds state).expect f -
      (FiniteLaw.adaptiveBatches (cfg.sparseBlockBatch hsmall omega homega homega1 hlower hbudget)
        physicalBlockUpdate rounds state).expect f| ≤
      rounds*(2*(N:ℝ)^2*((1/(L:ℝ))*((1/cfg.q)/omega))^2)*B := by
  apply FiniteLaw.adaptiveBatches_expect_approximation _ _ physicalBlockUpdate _ B hB
    (fun state => cfg.physical_round_approximation hsmall omega homega homega1 hlower state.1 state.2 hbudget)
    rounds state f hf

theorem physical_blocks_error_full_grid (R B : ℝ) (hL : 0 < L) :
    (L:ℝ)*(2*(N:ℝ)^2*((1/(L:ℝ))*R)^2)*B = 2*(N:ℝ)^2*R^2*B/L := by
  have hL' : (L:ℝ) ≠ 0 := by exact_mod_cast hL.ne'
  field_simp
  <;> ring

end MatroidProphetSecretary.PrivateGridConfig
