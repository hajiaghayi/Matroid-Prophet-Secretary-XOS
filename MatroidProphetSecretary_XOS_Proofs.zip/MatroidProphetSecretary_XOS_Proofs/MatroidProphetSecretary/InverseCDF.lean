import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.MeasureTheory.Constructions.BorelSpace.Basic
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Tactic

/-! Strict inverse-CDF lookup and its shared-uniform downward-grid coupling. -/

noncomputable section

namespace MatroidProphetSecretary

open MeasureTheory
open scoped Classical

def inverseCDF : List ℝ → ℝ → ℕ
  | [], _ => 0
  | b :: bs, u => if u < b then 0 else 1+inverseCDF bs u

theorem inverseCDF_le_length (bs : List ℝ) (u : ℝ) : inverseCDF bs u ≤ bs.length := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp only [inverseCDF,List.length_cons]; split_ifs <;> omega

theorem inverseCDF_monotone (bs : List ℝ) : Monotone (inverseCDF bs) := by
  induction bs with
  | nil => intro x y h; rfl
  | cons b bs ih =>
    intro x y h
    simp only [inverseCDF]
    split_ifs with hx hy hy
    · rfl
    · omega
    · exact False.elim (hx (lt_of_le_of_lt h hy))
    · exact Nat.add_le_add_left (ih h) 1

theorem inverseCDF_discrepancy (bs : List ℝ) (x y : ℝ) (hxy : x ≤ y)
    (hne : inverseCDF bs x ≠ inverseCDF bs y) : ∃ b ∈ bs, x < b ∧ b ≤ y := by
  induction bs with
  | nil => exact False.elim (hne rfl)
  | cons b bs ih =>
    by_cases hx : x < b
    · by_cases hy : y < b
      · exact False.elim (hne (by simp [inverseCDF,hx,hy]))
      · exact ⟨b,by simp,hx,le_of_not_gt hy⟩
    · have hy : ¬ y < b := fun h => hx (lt_of_le_of_lt hxy h)
      have hn : inverseCDF bs x ≠ inverseCDF bs y := by
        intro he
        exact hne (by simp [inverseCDF,hx,hy,he])
      obtain ⟨c,hc,hcx,hcy⟩ := ih hn
      exact ⟨c,by simp [hc],hcx,hcy⟩

theorem inverseCDF_measurable (bs : List ℝ) : Measurable (inverseCDF bs) := by
  induction bs with
  | nil => exact measurable_const
  | cons b bs ih =>
    exact Measurable.ite measurableSet_Iio measurable_const (measurable_const.add ih)

def uniformGridDown (G : ℕ) (u : ℝ) : ℝ := (⌊(G:ℝ)*u⌋₊ : ℝ)/G

theorem uniformGridDown_bounds (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : 0 ≤ u) :
    uniformGridDown G u ≤ u ∧ u < uniformGridDown G u+1/G := by
  have hG' : (0:ℝ) < G := by exact_mod_cast hG
  have hl := Nat.floor_le (mul_nonneg hG'.le hu)
  have hh := Nat.lt_floor_add_one ((G:ℝ)*u)
  constructor
  · exact (div_le_iff₀ hG').mpr (by nlinarith)
  · change u < (⌊(G:ℝ)*u⌋₊ : ℝ)/G+1/G
    rw [← add_div,lt_div_iff₀ hG']
    nlinarith

theorem inverseCDF_grid_le (bs : List ℝ) (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : 0 ≤ u) :
    inverseCDF bs (uniformGridDown G u) ≤ inverseCDF bs u :=
  inverseCDF_monotone bs (uniformGridDown_bounds G hG u hu).1

theorem inverseCDF_grid_discrepancy (bs : List ℝ) (G : ℕ) (hG : 0 < G) (u : ℝ) (hu : 0 ≤ u)
    (hne : inverseCDF bs (uniformGridDown G u) ≠ inverseCDF bs u) :
    ∃ b ∈ bs, u ∈ Set.Ico b (b+1/G) := by
  have hb := uniformGridDown_bounds G hG u hu
  obtain ⟨b,hbmem,hbx,hby⟩ := inverseCDF_discrepancy bs _ u hb.1 hne
  exact ⟨b,hbmem,hby,by linarith⟩

theorem volume_boundary_intervals_le (bs : List ℝ) (d : ℝ) (hd : 0 ≤ d) :
    volume {u : ℝ | ∃ b ∈ bs, u ∈ Set.Ico b (b+d)} ≤ ENNReal.ofReal (bs.length*d) := by
  induction bs with
  | nil => simp
  | cons b bs ih =>
    have he : {u : ℝ | ∃ c ∈ b::bs, u ∈ Set.Ico c (c+d)} =
        Set.Ico b (b+d) ∪ {u : ℝ | ∃ c ∈ bs, u ∈ Set.Ico c (c+d)} := by
      ext u
      simp only [Set.mem_setOf_eq,List.mem_cons,Set.mem_union]
      aesop
    rw [he]
    apply (measure_union_le _ _).trans
    have hv : volume (Set.Ico b (b+d)) = ENNReal.ofReal d := by simp
    rw [hv]
    calc
      _ ≤ ENNReal.ofReal d + ENNReal.ofReal (bs.length*d) := add_le_add_left ih _
      _ = ENNReal.ofReal ((b::bs).length*d) := by
        rw [← ENNReal.ofReal_add hd (mul_nonneg (Nat.cast_nonneg _) hd)]
        congr 1
        simp only [List.length_cons,Nat.cast_add,Nat.cast_one]
        ring

theorem inverseCDF_grid_error (bs : List ℝ) (G : ℕ) (hG : 0 < G) :
    (volume.restrict (Set.Ico (0:ℝ) 1))
      {u | inverseCDF bs (uniformGridDown G u) ≠ inverseCDF bs u} ≤
      ENNReal.ofReal (bs.length/G) := by
  rw [Measure.restrict_apply' measurableSet_Ico]
  have hs : {u : ℝ | inverseCDF bs (uniformGridDown G u) ≠ inverseCDF bs u} ∩ Set.Ico 0 1 ⊆
      {u : ℝ | ∃ b ∈ bs, u ∈ Set.Ico b (b+1/G)} := by
    intro u hu
    exact inverseCDF_grid_discrepancy bs G hG u hu.2.1 hu.1
  apply (measure_mono hs).trans
  simpa only [mul_one_div] using volume_boundary_intervals_le bs (1/G) (by positivity)

end MatroidProphetSecretary
