import MatroidProphetSecretary.UniformArrivalDecomposition
import Mathlib.Data.List.Sort
import Mathlib.Order.Fin.Basic

/-! A fixed label has a uniform insertion position independent of the uniform residual order. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

def insertArrivalOrder {n : ℕ} (e pos : Fin (n+1)) (rest : Equiv.Perm (Fin n)) : Equiv.Perm (Fin (n+1)) :=
  pos.cycleRange.trans (Equiv.Perm.decomposeFin.symm (e,rest))

theorem insertArrivalOrder_at {n : ℕ} (e pos : Fin (n+1)) (rest : Equiv.Perm (Fin n)) :
    insertArrivalOrder e pos rest pos = e := by
  simp [insertArrivalOrder]

theorem insertArrivalOrder_away {n : ℕ} (e pos : Fin (n+1)) (rest : Equiv.Perm (Fin n)) (i : Fin n) :
    insertArrivalOrder e pos rest (pos.succAbove i) = remainingLabel e (rest i) := by
  simp only [insertArrivalOrder,Equiv.trans_apply,Fin.cycleRange_succAbove,
    Equiv.Perm.decomposeFin_symm_apply_succ,remainingLabel]

theorem insertArrivalOrder_injective {n : ℕ} (e : Fin (n+1)) :
    Function.Injective (fun pair : Fin (n+1) × Equiv.Perm (Fin n) => insertArrivalOrder e pair.1 pair.2) := by
  rintro ⟨p,σ⟩ ⟨q,τ⟩ h
  dsimp only at h
  have hpq : p = q := by
    apply (insertArrivalOrder e p σ).injective
    rw [insertArrivalOrder_at,h,insertArrivalOrder_at]
  subst q
  have hστ : σ = τ := by
    apply Equiv.ext
    intro i
    apply remainingLabel_injective e
    rw [← insertArrivalOrder_away e p σ i,h,insertArrivalOrder_away]
  subst τ
  rfl

def insertArrivalEquiv {n : ℕ} (e : Fin (n+1)) :
    (Fin (n+1) × Equiv.Perm (Fin n)) ≃ Equiv.Perm (Fin (n+1)) :=
  Equiv.ofBijective (fun pair => insertArrivalOrder e pair.1 pair.2)
    ((Fintype.bijective_iff_injective_and_card _).mpr
      ⟨insertArrivalOrder_injective e,Fintype.card_congr Equiv.Perm.decomposeFin.symm⟩)

theorem uniform_fixed_label_decomposition {n : ℕ} (e : Fin (n+1)) (f : Equiv.Perm (Fin (n+1)) → ℝ) :
    (FiniteLaw.uniform (Equiv.Perm (Fin (n+1)))).expect f =
      (FiniteLaw.uniform (Fin (n+1))).expect (fun pos =>
        (FiniteLaw.uniform (Equiv.Perm (Fin n))).expect (fun rest => f (insertArrivalOrder e pos rest))) := by
  have h := FiniteLaw.uniform_expect_equiv (insertArrivalEquiv e) f
  rw [FiniteLaw.uniform_pair,FiniteLaw.pair_expect] at h
  exact h.symm

theorem finRange_filter_ne {n : ℕ} (pos : Fin (n+1)) :
    (List.finRange (n+1)).filter (fun i => decide (i ≠ pos)) = (List.finRange n).map pos.succAbove := by
  apply List.Sorted.eq_of_mem_iff (r := (· < ·))
  · exact (List.pairwise_lt_finRange (n+1)).sublist List.filter_sublist
  · exact (List.pairwise_lt_finRange n).map _ (fun i j hij => Fin.strictMono_succAbove pos hij)
  · intro i
    simp only [List.mem_filter,List.mem_finRange,true_and,decide_eq_true_eq,List.mem_map]
    simpa only [List.mem_finRange,true_and] using (Fin.exists_succAbove_eq_iff (x := pos) (y := i)).symm

theorem insertArrivalOrder_filter {n : ℕ} (e pos : Fin (n+1)) (rest : Equiv.Perm (Fin n)) :
    ((List.finRange (n+1)).map (insertArrivalOrder e pos rest)).filter (fun x => decide (x ≠ e)) =
      ((List.finRange n).map rest).map (remainingLabel e) := by
  rw [List.filter_map]
  have hp (i : Fin (n+1)) : (insertArrivalOrder e pos rest i ≠ e) ↔ i ≠ pos := by
    constructor
    · intro h hi
      subst i
      exact h (insertArrivalOrder_at e pos rest)
    · intro hi h
      apply hi
      exact (insertArrivalOrder e pos rest).injective (h.trans (insertArrivalOrder_at e pos rest).symm)
  have hpred : ((fun x => decide (x ≠ e)) ∘ insertArrivalOrder e pos rest) = (fun i => decide (i ≠ pos)) := by
    funext i
    simp only [Function.comp_apply,hp]
  rw [hpred,finRange_filter_ne,List.map_map,List.map_map]
  apply List.map_congr_left
  intro i hi
  exact insertArrivalOrder_away e pos rest i

end MatroidProphetSecretary
