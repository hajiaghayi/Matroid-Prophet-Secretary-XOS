import MatroidProphetSecretary.FiniteLawRounding
import Mathlib.Analysis.SpecificLimits.Basic

/-! A uniform bit budget approximates every kernel of a finite adaptive experiment. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {Ω S : Type*} [Fintype Ω]

def fairBitSample (μ : FiniteLaw Ω) (K : ℕ) : Fin (2^K) → Ω :=
  countSeedSample (roundedCounts μ (2^K) (Classical.choice (nonempty_of_law μ))) (2^K)
    (roundedCounts_total μ (2^K) _)

def fairBitLaw (μ : FiniteLaw Ω) (K : ℕ) : FiniteLaw Ω :=
  (uniform (Fin (2^K))).map (fairBitSample μ K)

theorem fairBitLaw_massDistance (μ : FiniteLaw Ω) (K : ℕ) :
    massDistance μ (fairBitLaw μ K) ≤ 2*Fintype.card Ω/(2^K:ℕ) :=
  roundedLaw_massDistance μ (2^K) (pow_pos (by omega) _) _

theorem exists_fair_bit_budget (N : ℕ) (err : ℝ) (herr : 0 < err) :
    ∃ K : ℕ, 2*N/(2^K:ℕ) < err := by
  obtain ⟨K,hK⟩ := pow_unbounded_of_one_lt (2*(N:ℝ)/err) (by norm_num : (1:ℝ)<2)
  refine ⟨K,?_⟩
  have hpow : (0 : ℝ) < 2^K := pow_pos (by norm_num) _
  have h := (div_lt_iff₀ herr).mp hK
  rw [Nat.cast_pow,Nat.cast_ofNat]
  exact (div_lt_iff₀ hpow).mpr (by nlinarith only [h])

theorem exists_fair_bit_approximation (μ : FiniteLaw Ω) (err : ℝ) (herr : 0 < err) :
    ∃ K : ℕ, massDistance μ (fairBitLaw μ K) < err := by
  obtain ⟨K,hK⟩ := exists_fair_bit_budget (Fintype.card Ω) err herr
  exact ⟨K,(fairBitLaw_massDistance μ K).trans_lt hK⟩

theorem adaptive_fair_bit_approximation (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (n : ℕ) (err B : ℝ) (herr : 0 < err) (hB : 0 ≤ B) :
    ∃ K : ℕ, ∀ s (f : (Fin n → Ω) → ℝ), (∀ x, |f x| ≤ B) →
      |(adaptiveBatches batch update n s).expect f-
        (adaptiveBatches (fun s => fairBitLaw (batch s) K) update n s).expect f| ≤ err*B := by
  have hn : (0 : ℝ) < n+1 := by positivity
  obtain ⟨K,hK⟩ := exists_fair_bit_budget (Fintype.card Ω) (err/(n+1)) (div_pos herr hn)
  refine ⟨K,fun s f hf => ?_⟩
  have h := adaptiveBatches_expect_approximation batch (fun s => fairBitLaw (batch s) K)
    update (err/(n+1)) B hB (fun s => (fairBitLaw_massDistance (batch s) K).trans hK.le) n s f hf
  have hbudget : (n:ℝ)*(err/(n+1)) ≤ err := by
    rw [← mul_div_assoc]
    apply (div_le_iff₀ hn).mpr
    nlinarith only [herr]
  exact h.trans (mul_le_mul_of_nonneg_right hbudget hB)

end MatroidProphetSecretary.FiniteLaw
