import MatroidProphetSecretary.FiniteValueSampler
import MatroidProphetSecretary.MaximumValue

/-! Positivity, scale bounds, and all pointwise guarantees of the finite-value sampler. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

variable {E : Type*} [Fintype E] [LinearOrder E]
  {V : E → Type*} [∀ e, Fintype (V e)]

theorem finiteValueVolume_eq_expected_maximum (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) :
    finiteValueVolume laws value G =
      (FiniteLaw.product laws).expect (fun x => maximumValue (coordinateValues value x)) :=
  nonemptyLayerVolume_eq_expected_maximum laws value G

theorem finiteValueVolume_nonneg (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) : 0 ≤ finiteValueVolume laws value G := by
  rw [finiteValueVolume_eq_expected_maximum]
  exact FiniteLaw.expect_nonneg _ (fun x => maximumValue_nonneg _)

theorem finiteValueVolume_le_expectedOptimum (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) (M : Matroid E)
    (hnonloop : ∀ e, M.Indep ({e} : Set E)) :
    finiteValueVolume laws value G ≤ expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) := by
  rw [finiteValueVolume_eq_expected_maximum]
  exact FiniteLaw.expect_mono _ (fun x => maximumValue_le_optimum M _ hnonloop)

theorem expectedOptimum_le_card_volume (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) (M : Matroid E) :
    expectedOptimum (FiniteLaw.product laws) M (coordinateValues value) ≤
      Fintype.card E * finiteValueVolume laws value G := by
  rw [finiteValueVolume_eq_expected_maximum, ← FiniteLaw.expect_const_mul]
  exact FiniteLaw.expect_mono _ (fun x => optimum_le_card_maximumValue M _)

theorem finiteValueVolume_pos (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) (M : Matroid E)
    (hF : 0 < expectedOptimum (FiniteLaw.product laws) M (coordinateValues value)) :
    0 < finiteValueVolume laws value G := by
  have h := hF.trans_le (expectedOptimum_le_card_volume laws value G M)
  exact (mul_pos_iff.mp h).resolve_right (by rintro ⟨hn, hv⟩; exact (not_lt_of_ge (Nat.cast_nonneg _)) hn) |>.2

theorem finiteValueSampler_ranges (laws : ∀ e, FiniteLaw (V e))
    (value : ∀ e, V e → ℝ) (G : ValueHeightGrid value) (hV : 0 < finiteValueVolume laws value G)
    (M : Matroid E) (hnonloop : ∀ e, M.Indep ({e} : Set E))
    (j : Fin G.last) (x : E → Bool) (hx : (finiteValueSampler laws value G hV).mass (j,x) ≠ 0) :
    let vol := finiteValueVolume laws value G
    let ZF := vol * realRank M (bitSet x)
    let ZD := vol * activeColoopCount M x
    let ZC := vol * activeUnstableCount M (coordinateTail laws value (G.level j.val)) x
    vol ≤ ZF ∧ ZF ≤ Fintype.card E * vol ∧ 0 ≤ ZC ∧ ZC ≤ ZD ∧ ZD ≤ ZF ∧
      ∀ e, 0 ≤ vol * activeOtherClosure M e x ∧ vol * activeOtherClosure M e x ≤ vol := by
  have h := layer_estimator_ranges (heightBinWidth value G) (heightBinLaws laws value G)
    (heightBinWidth_nonneg value G) hV M hnonloop j x hx
  have hp : activityProbability (heightBinLaws laws value G j) = coordinateTail laws value (G.level j.val) :=
    funext (heightBin_activityProbability laws value G j)
  simpa only [hp] using h

end MatroidProphetSecretary
