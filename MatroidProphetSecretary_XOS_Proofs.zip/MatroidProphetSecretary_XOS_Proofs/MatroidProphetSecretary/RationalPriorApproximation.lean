import MatroidProphetSecretary.ProductLawApproximation
import MatroidProphetSecretary.FairBitApproximation
import MatroidProphetSecretary.Problem

/-! Explicit rational probability vectors approximate independent finite laws on the same rational value support. -/

noncomputable section

namespace MatroidProphetSecretary

open Finset
open scoped Classical

def roundedRationalPriors {N k : ℕ} (value : Fin N → Fin k → ℚ) (hv : ∀ e v, 0 ≤ value e v)
    (laws : Fin N → FiniteLaw (Fin k)) (K : ℕ) (default : Fin k) : RationalPriors N k where
  value := value
  value_nonneg := hv
  probability e v := (FiniteLaw.roundedCounts (laws e) (2^K) default v : ℚ)/(2^K:ℕ)
  probability_nonneg e v := by positivity
  probability_sum e := by
    rw [← sum_div,← Nat.cast_sum,FiniteLaw.roundedCounts_total]
    exact div_self (by positivity)

theorem roundedRationalPriors_law {N k : ℕ} (value : Fin N → Fin k → ℚ) (hv : ∀ e v, 0 ≤ value e v)
    (laws : Fin N → FiniteLaw (Fin k)) (K : ℕ) (default : Fin k) (e : Fin N) :
    (roundedRationalPriors value hv laws K default).law e =
      FiniteLaw.roundedLaw (laws e) (2^K) (pow_pos (by omega) _) default := by
  apply FiniteLaw.ext_mass
  funext v
  rw [FiniteLaw.roundedLaw,FiniteLaw.countSampleLaw_mass]
  simp only [RationalPriors.law,roundedRationalPriors,Rat.cast_div,Rat.cast_natCast]

theorem roundedRationalPriors_error {N k : ℕ} (value : Fin N → Fin k → ℚ) (hv : ∀ e v, 0 ≤ value e v)
    (laws : Fin N → FiniteLaw (Fin k)) (K : ℕ) (default : Fin k) (e : Fin N) :
    FiniteLaw.massDistance (laws e) ((roundedRationalPriors value hv laws K default).law e) ≤ 2*k/(2^K:ℕ) := by
  rw [roundedRationalPriors_law]
  simpa only [Fintype.card_fin] using FiniteLaw.roundedLaw_massDistance (laws e) (2^K) (pow_pos (by omega) _) default

theorem exists_rational_prior_approximation {N k : ℕ} (value : Fin N → Fin k → ℚ) (hv : ∀ e v, 0 ≤ value e v)
    (laws : Fin N → FiniteLaw (Fin k)) (default : Fin k) (err : ℝ) (herr : 0 < err) :
    ∃ prior : RationalPriors N k, prior.value = value ∧
      ∀ e, FiniteLaw.massDistance (laws e) (prior.law e) < err := by
  obtain ⟨K,hK⟩ := FiniteLaw.exists_fair_bit_budget k err herr
  exact ⟨roundedRationalPriors value hv laws K default,rfl,
    fun e => (roundedRationalPriors_error value hv laws K default e).trans_lt hK⟩

end MatroidProphetSecretary
