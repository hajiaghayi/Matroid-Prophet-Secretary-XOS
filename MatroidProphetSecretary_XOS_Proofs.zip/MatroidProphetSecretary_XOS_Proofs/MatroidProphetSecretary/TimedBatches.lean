import MatroidProphetSecretary.AdaptivePathMass

/-! Finite sequential rounds with an explicit slot index. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω S : Type*} [Fintype Ω]

def timedBatches (kernel : ℕ → S → FiniteLaw Ω) (update : S → Ω → S) :
    (n offset : ℕ) → S → FiniteLaw (Fin n → Ω)
  | 0, _, _ => pointMass Fin.elim0
  | n+1, offset, s => (kernel offset s).bind (fun x =>
      (timedBatches kernel update n (offset+1) (update s x)).map (fun y => Fin.cons x y))

theorem timedBatches_mass_cons (kernel : ℕ → S → FiniteLaw Ω) (update : S → Ω → S)
    (n offset : ℕ) (s : S) (x : Ω) (tail : Fin n → Ω) :
    (timedBatches kernel update (n+1) offset s).mass (Fin.cons x tail) =
      (kernel offset s).mass x*(timedBatches kernel update n (offset+1) (update s x)).mass tail := by
  simp [timedBatches,bind,map,Fin.cons_inj,ite_and]

theorem timedBatches_mass_succ (kernel : ℕ → S → FiniteLaw Ω) (update : S → Ω → S)
    (n offset : ℕ) (s : S) (x : Fin (n+1) → Ω) :
    (timedBatches kernel update (n+1) offset s).mass x =
      (kernel offset s).mass (x 0)*(timedBatches kernel update n (offset+1) (update s (x 0))).mass (fun i => x i.succ) := by
  have h := timedBatches_mass_cons kernel update n offset s (x 0) (Fin.tail x)
  rwa [Fin.cons_self_tail] at h

variable {W : Type*} [Fintype W]

def oneMarkTrace {n : ℕ} (i : Fin n) (w : W) : Fin n → Option W := fun j => if j = i then some w else none

theorem oneMarkTrace_zero (n : ℕ) (w : W) :
    oneMarkTrace (0 : Fin (n+1)) w = Fin.cons (some w) (fun _ => none) := by
  funext j
  refine Fin.cases ?_ (fun j => ?_) j <;> simp [oneMarkTrace]

theorem oneMarkTrace_succ {n : ℕ} (i : Fin n) (w : W) :
    oneMarkTrace i.succ w = Fin.cons none (oneMarkTrace i w) := by
  funext j
  refine Fin.cases ?_ (fun j => ?_) j <;> simp [oneMarkTrace,Ne.symm (Fin.succ_ne_zero i)]

theorem timed_none_mass_lower (kernel : ℕ → S → FiniteLaw (Option W)) (update : S → Option W → S)
    (hnone : ∀ s, update s none = s) (h : ℝ) (h0 : 0 ≤ h)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) :
    1-(n:ℝ)*h ≤ (timedBatches kernel update n offset s).mass (fun _ => none) := by
  induction n generalizing offset s with
  | zero =>
    have he : (fun _ : Fin 0 => (none : Option W)) = Fin.elim0 := funext (fun i => Fin.elim0 i)
    simp [timedBatches,pointMass,he]
  | succ n ih =>
    rw [timedBatches_mass_succ,hnone]
    have hn : (n:ℝ)*h ≤ 1 := by push_cast at hbudget; nlinarith only [hbudget,h0]
    have ht := ih (offset+1) s hn
    have hk : 1-h ≤ (kernel offset s).mass none := by linarith [hsmall offset s]
    have hmul := mul_le_mul hk ht (by linarith : 0 ≤ 1-(n:ℝ)*h) ((kernel offset s).nonneg none)
    have hextra : 0 ≤ (n:ℝ)*h*h := mul_nonneg (mul_nonneg (Nat.cast_nonneg _) h0) h0
    push_cast
    nlinarith only [hmul,hextra]

theorem timed_one_mark_mass_lower (kernel : ℕ → S → FiniteLaw (Option W)) (update : S → Option W → S)
    (hnone : ∀ s, update s none = s) (h : ℝ) (h0 : 0 ≤ h)
    (hsmall : ∀ i s, 1-(kernel i s).mass none ≤ h)
    (n offset : ℕ) (s : S) (hbudget : (n:ℝ)*h ≤ 1) (i : Fin n) (w : W) :
    (1-(n:ℝ)*h)*(kernel (offset+i.val) s).mass (some w) ≤
      (timedBatches kernel update n offset s).mass (oneMarkTrace i w) := by
  induction n generalizing offset s with
  | zero => exact Fin.elim0 i
  | succ n ih =>
    have hn : (n:ℝ)*h ≤ 1 := by push_cast at hbudget; nlinarith only [hbudget,h0]
    refine Fin.cases ?_ (fun j => ?_) i
    · rw [oneMarkTrace_zero,timedBatches_mass_cons]
      simp only [Fin.val_zero,Nat.add_zero]
      have ht := timed_none_mass_lower kernel update hnone h h0 hsmall n (offset+1) (update s (some w)) hn
      have hm := mul_le_mul_of_nonneg_left ht ((kernel offset s).nonneg (some w))
      have hp := mul_nonneg h0 ((kernel offset s).nonneg (some w))
      push_cast
      nlinarith only [hm,hp]
    · rw [oneMarkTrace_succ,timedBatches_mass_cons,hnone]
      have ht := ih (offset+1) s hn j
      have he : offset+1+j.val = offset+j.succ.val := by simp; omega
      rw [he] at ht
      have hk : 1-h ≤ (kernel offset s).mass none := by linarith [hsmall offset s]
      have hbase : 0 ≤ (1-(n:ℝ)*h)*(kernel (offset+j.succ.val) s).mass (some w) :=
        mul_nonneg (by linarith) ((kernel _ s).nonneg _)
      have hm := mul_le_mul hk ht hbase ((kernel offset s).nonneg none)
      have hextra := mul_nonneg (mul_nonneg (mul_nonneg (Nat.cast_nonneg n) h0) h0)
        ((kernel (offset+j.succ.val) s).nonneg (some w))
      push_cast
      nlinarith only [hm,hextra]

end MatroidProphetSecretary.FiniteLaw
