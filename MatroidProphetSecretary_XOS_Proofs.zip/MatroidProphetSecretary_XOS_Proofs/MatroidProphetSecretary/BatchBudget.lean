import Mathlib.Analysis.SpecialFunctions.Log.Base
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

/-! The paper's two ceilings give the required finite-batch failure budget. -/

noncomputable section

namespace MatroidProphetSecretary

def confidenceArgument (N K : ℕ) (ρ : ℝ) : ℝ := 2 * N * K * ((N:ℝ)+3) / ρ

def confidenceHeight (N K : ℕ) (ρ : ℝ) : ℕ := ⌈Real.logb 2 (confidenceArgument N K ρ)⌉₊

def commonBatchSize (N K : ℕ) (ε ρ : ℝ) : ℕ := ⌈2 * N * (confidenceHeight N K ρ : ℝ) / ε^2⌉₊

theorem confidenceArgument_gt_one (N K : ℕ) (hN : 0 < N) (hK : 0 < K)
    (ρ : ℝ) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1) : 1 < confidenceArgument N K ρ := by
  have hn : (1:ℝ) ≤ N := by exact_mod_cast hN
  have hk : (1:ℝ) ≤ K := by exact_mod_cast hK
  have hnk : (1:ℝ) ≤ (N:ℝ)*K := by nlinarith [mul_nonneg (sub_nonneg.mpr hn) (sub_nonneg.mpr hk)]
  unfold confidenceArgument
  apply (lt_div_iff₀ hρ0).mpr
  have hmul := mul_le_mul_of_nonneg_right hnk (show 0 ≤ (N:ℝ)+3 by positivity)
  nlinarith

theorem log_le_logb_two (A : ℝ) (hA : 1 ≤ A) : Real.log A ≤ Real.logb 2 A := by
  have hl : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hu : Real.log 2 ≤ 1 := by
    have h := Real.log_le_sub_one_of_pos (by norm_num : (0:ℝ)<2)
    linarith
  rw [Real.logb, le_div_iff₀ hl]
  exact mul_le_of_le_one_right (Real.log_nonneg hA) hu

theorem confidenceHeight_log_bound (N K : ℕ) (ρ : ℝ) (hA : 1 ≤ confidenceArgument N K ρ) :
    Real.log (confidenceArgument N K ρ) ≤ (confidenceHeight N K ρ : ℝ) :=
  (log_le_logb_two _ hA).trans (Nat.le_ceil _)

theorem commonBatchSize_pos (N K : ℕ) (hN : 0 < N) (ε ρ : ℝ) (hε : 0 < ε)
    (hA : 1 < confidenceArgument N K ρ) : 0 < commonBatchSize N K ε ρ := by
  have hH : 0 < confidenceHeight N K ρ := Nat.ceil_pos.mpr
    (div_pos (Real.log_pos hA) (Real.log_pos (by norm_num : (1:ℝ)<2)))
  apply Nat.ceil_pos.mpr
  exact div_pos (mul_pos (mul_pos (by norm_num) (Nat.cast_pos.mpr hN)) (Nat.cast_pos.mpr hH))
    (sq_pos_of_pos hε)

theorem commonBatchSize_exponent (N K : ℕ) (hN : 0 < N) (ε ρ : ℝ) (hε : 0 < ε)
    (hA : 1 ≤ confidenceArgument N K ρ) :
    Real.log (confidenceArgument N K ρ) ≤ (commonBatchSize N K ε ρ : ℝ)*ε^2/N := by
  have hn : 0 < (N:ℝ) := Nat.cast_pos.mpr hN
  have hm : 2*(N:ℝ)*(confidenceHeight N K ρ : ℝ) ≤ (commonBatchSize N K ε ρ : ℝ)*ε^2 :=
    (div_le_iff₀ (sq_pos_of_pos hε)).mp (Nat.le_ceil _)
  have hH := confidenceHeight_log_bound N K ρ hA
  have hh0 : 0 ≤ (confidenceHeight N K ρ : ℝ) := Nat.cast_nonneg _
  apply (le_div_iff₀ hn).mpr
  have hmul := mul_le_mul_of_nonneg_right hH hn.le
  nlinarith

theorem commonBatchSize_failure_budget (N K : ℕ) (hN : 0 < N) (hK : 0 < K)
    (ε ρ : ℝ) (hε : 0 < ε) (hρ0 : 0 < ρ) (hρ1 : ρ ≤ 1) :
    2*((N:ℝ)+3)*Real.exp (-(commonBatchSize N K ε ρ : ℝ)*ε^2/N) ≤ ρ/((N:ℝ)*K) := by
  have hA := confidenceArgument_gt_one N K hN hK ρ hρ0 hρ1
  have hexp := commonBatchSize_exponent N K hN ε ρ hε hA.le
  have hn : (N:ℝ) ≠ 0 := (Nat.cast_pos.mpr hN).ne'
  have hk : (K:ℝ) ≠ 0 := (Nat.cast_pos.mpr hK).ne'
  have hn3 : (N:ℝ)+3 ≠ 0 := by positivity
  calc
    _ ≤ 2*((N:ℝ)+3)*Real.exp (-Real.log (confidenceArgument N K ρ)) := by
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply Real.exp_le_exp.mpr
      convert neg_le_neg hexp using 1 <;> ring
    _ = ρ/((N:ℝ)*K) := by
      rw [Real.exp_neg, Real.exp_log (lt_trans zero_lt_one hA)]
      unfold confidenceArgument
      field_simp
      <;> ring

end MatroidProphetSecretary
