import MatroidProphetSecretary.WeightLayers
import Mathlib.Data.Matroid.Minor.Contract

/-! Real-valued finite rank and the single-element contraction marginal. -/

noncomputable section

namespace MatroidProphetSecretary

open Set
open scoped Classical Matroid

variable {E : Type*} [Fintype E] [DecidableEq E]

def realRank (M : Matroid E) (S : Set E) : ℝ := (M.eRk S).toNat

theorem realRank_eq_ncard {M : Matroid E} {I S : Set E} (hI : M.IsBasis I S) :
    realRank M S = I.ncard := by
  rw [realRank, hI.eRk_eq_encard]
  rfl

theorem realRank_closure (M : Matroid E) (S : Set E) :
    realRank M (M.closure S) = realRank M S := by
  rw [realRank, M.eRk_closure_eq]
  rfl

theorem realRank_insert (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (e : E) (he : e ∈ M.E) :
    realRank M (insert e S) = realRank M S + if e ∈ M.closure S then 0 else 1 := by
  classical
  by_cases hc : e ∈ M.closure S
  · rw [if_pos hc, add_zero, ← realRank_closure M (insert e S),
      M.closure_insert_eq_of_mem_closure hc, realRank_closure]
  · obtain ⟨I, hI⟩ := M.exists_isBasis S hS
    have heIcl : e ∉ M.closure I := by rwa [hI.closure_eq_closure]
    have heI : e ∉ I := fun h => heIcl (M.mem_closure_of_mem h hI.indep.subset_ground)
    have hins := hI.insert_isBasis_insert_of_not_mem_closure heIcl he
    rw [if_neg hc, realRank_eq_ncard hins, realRank_eq_ncard hI,
      Set.ncard_insert_of_not_mem heI, Nat.cast_add, Nat.cast_one]

theorem realRank_contract_singleton_add_one (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (e : E) (he : M.Indep ({e} : Set E)) :
    realRank (M ／ {e}) (S \ {e}) + 1 = realRank M (insert e S) := by
  obtain ⟨I, hI, heI⟩ := he.subset_isBasis_of_subset
    (show ({e} : Set E) ⊆ insert e S from singleton_subset_iff.mpr (mem_insert e S))
    (insert_subset (he.subset_ground (mem_singleton e)) hS)
  have hc := hI.contract_isBasis_diff_diff_of_subset heI
  have hid : insert e S \ {e} = S \ {e} := by simp
  rw [hid] at hc
  rw [realRank_eq_ncard hc, realRank_eq_ncard hI]
  have heI' : e ∈ I := heI (mem_singleton e)
  exact_mod_cast Set.ncard_diff_singleton_add_one heI'

theorem realRank_contraction_marginal (M : Matroid E) (S : Set E) (hS : S ⊆ M.E)
    (e : E) (he : M.Indep ({e} : Set E)) :
    realRank M S - realRank (M ／ {e}) (S \ {e}) =
      if e ∈ M.closure S then 1 else 0 := by
  have h := realRank_contract_singleton_add_one M S hS e he
  rw [realRank_insert M S hS e (he.subset_ground (mem_singleton e))] at h
  split_ifs at h ⊢ <;> linarith

theorem contractionValue_eq_contract_optimum (M : Matroid E) (v : E → ℝ)
    (e : E) (he : M.Indep ({e} : Set E)) :
    contractionValue M v e he = optimum (M ／ {e}) v := by
  have hiff : ∀ I : Finset E,
      (e ∉ I ∧ M.Indep ((insert e I : Finset E) : Set E)) ↔ (M ／ {e}).Indep (I : Set E) := by
    intro I
    simpa only [Finset.coe_insert] using (he.isNonloop.contractElem_indep_iff (I := (I : Set E))).symm
  apply le_antisymm
  · apply optimumOver_le
    intro I hI
    exact weight_le_optimumOver _ _ v ((hiff I).mp hI)
  · apply optimumOver_le
    intro I hI
    exact weight_le_optimumOver _ _ v ((hiff I).mpr hI)

theorem valueLayer_contract_singleton (M : Matroid E) (v : E → ℝ) (z : ℝ) (e : E) :
    valueLayer (M ／ {e}) v z = valueLayer M v z \ {e} := by
  ext x
  simp only [valueLayer, mem_setOf_eq, Matroid.contract_ground, mem_diff, mem_singleton_iff]
  tauto

end MatroidProphetSecretary
