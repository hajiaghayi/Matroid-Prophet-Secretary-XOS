import MatroidProphetSecretary.FairBitApproximation
import Mathlib.Algebra.BigOperators.Fin

/-! Executing adaptive finite kernels from one bounded fair-bit tape. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset

variable {U Ω S : Type*} [Fintype U] [Fintype Ω]

theorem iid_expect_succ (μ : FiniteLaw U) (n : ℕ) (f : (Fin (n+1) → U) → ℝ) :
    (product (fun _ : Fin (n+1) => μ)).expect f =
      μ.expect (fun u => (product (fun _ : Fin n => μ)).expect (fun x => f (Fin.cons u x))) := by
  unfold expect
  rw [← (Fin.consEquiv (fun _ : Fin (n+1) => U)).sum_comp
    (fun x => (product (fun _ : Fin (n+1) => μ)).mass x*f x)]
  simp only [Fintype.sum_prod_type,Fin.consEquiv,Equiv.coe_fn_mk,product,
    Fin.prod_univ_succ,Fin.cons_zero,Fin.cons_succ,mul_sum,mul_assoc]

def sampleTrajectory (sample : S → U → Ω) (update : S → Ω → S) :
    (n : ℕ) → S → (Fin n → U) → (Fin n → Ω)
  | 0, _, _ => Fin.elim0
  | n+1, s, tape => Fin.cons (sample s (tape 0))
      (sampleTrajectory sample update n (update s (sample s (tape 0))) (fun i => tape i.succ))

theorem sampled_trajectory_expect (μ : FiniteLaw U) (sample : S → U → Ω) (update : S → Ω → S)
    (n : ℕ) (s : S) (f : (Fin n → Ω) → ℝ) :
    (product (fun _ : Fin n => μ)).expect (fun tape => f (sampleTrajectory sample update n s tape)) =
      (adaptiveBatches (fun s => μ.map (sample s)) update n s).expect f := by
  induction n generalizing s with
  | zero => simp [sampleTrajectory,adaptiveBatches,pointMass_expect]
  | succ n ih =>
    rw [iid_expect_succ]
    simp only [sampleTrajectory,Fin.cons_zero,Fin.cons_succ,adaptiveBatches,bind_expect,map_expect]
    congr 1
    funext u
    exact ih (update s (sample s u)) (fun x => f (Fin.cons (sample s u) x))

theorem product_uniform_eq [Nonempty U] (n : ℕ) :
    product (fun _ : Fin n => uniform U) = uniform (Fin n → U) := by
  apply ext_mass
  funext x
  simp [product,uniform,Fintype.card_fun,one_div_pow]

theorem uniform_expect_equiv {X Y : Type*} [Fintype X] [Fintype Y] [Nonempty X] [Nonempty Y]
    (e : X ≃ Y) (f : Y → ℝ) :
    (uniform X).expect (fun x => f (e x)) = (uniform Y).expect f := by
  simp only [expect,uniform,Fintype.card_congr e]
  exact e.sum_comp (fun y => (1/(Fintype.card Y:ℝ))*f y)

def bitBlocksEquiv (K n : ℕ) : Fin (2^(K*n)) ≃ (Fin n → Fin (2^K)) :=
  Fintype.equivOfCardEq (by simp [Fintype.card_fun,pow_mul])

def fairBitTrajectory (batch : S → FiniteLaw Ω) (update : S → Ω → S) (K n : ℕ) (s : S)
    (seed : Fin (2^(K*n))) : Fin n → Ω :=
  sampleTrajectory (fun s => fairBitSample (batch s) K) update n s (bitBlocksEquiv K n seed)

theorem fairBitTrajectory_expect (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (K n : ℕ) (s : S) (f : (Fin n → Ω) → ℝ) :
    (uniform (Fin (2^(K*n)))).expect (fun seed => f (fairBitTrajectory batch update K n s seed)) =
      (adaptiveBatches (fun s => fairBitLaw (batch s) K) update n s).expect f := by
  unfold fairBitTrajectory
  rw [uniform_expect_equiv (bitBlocksEquiv K n)
    (fun tape => f (sampleTrajectory (fun s => fairBitSample (batch s) K) update n s tape)),
    ← product_uniform_eq]
  exact sampled_trajectory_expect (uniform (Fin (2^K))) (fun s => fairBitSample (batch s) K) update n s f

theorem finite_fair_bit_execution_approximation (batch : S → FiniteLaw Ω) (update : S → Ω → S)
    (n : ℕ) (err B : ℝ) (herr : 0 < err) (hB : 0 ≤ B) :
    ∃ K : ℕ, ∀ s (f : (Fin n → Ω) → ℝ), (∀ x, |f x| ≤ B) →
      |(adaptiveBatches batch update n s).expect f-
        (uniform (Fin (2^(K*n)))).expect (fun seed => f (fairBitTrajectory batch update K n s seed))| ≤ err*B := by
  obtain ⟨K,hK⟩ := adaptive_fair_bit_approximation batch update n err B herr hB
  refine ⟨K,fun s f hf => ?_⟩
  rw [fairBitTrajectory_expect]
  exact hK s f hf

end MatroidProphetSecretary.FiniteLaw
