import MatroidProphetSecretary.ExchangeMapExtension

/-! The fixed-order exchange-map algorithm and its quadratic independence-query budget. -/

namespace MatroidProphetSecretary

open Finset

variable {E : Type*} [LinearOrder E]

structure ExchangeOutput (E : Type*) where
  map : E → E
  queryBudget : ℕ

def orderedExchangeRun (oracle : Finset E → Bool) (B : Finset E) : ℕ → Finset E → ExchangeOutput E
  | 0, _ => ⟨id, 0⟩
  | k+1, C =>
      if h : (C \ B).Nonempty then
        let e := (C \ B).min' h
        let queries := exchangeScanQueries oracle C B e
        match firstExchangeTarget oracle C B e with
        | none => ⟨id, queries⟩
        | some b =>
            let rest := orderedExchangeRun oracle B k (insert b (C.erase e))
            ⟨fun x => if x = e then b else rest.map x, queries + rest.queryBudget⟩
      else ⟨id, 0⟩

theorem orderedExchangeRun_correct (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (B : Finset E) (hB : M.IsBase (B : Set E)) (fuel : ℕ) :
    ∀ C : Finset E, M.IsBase (C : Set E) → (C \ B).card ≤ fuel →
      ∃ φ : ExchangeMap M C B, φ.map = (orderedExchangeRun oracle B fuel C).map ∧
        (orderedExchangeRun oracle B fuel C).queryBudget ≤ (C \ B).card * ((C \ B).card + 1) := by
  induction fuel with
  | zero =>
    intro C hC hc
    have hsub : C ⊆ B := by
      have hempty : C \ B = ∅ := card_eq_zero.mp (Nat.eq_zero_of_le_zero hc)
      exact sdiff_eq_empty_iff_subset.mp hempty
    have hCB : C = B := Finset.coe_injective (hC.eq_of_subset_isBase hB hsub)
    subst C
    exact ⟨identityExchangeMap M B hB, rfl, by simp [orderedExchangeRun]⟩
  | succ fuel ih =>
    intro C hC hc
    by_cases hdiff : (C \ B).Nonempty
    · let e := (C \ B).min' hdiff
      have he : e ∈ C \ B := min'_mem _ _
      obtain ⟨b, hbopt⟩ := firstExchangeTarget_exists M oracle horacle C B hC hB e he
      obtain ⟨hb, hBe, hC'⟩ := firstExchangeTarget_spec M oracle horacle C B hC hB e b he hbopt
      let C' := insert b (C.erase e)
      have hdist : (C' \ B).card + 1 = (C \ B).card := exchange_distance_step C B e b he (mem_sdiff.mp hb).1
      have hfuel : (C' \ B).card ≤ fuel := by omega
      obtain ⟨ψ, hψmap, hψcost⟩ := ih C' hC' hfuel
      refine ⟨extendExchangeMap M C B e b he hb hBe ψ, ?_, ?_⟩
      · simp only [orderedExchangeRun, dif_pos hdiff]
        change (fun x => if x = e then b else ψ.map x) =
          (match firstExchangeTarget oracle C B e with
            | none => (⟨id, exchangeScanQueries oracle C B e⟩ : ExchangeOutput E)
            | some b => let rest := orderedExchangeRun oracle B fuel (insert b (C.erase e))
              (⟨fun x => if x = e then b else rest.map x,
                exchangeScanQueries oracle C B e + rest.queryBudget⟩ : ExchangeOutput E)).map
        rw [hbopt]
        change (fun x => if x = e then b else ψ.map x) =
          (fun x => if x = e then b else (orderedExchangeRun oracle B fuel C').map x)
        rw [hψmap]
      · have hscan := exchangeScanQueries_le M oracle C B hC hB e
        have hcost : exchangeScanQueries oracle C B e + (orderedExchangeRun oracle B fuel C').queryBudget ≤
            (C \ B).card * ((C \ B).card+1) := by
          nlinarith only [hscan, hψcost, hdist]
        have hbopt' : firstExchangeTarget oracle C B ((C \ B).min' hdiff) = some b := hbopt
        simpa only [orderedExchangeRun, dif_pos hdiff, hbopt'] using hcost
    · have hsub : C ⊆ B := by
        intro x hx
        by_cases hxB : x ∈ B
        · exact hxB
        · exact (hdiff ⟨x, mem_sdiff.mpr ⟨hx, hxB⟩⟩).elim
      have hCB : C = B := Finset.coe_injective (hC.eq_of_subset_isBase hB hsub)
      subst C
      refine ⟨identityExchangeMap M B hB, ?_, ?_⟩ <;> simp [orderedExchangeRun, identityExchangeMap]

def orderedOracleExchange (oracle : Finset E → Bool) (C B : Finset E) : ExchangeOutput E :=
  orderedExchangeRun oracle B (C \ B).card C

theorem orderedOracleExchange_correct (M : Matroid E) (oracle : Finset E → Bool)
    (horacle : ∀ I, oracle I = true ↔ M.Indep (I : Set E))
    (C B : Finset E) (hC : M.IsBase (C : Set E)) (hB : M.IsBase (B : Set E)) :
    ∃ φ : ExchangeMap M C B, φ.map = (orderedOracleExchange oracle C B).map ∧
      (orderedOracleExchange oracle C B).queryBudget ≤ (C \ B).card * ((C \ B).card+1) :=
  orderedExchangeRun_correct M oracle horacle B hB _ C hC le_rfl

end MatroidProphetSecretary
