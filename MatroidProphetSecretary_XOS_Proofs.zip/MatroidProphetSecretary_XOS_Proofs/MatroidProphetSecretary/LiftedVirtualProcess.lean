import MatroidProphetSecretary.VirtualLateReward

/-! Exchange-process estimates remain valid when the state also stores accepted records and clocks. -/

noncomputable section

namespace MatroidProphetSecretary

namespace FiniteLaw

variable {S T Ω : Type*} [Fintype Ω]

theorem adaptiveBatches_projection (project : S → T) (update : S → Ω → S) (other : T → Ω → T)
    (hupdate : ∀ s x, project (update s x) = other (project s) x)
    (batch : T → FiniteLaw Ω) (n : ℕ) (s : S) :
    adaptiveBatches (fun state => batch (project state)) update n s = adaptiveBatches batch other n (project s) := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih =>
    simp only [adaptiveBatches]
    congr 1
    funext x
    rw [ih,hupdate]

theorem stateAfter_projection (project : S → T) (update : S → Ω → S) (other : T → Ω → T)
    (hupdate : ∀ s x, project (update s x) = other (project s) x)
    (n : ℕ) (s : S) (x : Fin n → Ω) :
    project (stateAfter update n s x) = stateAfter other n (project s) x := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih => simp only [stateAfter,ih,hupdate]

theorem trajectoryReward_projection (project : S → T) (update : S → Ω → S) (other : T → Ω → T)
    (hupdate : ∀ s x, project (update s x) = other (project s) x)
    (reward : T → Ω → ℝ) (n : ℕ) (s : S) (x : Fin n → Ω) :
    trajectoryReward update (fun state => reward (project state)) n s x =
      trajectoryReward other reward n (project s) x := by
  induction n generalizing s with
  | zero => rfl
  | succ n ih => simp only [trajectoryReward,ih,hupdate]

end FiniteLaw

variable {E W S : Type*} [Fintype E] [DecidableEq E] [Fintype W]

theorem lifted_virtual_late_reward (μ : FiniteLaw W) (M : Matroid E)
    (base : W → Finset E) (hbase : ∀ y, M.IsBase (base y : Set E))
    (value : W → E → ℝ) (hv : ∀ y e, 0 ≤ value y e)
    (project : S → VirtualState M) (update : S → Option (E × W) → S)
    (hupdate : ∀ s x, project (update s x) = virtualUpdate M base hbase value (project s) x)
    (multiplier : E → ℝ) (hm : ∀ e, 0 ≤ multiplier e)
    (dt lam omega : ℝ) (hdt : 0 ≤ dt) (hlam : 0 ≤ lam) (homega : 0 < omega)
    (hstep : dt*(lam/omega) ≤ 1) (hsmall : dt*(lam/omega)*Fintype.card E ≤ 1)
    (rate : S → E → ℝ) (hrate0 : ∀ s e, 0 ≤ rate s e)
    (hrate1 : ∀ s e, rate s e ≤ lam/omega) (hlower : ∀ s e, lam*multiplier e ≤ rate s e)
    (n : ℕ) (s : S) :
    omega*(1-(1-dt*(lam/omega))^n)*virtualWeightedLiveValue μ M base hbase value multiplier (project s) ≤
      (FiniteLaw.adaptiveBatches
        (fun state => virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
          hdt (div_nonneg hlam homega.le) (hrate0 state) (hrate1 state) hsmall)
        update n s).expect
        (FiniteLaw.trajectoryReward update (fun state => virtualCredit M base hbase value (project state)) n s) := by
  have hR : 0 ≤ lam/omega := div_nonneg hlam homega.le
  let batch := fun state => virtualStepLaw μ M base hbase value (project state) dt (rate state) (lam/omega)
    hdt hR (hrate0 state) (hrate1 state) hsmall
  let potential := fun state => omega*virtualWeightedLiveValue μ M base hbase value multiplier (project state)
  have hpersist (state : S) : (1-dt*(lam/omega))*potential state ≤
      (batch state).expect (fun event => potential (update state event)) := by
    simp only [potential,hupdate,FiniteLaw.expect_const_mul]
    have h := mul_le_mul_of_nonneg_left
      (virtualStep_weighted_persistence μ M base hbase value hv multiplier hm (project state) dt (rate state)
        (lam/omega) hdt hR (hrate0 state) (hrate1 state) hsmall) homega.le
    convert h using 1 <;> ring
  have hcredit (state : S) : (1-(1-dt*(lam/omega)))*potential state ≤
      (batch state).expect (virtualCredit M base hbase value (project state)) := by
    have h := virtualStep_weighted_credit μ M base hbase value hv multiplier lam (project state) dt (rate state)
      (lam/omega) hdt hR (hrate0 state) (hrate1 state) hsmall (hlower state)
    convert h using 1
    dsimp only [potential]
    field_simp
    <;> ring
  have h := FiniteLaw.adaptive_reward_lower batch update
    (fun state => virtualCredit M base hbase value (project state)) potential
    (1-dt*(lam/omega)) (sub_nonneg.mpr hstep) (sub_le_self _ (mul_nonneg hdt hR))
    hpersist hcredit n s
  convert h using 1
  dsimp only [potential]
  ring

end MatroidProphetSecretary
