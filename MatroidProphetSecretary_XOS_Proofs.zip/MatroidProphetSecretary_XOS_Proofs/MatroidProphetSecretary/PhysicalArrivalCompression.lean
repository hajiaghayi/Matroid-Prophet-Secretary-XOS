import MatroidProphetSecretary.GridArrivalOrder
import MatroidProphetSecretary.AcceptedTrace

/-! The grid algorithm executes exactly the same accepted-record updates as the sorted arrival sequence. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

theorem privateStepRun_fold {E T S : Type*} (label : ℕ → E) (step : ℕ → S → T → S)
    (initial : S) (tapes : E → T) (n : ℕ) :
    privateStepRun label step initial tapes n =
      (List.range n).foldl (fun state j => step j state (tapes (label j))) initial := by
  induction n with
  | zero => rfl
  | succ n ih => rw [privateStepRun,List.range_succ,List.foldl_append]; simpa only [List.foldl_cons,List.foldl_nil] using congrArg (fun s => step n s (tapes (label n))) ih

theorem privateStepRun_filter {E T S : Type*} (label : ℕ → E) (step : ℕ → S → T → S)
    (initial : S) (tapes : E → T) (P : ℕ → Prop)
    (hskip : ∀ n, ¬ P n → ∀ state, step n state (tapes (label n)) = state) (n : ℕ) :
    privateStepRun label step initial tapes n =
      ((List.range n).filter (fun j => decide (P j))).foldl (fun state j => step j state (tapes (label j))) initial := by
  rw [privateStepRun_fold,List.foldl_filter]
  have hf : (fun state j => step j state (tapes (label j))) =
      (fun state j => if decide (P j) then step j state (tapes (label j)) else state) := by
    funext state j
    by_cases hj : P j <;> simp [hj,hskip]
  rw [← hf]

namespace PrivateGridConfig

set_option synthInstance.maxSize 1024
set_option maxRecDepth 2048

variable {N L : ℕ} {V : Type*} [Fintype V] (cfg : PrivateGridConfig N L V)

def arrivalUpdate (clock : Fin L) (e : Fin N)
    (history : StampedHistory (Fin N) (Fin N → Option V)) (tape : GridPrivateTape N L V) :
    StampedHistory (Fin N) (Fin N → Option V) :=
  updateGridHistory history ((cfg.decision (gridSlot clock e) history tape).map (fun y => (e,(clock,y))))

theorem run_eq_arrival_fold (schedule : ClockSchedule N L) (order : Equiv.Perm (Fin N))
    (tapes : Fin N → GridPrivateTape N L V) :
    cfg.run (fun e => (decodeClocks (schedule,order.symm) e,tapes e)) (L*N) =
      (List.finRange N).foldl
        (fun history i => cfg.arrivalUpdate (schedule.val.orderEmbOfFin schedule.property i) (order i) history (tapes (order i))) [] := by
  unfold run stampedRun
  rw [privateStepRun_filter (gridLabel N cfg.labels_pos)
    (markedStep (gridLabel N cfg.labels_pos) (gridClock N L cfg.clocks_pos) (stampDecision cfg.decision)) []
    (fun e => (decodeClocks (schedule,order.symm) e,tapes e))
    (fun n => decodeClocks (schedule,order.symm) (gridLabel N cfg.labels_pos n) = gridClock N L cfg.clocks_pos n)
    (by intro n hn history; simp [markedStep,hn]) (L*N)]
  have hlist : (List.range (L*N)).filter (fun j => @decide
      (decodeClocks (schedule,order.symm) (gridLabel N cfg.labels_pos j) = gridClock N L cfg.clocks_pos j)
      (Classical.propDecidable _)) = List.ofFn (scheduledSlot schedule order) := by
    convert scheduledSlot_list cfg.labels_pos cfg.clocks_pos schedule order using 1
    congr 1
    funext j
    exact congrArg (@decide
      (decodeClocks (schedule,order.symm) (gridLabel N cfg.labels_pos j) = gridClock N L cfg.clocks_pos j))
      (Subsingleton.elim _ _)
  rw [hlist,List.ofFn_eq_map,List.foldl_map]
  apply congrArg (fun f => (List.finRange N).foldl f [])
  funext history i
  unfold scheduledSlot
  simp only [gridLabel_slot N L cfg.labels_pos,gridClock_slot N L cfg.clocks_pos,
    decoded_schedule_clock,markedStep,if_true,stampDecision]
  unfold arrivalUpdate updateGridHistory
  cases cfg.decision (gridSlot (schedule.val.orderEmbOfFin schedule.property i) (order i)) history (tapes (order i)) <;>
    rfl

end PrivateGridConfig
end MatroidProphetSecretary
