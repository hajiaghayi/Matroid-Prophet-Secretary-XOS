import MatroidProphetSecretary.BlockIndependence
import MatroidProphetSecretary.CanonicalBasis
import MatroidProphetSecretary.ProductAssociation

/-! The forward/reverse nonspanning comparison at a fixed value layer. -/

noncomputable section

namespace MatroidProphetSecretary

open scoped Classical

variable {E : Type*} [Fintype E] [DecidableEq E]

def activeBlock (M : Matroid E) (e : E) (p : E → Prop) (x : E → Bool) : Set E :=
  {f | f ∈ M.E ∧ f ≠ e ∧ p f ∧ x f = true}

def nonspanEvent (M : Matroid E) (e : E) (p : E → Prop) (x : E → Bool) : Prop :=
  e ∉ M.closure (activeBlock M e p x)

def nonspanProbability (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E) (p : E → Prop) : ℝ :=
  (FiniteLaw.product laws).prob (nonspanEvent M e p)

theorem nonspanEvent_depends (M : Matroid E) (e : E) (p : E → Prop) (x y : E → Bool)
    (hxy : ∀ f, p f → x f = y f) : nonspanEvent M e p x ↔ nonspanEvent M e p y := by
  have hid : activeBlock M e p x = activeBlock M e p y := by
    ext f
    by_cases hp : p f
    · simp [activeBlock, hp, hxy f hp]
    · simp [activeBlock, hp]
  unfold nonspanEvent
  rw [hid]

theorem nonspanProbability_bounds (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E) (p : E → Prop) :
    0 ≤ nonspanProbability laws M e p ∧ nonspanProbability laws M e p ≤ 1 :=
  ⟨(FiniteLaw.product laws).prob_nonneg _, (FiniteLaw.product laws).prob_le_one _⟩

theorem nonspanProbability_antitone (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E)
    {p q : E → Prop} (hpq : ∀ f, p f → q f) :
    nonspanProbability laws M e q ≤ nonspanProbability laws M e p := by
  apply FiniteLaw.prob_mono
  intro x hx hcl
  apply hx
  apply M.closure_subset_closure _ hcl
  intro f hf
  exact ⟨hf.1, hf.2.1, hpq f hf.2.2.1, hf.2.2.2⟩

theorem nonspanProbability_le_partition_product (laws : E → FiniteLaw Bool) (M : Matroid E)
    (e : E) (p : E → Prop) :
    nonspanProbability laws M e (fun _ => True) ≤
      nonspanProbability laws M e p * nonspanProbability laws M e (fun f => ¬p f) := by
  have hind := FiniteLaw.product_prob_and_of_disjoint laws p
    (nonspanEvent M e p) (nonspanEvent M e (fun f => ¬p f))
    (nonspanEvent_depends M e p) (nonspanEvent_depends M e (fun f => ¬p f))
  unfold nonspanProbability
  rw [← hind]
  apply FiniteLaw.prob_mono
  intro x hx
  constructor
  · intro hcl
    apply hx
    apply M.closure_subset_closure _ hcl
    intro f hf
    exact ⟨hf.1, hf.2.1, trivial, hf.2.2.2⟩
  · intro hcl
    apply hx
    apply M.closure_subset_closure _ hcl
    intro f hf
    exact ⟨hf.1, hf.2.1, trivial, hf.2.2.2⟩

variable [LinearOrder E]

theorem priorityBefore_of_own_up_others_down {v w : E → ℝ} {e f : E}
    (he : v e ≤ w e) (hf : w f ≤ v f) (h : priorityBefore w e f) : priorityBefore v e f := by
  rcases h with h | ⟨h, hef⟩
  · exact Or.inl ((he.trans_lt h).trans_le hf)
  · have hle : v e ≤ v f := he.trans (h.le.trans hf)
    rcases lt_or_eq_of_le hle with hlt | heq
    · exact Or.inl hlt
    · exact Or.inr ⟨heq, hef⟩

theorem forward_nonspan_mono (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E)
    {v w : E → ℝ} (he : v e ≤ w e) (hothers : ∀ f, f ≠ e → w f ≤ v f) :
    nonspanProbability laws M e (priorityBefore v e) ≤
      nonspanProbability laws M e (priorityBefore w e) := by
  apply nonspanProbability_antitone
  intro f hf
  have hfe : f ≠ e := by rintro rfl; exact priorityBefore_irrefl _ _ hf
  exact priorityBefore_of_own_up_others_down he (hothers f hfe) hf

theorem reverse_nonspan_antitone (laws : E → FiniteLaw Bool) (M : Matroid E) (e : E)
    {v w : E → ℝ} (he : v e ≤ w e) (hothers : ∀ f, f ≠ e → w f ≤ v f) :
    nonspanProbability laws M e (fun f => priorityBefore w f e) ≤
      nonspanProbability laws M e (fun f => priorityBefore v f e) := by
  apply nonspanProbability_antitone
  intro f hf
  have hfe : f ≠ e := by rintro rfl; exact priorityBefore_irrefl _ _ hf
  exact priorityBefore_of_own_up_others_down (hothers f hfe) he hf

end MatroidProphetSecretary
