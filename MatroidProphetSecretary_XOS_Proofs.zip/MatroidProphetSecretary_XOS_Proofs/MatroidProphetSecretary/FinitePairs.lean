import MatroidProphetSecretary.FinitePushforward

/-! Independent pairs of finite laws and regrouping their coordinate products. -/

noncomputable section

namespace MatroidProphetSecretary.FiniteLaw

open Finset
open scoped Classical

variable {Ω Ψ : Type*} [Fintype Ω] [Fintype Ψ]

def pair (μ : FiniteLaw Ω) (ν : FiniteLaw Ψ) : FiniteLaw (Ω × Ψ) where
  mass x := μ.mass x.1 * ν.mass x.2
  nonneg x := mul_nonneg (μ.nonneg x.1) (ν.nonneg x.2)
  total := by
    rw [Fintype.sum_prod_type]
    simp only [← mul_sum, ν.total, mul_one, μ.total]

theorem pair_expect (μ : FiniteLaw Ω) (ν : FiniteLaw Ψ) (f : Ω × Ψ → ℝ) :
    (μ.pair ν).expect f = μ.expect (fun x => ν.expect (fun y => f (x,y))) := by
  simp only [expect, pair, Fintype.sum_prod_type, mul_sum, mul_assoc]

theorem ext_expect (μ ν : FiniteLaw Ω) (h : ∀ f : Ω → ℝ, μ.expect f = ν.expect f) : μ = ν := by
  apply ext_mass
  funext x
  have hx := h (fun y => if y = x then 1 else 0)
  simpa [expect] using hx

variable {ι : Type*} [Fintype ι] [DecidableEq ι]
    {V W : ι → Type*} [∀ i, Fintype (V i)] [∀ i, Fintype (W i)]

def piPairEquiv : (∀ i, V i × W i) ≃ ((∀ i, V i) × (∀ i, W i)) where
  toFun x := (fun i => (x i).1, fun i => (x i).2)
  invFun x := fun i => (x.1 i, x.2 i)
  left_inv _ := rfl
  right_inv _ := rfl

theorem product_pair_expect (laws : ∀ i, FiniteLaw (V i)) (laws' : ∀ i, FiniteLaw (W i))
    (f : (∀ i, V i × W i) → ℝ) :
    (product (fun i => (laws i).pair (laws' i))).expect f =
      (product laws).expect (fun x => (product laws').expect (fun y => f (fun i => (x i, y i)))) := by
  unfold expect
  rw [← (piPairEquiv (V := V) (W := W)).symm.sum_comp
    (fun x => (product (fun i => (laws i).pair (laws' i))).mass x * f x)]
  simp only [Fintype.sum_prod_type, piPairEquiv, Equiv.coe_fn_symm_mk, product, pair,
    prod_mul_distrib, mul_sum, mul_assoc]

end MatroidProphetSecretary.FiniteLaw
