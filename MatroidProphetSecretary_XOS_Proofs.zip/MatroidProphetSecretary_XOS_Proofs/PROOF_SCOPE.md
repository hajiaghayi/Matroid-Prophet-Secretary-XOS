# Matroid prophet secretary and XOS hardness: Lean formalization

This project proves the mathematical competitiveness assertion of Theorem 1 in *Prophet Secretary for Matroids and XOS Auctions: A Strict Separation at 1 − 1/e*:

**Every finite matroid with independent measurable nonnegative values and integrable offline optimum admits a feasible online policy with competitive ratio `1 − 1 / exp(1) + 10⁻⁷`.**

Computational guarantees are excluded from the requested scope. The proof makes classical existence choices for suitable searches and policy seeds. It establishes existence of an online policy; it does not establish a polynomial implementation of that policy or verify every operational assertion about the paper's particular randomized algorithm.

## Main theorem and model

- [`MatroidProphetSecretary/MainTheorem.lean`](MatroidProphetSecretary/MainTheorem.lean): `matroid_prophet_secretary`, with the numerical competitive ratio written explicitly.
- [`MatroidProphetSecretary/GeneralCompetitiveness.lean`](MatroidProphetSecretary/GeneralCompetitiveness.lean): the general-prior proof and the actual-reward transfer from finite observations.
- [`MatroidProphetSecretary/FiniteCompetitiveness.lean`](MatroidProphetSecretary/FiniteCompetitiveness.lean): finite rational priors, including loops and zero-benchmark instances.
- [`MatroidProphetSecretary/Problem.lean`](MatroidProphetSecretary/Problem.lean): the online policy, execution, feasibility, independent priors, and uniform arrival model.

`OnlinePolicy N 0` receives only the past observations and acceptance decisions, and the current label and value. The zero-length private tape means the existentially selected policy is deterministic. Arrival order remains random: `orderAveragedReward` averages over all permutations uniformly, independently of the value sample. `PolicyFeasible` requires an independent accepted set for every value vector and every arrival permutation.

The general theorem assumes a probability space, measurable independent coordinate values, pointwise nonnegativity, and integrability of the offline optimum. It proves feasibility, measurability and integrability of the order-averaged actual reward, and the competitive inequality. It places no finite-support, rational-probability, bounded-value, or looplessness restriction on the instance.

[`MainTheoremAudit.lean`](MainTheoremAudit.lean) separately checks the main theorem, its transitive axiom dependencies, the numerical parameter certificate, and the strict `10⁻⁷` improvement over `1 − 1 / exp(1)`. All numerical inequalities use exact real and rational arithmetic.

## Proof route

1. Finite matroid optimization, deletion/contraction identities, weighted rank layers, strong overlap, contraction prices, surplus decomposition, and the capped-surplus inequality.
2. The actual reference distributions, their shape and derivative bounds, certified parameter inequalities, common-layer sampling, adaptive concentration, and accurate reference search.
3. Feasible continuation policies. The finite virtual and physical exchange processes are connected through quantitative discretization, clock conditioning, and random tables indexed only by observed values.
4. Recursive composition of actual threshold and continuation policies on deletion/contraction minors. A proved positive-probability accuracy bound supplies a suitable search; finite averaging supplies suitable policy seeds. This proves finite-prior competitiveness without a runtime claim.
5. Approximation of real probabilities by rational probabilities, measurable downward quantization of arbitrary values, convergence of expected optimum, and transfer to the actual accepted values. The strict numerical margin absorbs the approximation error and yields the stated general-prior ratio.

Every dependency used by the main theorem is proved. The general-prior theorem uses this approximation route; separate general-prior versions of every intermediate finite-distribution lemma are not prerequisites.

Additional checked modules cover the paper's independence-oracle coloop recovery, exact-rational bounded categorical primitive and its coupling, bounded Poisson count sampler, clock and prefix rounding, and adaptive finite couplings. These supporting results do not constitute a claim of complete computational implementation.

## XOS hardness (Theorem 2, Section 10)

[`MatroidProphetSecretary/XOSMainTheorem.lean`](MatroidProphetSecretary/XOSMainTheorem.lean) proves the strict information-theoretic upper bound: for every real `ξ > 0`, one finite instance satisfies

`E[ALG] < (1 - 1 / exp(1) + ξ) * E[OPT]`

for **every randomized online allocation policy**, with positive expected optimum. The instance is chosen before the policy. Buyers have identical independent uniform finite label priors; each label determines a normalized, monotone XOS valuation whose public additive coefficients are binary. Allocated bundles are disjoint and irrevocable. The main theorem explicitly averages over an independent uniform arrival permutation and allows the policy to know that entire permutation in advance.

The ten `XOS*.lean` modules prove the public partition count, valuation representation and maximizing witnesses, independence of future labels from adaptive choices, the actual offline optimum lower bound, the actual online welfare upper bound, the limiting constant, and parameter existence. `XOSRandomTape.lean` proves reduction from an arbitrary measurable independent random tape to a distribution over the finite policy space. Thus neither finite random bits nor rational mixing probabilities are assumed. A legal empty-allocation policy and positive expected optimum are proved, so the universal policy bound is not vacuous.

Two explicit presentation differences from the paper simplify the formal proof without changing its conclusion: partition indices are ordered injections of `n` labels into `L` labels, and the union bounds use `n²/L` for repeated labels and `n³/L` for repeated witnesses. The proved finite ratio bound is

`(1 - (1 - 1/n)^n + n³/L) / (1 - n²/L)`.

It tends to `1 - 1/exp(1)` by first increasing `n` and then `L`. The proof uses the paper's direct construction; Section 10.3's separate transposition from prior coverage-welfare results is not required or claimed as formalized. No computational restriction is used in this hardness result.

[`XOSAudit.lean`](XOSAudit.lean) checks every XOS theorem's transitive axiom dependencies. [`verification/xos-summary.json`](verification/xos-summary.json) records its verification and [`verification/xos-axioms.log`](verification/xos-axioms.log) contains the audit output.

The XOS extension adds 10 modules and 56 audited theorems. The 328 existing matroid modules are unchanged by source hash, so their 1,511 prior theorem certificates remain applicable. [`CombinedMainAudit.lean`](CombinedMainAudit.lean) additionally checks both main results together in the rebuilt aggregate library. The combined project has 338 source modules and 1,567 theorem certificates; audit provenance is recorded in [`verification/summary.json`](verification/summary.json).

## Verification

See [README.md](README.md) for portable build instructions and [verification/summary.json](verification/summary.json) for the original proof certificates. The public entry point is [Main.lean](Main.lean).

## Source paper

The supplied PDF has SHA-256:

```text
8dddcc8b51ed7018349ca91c5dd507be4ca8cfa8d2cda8ea100966746e61768f
```

Its extracted text is in [`paper/source.txt`](paper/source.txt). The project formalizes the mathematical matroid competitiveness theorem and the direct XOS auction hardness theorem.
