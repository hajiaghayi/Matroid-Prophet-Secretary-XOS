param([switch]$FetchCache, [switch]$FullAudit)
$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
    if ($FetchCache) {
        & lake exe cache get
        if ($LASTEXITCODE -ne 0) { throw 'Mathlib cache download failed.' }
    }
    & lake build
    if ($LASTEXITCODE -ne 0) { throw 'Lean library build failed.' }
    & lake env lean Main.lean
    if ($LASTEXITCODE -ne 0) { throw 'Main theorem verification failed.' }
    if ($FullAudit) {
        & lake env lean Audit.lean
        if ($LASTEXITCODE -ne 0) { throw 'Full declaration audit failed.' }
    }
} finally { Pop-Location }
