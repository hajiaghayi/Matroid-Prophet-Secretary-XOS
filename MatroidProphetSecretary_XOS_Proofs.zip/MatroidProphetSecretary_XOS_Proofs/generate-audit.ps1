$ErrorActionPreference = 'Stop'
$declarations = [Collections.Generic.List[string]]::new()
$importedSources = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MatroidProphetSecretary.lean') |
    Where-Object { $_ -match '^import MatroidProphetSecretary\.' } |
    ForEach-Object { Get-Item -LiteralPath (Join-Path $PSScriptRoot (($_ -replace '^import ', '' -replace '\.', '\') + '.lean')) }
foreach ($source in $importedSources | Sort-Object Name) {
    $namespaces = [Collections.Generic.List[string]]::new()
    foreach ($line in Get-Content -LiteralPath $source.FullName) {
        $ns = [regex]::Match($line, '^namespace\s+(\S+)')
        if ($ns.Success) { $namespaces.Add($ns.Groups[1].Value); continue }
        $ending = [regex]::Match($line, '^end\s+(\S+)')
        if ($ending.Success -and $namespaces.Count -gt 0 -and $ending.Groups[1].Value -eq $namespaces[$namespaces.Count - 1]) {
            $namespaces.RemoveAt($namespaces.Count - 1)
            continue
        }
        $decl = [regex]::Match($line, '^(?:@\[[^\]]*\]\s*)?(?:theorem|lemma)\s+([^\s({:]+)')
        if ($decl.Success) { $declarations.Add(($namespaces -join '.') + '.' + $decl.Groups[1].Value) }
    }
}
$auditLines = @('import MatroidProphetSecretary', '', '/- Audits the mathematical competitiveness formalization. Computational guarantees are outside the requested scope. -/')
$auditLines += $declarations | ForEach-Object { '#print axioms ' + $_ }
$auditLines += @('', '#check MatroidProphetSecretary.parameter_choice', '#check MatroidProphetSecretary.finite_matroid_prophet_secretary_competitive', '#check MatroidProphetSecretary.matroid_prophet_secretary_competitive', '#check MatroidProphetSecretary.matroid_prophet_secretary', '#check MatroidProphetSecretary.XOS.xos_main_theorem', '#check MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes')
$auditLines | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'Audit.lean') -Encoding utf8
Write-Output "$($declarations.Count) theorem declarations included in Audit.lean."
