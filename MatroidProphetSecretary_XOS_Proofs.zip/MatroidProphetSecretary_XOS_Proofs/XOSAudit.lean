import MatroidProphetSecretary.XOSMainTheorem

/- Full axiom audit of the XOS hardness development. -/
#print axioms MatroidProphetSecretary.XOS.uniform_prob_card
#print axioms MatroidProphetSecretary.XOS.uniform_product
#print axioms MatroidProphetSecretary.XOS.prob_not
#print axioms MatroidProphetSecretary.XOS.mem_part
#print axioms MatroidProphetSecretary.XOS.prob_coordinate_ne
#print axioms MatroidProphetSecretary.XOS.partition_union_card
#print axioms MatroidProphetSecretary.XOS.mem_allowed
#print axioms MatroidProphetSecretary.XOS.allowed_nonempty
#print axioms MatroidProphetSecretary.XOS.clause_le_value
#print axioms MatroidProphetSecretary.XOS.value_le_card
#print axioms MatroidProphetSecretary.XOS.value_empty
#print axioms MatroidProphetSecretary.XOS.value_mono
#print axioms MatroidProphetSecretary.XOS.value_attained
#print axioms MatroidProphetSecretary.XOS.witness_label
#print axioms MatroidProphetSecretary.XOS.witness_value
#print axioms MatroidProphetSecretary.XOS.coefficient_binary
#print axioms MatroidProphetSecretary.XOS.clause_additive
#print axioms MatroidProphetSecretary.XOS.value_is_XOS
#print axioms MatroidProphetSecretary.XOS.product_expect_eval
#print axioms MatroidProphetSecretary.XOS.future_hit_probability
#print axioms MatroidProphetSecretary.XOS.label_collision_bound
#print axioms MatroidProphetSecretary.XOS.empty_rule_legal
#print axioms MatroidProphetSecretary.XOS.welfare_le_prophet
#print axioms MatroidProphetSecretary.XOS.disjoint_sum_card_le
#print axioms MatroidProphetSecretary.XOS.welfare_le_goods
#print axioms MatroidProphetSecretary.XOS.prophet_le_goods
#print axioms MatroidProphetSecretary.XOS.prophet_of_injective
#print axioms MatroidProphetSecretary.XOS.expectedProphet_lower
#print axioms MatroidProphetSecretary.XOS.coverageRatio_nonneg
#print axioms MatroidProphetSecretary.XOS.coverageRatio_tendsto
#print axioms MatroidProphetSecretary.XOS.finiteRatio_tendsto
#print axioms MatroidProphetSecretary.XOS.exists_hard_parameters
#print axioms MatroidProphetSecretary.XOS.chosen_causal
#print axioms MatroidProphetSecretary.XOS.noninjective_iff_ordered_pair
#print axioms MatroidProphetSecretary.XOS.witness_collision_bound
#print axioms MatroidProphetSecretary.XOS.welfare_le_partition_union
#print axioms MatroidProphetSecretary.XOS.welfare_of_distinct_witnesses
#print axioms MatroidProphetSecretary.XOS.expectedReward_upper
#print axioms MatroidProphetSecretary.XOS.randomizedReward_upper
#print axioms MatroidProphetSecretary.XOS.expectedProphet_pos
#print axioms MatroidProphetSecretary.XOS.randomized_ratio_bound
#print axioms MatroidProphetSecretary.XOS.xos_hardness
#print axioms MatroidProphetSecretary.XOS.feasible_reindex
#print axioms MatroidProphetSecretary.XOS.welfare_reindex
#print axioms MatroidProphetSecretary.XOS.prophet_reindex_le
#print axioms MatroidProphetSecretary.XOS.prophet_permutation_invariant
#print axioms MatroidProphetSecretary.XOS.labels_permutation_invariant
#print axioms MatroidProphetSecretary.XOS.secretaryReward_eq
#print axioms MatroidProphetSecretary.XOS.secretaryReward_upper
#print axioms MatroidProphetSecretary.XOS.secretary_ratio_bound
#print axioms MatroidProphetSecretary.XOS.xos_prophet_secretary_hardness
#print axioms MatroidProphetSecretary.XOS.secretaryReward_as_expect
#print axioms MatroidProphetSecretary.XOS.random_tape_reduction
#print axioms MatroidProphetSecretary.XOS.arbitrary_random_tape_ratio_bound
#print axioms MatroidProphetSecretary.XOS.xos_main_theorem
#print axioms MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes

#check MatroidProphetSecretary.XOS.xos_main_theorem
#check MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes
