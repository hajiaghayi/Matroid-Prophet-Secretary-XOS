import MatroidProphetSecretary.MainTheorem

/- Focused verification of the exact competitive ratio and every transitive proof dependency. -/

#check @MatroidProphetSecretary.matroid_prophet_secretary
#print axioms MatroidProphetSecretary.matroid_prophet_secretary
#print axioms MatroidProphetSecretary.matroid_prophet_secretary_competitive
#print axioms MatroidProphetSecretary.finite_matroid_prophet_secretary_competitive
#check MatroidProphetSecretary.parameter_choice
#print axioms MatroidProphetSecretary.parameter_choice

example : (1:ℝ)-1/Real.exp 1+1/10000000 < MatroidProphetSecretary.beta := by
  exact MatroidProphetSecretary.parameter_choice.2.2.2

example : (1:ℝ)-1/Real.exp 1 < (1:ℝ)-1/Real.exp 1+1/10000000 := by
  linarith
