# Matroid prophet secretary and XOS hardness — Lean proof project

Start with **[Main.lean](Main.lean)**. It imports the complete development,
displays both main results, checks the exact strict improvement, and reports
their transitive axiom dependencies.

This directory contains every project-specific Lean source file. No other
local project is needed. Lean and mathlib are external dependencies pinned by
`lean-toolchain`, `lakefile.toml`, and `lake-manifest.json`.

## Build and check

Use a configured Lean/elan installation and run these commands in this directory:

```text
lake exe cache get
lake build
lake env lean Main.lean
```

The pinned versions are Lean **4.19.0** and mathlib **v4.19.0**. The initial
dependency/cache download needs internet access. For the complete declaration
audit, also run:

```text
lake env lean Audit.lean
```

On Windows, the equivalent helper is:

```powershell
./check.ps1 -FetchCache
./check.ps1 -FullAudit
```

## Main results

- [Matroid main theorem](MatroidProphetSecretary/MainTheorem.lean): the exact
  ratio `1 - 1 / exp(1) + 1 / 10000000` for independent measurable nonnegative
  values with integrable offline optimum, using an actual feasible online policy.
- [XOS main theorem](MatroidProphetSecretary/XOSMainTheorem.lean): for every
  `xi > 0`, one finite identical-prior binary-clause XOS instance defeats every
  randomized online algorithm above `1 - 1 / exp(1) + xi`, even when the entire
  arrival permutation is known. Arbitrary independent random tapes are covered.

The verified scope is mathematical competitiveness and direct XOS hardness.
The matroid policy uses classical existence choices. The paper's complete
algorithm implementation and computational guarantees are not claimed.
See [PROOF_SCOPE.md](PROOF_SCOPE.md) and [proof-coverage.json](proof-coverage.json)
for the proof route and precise coverage.

## Contents and verification

- `MatroidProphetSecretary/`: all **338** source modules.
- `MatroidProphetSecretary.lean`: aggregate library import.
- `Main.lean`: convenient public entry point and main-result audit.
- `Audit.lean`: all **1,567** registered theorem axiom checks.
- The focused audit files and `verification/` retain the check outputs and
  source hashes, including the fresh `Main.lean` check.
- `distribution-manifest.json` records every distributed file's SHA-256 hash.

No proof uses `sorry`, a custom axiom, or `native_decide`. The allowed standard
foundations are `propext`, `Classical.choice`, and `Quot.sound`. The modular
distribution is the verified deliverable; no unfinished single-file experiment
or its compiler logs are included.

The source PDF's SHA-256 is
`8dddcc8b51ed7018349ca91c5dd507be4ca8cfa8d2cda8ea100966746e61768f`.
Its extracted text is included in `paper/source.txt`.
