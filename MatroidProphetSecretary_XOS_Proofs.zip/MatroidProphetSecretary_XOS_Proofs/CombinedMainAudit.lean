import MatroidProphetSecretary

/- Integration audit: both main results coexist in the aggregate library. -/
#check MatroidProphetSecretary.matroid_prophet_secretary
#check MatroidProphetSecretary.XOS.xos_main_theorem
#check MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes
#print axioms MatroidProphetSecretary.matroid_prophet_secretary
#print axioms MatroidProphetSecretary.XOS.xos_main_theorem
#print axioms MatroidProphetSecretary.XOS.xos_hardness_arbitrary_random_tapes
